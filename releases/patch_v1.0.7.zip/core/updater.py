"""
Updater Module — GitHub Delta Update System
=============================================
Kiểm tra phiên bản mới từ GitHub, tải patch ZIP,
xác minh SHA256, giải nén đè lên source code.
KHÔNG ghi đè thư mục data/ (settings, profiles, license).

Flow:
1. GET version.json từ GitHub raw URL
2. So sánh version local vs remote
3. Download patch ZIP từ GitHub Releases
4. Xác minh SHA256 hash
5. Giải nén đè source files (core/, ui/, modules/, main.py)
6. Cập nhật version.json local
7. Restart tool
"""

import requests
import json
import os
import sys
import hashlib
import zipfile
import shutil
from PyQt6.QtCore import QThread, pyqtSignal

CURRENT_VERSION = "1.0.6"

# ─── Paths ───
_APP_DIR = None
_UPDATE_CONFIG_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "update_config.json")
_VERSION_FILE = os.path.join(os.path.dirname(__file__), "..", "version.json")

# Directories that CAN be updated (source code only)
UPDATABLE_DIRS = {"core", "ui", "modules", "assets"}
UPDATABLE_FILES = {"main.py", "version.json"}

# Directories that MUST NOT be overwritten
PROTECTED_DIRS = {"data"}
PROTECTED_FILES = {"data/settings.json", "data/license.json", "data/profiles.json",
                   "data/emails.json", "data/gmails.json"}


def _get_app_dir():
    """Get the app root directory."""
    global _APP_DIR
    if _APP_DIR:
        return _APP_DIR
    if getattr(sys, 'frozen', False):
        _APP_DIR = os.path.dirname(os.path.abspath(sys.executable))
    else:
        _APP_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    return _APP_DIR


def get_local_version():
    """Read current version from version.json, fallback to CURRENT_VERSION."""
    try:
        vf = os.path.join(_get_app_dir(), "version.json")
        if os.path.exists(vf):
            with open(vf, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data.get("version", CURRENT_VERSION)
    except Exception:
        pass
    return CURRENT_VERSION


def _parse_version(ver_str):
    """Parse version string '1.0.6' into tuple (1, 0, 6) for proper comparison."""
    try:
        return tuple(int(x) for x in ver_str.strip().split("."))
    except (ValueError, AttributeError):
        return (0, 0, 0)

def _get_update_url():
    """Get the update check URL from config."""
    config_path = os.path.join(_get_app_dir(), "data", "update_config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f).get("update_url", "")
        except:
            pass
    return ""


def set_update_url(url):
    """Admin function: set the update URL."""
    config_path = os.path.join(_get_app_dir(), "data", "update_config.json")
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump({"update_url": url}, f, indent=2)


def _sha256_file(path):
    """Calculate SHA256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _is_safe_path(member_name):
    """Check if a ZIP member path is safe to extract (no path traversal)."""
    if member_name.startswith("/") or ".." in member_name:
        return False
    # Only allow files in updatable dirs or root-level updatable files
    parts = member_name.replace("\\", "/").split("/")
    if len(parts) == 1:
        return parts[0] in UPDATABLE_FILES
    return parts[0] in UPDATABLE_DIRS


def check_for_update():
    """
    Checks if a new version is available on GitHub.
    Returns (found: bool, latest_version: str, changelog: str)
    """
    url = _get_update_url()
    if not url:
        return False, None, "Chưa cấu hình URL cập nhật."

    try:
        response = requests.get(url, timeout=15)
        response.raise_for_status()
        data = response.json()

        latest_version = data.get("version", "")
        changelog = data.get("changelog", "Không có thông tin thay đổi.")
        download_url = data.get("download_url", "")
        sha256 = data.get("sha256", "")

        local_version = get_local_version()

        if latest_version and _parse_version(latest_version) > _parse_version(local_version):
            # Save pending update info
            _save_pending_update(latest_version, download_url, changelog, sha256)
            return True, latest_version, changelog

    except requests.exceptions.ConnectionError:
        return False, None, "Không thể kết nối đến server cập nhật."
    except requests.exceptions.Timeout:
        return False, None, "Timeout khi kiểm tra cập nhật."
    except Exception as e:
        return False, None, f"Lỗi: {str(e)}"

    return False, None, None


def _save_pending_update(version, download_url, changelog, sha256=""):
    """Save pending update info to data/pending_update.json."""
    pending_file = os.path.join(_get_app_dir(), "data", "pending_update.json")
    os.makedirs(os.path.dirname(pending_file), exist_ok=True)
    with open(pending_file, "w", encoding="utf-8") as f:
        json.dump({
            "version": version,
            "download_url": download_url,
            "changelog": changelog,
            "sha256": sha256,
        }, f, indent=2)


def _get_pending_update():
    """Read pending update info."""
    pending_file = os.path.join(_get_app_dir(), "data", "pending_update.json")
    if os.path.exists(pending_file):
        try:
            with open(pending_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return None


class DownloadUpdateThread(QThread):
    """Background thread: download patch ZIP → verify SHA256 → extract → update."""
    progress = pyqtSignal(int, str)     # (percent, message)
    finished = pyqtSignal(bool, str)    # (success, message)

    MAX_RETRIES = 3

    def __init__(self, update_url=None):
        super().__init__()
        self.update_url = update_url

    def run(self):
        try:
            pending = _get_pending_update()
            url = self.update_url
            expected_sha256 = ""

            if not url and pending:
                url = pending.get("download_url", "")
                expected_sha256 = pending.get("sha256", "")

            if not url:
                self.finished.emit(False, "Không có URL tải xuống.")
                return

            app_dir = _get_app_dir()

            # Determine target directory
            if getattr(sys, 'frozen', False):
                target_dir = os.path.join(app_dir, "_internal")
            else:
                target_dir = app_dir

            # ─── Step 1: Download patch ZIP with retry ───
            update_zip = os.path.join(app_dir, "update_patch.zip")
            downloaded = False

            for attempt in range(1, self.MAX_RETRIES + 1):
                try:
                    self.progress.emit(0, f"Đang kết nối... (lần {attempt})")
                    response = requests.get(url, timeout=300, stream=True)
                    response.raise_for_status()

                    total_size = int(response.headers.get('content-length', 0))
                    dl_bytes = 0

                    with open(update_zip, "wb") as f:
                        for chunk in response.iter_content(chunk_size=65536):
                            f.write(chunk)
                            dl_bytes += len(chunk)
                            if total_size > 0:
                                pct = int(dl_bytes * 50 / total_size)
                                if total_size > 1024 * 1024:
                                    self.progress.emit(pct, f"Tải: {dl_bytes/(1024*1024):.1f}/{total_size/(1024*1024):.1f} MB")
                                else:
                                    self.progress.emit(pct, f"Tải: {dl_bytes/1024:.0f}/{total_size/1024:.0f} KB")

                    downloaded = True
                    break

                except Exception as e:
                    if attempt >= self.MAX_RETRIES:
                        self.finished.emit(False, f"Tải thất bại sau {self.MAX_RETRIES} lần: {str(e)[:60]}")
                        return
                    self.progress.emit(0, f"Thử lại ({attempt + 1}/{self.MAX_RETRIES})...")
                    import time
                    time.sleep(2)

            if not downloaded:
                self.finished.emit(False, "Tải thất bại.")
                return

            # ─── Step 2: Verify SHA256 hash ───
            self.progress.emit(55, "Xác minh SHA256...")
            if expected_sha256:
                actual_hash = _sha256_file(update_zip)
                if actual_hash != expected_sha256:
                    try: os.remove(update_zip)
                    except: pass
                    self.finished.emit(False,
                        f"SHA256 không khớp!\nExpected: {expected_sha256[:16]}...\nActual: {actual_hash[:16]}...")
                    return
                self.progress.emit(60, "SHA256 ✅ hợp lệ")

            # ─── Step 3: Backup current source ───
            self.progress.emit(62, "Backup source cũ...")
            backup_dir = os.path.join(app_dir, "_backup")
            try:
                if os.path.exists(backup_dir):
                    shutil.rmtree(backup_dir, ignore_errors=True)
                os.makedirs(backup_dir, exist_ok=True)
                for src_dir in UPDATABLE_DIRS:
                    src_path = os.path.join(target_dir, src_dir)
                    if os.path.exists(src_path):
                        shutil.copytree(src_path, os.path.join(backup_dir, src_dir),
                                       dirs_exist_ok=True)
            except Exception as e:
                self.progress.emit(62, f"Backup warning: {str(e)[:30]}")

            # ─── Step 4: Extract patch files (only safe paths) ───
            self.progress.emit(65, "Giải nén và áp dụng...")

            try:
                with zipfile.ZipFile(update_zip, 'r') as zf:
                    members = [m for m in zf.namelist() if not m.endswith('/')]
                    safe_members = [m for m in members if _is_safe_path(m)]
                    total_files = len(safe_members)

                    for i, member in enumerate(safe_members):
                        target_path = os.path.join(target_dir, member)
                        os.makedirs(os.path.dirname(target_path), exist_ok=True)
                        with zf.open(member) as src, open(target_path, 'wb') as dst:
                            dst.write(src.read())

                        if i % 5 == 0:
                            pct = 65 + int(i * 30 / max(total_files, 1))
                            self.progress.emit(min(pct, 95), f"Cập nhật: {i+1}/{total_files} files")

            except zipfile.BadZipFile:
                # Restore backup
                self._restore_backup(backup_dir, target_dir)
                self.finished.emit(False, "File ZIP bị hỏng!")
                return
            except Exception as e:
                self._restore_backup(backup_dir, target_dir)
                self.finished.emit(False, f"Lỗi giải nén: {str(e)[:60]}")
                return

            # ─── Step 5: Update local version ───
            self.progress.emit(96, "Cập nhật version...")
            self._update_local_version(target_dir, pending)

            # ─── Step 6: Cleanup ───
            self.progress.emit(98, "Dọn dẹp...")
            try: os.remove(update_zip)
            except: pass
            try:
                pending_file = os.path.join(app_dir, "data", "pending_update.json")
                os.remove(pending_file)
            except: pass
            # Keep backup for safety — user can delete manually

            self.progress.emit(100, "Cập nhật hoàn tất!")
            self.finished.emit(True, "Cập nhật thành công! Vui lòng khởi động lại tool.")

        except Exception as e:
            self.finished.emit(False, f"Lỗi: {str(e)}")

    def _update_local_version(self, target_dir, pending):
        """Update local version.json and CURRENT_VERSION in updater.py."""
        if not pending:
            return
        new_version = pending.get("version", "")
        if not new_version:
            return

        # Update version.json
        version_path = os.path.join(target_dir, "version.json")
        try:
            if os.path.exists(version_path):
                with open(version_path, "r", encoding="utf-8") as f:
                    vdata = json.load(f)
            else:
                vdata = {}
            vdata["version"] = new_version
            vdata["changelog"] = pending.get("changelog", "")
            with open(version_path, "w", encoding="utf-8") as f:
                json.dump(vdata, f, indent=2, ensure_ascii=False)
        except:
            pass

        # Update CURRENT_VERSION in updater.py
        updater_path = os.path.join(target_dir, "core", "updater.py")
        if os.path.exists(updater_path):
            try:
                import re
                with open(updater_path, "r", encoding="utf-8") as f:
                    content = f.read()
                content = re.sub(
                    r'CURRENT_VERSION\s*=\s*"[^"]*"',
                    f'CURRENT_VERSION = "{new_version}"',
                    content
                )
                with open(updater_path, "w", encoding="utf-8") as f:
                    f.write(content)
            except:
                pass

    def _restore_backup(self, backup_dir, target_dir):
        """Restore source from backup on failure."""
        if not os.path.exists(backup_dir):
            return
        try:
            for src_dir in UPDATABLE_DIRS:
                bk_path = os.path.join(backup_dir, src_dir)
                tgt_path = os.path.join(target_dir, src_dir)
                if os.path.exists(bk_path):
                    if os.path.exists(tgt_path):
                        shutil.rmtree(tgt_path, ignore_errors=True)
                    shutil.copytree(bk_path, tgt_path)
        except:
            pass


def apply_update():
    """Restart the app after update."""
    if getattr(sys, 'frozen', False):
        app_path = os.path.abspath(sys.executable)
        try:
            app_dir = os.path.dirname(app_path)
            script = os.path.join(app_dir, "restart.bat")
            with open(script, "w") as f:
                f.write(f'@echo off\ntimeout /t 2 /nobreak > nul\nstart "" "{app_path}"\ndel "%~f0"\n')
            os.startfile(script)
            sys.exit(0)
        except:
            sys.exit(0)
    else:
        # Source mode: just exit, user re-runs main.py
        sys.exit(0)


# ─── Backward compatibility ───
def download_and_install(update_url=None):
    """Legacy sync function — kept for backward compatibility.
    Use DownloadUpdateThread instead for async updates."""
    return False

