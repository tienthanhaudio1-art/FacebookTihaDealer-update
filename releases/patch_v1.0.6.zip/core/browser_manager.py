import os
import sys
import subprocess
from PyQt6.QtCore import QThread, pyqtSignal
from playwright.sync_api import sync_playwright


import threading

# ═══════════════════════════════════════════════════════
# Global thread-safe counter for browser grid positions
# All tabs/workers share this for consistent left→right, top→bottom
# ═══════════════════════════════════════════════════════
_browser_pos_lock = threading.Lock()
_browser_pos_counter = 0


def reset_browser_positions():
    """Reset browser grid position counter. Call at START of each batch operation."""
    global _browser_pos_counter
    with _browser_pos_lock:
        _browser_pos_counter = 0


def next_browser_window_params() -> dict:
    """
    Thread-safe: atomically get next browser position and increment counter.
    Each call returns a unique grid position (left→right, top→bottom).
    """
    global _browser_pos_counter
    with _browser_pos_lock:
        idx = _browser_pos_counter
        _browser_pos_counter += 1
    return get_browser_window_params(idx)


def get_browser_window_params(pos_index: int = 0) -> dict:
    """
    Calculate browser window size/position based on global settings.
    
    Returns dict with keys:
        - win_w, win_h: window dimensions in pixels
        - pos_x, pos_y: window position in pixels
        - zoom_factor: device scale factor (0.25-1.0)
        - chrome_args: list of Chrome args for --window-size, --window-position, --force-device-scale-factor
    
    For thread-safe auto-increment, use next_browser_window_params() instead.
    """
    import ctypes
    import ctypes.wintypes
    import json
    
    # ── Load scale setting ──
    try:
        settings_path = os.path.join(os.path.dirname(__file__), "..", "data", "settings.json")
        with open(settings_path, "r", encoding="utf-8") as f:
            settings = json.load(f)
        chrome_scale = float(settings.get("chrome_scale", "0.25"))
    except Exception:
        chrome_scale = 0.25
    
    # ── Get work area (excludes taskbar) ──
    try:
        rect = ctypes.wintypes.RECT()
        ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0)
        work_left = rect.left
        work_top = rect.top
        work_w = rect.right - rect.left
        work_h = rect.bottom - rect.top
    except Exception:
        work_left, work_top = 0, 0
        work_w, work_h = 1920, 1040
    
    # ── Fully dynamic sizing ──
    # Scale controls browser size, columns auto-calculated
    scale = max(0.1, min(1.0, chrome_scale))
    
    # Browser size from scale (proportion of screen width)
    win_w = max(200, int(work_w * scale))
    
    # Aspect ratio 500:500 (square)
    win_h = win_w
    
    # Clamp: if browser height exceeds work area, cap it
    if win_h > work_h:
        win_h = work_h
    # Also cap width to screen
    if win_w > work_w:
        win_w = work_w
    
    # Auto-calculate columns: how many browsers fit horizontally
    cols = max(1, work_w // win_w)
    
    # Auto-calculate rows: how many fit vertically
    rows = max(1, work_h // win_h)
    
    # ── Grid arrangement: left→right, top→bottom ──
    items_per_page = cols * rows
    local_index = pos_index % items_per_page
    
    col = local_index % cols
    row = local_index // cols
    
    pos_x = work_left + col * win_w
    pos_y = work_top + row * win_h
    
    # Clamp within work area (safety)
    if pos_x + win_w > work_left + work_w:
        pos_x = work_left + work_w - win_w
    if pos_y + win_h > work_top + work_h:
        pos_y = work_top + work_h - win_h
    
    # ── Zoom: proportional to window width for readability ──
    # 800px reference = 100% zoom. Smaller windows = proportionally lower zoom
    # This ensures content is always readable, not microscopic
    zoom_factor = min(1.0, max(0.4, win_w / 800.0))
    
    # DEBUG: log to file to verify algorithm is being used
    try:
        _dbg = os.path.join(os.path.dirname(__file__), "..", "data", "window_debug.log")
        with open(_dbg, "a", encoding="utf-8") as _f:
            _f.write(f"[get_browser_window_params] idx={pos_index} scale={scale} "
                     f"screen={work_w}x{work_h} -> {win_w}x{win_h} cols={cols} "
                     f"pos=({pos_x},{pos_y}) zoom={zoom_factor:.2f}\n")
    except:
        pass
    
    return {
        "win_w": win_w,
        "win_h": win_h,
        "pos_x": pos_x,
        "pos_y": pos_y,
        "zoom_factor": zoom_factor,
        "scale": scale,
        "chrome_args": [
            f"--window-size={win_w},{win_h}",
            f"--window-position={pos_x},{pos_y}",
            f"--force-device-scale-factor={zoom_factor:.2f}",
        ]
    }


def setup_playwright():
    """Configures Playwright to use the correct browser path, especially for packaged EXEs."""
    if getattr(sys, 'frozen', False):
        # Running as a packaged EXE
        # Set browser path to standard LocalAppData location to avoid searching app folder
        standard_path = os.path.join(os.environ.get("LOCALAPPDATA", ""), "ms-playwright")
        if os.path.exists(standard_path):
             os.environ["PLAYWRIGHT_BROWSERS_PATH"] = standard_path
        else:
            # If not found, we might need to tell the user to install it
            # or try to use a bundled path if one was intended.
            # Setting it to a known path is safer than letting it fail relative to EXE.
            os.environ["PLAYWRIGHT_BROWSERS_PATH"] = standard_path

def is_chromium_installed():
    """Checks if chromium is installed in the expected playwright location."""
    path = os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
    if not path:
        path = os.path.join(os.environ.get("LOCALAPPDATA", ""), "ms-playwright")
    
    if os.path.exists(path):
        # Look for any folder starting with 'chromium-'
        for folder in os.listdir(path):
            if folder.startswith("chromium-") and os.path.isdir(os.path.join(path, folder)):
                return True
    return False

def install_chromium():
    """Attempts to install chromium via playwright.
    Works in both source (python) and frozen (PyInstaller EXE) modes.
    """
    try:
        # Ensure browser path is set
        browser_path = os.path.join(os.environ.get("LOCALAPPDATA", ""), "ms-playwright")
        os.environ["PLAYWRIGHT_BROWSERS_PATH"] = browser_path

        # ── Method 1: Use Playwright's internal CLI driver ──
        # compute_driver_executable() returns (node_exe, cli_js_path)
        # We run: node.exe cli.js install chromium
        try:
            from playwright._impl._driver import compute_driver_executable
            node_exe, cli_js = compute_driver_executable()
            env = os.environ.copy()
            env["PLAYWRIGHT_BROWSERS_PATH"] = browser_path
            result = subprocess.run(
                [str(node_exe), str(cli_js), "install", "chromium"],
                capture_output=True, text=True, env=env, timeout=300
            )
            if result.returncode == 0:
                print(f"Chromium installed successfully via driver: {browser_path}")
                return True
            print(f"Driver install failed (rc={result.returncode}): {result.stderr[:200]}")
        except Exception as e:
            print(f"Method 1 (driver) failed: {e}")

        # ── Method 2: Find a real Python interpreter ──
        if getattr(sys, 'frozen', False):
            # In frozen mode, find the real Python
            python_paths = [
                # System Python installations
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Python", "Python313", "python.exe"),
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Python", "Python312", "python.exe"),
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Python", "Python311", "python.exe"),
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Python", "Python310", "python.exe"),
                r"C:\Python313\python.exe",
                r"C:\Python312\python.exe",
                r"C:\Python311\python.exe",
            ]
            # Also try 'where python'
            try:
                where_result = subprocess.run(["where", "python"], capture_output=True, text=True, timeout=5)
                if where_result.returncode == 0:
                    for line in where_result.stdout.strip().split("\n"):
                        line = line.strip()
                        if line and os.path.exists(line) and "WindowsApps" not in line:
                            python_paths.insert(0, line)
            except:
                pass

            for py_path in python_paths:
                if os.path.exists(py_path):
                    try:
                        env = os.environ.copy()
                        env["PLAYWRIGHT_BROWSERS_PATH"] = browser_path
                        result = subprocess.run(
                            [py_path, "-m", "playwright", "install", "chromium"],
                            capture_output=True, text=True, env=env, timeout=300
                        )
                        if result.returncode == 0:
                            print(f"Chromium installed via {py_path}")
                            return True
                    except:
                        continue
        else:
            # Not frozen, use sys.executable normally
            env = os.environ.copy()
            env["PLAYWRIGHT_BROWSERS_PATH"] = browser_path
            result = subprocess.run(
                [sys.executable, "-m", "playwright", "install", "chromium"],
                capture_output=True, text=True, env=env, timeout=300
            )
            if result.returncode == 0:
                print(f"Chromium installed via {sys.executable}")
                return True

        print("All methods failed to install Chromium")
        return False
    except Exception as e:
        print(f"Error installing chromium: {e}")
        return False

class SmartBrowserDetector:
    @staticmethod
    def find_browser(browser_name):
        import winreg
        
        def check_paths(paths):
            for p in paths:
                if os.path.exists(p): return p
            return None

        # 1. Google Chrome
        if browser_name == "Google Chrome":
            local_app_data = os.environ.get("LOCALAPPDATA", "C:\\")
            chrome_paths = [
                os.path.join(local_app_data, "Google", "Chrome", "Application", "chrome.exe"),
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            ]
            found = check_paths(chrome_paths)
            if found: return found
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe") as key:
                    exe_path = winreg.QueryValueEx(key, "")[0]
                    if os.path.exists(exe_path): return exe_path
            except Exception: pass
            return None

        # 3. Microsoft Edge
        elif browser_name == "Microsoft Edge":
            edge_paths = [
                r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
            ]
            return check_paths(edge_paths)

        # 4. Brave Browser
        elif browser_name == "Brave":
            local_app_data = os.environ.get("LOCALAPPDATA", "C:\\")
            brave_paths = [
                os.path.join(local_app_data, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
                r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
                r"C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe",
            ]
            return check_paths(brave_paths)

        return None

# ═══════════════════════════════════════════
# Standalone browser window placement helpers
# ═══════════════════════════════════════════

def force_chrome_window_placement(user_data_dir, chrome_args):
    """Write window placement into Chrome Preferences before launch.
    Chrome ignores --window-size/--window-position for existing profiles."""
    import json as _json
    import re as _re
    win_w, win_h = 480, 480
    pos_x, pos_y = 0, 0
    for arg in chrome_args:
        m = _re.match(r'--window-size=(\d+),(\d+)', arg)
        if m: win_w, win_h = int(m.group(1)), int(m.group(2))
        m = _re.match(r'--window-position=(-?\d+),(-?\d+)', arg)
        if m: pos_x, pos_y = int(m.group(1)), int(m.group(2))
    wp = {"bottom": pos_y + win_h, "left": pos_x, "maximized": False,
          "right": pos_x + win_w, "top": pos_y,
          "work_area_bottom": 1040, "work_area_left": 0,
          "work_area_right": 1920, "work_area_top": 0}
    for pref_path in [os.path.join(user_data_dir, "Default", "Preferences"),
                      os.path.join(user_data_dir, "Preferences")]:
        try:
            prefs = {}
            if os.path.exists(pref_path):
                with open(pref_path, "r", encoding="utf-8") as f:
                    prefs = _json.load(f)
            if "browser" not in prefs: prefs["browser"] = {}
            prefs["browser"]["window_placement"] = wp
            os.makedirs(os.path.dirname(pref_path), exist_ok=True)
            with open(pref_path, "w", encoding="utf-8") as f:
                _json.dump(prefs, f, ensure_ascii=False)
        except Exception:
            pass


def reposition_browser_window(proc_pid, chrome_args):
    """Force-reposition browser window using Windows MoveWindow API after launch."""
    import ctypes
    import ctypes.wintypes
    import re as _re
    win_w, win_h = 480, 480
    pos_x, pos_y = 0, 0
    for arg in chrome_args:
        m = _re.match(r'--window-size=(\d+),(\d+)', arg)
        if m: win_w, win_h = int(m.group(1)), int(m.group(2))
        m = _re.match(r'--window-position=(-?\d+),(-?\d+)', arg)
        if m: pos_x, pos_y = int(m.group(1)), int(m.group(2))
    target_pids = {proc_pid}
    try:
        import psutil
        parent = psutil.Process(proc_pid)
        for child in parent.children(recursive=True):
            target_pids.add(child.pid)
    except Exception:
        pass
    user32 = ctypes.windll.user32
    EnumWindowsProc = ctypes.WINFUNCTYPE(
        ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
    found_hwnds = []
    def _enum_cb(hwnd, lparam):
        if user32.IsWindowVisible(hwnd):
            pid = ctypes.wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value in target_pids:
                length = user32.GetWindowTextLengthW(hwnd)
                if length > 0:
                    found_hwnds.append(hwnd)
        return True
    user32.EnumWindows(EnumWindowsProc(_enum_cb), 0)
    for hwnd in found_hwnds:
        user32.MoveWindow(hwnd, pos_x, pos_y, win_w, win_h, True)
        break


class BrowserThread(QThread):
    finished_signal = pyqtSignal(str) # profile_id
    error_signal = pyqtSignal(str, str) # profile_id, error_message
    info_ready = pyqtSignal(str, dict)  # profile_id, scraped_data
    status_update = pyqtSignal(str, str) # profile_id, status_message

    def __init__(self, profile, auto_login=False, headless=False, action="launch", pos_index=0):
        super().__init__()
        self.profile = profile
        self.auto_login = auto_login
        self.headless = headless
        self.action = action # "launch", "check_cookie", "check_info_full"
        self.pos_index = pos_index # Grid placement index
        self.playwright = None
        self.browser = None
        self.context = None
        self.is_running = False

    def _launch_subprocess_browser(self, exe_path, user_data_dir, extra_args, 
                                    proxy_str, startup_url, browser_name):
        """Launch third-party browser via subprocess. Monitors process lifecycle."""
        import time as _time
        
        # ── Force Chrome window placement via Preferences file ──
        # Chrome ignores --window-size/--window-position if Preferences has saved state
        self._force_chrome_window_placement(user_data_dir, extra_args)
        
        cmd = [exe_path]
        cmd.append(f"--user-data-dir={user_data_dir}")
        cmd.extend(extra_args)
        
        if proxy_str:
            cmd.append(f"--proxy-server={proxy_str}")
        
        cmd.extend([
            "--disable-blink-features=AutomationControlled",
            "--no-first-run",
            "--no-default-browser-check",
        ])
        
        # Remove headless flags for subprocess browsers
        cmd = [a for a in cmd if not a.startswith("--headless")]
        
        if startup_url:
            cmd.append(startup_url)
        
        self.status_update.emit(self.profile["id"], f"Đang mở {browser_name}...")
        
        try:
            proc = subprocess.Popen(cmd)
            self.status_update.emit(self.profile["id"], f"{browser_name} đang chạy (PID: {proc.pid})")
            
            # Wait for browser window to appear, then FORCE position via Windows API
            _time.sleep(2)
            self._reposition_browser_window(proc.pid, extra_args)
            
            # Additional wait for full init
            _time.sleep(3)
            
            # Monitor: check if browser process (or its children) are still running
            exe_name = os.path.basename(exe_path).lower()
            
            while True:
                _time.sleep(3)
                
                # Check if any process with this exe name is still running
                browser_running = False
                try:
                    import psutil
                    for p in psutil.process_iter(['name', 'cmdline']):
                        try:
                            pname = (p.info.get('name') or '').lower()
                            if pname == exe_name:
                                # Check if this instance uses our user-data-dir
                                cmdline = p.info.get('cmdline') or []
                                cmd_str = ' '.join(cmdline)
                                if user_data_dir in cmd_str:
                                    browser_running = True
                                    break
                        except (psutil.AccessDenied, psutil.NoSuchProcess):
                            pass
                except ImportError:
                    # Without psutil, check if original process is alive
                    browser_running = (proc.poll() is None)
                
                if not browser_running:
                    break
            
            self.status_update.emit(self.profile["id"], "Stopped")
            self.finished_signal.emit(self.profile["id"])
        except FileNotFoundError:
            self.error_signal.emit(self.profile["id"], 
                f"Không tìm thấy {browser_name} tại: {exe_path}")
        except Exception as e:
            self.error_signal.emit(self.profile["id"], f"Lỗi mở {browser_name}: {str(e)}")

    def _reposition_browser_window(self, proc_pid, args):
        """Force-reposition browser window using Windows API after launch.
        
        Chrome ignores --window-size/--window-position for existing profiles.
        This uses MoveWindow API to force the correct position/size.
        """
        import ctypes
        import ctypes.wintypes
        import re
        
        # Parse target position from args
        win_w, win_h = 480, 480
        pos_x, pos_y = 0, 0
        for arg in args:
            m = re.match(r'--window-size=(\d+),(\d+)', arg)
            if m:
                win_w, win_h = int(m.group(1)), int(m.group(2))
            m = re.match(r'--window-position=(-?\d+),(-?\d+)', arg)
            if m:
                pos_x, pos_y = int(m.group(1)), int(m.group(2))
        
        # Collect all PIDs in the Chrome process tree
        target_pids = {proc_pid}
        try:
            import psutil
            parent = psutil.Process(proc_pid)
            for child in parent.children(recursive=True):
                target_pids.add(child.pid)
        except Exception:
            pass
        
        # Find visible windows belonging to these PIDs
        user32 = ctypes.windll.user32
        EnumWindowsProc = ctypes.WINFUNCTYPE(
            ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM
        )
        found_hwnds = []
        
        def _enum_callback(hwnd, lparam):
            if user32.IsWindowVisible(hwnd):
                pid = ctypes.wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if pid.value in target_pids:
                    # Only real windows with titles (not tooltips/popups)
                    length = user32.GetWindowTextLengthW(hwnd)
                    if length > 0:
                        found_hwnds.append(hwnd)
            return True
        
        user32.EnumWindows(EnumWindowsProc(_enum_callback), 0)
        
        # Move the main browser window
        for hwnd in found_hwnds:
            user32.MoveWindow(hwnd, pos_x, pos_y, win_w, win_h, True)
            break  # Only move the first (main) window

    def _force_chrome_window_placement(self, user_data_dir, args):
        """Write window placement into Chrome Preferences to override saved state.
        
        Chrome ignores --window-size/--window-position when Preferences has
        saved window_placement. This method patches the Preferences file 
        BEFORE launching Chrome so the window opens at our desired size/position.
        """
        import json as _json
        import re
        
        # Parse window-size and window-position from args
        win_w, win_h = 480, 480
        pos_x, pos_y = 0, 0
        for arg in args:
            m = re.match(r'--window-size=(\d+),(\d+)', arg)
            if m:
                win_w, win_h = int(m.group(1)), int(m.group(2))
            m = re.match(r'--window-position=(-?\d+),(-?\d+)', arg)
            if m:
                pos_x, pos_y = int(m.group(1)), int(m.group(2))
        
        window_placement = {
            "bottom": pos_y + win_h,
            "left": pos_x,
            "maximized": False,
            "right": pos_x + win_w,
            "top": pos_y,
            "work_area_bottom": 1040,
            "work_area_left": 0,
            "work_area_right": 1920,
            "work_area_top": 0,
        }
        
        # Try both Default/Preferences and root Preferences
        for pref_path in [
            os.path.join(user_data_dir, "Default", "Preferences"),
            os.path.join(user_data_dir, "Preferences"),
        ]:
            try:
                prefs = {}
                if os.path.exists(pref_path):
                    with open(pref_path, "r", encoding="utf-8") as f:
                        prefs = _json.load(f)
                
                if "browser" not in prefs:
                    prefs["browser"] = {}
                prefs["browser"]["window_placement"] = window_placement
                
                os.makedirs(os.path.dirname(pref_path), exist_ok=True)
                with open(pref_path, "w", encoding="utf-8") as f:
                    _json.dump(prefs, f, ensure_ascii=False)
            except Exception:
                pass

    def _parse_proxy(self, proxy_str):
        """Auto-detect proxy format and return Playwright proxy dict.
        Supports: ip:port, ip:port:user:pass, user:pass@ip:port, 
        socks5://ip:port, http://user:pass@ip:port, etc."""
        import re
        proxy_str = proxy_str.strip()
        if not proxy_str:
            return None
        
        # Detect protocol prefix
        protocol = "http"
        proto_match = re.match(r'^(https?|socks[45])://', proxy_str, re.IGNORECASE)
        if proto_match:
            protocol = proto_match.group(1).lower()
            proxy_str = proxy_str[proto_match.end():]
        
        username = None
        password = None
        host = None
        port = None
        
        # Format: user:pass@host:port
        at_match = re.match(r'^([^:]+):([^@]+)@([^:]+):(\d+)$', proxy_str)
        if at_match:
            username, password, host, port = at_match.groups()
        else:
            parts = proxy_str.split(':')
            if len(parts) == 2:
                # host:port
                host, port = parts[0], parts[1]
            elif len(parts) == 4:
                # host:port:user:pass
                host, port, username, password = parts
            elif len(parts) == 3:
                # Could be host:port:user (unlikely) — treat as host:port
                host, port = parts[0], parts[1]
            else:
                return None
        
        if not host or not port:
            return None
            
        result = {"server": f"{protocol}://{host}:{port}"}
        if username:
            result["username"] = username
        if password:
            result["password"] = password
        return result

    def _detect_checkpoint_type(self, page):
        """Detect specific Facebook checkpoint/verification type from URL and page content.
        Returns tuple: (checkpoint_type_str, fb_live_status)
        Examples: ('CP282 - Xác minh ảnh', 'CP282'), ('Vô hiệu hóa', 'Disabled')"""
        try:
            url = page.url.lower()
            content = ""
            try:
                content = page.content().lower()
            except:
                pass
            
            # ── URL-Based Detection ──
            # CP282: Photo verification
            if "282" in url or "photo" in url and "checkpoint" in url:
                return "CP282 - Xác minh ảnh đại diện", "CP282"
            
            # CP956: Identity verification (upload ID)
            if "956" in url or ("identity" in url and "checkpoint" in url):
                return "CP956 - Xác minh danh tính (CMND/CCCD)", "CP956"
            
            # Disabled account
            if "disabled" in url or "account_disabled" in url:
                return "Tài khoản bị vô hiệu hóa", "Disabled"
            
            # Locked account
            if "locked" in url or "account_locked" in url:
                return "Tài khoản bị khóa", "Locked"
            
            # Suspicious login
            if "suspicious" in url or "login_attempt" in url:
                return "Đăng nhập đáng ngờ", "Suspicious"
            
            # Generic checkpoint URL
            if "checkpoint" in url:
                # ── Content-Based Sub-Detection ──
                
                # CP282 keywords
                if any(kw in content for kw in ["upload a photo", "tải ảnh lên", "photo of yourself", "ảnh của bạn", "identify yourself", "xác nhận danh tính bằng ảnh"]):
                    return "CP282 - Xác minh ảnh đại diện", "CP282"
                
                # CP956 keywords
                if any(kw in content for kw in ["upload your id", "government-issued id", "giấy tờ tùy thân", "chứng minh nhân dân", "căn cước công dân", "identity document", "xác minh danh tính"]):
                    return "CP956 - Xác minh danh tính (CMND/CCCD)", "CP956"
                
                # Phone verification
                if any(kw in content for kw in ["phone number", "số điện thoại", "verify your phone", "xác minh số điện thoại", "enter the code we sent"]):
                    return "CP - Xác minh số điện thoại", "CP Phone"
                
                # Email verification
                if any(kw in content for kw in ["confirm your email", "xác nhận email", "verify your email", "mã xác nhận email"]):
                    return "CP - Xác minh email", "CP Email"
                
                # Disabled/banned keywords
                if any(kw in content for kw in ["account has been disabled", "tài khoản đã bị vô hiệu hóa", "your account is disabled", "tài khoản bị khóa", "account has been locked"]):
                    return "Tài khoản bị vô hiệu hóa", "Disabled"
                
                # Suspicious activity
                if any(kw in content for kw in ["suspicious activity", "hoạt động đáng ngờ", "unusual activity", "unusual login", "we noticed unusual"]):
                    return "Hoạt động đáng ngờ", "Suspicious"
                
                # Friends verification (tag friends in photos)
                if any(kw in content for kw in ["identify your friends", "nhận dạng bạn bè", "tag friends", "gắn thẻ bạn bè"]):
                    return "CP - Nhận dạng bạn bè", "CP Friends"
                
                # Terms of service violation
                if any(kw in content for kw in ["community standards", "tiêu chuẩn cộng đồng", "violated", "vi phạm", "restricted", "bị hạn chế"]):
                    return "Vi phạm tiêu chuẩn cộng đồng", "Violated"
                
                # 2FA / Code verification
                if any(kw in content for kw in ["two-factor", "xác thực hai yếu tố", "authentication code", "mã xác thực", "code generator"]):
                    return "CP - Xác thực 2FA", "CP 2FA"
                
                # Generic checkpoint
                return "Checkpoint (chưa xác định loại)", "Checkpoint"
            
            # Login page redirect (not logged in)
            if "login" in url and "facebook.com" in url:
                return "Hết phiên đăng nhập", "Out"
            
            # Hacked / compromised
            if "hacked" in url or "compromised" in url:
                return "Tài khoản bị hack/xâm nhập", "Hacked"
            
            return None, None
        except Exception:
            return None, None

    def run(self):
        self.is_running = True
        
        # ══════════════════════════════════════════════════════
        # Phase 1: Load settings (no Playwright needed)
        # ══════════════════════════════════════════════════════
        try:
            import json
            settings_path = os.path.join(os.path.dirname(__file__), "..", "data", "settings.json")
            with open(settings_path, "r", encoding="utf-8") as f:
                settings = json.load(f)
            base_w = int(settings.get("browser_width", 640))
            base_h = int(settings.get("browser_height", 480))
            omocaptcha_key = settings.get("omocaptcha_key", "").strip()
            two_captcha_path = settings.get("two_captcha_path", "").strip()
            chrome_scale = float(settings.get("chrome_scale", "0.9"))
            startup_url = settings.get("startup_urls", "https://www.facebook.com").strip()
            profile_base = settings.get("chrome_profile_base_path", "").strip()
            selected_browser = settings.get("selected_browser", "Chromium")
            close_after_login = settings.get("close_chrome_after_login", True)
        except Exception:
            base_w, base_h = 640, 480
            omocaptcha_key = ""
            two_captcha_path = ""
            chrome_scale = 0.9
            startup_url = "https://www.facebook.com"
            profile_base = ""
            selected_browser = "Chromium"
            close_after_login = True
        
        # ── Profile directory ──
        if profile_base and os.path.isdir(profile_base):
            user_data_dir = os.path.join(profile_base, f"profile_{self.profile['id']}")
        else:
            user_data_dir = os.path.abspath(self.profile["data_dir"])
        os.makedirs(user_data_dir, exist_ok=True)
        
        # ── Window sizing/positioning — uses shared utility ──
        wp = get_browser_window_params(self.pos_index)
        win_w = wp["win_w"]
        win_h = wp["win_h"]
        zoom_factor = wp["zoom_factor"]
        
        args = [
            "--disable-blink-features=AutomationControlled",
            f"--window-size={win_w},{win_h}",
            f"--window-position={wp['pos_x']},{wp['pos_y']}",
            f"--force-device-scale-factor={zoom_factor:.2f}",
        ]
        
        # ── Extension check ──
        actual_ext_path = None
        if two_captcha_path and os.path.isdir(two_captcha_path):
            import json
            def is_valid_manifest(path):
                if os.path.exists(path):
                    try:
                        with open(path, 'r', encoding='utf-8') as mf:
                            data = json.load(mf)
                            return 'manifest_version' in data
                    except Exception:
                        pass
                return False
            manifest_root = os.path.join(two_captcha_path, "manifest.json")
            if is_valid_manifest(manifest_root):
                actual_ext_path = two_captcha_path
            else:
                sub_src = os.path.join(two_captcha_path, "src")
                if os.path.isdir(sub_src) and is_valid_manifest(os.path.join(sub_src, "manifest.json")):
                    actual_ext_path = sub_src
        if actual_ext_path:
            args.append(f"--disable-extensions-except={actual_ext_path}")
            args.append(f"--load-extension={actual_ext_path}")
            
        if self.headless:
            args.append("--headless=new")
        
        # ── Proxy ──
        proxy_str = self.profile.get("fb_proxy", "").strip()
        proxy_config = None
        if proxy_str:
            proxy_config = self._parse_proxy(proxy_str)
            if not proxy_config:
                args.append(f"--proxy-server={proxy_str}")
        
        # ══════════════════════════════════════════════════════
        # Phase 2: Route to subprocess OR Playwright
        # ══════════════════════════════════════════════════════
        self.status_update.emit(self.profile["id"], f"Mở {selected_browser}...")
        
        # ── DETERMINE EXECUTABLE PATH ──
        executable_path = None
        
        # External browsers: detect via SmartBrowserDetector
        EXTERNAL_BROWSERS = ["Google Chrome", "Microsoft Edge", "Brave"]
        
        if selected_browser in EXTERNAL_BROWSERS:
            executable_path = SmartBrowserDetector.find_browser(selected_browser)
            if not executable_path:
                self.error_signal.emit(self.profile["id"], 
                    f"Không tìm thấy {selected_browser}. Vui lòng cài đặt hoặc chọn Chromium trong Cài đặt.")
                return
        elif selected_browser == "Firefox":
            # Use Playwright's Firefox exe
            pw_base = os.path.join(os.environ.get("LOCALAPPDATA", ""), "ms-playwright")
            executable_path = None
            if os.path.isdir(pw_base):
                for d in os.listdir(pw_base):
                    if d.startswith("firefox-"):
                        ff_exe = os.path.join(pw_base, d, "firefox", "firefox.exe")
                        if os.path.exists(ff_exe):
                            executable_path = ff_exe
                            break
            if not executable_path:
                self.error_signal.emit(self.profile["id"], 
                    "Firefox chưa cài. Dùng nút 'Fix Browser' trong tab Cài đặt.")
                return
        else:
            # Chromium (default) — use Playwright's Chromium exe
            pw_dir = os.path.join(os.environ.get("LOCALAPPDATA", ""), "ms-playwright")
            executable_path = None
            if os.path.isdir(pw_dir):
                for d in os.listdir(pw_dir):
                    if d.startswith("chromium-"):
                        ch_exe = os.path.join(pw_dir, d, "chrome-win64", "chrome.exe")
                        if not os.path.exists(ch_exe):
                            ch_exe = os.path.join(pw_dir, d, "chrome-win", "chrome.exe")
                        if os.path.exists(ch_exe):
                            executable_path = ch_exe
                            break
            if not executable_path:
                self.error_signal.emit(self.profile["id"], 
                    "Chromium chưa cài. Dùng nút 'Fix Browser' trong tab Cài đặt.")
                return
        
        # ── DEBUG LOG ──
        try:
            _dbg = os.path.join(os.path.dirname(__file__), "..", "data", "browser_debug.log")
            with open(_dbg, "a", encoding="utf-8") as _f:
                import datetime
                _f.write(f"\n[{datetime.datetime.now()}] browser={selected_browser} action={self.action} exe={executable_path} profile={self.profile['id']}\n")
        except:
            pass
        
        # ═════════════════════════════════════════════════
        # For plain 'launch' (no auto_login): use subprocess (fast, no hang)
        # For auto_login / automation actions: use Playwright (page control needed)
        # ═════════════════════════════════════════════════
        if self.action == "launch" and not self.auto_login:
            self._launch_subprocess_browser(
                executable_path, user_data_dir, args,
                proxy_str, startup_url, selected_browser
            )
            return
        
        # ── OPEN WITH COOKIE: inject cookies headless, then launch subprocess ──
        if self.action == "open_with_cookie":
            cookie_str = self.profile.get("fb_cookie", "")
            if cookie_str:
                self.status_update.emit(self.profile["id"], "Đang nạp Cookie (headless)...")
                try:
                    setup_playwright()
                    with sync_playwright() as p:
                        ctx = p.chromium.launch_persistent_context(
                            user_data_dir=user_data_dir,
                            headless=True,
                            args=["--disable-blink-features=AutomationControlled"]
                        )
                        page = ctx.pages[0] if ctx.pages else ctx.new_page()
                        valid_cookies = []
                        for part in cookie_str.split(';'):
                            if '=' in part:
                                k, v = part.strip().split('=', 1)
                                valid_cookies.append({
                                    "name": k, "value": v,
                                    "domain": ".facebook.com", "path": "/"
                                })
                        if valid_cookies:
                            ctx.add_cookies(valid_cookies)
                            page.goto("https://www.facebook.com", wait_until="domcontentloaded", timeout=15000)
                            import time as _time
                            _time.sleep(2)
                        ctx.close()
                    self.status_update.emit(self.profile["id"], "Cookie đã nạp! Mở browser...")
                except Exception as e:
                    self.status_update.emit(self.profile["id"], f"Lỗi nạp cookie: {e}")
            
            # Now launch visible browser via subprocess (cookies are saved in profile dir)
            self._launch_subprocess_browser(
                executable_path, user_data_dir, args,
                proxy_str, "https://www.facebook.com", selected_browser
            )
            return
        
        # ── PLAYWRIGHT PATH (auto_login, cookie_login, etc.) ──
        self.status_update.emit(self.profile["id"], "Khởi tạo Playwright...")
        setup_playwright()
        
        if not is_chromium_installed():
            self.error_signal.emit(self.profile["id"], 
                "Browser not found! Dùng nút 'Fix Browser' trong tab Cài đặt.")
            return

        try:
            with sync_playwright() as p:
                self.playwright = p
                
                # For automation, always use Playwright's built-in browsers
                # (Cốc Cốc/Tor/Orbita can't use Playwright CDP)
                browser_type = p.chromium
                if selected_browser == "Firefox":
                    browser_type = p.firefox

                launch_kwargs = {
                    "user_data_dir": user_data_dir,
                    "headless": self.headless,
                    "args": args,
                    "no_viewport": not self.headless,
                    "permissions": []
                }
                
                if proxy_config:
                    launch_kwargs["proxy"] = proxy_config
                    
                # Do NOT pass executable_path — Playwright uses its own built-in browsers
                # The executable_path was determined for subprocess, not for Playwright
                
                # Launch a persistent context to save cookies, local storage, etc.
                self.context = browser_type.launch_persistent_context(**launch_kwargs)
                
                # Wait for all pages to close, which effectively waits until the browser is closed by the user
                if len(self.context.pages) > 0:
                    page = self.context.pages[0]
                else:
                    page = self.context.new_page()
                    
                # Ensure the window doesn't close on error by keeping a reference hook
                page.on("close", lambda _: print("Page closed"))
                
                # Block browser notification popup automatically
                self.context.grant_permissions([], origin="https://www.facebook.com")
                
                # ── Handle Open With Cookie Special Action ──
                if self.action == "open_with_cookie":
                    cookie_str = self.profile.get("fb_cookie", "")
                    if cookie_str:
                        self.status_update.emit(self.profile["id"], "Đang nạp Cookie...")
                        valid_cookies = []
                        parts = cookie_str.split(';')
                        for p in parts:
                            if '=' in p:
                                k, v = p.strip().split('=', 1)
                                valid_cookies.append({
                                    "name": k,
                                    "value": v,
                                    "domain": ".facebook.com",
                                    "path": "/"
                                })
                        if valid_cookies:
                            self.context.add_cookies(valid_cookies)

                    # Then let it naturally proceed to goto startup_url below
                    self.action = "launch" # Reset action so it behaves like a normal UI launch from here out
                    
                # ── Handle Specific Actions ──
                if self.action in ["check_cookie", "check_info_full"]:
                    self.status_update.emit(self.profile["id"], "Đang kiểm tra...")
                    page.goto("https://www.facebook.com/", timeout=30000)
                    page.wait_for_timeout(2000)
                    
                    scraped_data = {}
                    cookies = self.context.cookies()
                    is_logged_in = any(c["name"] == "c_user" for c in cookies)
                    
                    if not is_logged_in:
                        # Detect specific checkpoint type
                        cp_type, cp_live = self._detect_checkpoint_type(page)
                        if cp_type:
                            self.status_update.emit(self.profile["id"], cp_type)
                            scraped_data["status"] = cp_type
                            scraped_data["fb_live"] = cp_live or "Checkpoint"
                        else:
                            self.status_update.emit(self.profile["id"], "Wall Out")
                            scraped_data["status"] = "Wall Out"
                            scraped_data["fb_live"] = "Dead"
                    else:
                        self.status_update.emit(self.profile["id"], "Wall Live")
                        scraped_data["status"] = "Wall Live"
                        scraped_data["fb_live"] = "Live"
                        
                        if self.action == "check_info_full":
                            self.status_update.emit(self.profile["id"], "Lấy thông tin...")
                            page.goto("https://www.facebook.com/me", timeout=15000)
                            page.wait_for_timeout(3000)
                            
                            # Scrape Name
                            try:
                                h1_loc = page.locator('h1').first
                                if h1_loc.is_visible(timeout=2000):
                                    scraped_data["fb_name"] = h1_loc.inner_text().strip()
                            except: pass
                            
                            # Scrape Gender & Friends from page content
                            try:
                                content = page.content().lower()
                                if any(x in content for x in ["female", "nữ", "woman"]): scraped_data["fb_gender"] = "Nữ"
                                elif any(x in content for x in ["male", "nam", "man"]): scraped_data["fb_gender"] = "Nam"
                                
                                # Simple friends check
                                import re
                                friends_match = re.search(r'(\d+[\d,.]*[KM]?)\s*(friends|bạn)', content)
                                if friends_match:
                                    scraped_data["fb_friends"] = friends_match.group(1)
                            except: pass
                            
                    if scraped_data:
                        self.info_ready.emit(self.profile["id"], scraped_data)
                    
                    # Close after check
                    self.context.close()
                    self.is_running = False
                    self.finished_signal.emit(self.profile["id"])
                    return

                # --- Normal Launch / Auto Login Flow ---
                try:
                    if self.auto_login:
                        self.status_update.emit(self.profile["id"], "Vào trang Facebook...")
                        try:
                            page.goto(startup_url, timeout=30000)
                        except Exception:
                            pass # Startup timeout doesn't break everything
                        
                        uid = self.profile.get("fb_uid", "")
                        # Fallback to email if uid is empty and user provided email
                        if not uid:
                            uid = self.profile.get("fb_email", "")
                        pwd = self.profile.get("fb_pass", "")
                        tfa = self.profile.get("fb_2fa", "")
                        
                        if uid and pwd:
                            try:
                                # Look for either "Continue" (fast login) or "Email" (normal login)
                                try:
                                    # Wait for either email input or generic button/text
                                    try:
                                        page.wait_for_selector('input[name="email"], div[role="button"]:has-text("Continue"), span:has-text("Continue"), div[role="button"]:has-text("Tiếp tục")', timeout=5000)
                                    except:
                                        pass
                                    
                                    self.status_update.emit(self.profile["id"], "Nhập UID/Email...")
                                    if page.locator('input[name="email"]').is_visible():
                                        page.locator('input[name="email"]').press_sequentially(uid, delay=100)
                                    else:
                                        # Click "Continue" if it's there
                                        try:
                                            clicked = False
                                            for text_val in ["Continue", "Tiếp tục"]:
                                                # Try finding visible div/button with this text
                                                for selector in [f'div[role="button"]:has-text("{text_val}")', f'span:has-text("{text_val}")', f'text="{text_val}"']:
                                                    loc = page.locator(selector)
                                                    for i in range(loc.count()):
                                                        if loc.nth(i).is_visible():
                                                            loc.nth(i).click(timeout=2000)
                                                            clicked = True
                                                            break
                                                    if clicked: break
                                                if clicked: break
                                        except:
                                            pass
                                            
                                        # Give the modal a moment to animate in
                                        page.wait_for_timeout(1000)

                                    # Facebook might have multiple password fields (one hidden, one in modal). 
                                    # Find all password fields and fill the first visible one.
                                    self.status_update.emit(self.profile["id"], "Điền Password...")
                                    pass_fields = page.locator('input[type="password"], input[name="pass"]')
                                    for i in range(pass_fields.count()):
                                        if pass_fields.nth(i).is_visible():
                                            pass_fields.nth(i).press_sequentially(pwd, delay=100)
                                            page.wait_for_timeout(500)
                                            pass_fields.nth(i).press("Enter")
                                            break
                                except Exception:
                                    pass # Handle timeout
                                
                                # Wait a bit to see if it submits; if not fallback to clicking the button
                                try:
                                    page.wait_for_navigation(timeout=3000)
                                except Exception:
                                    try:
                                        # Try various login submit buttons
                                        for selector in [
                                            'button[name="login"]',
                                            'div[role="button"]:has-text("Log in")',
                                            'div[role="button"]:has-text("Đăng nhập")',
                                            'div[role="button"]:has-text("Continue")',
                                            'div[role="button"]:has-text("Tiếp tục")',
                                            'button:has-text("Continue")',
                                            'button:has-text("Tiếp tục")'
                                        ]:
                                            loc = page.locator(selector)
                                            if loc.first.is_visible(timeout=1000):
                                                loc.first.click()
                                                page.wait_for_timeout(2000)
                                                break
                                    except:
                                        pass
                                
                                # ── Check for CAPTCHA challenge after login submit ──
                                try:
                                    from core.captcha_solver import handle_captcha_on_page
                                    handle_captcha_on_page(
                                        page,
                                        status_callback=lambda msg: self.status_update.emit(self.profile["id"], msg)
                                    )
                                except Exception:
                                    pass

                                # Handle 2FA if provided
                                if tfa:
                                    self.status_update.emit(self.profile["id"], "Giải 2FA...")
                                    try:
                                        # Handle modern Facebook "Try Another Way" flow
                                        try:
                                            # Look for "Try Another Way" explicitly
                                            page.wait_for_selector('text="Try Another Way"', timeout=8000)
                                            page.locator('text="Try Another Way"').click()
                                            
                                            # We need to wait for the options to render.
                                            # Look for 'Authentication app' or 'Authenticator app'
                                            page.wait_for_timeout(2000)
                                            page.locator('text="Authentication app"').click()
                                            
                                            # Click Continue (Facebook usually uses 'Continue' or 'Submit')
                                            page.locator('text="Continue"').click()
                                        except Exception:
                                            pass
                                            
                                        page.wait_for_timeout(2000)

                                        code = ""
                                        import requests
                                        try:
                                            resp = requests.get(f"https://2fa.live/tok/{tfa.replace(' ', '')}", headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
                                            if resp.status_code == 200:
                                                code = resp.json().get("token", "")
                                        except Exception:
                                            pass
                                            
                                        if code:
                                            # Try classic approvals_code first
                                            if page.locator('input[id="approvals_code"], input[autocomplete="one-time-code"]').first.is_visible(timeout=2000):
                                                page.locator('input[id="approvals_code"], input[autocomplete="one-time-code"]').first.press_sequentially(code, delay=100)
                                                page.wait_for_timeout(500)
                                                if page.locator('button[id="checkpointSubmitButton"]').is_visible(timeout=1000):
                                                    page.click('button[id="checkpointSubmitButton"]')
                                                else:
                                                    page.keyboard.press("Enter")
                                            else:
                                                # Try falling back to writing in the first visible text input
                                                text_inputs = page.locator('input[type="text"], input[type="number"]')
                                                for i in range(text_inputs.count()):
                                                    if text_inputs.nth(i).is_visible():
                                                        text_inputs.nth(i).press_sequentially(code, delay=100)
                                                        page.wait_for_timeout(500)
                                                        page.keyboard.press("Enter")
                                                        break
                                                        
                                        # Ensure we click Continue / Submit / Gửi / Tiếp tục repeatedly up to 3 times to get through
                                        for attempt in range(3):
                                            page.wait_for_timeout(2000)
                                            clicked = False
                                            for text_val in ["Continue", "Tiếp tục", "Submit", "Gửi", "Save Browser", "Lưu trình duyệt", "Don't Save", "Không lưu", "Trust this device", "Tin cậy thiết bị này"]:
                                                for selector in [f'button:has-text("{text_val}")', f'div[role="button"]:has-text("{text_val}")']:
                                                    try:
                                                        loc = page.locator(selector).first
                                                        if loc.is_visible(timeout=500):
                                                            loc.click()
                                                            clicked = True
                                                            break
                                                    except:
                                                        pass
                                                if clicked: break
                                                
                                    except Exception:
                                        pass
                                # === POST LOGIN: Handle Captcha Checkpoints ===
                                try:
                                    # Wait briefly to let potential checkpoints load
                                    page.wait_for_timeout(2000)
                                    
                                    # Detect if it's a Checkpoint page with reCAPTCHA
                                    captcha_iframe = page.locator('iframe[title="reCAPTCHA"], div.g-recaptcha, iframe[src*="recaptcha"]').first
                                    
                                    if captcha_iframe.is_visible(timeout=2000) and omocaptcha_key:
                                        self.status_update.emit(self.profile["id"], "Đang giải Captcha...")
                                        
                                        # 1. Grab SiteKey which might be in div or inside the iframe URL
                                        site_key = None
                                        
                                        # Method A: Try grabbing from data-sitekey attribute directly if it's a div
                                        try:
                                            # Use a very short timeout so it doesn't freeze the whole Checkpoint process
                                            div_loc = page.locator('.g-recaptcha, div[data-sitekey]').first
                                            if div_loc.is_visible(timeout=500):
                                                site_key = div_loc.get_attribute('data-sitekey', timeout=500)
                                        except:
                                            pass
                                            
                                        if not site_key:
                                            # Method B: Parse iframe src
                                            try:
                                                src = captcha_iframe.get_attribute('src', timeout=500)
                                                if src and 'k=' in src:
                                                    import urllib.parse as urlparse
                                                    parsed = urlparse.urlparse(src)
                                                    site_key = urlparse.parse_qs(parsed.query).get('k', [None])[0]
                                            except:
                                                pass
                                                
                                        if site_key:
                                            import requests
                                            import time
                                            
                                            # 2. Request Task Creation
                                            payload = {
                                                "api_token": omocaptcha_key,
                                                "data": {
                                                    "type_job_id": "2", # 2 is usually reCAPTCHA v2 on Omo
                                                    "url_web": page.url,
                                                    "sitekey": site_key
                                                }
                                            }
                                            # Format for OmoCaptcha which uses createTask
                                            resp = requests.post("https://omocaptcha.com/api/createJob", json=payload)
                                            if resp.status_code == 200:
                                                resultData = resp.json()
                                                if not resultData.get("error"):
                                                    job_id = resultData.get("job_id")
                                                    
                                                    # 3. Polling for Result
                                                    solved_token = None
                                                    poll_payload = {
                                                        "api_token": omocaptcha_key,
                                                        "job_id": job_id
                                                    }
                                                    
                                                    # Poll for up to 120 seconds
                                                    for _ in range(24):
                                                        time.sleep(5)
                                                        poll_resp = requests.post("https://omocaptcha.com/api/getJobResult", json=poll_payload)
                                                        if poll_resp.status_code == 200:
                                                            poll_data = poll_resp.json()
                                                            if poll_data.get("status") == "success":
                                                                solved_token = poll_data.get("result")
                                                                break
                                                            elif poll_data.get("status") == "fail" or poll_data.get("error"):
                                                                break # Failed solving
                                                                
                                                    # 4. Inject solved token back to page
                                                    if solved_token:
                                                        self.status_update.emit(self.profile["id"], "Nhúng Captcha Token...")
                                                        try:
                                                            # Inject to standard standard recaptcha forms
                                                            page.evaluate(f'document.getElementById("g-recaptcha-response").innerHTML="{solved_token}";')
                                                            # Also try to fire the callback if one exists, otherwise click the continue button
                                                            page.evaluate("""
                                                                try {
                                                                    var cbs = document.querySelectorAll('.g-recaptcha');
                                                                    if(cbs.length > 0 && cbs[0].dataset.callback) {
                                                                        window[cbs[0].dataset.callback]('""" + solved_token + """');
                                                                    }
                                                                } catch(e) {}
                                                            """)
                                                        except:
                                                            pass
                                                        
                                                        # Click the Submit/Continue Checkpoint button
                                                        page.wait_for_timeout(1000)
                                                        for selector in ['button[name="submit[Continue]"]', 'button:has-text("Continue")', 'button:has-text("Tiếp tục")']:
                                                            btn = page.locator(selector).first
                                                            if btn.is_visible(timeout=500):
                                                                btn.click()
                                                                page.wait_for_timeout(5000) # Wait for review processing
                                                                break
                                except Exception as e:
                                    print("Captcha block error:", e)

                                # === POST LOGIN: Dismiss notification popup if it still appears ===
                                try:
                                    # Dismiss notification popup by clicking Block if it somehow shows
                                    block_loc = page.locator('button:has-text("Block")')
                                    if block_loc.is_visible(timeout=2000):
                                        block_loc.click()
                                except:
                                    pass
                            except Exception:
                                pass # Already logged in or network error
                        
                        # ── Background Info Scraper ──
                        if self.auto_login:
                            try:
                                scraped_data = {}
                                # Give the page a moment to settle
                                page.wait_for_timeout(3000)

                                self.status_update.emit(self.profile["id"], "Kiểm tra Live/Out...")
                                
                                # Try to navigate to profile to check status and scrape info
                                try:
                                    page.goto("https://www.facebook.com/me", timeout=15000)
                                    page.wait_for_timeout(3000)
                                    
                                    # Check if we are actually on a profile page or got redirected to login/checkpoint
                                    current_url = page.url
                                    cp_type, cp_live = self._detect_checkpoint_type(page)
                                    if cp_type:
                                        self.status_update.emit(self.profile["id"], cp_type)
                                        scraped_data["status"] = cp_type
                                        scraped_data["fb_live"] = cp_live or "Checkpoint"
                                    elif "mbasic.facebook" in current_url or "m.facebook" in current_url:
                                        self.status_update.emit(self.profile["id"], "Wall Live")
                                        scraped_data["status"] = "Wall Live"
                                    else:
                                        self.status_update.emit(self.profile["id"], "Wall Live")
                                        scraped_data["status"] = "Wall Live"
                                        
                                        # Scrape Name (Target standard H1s or large text headers)
                                        try:
                                            # Wait for the page content to fully load visually
                                            page.wait_for_selector('h1', timeout=5000)
                                            h1_loc = page.locator('h1').first
                                            if h1_loc.is_visible(timeout=2000):
                                                name_txt = h1_loc.inner_text().strip()
                                                if name_txt: scraped_data["fb_name"] = name_txt
                                        except: pass

                                        # Friends count (Better locator)
                                        try:
                                            # Usually friends are listed as "1.2K Friends" or "500 Người bạn"
                                            # We will try scanning the generic span text
                                            friends_el = page.locator('a[href*="/friends"] span, a[href*="/friends_"] span').all_inner_texts()
                                            for f in friends_el:
                                                if f.strip().replace(',', '').replace('.', '').isdigit() or "K" in f or "M" in f:
                                                    scraped_data["fb_friends"] = f.strip()
                                                    break
                                            if "fb_friends" not in scraped_data:
                                                # Fallback to direct label parsing
                                                lbls = page.locator('a[role="link"]:has-text("friends"), a[role="link"]:has-text("bạn bè")').all_inner_texts()
                                                for lbl in lbls:
                                                    if "friend" in lbl.lower() or "bạn" in lbl.lower():
                                                        parts = lbl.split('\n')
                                                        if len(parts) > 1:
                                                            scraped_data["fb_friends"] = parts[0].strip()
                                                            break
                                        except: pass
                                        
                                        # Gender / Location from Intro (Extended languages)
                                        try:
                                            intro_texts = page.locator('div[data-pagelet*="ProfileTilesFeed"], span[dir="auto"]').all_inner_texts()
                                            for text in intro_texts:
                                                t = text.lower()
                                                if "fb_gender" not in scraped_data:
                                                    if any(x in t for x in ["female", "nữ", "woman", "cô ấy", "chị ấy"]): scraped_data["fb_gender"] = "Nữ"
                                                    elif any(x in t for x in ["male", "nam", "man", "anh ấy", "ông ấy"]): scraped_data["fb_gender"] = "Nam"
                                                if "fb_location" not in scraped_data:
                                                    if any(x in t for x in ["lives in", "sống tại", "đến từ", "from"]): scraped_data["fb_location"] = text.strip()
                                        except: pass
                                        
                                        # Extract Cookies accurately from persistent state
                                        try:
                                            # We need to get all cookies for facebook domains
                                            cookies = self.context.cookies()
                                            cookie_str_parts = []
                                            for ck in cookies:
                                                if "facebook" in ck["domain"] or ck["domain"].endswith("fb.com"):
                                                    cookie_str_parts.append(f"{ck['name']}={ck['value']}")
                                                if ck["name"] == "xs":
                                                    scraped_data["fb_token"] = ck["value"][:20] + "..."
                                            if cookie_str_parts:
                                                scraped_data["fb_cookie"] = "; ".join(cookie_str_parts)
                                        except: pass
                                        
                                        # Extract Graph API Token (EAAB...) via searching the page content or requests
                                        try:
                                            import re
                                            # The EAAB page token is often embedded inside the source code window.__INITIAL_DATA__
                                            content = page.content()
                                            tokens = re.findall(r'EAAB\w+', content)
                                            if tokens:
                                                # Use the longest token found typically
                                                best_token = max(tokens, key=len)
                                                scraped_data["fb_token"] = best_token
                                        except: pass

                                except Exception as e:
                                    self.status_update.emit(self.profile["id"], "Wall Out")
                                    scraped_data["status"] = "Wall Out"

                                if scraped_data:
                                    self.info_ready.emit(self.profile["id"], scraped_data)
                            except Exception:
                                pass # Scraper failed silently
                    else:
                        try:
                            page.goto(startup_url)
                        except:
                            pass
                except Exception:
                    pass
                
                # Keep the thread alive until ALL pages/context are closed by the user
                # UNLESS close_chrome_after_login is enabled and we did an auto_login
                if not self.headless:
                    if close_after_login and self.auto_login:
                        # Auto-close after login/set cookie completed
                        try:
                            self.status_update.emit(self.profile["id"], "Tự động đóng browser...")
                            import time as _time
                            _time.sleep(2)
                            self.context.close()
                        except:
                            pass
                    else:
                        try:
                            # Wait for all pages to close one-by-one (user closes the browser)
                            while self.context.pages:
                                self.context.pages[0].wait_for_event("close")
                        except Exception:
                            pass
                else:
                    # Headless: auto-close context after automation completes
                    try:
                        self.context.close()
                    except:
                        pass

        except Exception as e:
            try:
                self.error_signal.emit(self.profile["id"], str(e))
            except:
                pass
        finally:
            self.is_running = False
            # Safely close context if still open
            try:
                if self.context:
                    self.context.close()
            except:
                pass
            self.context = None
            # Always emit finished signal so main thread cleans up
            try:
                self.finished_signal.emit(self.profile["id"])
            except:
                pass

class BrowserManager:
    def __init__(self):
        self.running_threads = {}

    def get_user_data_dir(self, profile):
        from ui.settings_dialog import load_settings
        settings = load_settings()
        base_path = settings.get("chrome_profile_base_path", "")
        if not base_path:
            base_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
            base_path = os.path.join(base_dir, "data", "browser_profiles")
        return os.path.join(base_path, profile["id"])

    def launch_browser(self, profile, on_finished, on_error, auto_login=False, headless=False, action="launch"):
        profile_id = profile["id"]
        if profile_id in self.running_threads and self.running_threads[profile_id].isRunning():
            return False # Already running
        
        # Use global thread-safe counter for grid position
        global _browser_pos_counter
        with _browser_pos_lock:
            pos_index = _browser_pos_counter
            _browser_pos_counter += 1
        
        thread = BrowserThread(profile, auto_login, headless, action=action, pos_index=pos_index)
        thread.finished_signal.connect(on_finished)
        thread.error_signal.connect(on_error)
        
        self.running_threads[profile_id] = thread
        thread.start()
        return True

    def close_browser(self, profile_id):
        if profile_id in self.running_threads:
            thread = self.running_threads[profile_id]
            if thread.isRunning():
                # Setting a flag or forcefully terminating
                thread.terminate() # Forceful QThread termination to close browser instantly
                self.running_threads.pop(profile_id, None)
            return True
        return False

    def get_cookie_from_chrome(self, profile_id):
        if profile_id in self.running_threads:
            thread = self.running_threads[profile_id]
            if thread.isRunning() and thread.context:
                try:
                    cookies = thread.context.cookies()
                    cookie_str_parts = []
                    for ck in cookies:
                        if "facebook" in ck["domain"] or ck["domain"].endswith("fb.com"):
                            cookie_str_parts.append(f"{ck['name']}={ck['value']}")
                            
                    if cookie_str_parts:
                        full_cookie = "; ".join(cookie_str_parts)
                        # Save directly via ProfileManager
                        from core.profile_manager import ProfileManager
                        pm = ProfileManager()
                        pm.update_profile(profile_id, {"fb_cookie": full_cookie})
                except Exception:
                    pass

    def set_cookie_to_chrome(self, profile_id):
        if profile_id in self.running_threads:
            thread = self.running_threads[profile_id]
            if thread.isRunning() and thread.context:
                from core.profile_manager import ProfileManager
                pm = ProfileManager()
                profile = pm.get_profile(profile_id)
                cookie_str = profile.get("fb_cookie", "") if profile else ""
                
                if cookie_str:
                    try:
                        valid_cookies = []
                        parts = cookie_str.split(';')
                        for p in parts:
                            if '=' in p:
                                k, v = p.strip().split('=', 1)
                                valid_cookies.append({
                                    "name": k,
                                    "value": v,
                                    "domain": ".facebook.com",
                                    "path": "/"
                                })
                        if valid_cookies:
                            thread.context.add_cookies(valid_cookies)
                            # If pages exist, refresh the first one
                            if thread.context.pages:
                                thread.context.pages[0].reload()
                    except Exception as e:
                        print("Set cookie error:", e)

    def clear_cache_profile(self, profile_id):
        # We must close it first
        self.close_browser(profile_id)
        
        from core.profile_manager import ProfileManager
        pm = ProfileManager()
        profile = pm.get_profile(profile_id)
        if not profile: return
        
        user_data_dir = self.get_user_data_dir(profile)
        if os.path.exists(user_data_dir):
            import shutil
            # Delete cache folders inside Default
            dirs_to_clear = [
                os.path.join(user_data_dir, "Default", "Cache"),
                os.path.join(user_data_dir, "Default", "Code Cache"),
                os.path.join(user_data_dir, "Default", "GPUCache"),
                os.path.join(user_data_dir, "GrShaderCache")
            ]
            for d in dirs_to_clear:
                if os.path.exists(d):
                    try: shutil.rmtree(d, ignore_errors=True)
                    except: pass

    def delete_chrome_profile(self, profile_id):
        self.close_browser(profile_id)
        
        from core.profile_manager import ProfileManager
        pm = ProfileManager()
        profile = pm.get_profile(profile_id)
        if not profile: return
        
        user_data_dir = self.get_user_data_dir(profile)
        if os.path.exists(user_data_dir):
            import shutil
            try:
                shutil.rmtree(user_data_dir, ignore_errors=True)
            except:
                pass
