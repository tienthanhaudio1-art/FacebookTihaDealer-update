"""
CopyableTable — QTableWidget subclass that supports:
- Drag-to-select cells in a column (or across columns)
- Ctrl+C copies selected cell text (each row on new line)
- Uses viewport event filter for proper coordinate mapping
"""
from PyQt6.QtWidgets import QTableWidget, QApplication, QTableWidgetSelectionRange
from PyQt6.QtCore import Qt, QObject, QEvent, QPointF
from PyQt6.QtGui import QKeySequence


class CopyableTable(QTableWidget):
    """QTableWidget with drag cell selection and Ctrl+C copy."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
        self.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectItems)
        self._drag_start = None  # (row, col) of drag start
        self._is_dragging = False
        # Install event filter on the viewport — this is where mouse events
        # actually happen in QAbstractScrollArea subclasses
        self.viewport().installEventFilter(self)

    def eventFilter(self, obj, event):
        """Intercept mouse events on the viewport for proper drag selection."""
        if obj is self.viewport():
            if event.type() == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                pos = event.position().toPoint()
                idx = self.indexAt(pos)
                if idx.isValid():
                    # Skip column 0 (checkbox column) - let default handler work
                    if idx.column() == 0:
                        return False
                    self._drag_start = (idx.row(), idx.column())
                    self._is_dragging = True
                    self.clearSelection()
                    self.setRangeSelected(
                        QTableWidgetSelectionRange(idx.row(), idx.column(), idx.row(), idx.column()),
                        True
                    )
                    return True  # Consume event

            elif event.type() == QEvent.Type.MouseMove and self._is_dragging and self._drag_start:
                pos = event.position().toPoint()
                idx = self.indexAt(pos)
                if idx.isValid():
                    sr, sc = self._drag_start
                    er, ec = idx.row(), idx.column()
                    self.clearSelection()
                    self.setRangeSelected(
                        QTableWidgetSelectionRange(
                            min(sr, er), min(sc, ec),
                            max(sr, er), max(sc, ec)
                        ),
                        True
                    )
                return True  # Consume event

            elif event.type() == QEvent.Type.MouseButtonRelease and event.button() == Qt.MouseButton.LeftButton:
                if self._is_dragging:
                    self._is_dragging = False
                    return True  # Consume event

        return super().eventFilter(obj, event)

    def keyPressEvent(self, event):
        """Handle Ctrl+C to copy selected cell content."""
        if event.matches(QKeySequence.StandardKey.Copy):
            self._copy_selection()
            return
        super().keyPressEvent(event)

    def _get_cell_text(self, row, col):
        """Get text from a cell using multiple fallback methods."""
        item = self.item(row, col)
        if item is not None:
            return item.text()
        try:
            idx = self.model().index(row, col)
            data = self.model().data(idx)
            if data is not None:
                return str(data)
        except Exception:
            pass
        widget = self.cellWidget(row, col)
        if widget is not None and hasattr(widget, 'text'):
            return widget.text()
        return ""

    def _copy_selection(self):
        """Copy selected cells to clipboard.
        Single column: one value per line
        Multiple columns: tab-separated
        """
        selected = self.selectedIndexes()
        if not selected:
            return

        selected.sort(key=lambda idx: (idx.row(), idx.column()))

        rows = {}
        for idx in selected:
            r, c = idx.row(), idx.column()
            if r not in rows:
                rows[r] = {}
            rows[r][c] = self._get_cell_text(r, c)

        lines = []
        for r in sorted(rows.keys()):
            cols = rows[r]
            sorted_cols = sorted(cols.keys())
            line = "\t".join(cols[c] for c in sorted_cols)
            if line.strip():
                lines.append(line)

        text = "\n".join(lines)
        if text:
            clipboard = QApplication.clipboard()
            if clipboard:
                clipboard.setText(text)
