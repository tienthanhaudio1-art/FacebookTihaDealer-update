import json
import os
from ui.copyable_table import CopyableTable
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QDialog, QFormLayout, QLineEdit,
    QDialogButtonBox, QLabel, QMessageBox, QTabWidget, QTextEdit, QMenu,
    QComboBox, QSpinBox, QCheckBox, QInputDialog, QScrollArea, QApplication
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, pyqtSlot
from PyQt6.QtGui import QColor
from core.i18n import tr
from core.email_manager import GlobalEmailManager

# ─── Column definitions for email table ───
EMAIL_COLUMNS = [
    ("chk",             ""),
    ("stt",             "STT"),
    ("uid",             "UID"),
    ("email",           "Email"),
    ("pass_email",      "Pass Email"),
    ("email_recovery",  "Email Recovery"),
    ("pass_em",         "PassEm"),
    ("live",            "Live"),
    ("category",        "Danh mục"),
    ("note",            "Ghi Chú"),
    ("status",          "Trạng thái"),
    ("proxy",           "Proxy"),
    ("token_hotmail",   "Token Hotmail"),
]


# ═══════════════════════════════════════════
#  IMAP Check Thread
# ═══════════════════════════════════════════
class ImapCheckThread(QThread):
    status_update = pyqtSignal(str, str)  # email_id, status_message
    finished_one = pyqtSignal(str)         # email_id
    finished_all = pyqtSignal()

    def __init__(self, emails_to_check: list):
        super().__init__()
        self.emails = emails_to_check
        self._running = True

    def run(self):
        import imaplib
        for rec in self.emails:
            if not self._running:
                break

            eid = rec.get("id", "")
            email_addr = rec.get("email", "")
            password = rec.get("pass_email", "")

            if not email_addr or not password:
                self.status_update.emit(eid, "Thiếu thông tin")
                self.finished_one.emit(eid)
                continue

            # Detect IMAP server
            domain = email_addr.split("@")[-1].lower() if "@" in email_addr else ""
            if "hotmail" in domain or "outlook" in domain or "live" in domain:
                imap_server = "imap-mail.outlook.com"
            elif "gmail" in domain or "google" in domain:
                imap_server = "imap.gmail.com"
            elif "yahoo" in domain:
                imap_server = "imap.mail.yahoo.com"
            else:
                imap_server = f"imap.{domain}"

            try:
                mail = imaplib.IMAP4_SSL(imap_server, 993, timeout=30)
                mail.login(email_addr, password)
                mail.logout()
                self.status_update.emit(eid, f"Login thành công email qua imap")
            except imaplib.IMAP4.error:
                self.status_update.emit(eid, "Sai pass / Bị khóa")
            except Exception as e:
                err = str(e)[:60]
                self.status_update.emit(eid, f"Lỗi: {err}")

            self.finished_one.emit(eid)

        self.finished_all.emit()

    def stop(self):
        self._running = False


# ═══════════════════════════════════════════
#  Import Email Dialog
# ═══════════════════════════════════════════
class ImportEmailDialog(QDialog):
    def __init__(self, parent=None, categories=None):
        super().__init__(parent)
        self.setWindowTitle("Import - Export Via")
        self.resize(800, 500)
        self.categories = categories or ["Mới"]

        layout = QVBoxLayout(self)

        # Category
        cat_row = QHBoxLayout()
        cat_row.addWidget(QLabel("Chọn danh mục"))
        self.combo_cat = QComboBox()
        self.combo_cat.addItems(self.categories)
        cat_row.addWidget(self.combo_cat)
        cat_row.addStretch()
        layout.addLayout(cat_row)

        # Format preset
        fmt_row = QHBoxLayout()
        fmt_row.addWidget(QLabel("Định dạng nhập"))
        self.combo_fmt = QComboBox()
        self.combo_fmt.addItem("All định dạng", [])
        self.combo_fmt.addItem("UID|PASS|2FA|Email|Pass Email|Mail Recovery|Cookie|Proxy|UserAgent",
                               ["uid", "fb_pass", "fb_2fa", "email", "pass_email", "email_recovery", "cookie", "proxy", "user_agent"])
        self.combo_fmt.addItem("UID|Email|Pass Email", ["uid", "email", "pass_email"])
        self.combo_fmt.addItem("Email|Pass Email", ["email", "pass_email"])
        self.combo_fmt.currentIndexChanged.connect(self._on_format_changed)
        fmt_row.addWidget(self.combo_fmt)
        fmt_row.addStretch()
        layout.addLayout(fmt_row)

        # Column mapping combos
        field_options = [
            ("Bỏ qua", ""),
            ("UID", "uid"),
            ("PASS", "fb_pass"),
            ("2FA", "fb_2fa"),
            ("Email", "email"),
            ("Pass Email", "pass_email"),
            ("Mail Reco", "email_recovery"),
            ("Proxy", "proxy"),
            ("Cookie", "cookie"),
            ("UserAgen", "user_agent"),
            ("Token", "token_hotmail"),
            ("Client ID", "client_id"),
            ("Birthday", "birthday"),
            ("UID large", "uid_large"),
            ("Note", "note"),
            ("Friend", "friend"),
            ("Ngày tạo", "created_date"),
            ("Email Old", "email_old"),
            ("Gender", "gender"),
        ]
        self.mapping_combos = []
        map_layout = QHBoxLayout()
        map_layout.setSpacing(2)
        for i in range(18):
            cb = QComboBox()
            for lbl, key in field_options:
                cb.addItem(lbl, key)
            cb.setFixedWidth(90)
            self.mapping_combos.append(cb)
            map_layout.addWidget(cb)
            if i < 17:
                sep = QLabel("|")
                sep.setFixedWidth(10)
                sep.setAlignment(Qt.AlignmentFlag.AlignCenter)
                map_layout.addWidget(sep)
        map_layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(55)
        scroll.setStyleSheet("QScrollArea { border: none; }")
        map_container = QWidget()
        map_container.setLayout(map_layout)
        scroll.setWidget(map_container)
        layout.addWidget(scroll)

        # Auto-detect label
        self.auto_detect_lbl = QLabel("")
        self.auto_detect_lbl.setStyleSheet("color: #0078d7; font-size: 11px; font-weight: bold; padding: 2px;")
        self.auto_detect_lbl.setWordWrap(True)
        layout.addWidget(self.auto_detect_lbl)

        # Text area
        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText("Dán thông tin email vào đây, chia cách bởi dấu '|'...")
        self.text_edit.textChanged.connect(self._auto_detect_format)
        layout.addWidget(self.text_edit)

        # Bottom
        bottom = QHBoxLayout()
        btn_ok = QPushButton("OK")
        btn_ok.setMinimumWidth(120)
        btn_ok.setStyleSheet("background-color: #409eff; color: white; font-weight: bold; border-radius: 4px; padding: 8px;")
        btn_ok.clicked.connect(self.accept)
        self.chk_no_ua = QCheckBox("Không lấy UserAgent từ cookie")
        self.chk_no_ua.setChecked(True)
        self.combo_ua = QComboBox()
        self.combo_ua.addItems(["Random UserAgent Chrome Android", "Random UserAgent Chrome Windows"])

        bottom.addWidget(btn_ok)
        bottom.addSpacing(20)
        bottom.addWidget(self.chk_no_ua)
        bottom.addWidget(self.combo_ua)
        bottom.addStretch()
        layout.addLayout(bottom)

        self._on_format_changed(0)

    def _on_format_changed(self, idx):
        keys = self.combo_fmt.currentData() or []
        for cb in self.mapping_combos:
            cb.setCurrentIndex(0)
        for i, key in enumerate(keys):
            if i < len(self.mapping_combos):
                idx_found = self.mapping_combos[i].findData(key)
                if idx_found >= 0:
                    self.mapping_combos[i].setCurrentIndex(idx_found)

    def _auto_detect_format(self):
        """Auto-detect format from first non-empty line and set mapping combos."""
        text = self.text_edit.toPlainText().strip()
        if not text:
            self.auto_detect_lbl.setText("")
            return

        first_line = ""
        for line in text.split("\n"):
            if line.strip():
                first_line = line.strip()
                break
        if not first_line:
            return

        parts = first_line.split("|")
        num_parts = len(parts)

        # Heuristic detection patterns
        import re as _re

        def looks_like_email(s):
            return "@" in s and "." in s

        def looks_like_uid(s):
            return s.strip().isdigit() and len(s.strip()) >= 5

        def looks_like_cookie(s):
            return "=" in s and (";" in s or len(s) > 50)

        def looks_like_token(s):
            return len(s.strip()) > 30 and not looks_like_cookie(s)

        def looks_like_proxy(s):
            s = s.strip()
            # ip:port or socks5://ip:port or user:pass@ip:port
            if _re.match(r'^(socks[45]|https?)://', s, _re.IGNORECASE):
                return True
            if _re.match(r'^\d+\.\d+\.\d+\.\d+:\d+', s):
                return True
            return False

        def looks_like_2fa(s):
            s = s.strip()
            return len(s) >= 16 and len(s) <= 40 and s.isalnum()

        def looks_like_password(s):
            return 4 <= len(s.strip()) <= 64 and not looks_like_cookie(s) and not looks_like_token(s)

        def looks_like_client_id(s):
            s = s.strip()
            return bool(_re.match(r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$', s, _re.IGNORECASE))

        # Try to detect each column
        detected_keys = []
        detected_names = []

        for i, part in enumerate(parts):
            p = part.strip()
            if not p:
                detected_keys.append("")
                detected_names.append("Bỏ qua")
                continue

            if looks_like_email(p):
                if "email" not in detected_keys:
                    detected_keys.append("email")
                    detected_names.append("Email")
                elif "email_recovery" not in detected_keys:
                    detected_keys.append("email_recovery")
                    detected_names.append("Mail Recovery")
                else:
                    detected_keys.append("")
                    detected_names.append("Bỏ qua")
            elif looks_like_uid(p):
                if "uid" not in detected_keys:
                    detected_keys.append("uid")
                    detected_names.append("UID")
                else:
                    detected_keys.append("")
                    detected_names.append("Bỏ qua")
            elif looks_like_cookie(p):
                detected_keys.append("cookie")
                detected_names.append("Cookie")
            elif looks_like_proxy(p):
                detected_keys.append("proxy")
                detected_names.append("Proxy")
            elif looks_like_client_id(p):
                if "client_id" not in detected_keys:
                    detected_keys.append("client_id")
                    detected_names.append("Client ID")
                else:
                    detected_keys.append("")
                    detected_names.append("B\u1ecf qua")
            elif looks_like_token(p):
                detected_keys.append("token_hotmail")
                detected_names.append("Token")
            elif looks_like_2fa(p):
                if "fb_2fa" not in detected_keys:
                    detected_keys.append("fb_2fa")
                    detected_names.append("2FA")
                else:
                    detected_keys.append("")
                    detected_names.append("Bỏ qua")
            elif looks_like_password(p):
                if "pass_email" not in detected_keys:
                    detected_keys.append("pass_email")
                    detected_names.append("Pass Email")
                elif "fb_pass" not in detected_keys:
                    detected_keys.append("fb_pass")
                    detected_names.append("PASS")
                else:
                    detected_keys.append("")
                    detected_names.append("Bỏ qua")
            else:
                detected_keys.append("")
                detected_names.append("Bỏ qua")

        # Apply detected mappings to combos
        for cb in self.mapping_combos:
            cb.setCurrentIndex(0)  # Reset all
        for i, key in enumerate(detected_keys):
            if i < len(self.mapping_combos) and key:
                idx_found = self.mapping_combos[i].findData(key)
                if idx_found >= 0:
                    self.mapping_combos[i].setCurrentIndex(idx_found)

        # Show detection result
        total_lines = len([l for l in text.split("\n") if l.strip()])
        fmt_str = " | ".join(detected_names[:num_parts])
        self.auto_detect_lbl.setText(f"📡 Tự nhận dạng {num_parts} cột, {total_lines} dòng: {fmt_str}")

    def get_parsed_data(self):
        text = self.text_edit.toPlainText().strip()
        if not text:
            return None, []

        category = self.combo_cat.currentText()
        mappings = [cb.currentData() for cb in self.mapping_combos]

        results = []
        for line in text.split('\n'):
            line = line.strip()
            if not line:
                continue
            parts = line.split('|')
            record = {"category": category}
            for i, part in enumerate(parts):
                if i < len(mappings) and mappings[i]:
                    record[mappings[i]] = part.strip()
            # Merge token + client_id into combined format: TOKEN|CLIENT_ID
            if record.get("client_id") and record.get("token_hotmail"):
                record["token_hotmail"] = f'{record["token_hotmail"]}|{record["client_id"]}'
            elif record.get("client_id") and not record.get("token_hotmail"):
                pass  # client_id alone is useless without token
            record.pop("client_id", None)
            if record.get("email") or record.get("uid"):
                results.append(record)
        return category, results


# ═══════════════════════════════════════════
#  Main Email Manager Widget
# ═══════════════════════════════════════════
class EmailManagerWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.em = GlobalEmailManager()
        self.imap_threads = []
        self._current_category = "Tất cả"
        self._init_ui()
        self.load_data()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(6, 6, 6, 0)
        main_layout.setSpacing(4)

        # ── Sub-Tabs ──
        self.sub_tabs = QTabWidget()
        
        # Tab 1: Email List (main)
        self.email_list_tab = QWidget()
        self._build_email_list_tab()
        self.sub_tabs.addTab(self.email_list_tab, "Danh sách Email")
        
        # Tab 2: Send Email (placeholder)
        send_tab = QWidget()
        send_layout = QVBoxLayout(send_tab)
        send_layout.addWidget(QLabel("Gởi Email — Tính năng đang phát triển"))
        send_layout.addStretch()
        self.sub_tabs.addTab(send_tab, "Gởi Email")
        
        # Tab 3: Got Code From Email (placeholder)
        code_tab = QWidget()
        code_layout = QVBoxLayout(code_tab)
        code_layout.addWidget(QLabel("Got Code From Email — Tính năng đang phát triển"))
        code_layout.addStretch()
        self.sub_tabs.addTab(code_tab, "Got Code From Email")

        main_layout.addWidget(self.sub_tabs, 1)

        # ── Status Bar ──
        status_bar = QWidget()
        status_bar.setStyleSheet("background: #1a202c; border-top: 1px solid #4a5568; padding: 4px 10px;")
        status_layout = QHBoxLayout(status_bar)
        status_layout.setContentsMargins(10, 2, 10, 2)
        self.lbl_total = QLabel("Tổng số Email: 0")
        self.lbl_selected = QLabel("Tích Chọn: 0")
        self.lbl_total.setStyleSheet("color: #f7fafc;")
        self.lbl_selected.setStyleSheet("color: #f7fafc;")
        status_layout.addWidget(self.lbl_total)
        status_layout.addSpacing(20)
        status_layout.addWidget(self.lbl_selected)
        status_layout.addStretch()
        main_layout.addWidget(status_bar, 0)

    def _build_email_list_tab(self):
        layout = QVBoxLayout(self.email_list_tab)
        layout.setContentsMargins(6, 6, 6, 0)
        layout.setSpacing(4)

        BTN_H = 30

        def make_btn(label, obj_name=None, min_w=90):
            b = QPushButton(label)
            if obj_name:
                b.setObjectName(obj_name)
            b.setMinimumWidth(min_w)
            b.setFixedHeight(BTN_H)
            return b

        # ───── Row 1: Action Buttons ─────
        row1 = QHBoxLayout()
        row1.setSpacing(4)

        self.btn_load_email = make_btn("Import Email", "PrimaryBtn", 100)
        self.btn_check_status = make_btn("Check Status", "PrimaryBtn", 100)
        self.btn_open_browser = make_btn("Open Profile", "PrimaryBtn", 100)
        self.btn_find_email = make_btn("Find Email", "PrimaryBtn", 90)
        self.btn_refresh = make_btn("Refresh", None, 80)
        self.btn_refresh.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #166534, stop:1 #14532d);
                border: 1px solid #22c55e;
                border-radius: 5px;
                color: #bbf7d0;
                font-weight: 700;
                font-size: 11px;
            }
            QPushButton:hover {
                background: #22c55e;
                color: #052e16;
            }
        """)

        self.btn_load_email.clicked.connect(self._load_email)
        self.btn_check_status.clicked.connect(self._check_status_all)
        self.btn_open_browser.clicked.connect(self._open_browser_selected)
        self.btn_find_email.clicked.connect(self._find_email)
        self.btn_refresh.clicked.connect(self.load_data)

        row1.addWidget(self.btn_load_email)
        row1.addWidget(self.btn_check_status)
        row1.addWidget(self.btn_open_browser)
        row1.addWidget(self.btn_find_email)
        row1.addWidget(self.btn_refresh)
        row1.addStretch()
        layout.addLayout(row1)

        # ───── Row 2: Folder Management ─────
        row2 = QHBoxLayout()
        row2.setSpacing(4)

        lbl_folder = QLabel("Quản lý Thư mục")
        lbl_folder.setStyleSheet("font-weight: bold;")
        self.combo_category = QComboBox()
        self.combo_category.setMinimumWidth(140)
        self.combo_category.setFixedHeight(BTN_H)
        self.combo_category.currentTextChanged.connect(self._on_category_changed)

        self.btn_add_cat = make_btn("Add", "PrimaryBtn", 50)
        self.btn_edit_cat = make_btn("Edit", None, 48)
        self.btn_delete_cat = make_btn("Delete", "DeleteBtn", 55)
        self.btn_move_cat = make_btn("Move", None, 55)

        self.btn_add_cat.clicked.connect(self._add_category)
        self.btn_edit_cat.clicked.connect(self._edit_category)
        self.btn_delete_cat.clicked.connect(self._delete_category)
        self.btn_move_cat.clicked.connect(self._move_to_category)

        lbl_threads = QLabel("Số luồng")
        self.spin_threads = QSpinBox()
        self.spin_threads.setRange(1, 100)
        self.spin_threads.setValue(10)
        self.spin_threads.setFixedWidth(60)
        self.spin_threads.setFixedHeight(BTN_H)

        row2.addWidget(lbl_folder)
        row2.addWidget(self.combo_category)
        row2.addWidget(self.btn_add_cat)
        row2.addWidget(self.btn_edit_cat)
        row2.addWidget(self.btn_delete_cat)
        row2.addWidget(self.btn_move_cat)
        row2.addSpacing(15)
        row2.addWidget(lbl_threads)
        row2.addWidget(self.spin_threads)
        row2.addStretch()
        layout.addLayout(row2)

        # ───── Table ─────
        self.table = CopyableTable()
        self.table.setAlternatingRowColors(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.DoubleClicked)
        self.table.verticalHeader().setVisible(False)
        self.table.cellChanged.connect(self._on_cell_changed)

        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._context_menu)

        # Spacebar toggle override
        self.table.keyPressEvent = self._table_key_press_event

        self._setup_columns()
        layout.addWidget(self.table)

    def _setup_columns(self):
        self.table.setColumnCount(len(EMAIL_COLUMNS))
        headers = [col[1] for col in EMAIL_COLUMNS]
        self.table.setHorizontalHeaderLabels(headers)

        # Select-all checkbox
        self._select_all_chk = QCheckBox(self.table.horizontalHeader())
        self._select_all_chk.setTristate(False)
        self._select_all_chk.stateChanged.connect(self._toggle_select_all)
        self._select_all_chk.setStyleSheet("QCheckBox::indicator { width: 14px; height: 14px; }")

        header = self.table.horizontalHeader()
        header.setMinimumSectionSize(24)
        header.setSectionsMovable(True)

        # 3-step sort
        self.sort_states = {}
        self.current_sort_col = -1
        header.sectionClicked.connect(self._on_header_clicked)

        # Column widths
        self.table.setColumnWidth(0, 30)   # chk
        self.table.setColumnWidth(1, 40)   # stt
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)

        for i, (key, label) in enumerate(EMAIL_COLUMNS):
            if key in ["chk", "stt"]:
                continue
            header.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            if key == "uid":
                self.table.setColumnWidth(i, 130)
            elif key == "email":
                self.table.setColumnWidth(i, 180)
            elif key in ["status"]:
                self.table.setColumnWidth(i, 210)
            elif key in ["token_hotmail", "proxy"]:
                self.table.setColumnWidth(i, 130)
            else:
                self.table.setColumnWidth(i, 90)

        self._reposition_select_all()

    def _reposition_select_all(self):
        header = self.table.horizontalHeader()
        x = header.sectionPosition(0)
        w = header.sectionSize(0)
        h = header.height()
        chk_w, chk_h = 16, 16
        self._select_all_chk.setGeometry(x + (w - chk_w) // 2, (h - chk_h) // 2, chk_w, chk_h)
        self._select_all_chk.raise_()
        self._select_all_chk.show()

    def _toggle_select_all(self, state):
        checked = state == 2
        self.table.blockSignals(True)
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item:
                item.setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
        self.table.blockSignals(False)
        self._update_status_bar()

    # ─── Data Loading ───

    def load_data(self):
        self.table.blockSignals(True)
        self.table.setRowCount(0)

        # Refresh categories
        self._refresh_categories()

        emails = self.em.get_all_emails(category=self._current_category)

        # Apply sorting if active
        if self.current_sort_col > 0:
            sort_key_name = EMAIL_COLUMNS[self.current_sort_col][0]
            sort_state = self.sort_states.get(self.current_sort_col, 0)
            if sort_state in (1, 2):
                reverse = (sort_state == 2)
                def sort_key(rec):
                    val = str(rec.get(sort_key_name, ""))
                    num = self._parse_numeric_for_sort(val)
                    if num != -999999999:
                        return (0, num, val.lower())
                    return (1, 0, val.lower())
                emails = sorted(emails, key=sort_key, reverse=reverse)

        for row_idx, rec in enumerate(emails):
            self.table.insertRow(row_idx)

            status_str = rec.get("status", "").lower()
            live_val = rec.get("live", "").lower()

            # Row colors  (brighter dark theme)
            row_bg = QColor("#243352")  # Default dark blue
            row_fg = QColor("#f7fafc")
            if "live" in live_val:
                row_bg = QColor("#243352")
                row_fg = QColor("#68d391")  # Green text for live
            elif "out" in live_val or "dead" in live_val:
                row_bg = QColor("#4a3c00")  # Dark amber
                row_fg = QColor("#fbd38d")  # Amber text
            elif "thành công" in status_str:
                row_bg = QColor("#244838")  # Dark green
                row_fg = QColor("#68d391")
            elif "sai pass" in status_str or "khóa" in status_str or "lỗi" in status_str:
                row_bg = QColor("#4a2020")  # Dark red
                row_fg = QColor("#fc8181")  # Red text

            for col_idx, (key, label) in enumerate(EMAIL_COLUMNS):
                item = None
                if key == "chk":
                    item = QTableWidgetItem()
                    item.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                    item.setCheckState(Qt.CheckState.Unchecked)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                elif key == "stt":
                    item = QTableWidgetItem(str(row_idx + 1))
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                else:
                    val = str(rec.get(key, ""))
                    item = QTableWidgetItem(val)

                if item:
                    item.setBackground(row_bg)
                    item.setForeground(row_fg)
                    self.table.setItem(row_idx, col_idx, item)

        self.table.blockSignals(False)
        self._reposition_select_all()
        self._select_all_chk.blockSignals(True)
        self._select_all_chk.setCheckState(Qt.CheckState.Unchecked)
        self._select_all_chk.blockSignals(False)
        self._update_status_bar()

    def _refresh_categories(self):
        self.combo_category.blockSignals(True)
        current = self.combo_category.currentText()
        self.combo_category.clear()
        self.combo_category.addItem("Tất cả")
        for cat in self.em.get_categories():
            self.combo_category.addItem(cat)
        idx = self.combo_category.findText(current)
        if idx >= 0:
            self.combo_category.setCurrentIndex(idx)
        self.combo_category.blockSignals(False)

    def _update_status_bar(self):
        total = self.table.rowCount()
        selected = len(self._get_checked_ids())
        self.lbl_total.setText(f"Tổng số Email  {total}")
        self.lbl_selected.setText(f"Tích Chọn  {selected}")

    # ─── Helpers ───

    def _get_email_at_row(self, row):
        emails = self.em.get_all_emails(category=self._current_category)
        if 0 <= row < len(emails):
            return emails[row]
        return None

    def _get_checked_ids(self):
        ids = []
        emails = self.em.get_all_emails(category=self._current_category)
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item and item.checkState() == Qt.CheckState.Checked:
                if row < len(emails):
                    ids.append(emails[row].get("id"))
        return ids

    # ─── Slots ───

    def _on_category_changed(self, text):
        self._current_category = text
        self.load_data()

    def _on_cell_changed(self, row, col):
        if row < 0 or col < 0:
            return
        key = EMAIL_COLUMNS[col][0]
        if key in ["chk", "stt"]:
            self._update_status_bar()
            return
        new_val = self.table.item(row, col).text()
        rec = self._get_email_at_row(row)
        if rec:
            self.em.update_email(rec["id"], {key: new_val})

    def _table_key_press_event(self, event):
        """Spacebar toggles checkboxes for selected rows."""
        from PyQt6.QtGui import QKeySequence
        if event.matches(QKeySequence.StandardKey.Copy):
            self.table._copy_selection()
            return
        if event.key() == Qt.Key.Key_Space:
            selected_items = self.table.selectedItems()
            if not selected_items:
                return
            selected_rows = set(item.row() for item in selected_items)
            self.table.blockSignals(True)
            for row in selected_rows:
                chk_item = self.table.item(row, 0)
                if chk_item:
                    current = chk_item.checkState()
                    new_state = Qt.CheckState.Unchecked if current == Qt.CheckState.Checked else Qt.CheckState.Checked
                    chk_item.setCheckState(new_state)
            self.table.blockSignals(False)
            self._update_status_bar()
            event.accept()
        else:
            QTableWidget.keyPressEvent(self.table, event)

    def _on_header_clicked(self, logicalIndex):
        """3-state sort: None -> Asc -> Desc -> None"""
        if logicalIndex == 0:
            return
        for idx in list(self.sort_states.keys()):
            if idx != logicalIndex:
                self.sort_states[idx] = 0
        current_state = self.sort_states.get(logicalIndex, 0)
        new_state = (current_state + 1) % 3
        self.sort_states[logicalIndex] = new_state
        self.current_sort_col = logicalIndex if new_state != 0 else -1
        self.load_data()

    def _parse_numeric_for_sort(self, val_str):
        import re
        val_str = str(val_str).lower().strip()
        if not val_str:
            return -999999999
        multiplier = 1
        if 'k' in val_str: multiplier = 1000
        elif 'm' in val_str: multiplier = 1000000
        num_match = re.search(r'([\d,.]+)', val_str)
        if num_match:
            try:
                num_str = num_match.group(1).replace(',', '.')
                parts = num_str.split('.')
                if len(parts) > 2: num_str = parts[0] + '.' + ''.join(parts[1:])
                return float(num_str) * multiplier
            except ValueError:
                pass
        return -999999999

    def _load_email(self):
        cats = self.em.get_categories()
        dlg = ImportEmailDialog(self, categories=cats)
        if dlg.exec():
            category, parsed = dlg.get_parsed_data()
            if not parsed:
                return
            count = 0
            for rec in parsed:
                cat = rec.pop("category", category)
                self.em.add_email(
                    email=rec.get("email", ""),
                    password=rec.get("pass_email", ""),
                    recovery=rec.get("email_recovery", ""),
                    uid=rec.get("uid", ""),
                    category=cat,
                    pass_em=rec.get("pass_em", ""),
                    proxy=rec.get("proxy", ""),
                    token_hotmail=rec.get("token_hotmail", ""),
                    note=rec.get("note", ""),
                    fb_pass=rec.get("fb_pass", ""),
                    fb_2fa=rec.get("fb_2fa", ""),
                    cookie=rec.get("cookie", ""),
                    user_agent=rec.get("user_agent", ""),
                    birthday=rec.get("birthday", ""),
                    uid_large=rec.get("uid_large", ""),
                    friend=rec.get("friend", ""),
                    created_date=rec.get("created_date", ""),
                    email_old=rec.get("email_old", ""),
                    gender=rec.get("gender", "")
                )
                count += 1
            self.load_data()
            QMessageBox.information(self, "Import", f"Đã nhập thành công {count} email.")

    def _check_status_all(self):
        """Background IMAP check for checked emails (like Load Profile)."""
        ids = self._get_checked_ids()
        if not ids:
            # If nothing checked, check all visible
            emails = self.em.get_all_emails(category=self._current_category)
            ids = [e["id"] for e in emails]
        if not ids:
            QMessageBox.information(self, "Check Status", "Không có email nào để kiểm tra.")
            return

        self.btn_check_status.setEnabled(False)
        self.btn_check_status.setText("Đang check...")

        import threading
        self._check_count = 0
        self._check_total = len(ids)

        def check_one(email_id):
            import imaplib
            rec = self.em.get_email(email_id)
            if not rec:
                return
            email_addr = rec.get("email", "")
            password = rec.get("pass_email", "")
            if not email_addr or not password:
                self.em.update_email(email_id, {"live": "N/A", "status": "Thiếu thông tin"})
                return

            # Detect IMAP server
            domain = email_addr.split("@")[-1].lower() if "@" in email_addr else ""
            imap_server = "imap.gmail.com"
            if "hotmail" in domain or "outlook" in domain or "live" in domain:
                imap_server = "imap-mail.outlook.com"
            elif "yahoo" in domain:
                imap_server = "imap.mail.yahoo.com"
            elif "gmail" in domain or "googlemail" in domain:
                imap_server = "imap.gmail.com"
            else:
                imap_server = f"imap.{domain}"

            try:
                mail = imaplib.IMAP4_SSL(imap_server, 993, timeout=15)
                mail.login(email_addr, password)
                mail.logout()
                self.em.update_email(email_id, {"live": "Live", "status": "IMAP OK"})
            except Exception as e:
                err = str(e)[:50]
                if "AUTHENTICATIONFAILED" in str(e).upper() or "LOGIN" in str(e).upper():
                    self.em.update_email(email_id, {"live": "Die", "status": f"IMAP Fail: {err}"})
                else:
                    self.em.update_email(email_id, {"live": "?", "status": f"Error: {err}"})

        def run_all():
            import concurrent.futures
            max_t = self.spin_threads.value() if hasattr(self, 'spin_threads') else 5
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_t) as executor:
                executor.map(check_one, ids)
            # Done — update UI from main thread
            from PyQt6.QtCore import QMetaObject, Qt, Q_ARG
            QMetaObject.invokeMethod(self, "_on_check_done", Qt.ConnectionType.QueuedConnection)

        threading.Thread(target=run_all, daemon=True).start()

    @pyqtSlot()
    def _on_check_done(self):
        self.btn_check_status.setEnabled(True)
        self.btn_check_status.setText("Check Status")
        self.load_data()
        QMessageBox.information(self, "Check Status", "Đã kiểm tra xong tất cả email!")

    def _open_browser_selected(self):
        """Open Chrome with stored login profile for selected emails (like Open Profile)."""
        ids = self._get_checked_ids()
        if not ids:
            QMessageBox.information(self, "Open Profile", "Vui lòng chọn email cần mở Profile.")
            return
        import subprocess as sp_sub
        import os
        import time
        from core.browser_manager import (SmartBrowserDetector, next_browser_window_params,
                                          reset_browser_positions, force_chrome_window_placement,
                                          reposition_browser_window)

        chrome_exe = SmartBrowserDetector.find_browser("Google Chrome")
        if not chrome_exe:
            chrome_exe = SmartBrowserDetector.find_browser("Microsoft Edge")
        if not chrome_exe:
            QMessageBox.warning(self, "Open Profile", "Không tìm thấy Chrome hoặc Edge!")
            return

        reset_browser_positions()

        for eid in ids:
            rec = self.em.get_email(eid)
            if not rec:
                continue
            user_data = rec.get("data_dir", "")
            if not user_data:
                from core.email_manager import EMAIL_PROFILES_DIR
                user_data = os.path.join(EMAIL_PROFILES_DIR, eid)
            if not os.path.isdir(user_data) or len(os.listdir(user_data)) == 0:
                self._update_email_row_status(eid, "⚠️ Chưa login - cần Login trước")
                continue

            wp = next_browser_window_params()
            chrome_args = wp["chrome_args"]

            # Force window placement via Preferences file
            force_chrome_window_placement(user_data, chrome_args)

            try:
                proc = sp_sub.Popen([
                    chrome_exe,
                    f"--user-data-dir={user_data}",
                    "--no-first-run",
                    "--no-default-browser-check",
                ] + chrome_args + [
                    "https://outlook.live.com/mail/0/inbox",
                ], stdout=sp_sub.DEVNULL, stderr=sp_sub.DEVNULL)

                # Force window position via Windows API after Chrome starts
                time.sleep(2)
                reposition_browser_window(proc.pid, chrome_args)

                self._update_email_row_status(eid, "✅ Đã mở Chrome")
            except Exception as e:
                self._update_email_row_status(eid, f"❌ Lỗi: {str(e)[:50]}")

    def _find_email(self):
        """Open FilterEmailDialog with advanced filter modes."""
        cats = self.em.get_categories()

        FILTER_MODES = [
            "Lọc theo Email",
            "Lọc theo UID",
            "Lọc theo Ghi chú",
            "Lọc nhiều danh mục",
            "Lọc theo Email Recovery",
            "Lọc theo Token Hotmail",
            "Lọc theo domain Email",
            "Lọc theo domain Recovery",
            "Lọc theo Proxy",
            "Lọc theo Password",
            "Lọc theo Live",
        ]

        dlg = QDialog(self)
        dlg.setWindowTitle("Lọc Email --- Điền từ khóa hoặc UID để lọc (có thể nhập nhiều dòng)")
        dlg.resize(650, 560)
        dlg.setMinimumSize(500, 400)
        dlg.setStyleSheet("""
            QDialog { background: #1a202c; color: #f7fafc; border: 1px solid #4a5568; border-radius: 10px; }
            QTextEdit { background: #2d3748; border: 1px solid #4a5568; border-radius: 6px; color: #f7fafc; padding: 8px; font-size: 12px; }
            QTextEdit:focus { border-color: #a78bfa; }
            QTableWidget { background: #1e2533; gridline-color: #334155; border: 1px solid #4a5568; border-radius: 6px; color: #f7fafc; }
            QTableWidget::item { padding: 4px; border-bottom: 1px solid #334155; }
            QHeaderView::section { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #2d3748, stop:1 #252f3f); color: #c4b5fd; padding: 5px; border: none; border-bottom: 2px solid #7c3aed; font-weight: 700; }
            QComboBox { background: #2d3748; border: 1px solid #4a5568; border-radius: 6px; color: #f7fafc; padding: 6px 10px; font-size: 12px; }
            QComboBox:focus { border-color: #a78bfa; }
            QComboBox::drop-down { border-left: 1px solid #4a5568; width: 22px; background: #3a4a5c; }
            QComboBox QAbstractItemView { background: #2d3748; border: 1px solid #4a5568; selection-background-color: #8b5cf6; color: #f7fafc; }
            QCheckBox { color: #f7fafc; }
            QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #718096; border-radius: 3px; background: #2d3748; }
            QCheckBox::indicator:checked { background: #8b5cf6; border-color: #a78bfa; }
        """)
        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(10)

        lbl_input = QLabel("Nhập nội dung tìm kiếm hoặc Email")
        lbl_input.setStyleSheet("color: #93c5fd; font-weight: 700; font-size: 12px;")
        layout.addWidget(lbl_input)

        text_input = QTextEdit()
        text_input.setPlaceholderText("Nhập email, UID, từ khóa... mỗi dòng một giá trị")
        text_input.setMinimumHeight(120)
        layout.addWidget(text_input)

        # Category table
        lbl_cat = QLabel("Chọn danh mục")
        lbl_cat.setStyleSheet("color: #93c5fd; font-weight: 700; font-size: 12px;")
        layout.addWidget(lbl_cat)

        cat_table = QTableWidget()
        cat_table.setColumnCount(3)
        cat_table.setHorizontalHeaderLabels(["", "ID", "Category"])
        cat_table.verticalHeader().setVisible(False)
        cat_table.setMinimumHeight(120)
        header = cat_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        cat_table.setColumnWidth(0, 34)
        cat_table.setColumnWidth(1, 50)
        cat_table.setRowCount(len(cats))
        cat_checkboxes = []
        for i, cat in enumerate(cats):
            chk = QCheckBox()
            chk.setChecked(True)
            cat_checkboxes.append(chk)
            chk_w = QWidget()
            chk_l = QHBoxLayout(chk_w)
            chk_l.addWidget(chk)
            chk_l.setAlignment(Qt.AlignmentFlag.AlignCenter)
            chk_l.setContentsMargins(0, 0, 0, 0)
            cat_table.setCellWidget(i, 0, chk_w)
            id_item = QTableWidgetItem(str(i + 1))
            id_item.setFlags(id_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            id_item.setForeground(QColor("#a78bfa"))
            cat_table.setItem(i, 1, id_item)
            cat_item = QTableWidgetItem(cat)
            cat_item.setFlags(cat_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            cat_item.setForeground(QColor("#f7fafc"))
            cat_table.setItem(i, 2, cat_item)
        layout.addWidget(cat_table)

        # Filter mode combo
        combo_mode = QComboBox()
        combo_mode.addItems(FILTER_MODES)
        combo_mode.setMinimumHeight(30)
        layout.addWidget(combo_mode)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_show_all = QPushButton("Hiện tất cả")
        btn_show_all.setMinimumWidth(110)
        btn_show_all.setFixedHeight(34)
        btn_show_all.setStyleSheet("""
            QPushButton { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #4a5568, stop:1 #3a4a5c);
                border: 1px solid #718096; border-radius: 6px; color: #f7fafc; font-weight: 700; padding: 0 16px; }
            QPushButton:hover { background: #718096; }
        """)
        btn_ok = QPushButton("OK — Lọc")
        btn_ok.setMinimumWidth(130)
        btn_ok.setFixedHeight(34)
        btn_ok.setStyleSheet("""
            QPushButton { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #2563eb, stop:1 #1d4ed8);
                border: 1px solid #3b82f6; border-radius: 6px; color: #ffffff; font-weight: 700; font-size: 13px; padding: 0 20px; }
            QPushButton:hover { background: #3b82f6; }
        """)
        btn_show_all.clicked.connect(lambda: (self.load_data(), dlg.reject()))
        btn_ok.clicked.connect(dlg.accept)
        btn_layout.addWidget(btn_show_all)
        btn_layout.addSpacing(10)
        btn_layout.addWidget(btn_ok)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        query_text = text_input.toPlainText().strip()
        query_lines = [l.strip() for l in query_text.split('\n') if l.strip()] if query_text else []
        filter_mode = combo_mode.currentText()
        selected_cats = [cats[i] for i, chk in enumerate(cat_checkboxes) if chk.isChecked() and i < len(cats)]

        if not query_lines and not selected_cats:
            return

        # Map filter mode to column key
        mode_key_map = {
            "Lọc theo Email": "email",
            "Lọc theo UID": "uid",
            "Lọc theo Ghi chú": "note",
            "Lọc nhiều danh mục": "_category",
            "Lọc theo Email Recovery": "email_recovery",
            "Lọc theo Token Hotmail": "token_hotmail",
            "Lọc theo domain Email": "email",
            "Lọc theo domain Recovery": "email_recovery",
            "Lọc theo Proxy": "proxy",
            "Lọc theo Password": "pass_email",
            "Lọc theo Live": "live",
        }
        data_key = mode_key_map.get(filter_mode, "email")
        is_domain = "domain" in filter_mode
        is_category = filter_mode == "Lọc nhiều danh mục"

        target_col = -1
        for col_idx, (key, _) in enumerate(EMAIL_COLUMNS):
            if key == data_key:
                target_col = col_idx
                break

        emails = self.em.get_all_emails(category=self._current_category)
        for row in range(self.table.rowCount()):
            show = False
            if is_category:
                if row < len(emails):
                    p_cat = emails[row].get("category", "Default")
                    if not selected_cats or p_cat in selected_cats:
                        show = True
            elif target_col >= 0 and query_lines:
                item = self.table.item(row, target_col)
                if item:
                    value = item.text().strip().lower()
                    if is_domain and "@" in value:
                        value = value.split("@")[1]
                    for q in query_lines:
                        if q.strip().lower() in value:
                            show = True
                            break
            elif not query_lines and selected_cats:
                if row < len(emails):
                    p_cat = emails[row].get("category", "Default")
                    if p_cat in selected_cats:
                        show = True
            else:
                show = True
            self.table.setRowHidden(row, not show)

        # Count visible
        visible = sum(1 for r in range(self.table.rowCount()) if not self.table.isRowHidden(r))
        self.lbl_total.setText(f"Tổng số Email  {visible} (lọc từ {self.table.rowCount()})")

    def _add_category(self):
        text, ok = QInputDialog.getText(self, "Thêm Thư mục", "Tên thư mục mới:")
        if ok and text and text.strip():
            name = text.strip()
            self.em.add_category(name)
            self._current_category = name
            self._refresh_categories()
            idx = self.combo_category.findText(name)
            if idx >= 0:
                self.combo_category.setCurrentIndex(idx)
            else:
                self.combo_category.addItem(name)
                self.combo_category.setCurrentText(name)

    def _edit_category(self):
        current = self.combo_category.currentText()
        if current == "Tất cả":
            QMessageBox.warning(self, "Edit", "Không thể sửa thư mục mặc định!")
            return
        new_name, ok = QInputDialog.getText(self, "Sửa Thư mục", "Tên mới:", text=current)
        if ok and new_name and new_name.strip() != current:
            self.em.rename_category(current, new_name.strip())
            self.load_data()

    def _delete_category(self):
        current = self.combo_category.currentText()
        if current == "Tất cả":
            QMessageBox.warning(self, "Delete", "Không thể xóa thư mục mặc định!")
            return
        reply = QMessageBox.question(self, "Xóa Thư mục",
                                     f"Xóa thư mục '{current}' và chuyển email về 'Mới'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.em.delete_category_name(current, "Mới")
            self.combo_category.setCurrentText("Tất cả")
            self.load_data()

    def _move_to_category(self):
        ids = self._get_checked_ids()
        if not ids:
            QMessageBox.information(self, "Move", "Vui lòng chọn email cần di chuyển.")
            return
        cats = self.em.get_categories()
        cat, ok = QInputDialog.getItem(self, "Move", "Chọn thư mục đích:", cats, 0, False)
        if ok and cat:
            self.em.move_emails(ids, cat)
            self.load_data()

    def _context_menu(self, pos):
        row = self.table.rowAt(pos.y())
        rec = None
        if row >= 0:
            rec = self._get_email_at_row(row)

        menu = QMenu()
        menu.setStyleSheet("""
            QMenu { background-color: white; border: 2px solid #1e5fa0; border-radius: 4px; padding: 4px; }
            QMenu::item { padding: 6px 20px; font-size: 13px; color: #333333; }
            QMenu::item:selected { background-color: #e6f7ff; color: #1890ff; }
            QMenu::separator { height: 1px; background: #abbed1; margin: 4px 0px; }
        """)

        action_refresh = menu.addAction("🔄 Làm mới danh sách")
        menu.addSeparator()
        
        # Copy sub-menu
        menu_copy = menu.addMenu("📋 Copy")
        copy_1 = menu_copy.addAction("Email")
        copy_2 = menu_copy.addAction("Email|Pass Email")
        copy_3 = menu_copy.addAction("Email|Pass Email|Token Hotmail")
        copy_4 = menu_copy.addAction("Email|Pass Email|Mail Recover")
        copy_5 = menu_copy.addAction("Email|Pass Email|Mail Recover|Token Hotmail")
        copy_6 = menu_copy.addAction("UID|Email|Pass Email|Mail Recover|Token Hotmail")
        copy_7 = menu_copy.addAction("Custom")
        
        menu.addSeparator()
        action_read_imap = menu.addAction("📧 Read Mail (Imap)")
        action_check_token = menu.addAction("🔍 Kiểm tra Refresh Token Hotmail")
        
        menu.addSeparator()
        action_login_pass = menu.addAction("🔐 Login Email (sử dụng password)")
        action_login_recover = menu.addAction("🔐 Login Email (sử dụng email khôi phục)")
        action_login_hotm = menu.addAction("🔐 Login Hotmail (Add Mail khôi phục nếu cần)")
        action_login_chrome = menu.addAction("🌐 Login Email with Chrome")
        action_close_browser = menu.addAction("❌ Đóng trình duyệt")
        
        menu.addSeparator()
        # Xuất/Nhập dữ liệu
        data_menu = menu.addMenu("📥 Xuất/Nhập dữ liệu")
        action_import = data_menu.addAction("📥 Import Email")
        action_export = data_menu.addAction("📤 Export Email")
        action_import_pass = data_menu.addAction("📥 Import Pass Email Recovery")
        
        # Quản lý thư mục
        cat_menu = menu.addMenu("📁 Quản lý Thư mục")
        action_add_cat = cat_menu.addAction("➕ Thêm thư mục")
        action_edit_cat = cat_menu.addAction("✏️ Sửa thư mục")
        action_del_cat = cat_menu.addAction("❌ Xóa thư mục")
        action_move_cat = cat_menu.addAction("📦 Move vào thư mục")
        
        menu.addSeparator()
        action_delete_all_mail = menu.addAction("🗑️ Xóa tất cả thư trong Hotmail")
        action_add_proxy = menu.addAction("🌐 Add Proxy")
        action_change_note = menu.addAction("📝 Change Note")
        action_fix_lower = menu.addAction("🔧 Fix Email In hoa")
        
        menu.addSeparator()
        action_sync_fb = menu.addAction("🔄 Đồng bộ vào quản lý Profile Facebook")
        action_sync_ins = menu.addAction("🔄 Đồng bộ vào quản lý Insta2M")
        
        menu.addSeparator()
        action_delete = menu.addAction("🗑️ Xóa Email")

        action = menu.exec(self.table.viewport().mapToGlobal(pos))
        if not action:
            return

        ids = self._get_checked_ids()
        # If the clicked row is not checked, act only on the clicked row.
        # Otherwise, act on all checked rows.
        if rec and rec["id"] not in ids:
            ids = [rec["id"]]
            target_recs = [rec]
        elif ids:
            target_recs = [self.em.get_email(eid) for eid in ids if self.em.get_email(eid)]
        else:
            # No row clicked and nothing checked
            target_recs = []

        # --- Handle Actions ---
        if action == action_refresh:
            self.load_data()
            
        elif action in [copy_1, copy_2, copy_3, copy_4, copy_5, copy_6, copy_7]:
            if not target_recs:
                QMessageBox.information(self, "Copy", "Vui lòng chọn email trước.")
                return
            text_lines = []
            for r in target_recs:
                if action == copy_1:
                    text_lines.append(r.get("email", ""))
                elif action == copy_2:
                    text_lines.append(f'{r.get("email", "")}|{r.get("pass_email", "")}')
                elif action == copy_3:
                    text_lines.append(f'{r.get("email", "")}|{r.get("pass_email", "")}|{r.get("token_hotmail", "")}')
                elif action == copy_4:
                    text_lines.append(f'{r.get("email", "")}|{r.get("pass_email", "")}|{r.get("email_recovery", "")}')
                elif action == copy_5:
                    text_lines.append(f'{r.get("email", "")}|{r.get("pass_email", "")}|{r.get("email_recovery", "")}|{r.get("token_hotmail", "")}')
                elif action == copy_6:
                    text_lines.append(f'{r.get("uid", "")}|{r.get("email", "")}|{r.get("pass_email", "")}|{r.get("email_recovery", "")}|{r.get("token_hotmail", "")}')
                elif action == copy_7:
                    text_lines.append(json.dumps(r))
            
            QApplication.clipboard().setText("\n".join(text_lines))
            QMessageBox.information(self, "Copy", f"Đã copy {len(text_lines)} dòng vào Clipboard.")
            
        elif action == action_import:
            self._load_email()
            
        elif action == action_read_imap:
            from ui.email_reader import ReadMailDialog
            if not target_recs:
                QMessageBox.information(self, 'Read Mail', 'Vui lòng chọn email.')
                return
            rec0 = target_recs[0]
            dlg = ReadMailDialog(self, email_addr=rec0.get('email',''), password=rec0.get('pass_email',''), token=rec0.get('token_hotmail',''), email_id=rec0.get('id',''), em=self.em)
            dlg.exec()
            
        elif action == action_check_token:
            self._check_tokens(target_recs)
            
        elif action == action_login_pass:
            self._do_login(target_recs, "password")
        elif action == action_login_recover:
            self._do_login(target_recs, "recovery")
        elif action == action_login_hotm:
            self._do_login_add_recovery(target_recs)
        elif action == action_login_chrome:
            self._do_login(target_recs, "chrome")
        elif action == action_close_browser:
            self._do_close_browser(target_recs)
        elif action in [action_delete_all_mail, action_sync_ins]:
            QMessageBox.information(self, "Feature", "Tính năng đang được phát triển.")
            
        elif action == action_add_proxy:
            proxy, ok = QInputDialog.getText(self, "Add Proxy", "Nhập Proxy:")
            if ok:
                for eid in ids:
                    self.em.update_email(eid, {"proxy": proxy.strip()})
                self.load_data()
                
        elif action == action_change_note:
            note, ok = QInputDialog.getText(self, "Change Note", "Nhập Ghi Chú mới:")
            if ok:
                for eid in ids:
                    self.em.update_email(eid, {"note": note.strip()})
                self.load_data()
                
        elif action == action_fix_lower:
            for eid in ids:
                r = self.em.get_email(eid)
                if r and r.get("email"):
                    self.em.update_email(eid, {"email": r["email"].lower()})
            self.load_data()
            
        elif action == action_delete:
            reply = QMessageBox.question(self, "Xóa Email", f"Xóa {len(ids)} email đã chọn?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                self.em.delete_emails(ids)
                self.load_data()
                
        elif action == action_sync_fb:
            self._sync_to_facebook(target_recs)
        
        # Category management from context menu
        elif action == action_add_cat:
            self._add_category()
        elif action == action_edit_cat:
            self._edit_category()
        elif action == action_del_cat:
            self._delete_category()
        elif action == action_move_cat:
            self._move_to_category()
        
        # Export
        elif action == action_export:
            self._export_emails()
        elif action == action_import_pass:
            self._import_pass_recovery()

    def _export_emails(self):
        """Export all emails in current category to clipboard."""
        emails = self.em.get_all_emails(category=self._current_category)
        if not emails:
            QMessageBox.information(self, "Export", "Không có email nào để export.")
            return
        lines = []
        for r in emails:
            line = "|".join([
                r.get("uid", ""),
                r.get("email", ""),
                r.get("pass_email", ""),
                r.get("email_recovery", ""),
                r.get("pass_em", ""),
                r.get("proxy", ""),
                r.get("token_hotmail", ""),
            ])
            lines.append(line)
        QApplication.clipboard().setText("\n".join(lines))
        QMessageBox.information(self, "Export",
                                f"Đã export {len(lines)} email vào Clipboard.\n"
                                f"Format: UID|Email|Pass Email|Mail Recover|PassEm|Proxy|Token")

    def _import_pass_recovery(self):
        """Import recovery passwords from clipboard — matches by email address."""
        text = QApplication.clipboard().text().strip()
        if not text:
            QMessageBox.information(self, "Import", "Clipboard trống.")
            return
        lines = text.strip().split("\n")
        count = 0
        for line in lines:
            parts = line.strip().split("|")
            if len(parts) >= 2:
                email_addr = parts[0].strip().lower()
                pass_recovery = parts[1].strip()
                for e in self.em.get_all_emails():
                    if e.get("email", "").lower() == email_addr:
                        self.em.update_email(e["id"], {"pass_em": pass_recovery})
                        count += 1
                        break
        self.load_data()
        QMessageBox.information(self, "Import", f"Đã import recovery password cho {count} email.")

    def _sync_to_facebook(self, recs):
        """Sync email data to matching Profile Manager profiles by UID."""
        try:
            # Use shared ProfileManager from main window
            main_win = self.window()
            pm = getattr(main_win, 'profile_manager', None)
            if pm is None:
                from core.profile_manager import ProfileManager
                pm = ProfileManager()
            
            count_updated = 0
            count_created = 0
            
            # Build UID -> profile lookup for efficiency
            uid_to_profile = {}
            for p in pm.get_all_profiles():
                uid = p.get("fb_uid", "")
                if uid:
                    uid_to_profile[uid] = p
            
            # Field mapping: Email Manager -> Profile Manager
            FIELD_MAP = {
                "email":          "fb_email",
                "pass_email":     "fb_pass_email",
                "email_recovery": "fb_email_recovery",
                "proxy":          "fb_proxy",
                "token_hotmail":  "fb_token_hotmail",
            }
            
            for r in recs:
                uid = r.get("uid", "").strip()
                if not uid:
                    continue
                
                # Build update dict from non-empty email fields
                update_fields = {}
                for email_key, profile_key in FIELD_MAP.items():
                    val = r.get(email_key, "")
                    if val:
                        update_fields[profile_key] = val
                
                if not update_fields:
                    continue
                
                prof = uid_to_profile.get(uid)
                if prof:
                    # Update existing profile
                    pm.update_profile(prof["id"], update_fields)
                    count_updated += 1
                else:
                    # Create new profile then update extra fields
                    new_prof = pm.add_profile(
                        name=r.get("email", uid),
                        fb_uid=uid,
                        fb_email=r.get("email", ""),
                        category="Default"
                    )
                    if new_prof:
                        pm.update_profile(new_prof["id"], update_fields)
                    count_created += 1
            
            # Reload main window table
            if hasattr(main_win, 'load_data'):
                main_win.load_data()
            
            msg = f"Đồng bộ thành công!\n• Cập nhật: {count_updated} profile\n• Tạo mới: {count_created} profile"
            QMessageBox.information(self, "Đồng bộ", msg)
        except Exception as e:
            QMessageBox.warning(self, "Lỗi", f"Không thể đồng bộ: {str(e)}")

    def _run_imap_check(self):
        ids = self._get_checked_ids()
        if ids:
            emails = [self.em.get_email(eid) for eid in ids if self.em.get_email(eid)]
        else:
            emails = self.em.get_all_emails(category=self._current_category)

        if not emails:
            QMessageBox.information(self, "Check IMAP", "Không có email nào để kiểm tra.")
            return

        thread = ImapCheckThread(emails)
        thread.status_update.connect(self._on_imap_status)
        thread.finished_all.connect(lambda: QMessageBox.information(self, "Check IMAP", "Đã kiểm tra xong tất cả email!"))
        thread.start()
        self.imap_threads.append(thread)

    def _do_login(self, target_recs, login_type):
        """Start login for selected emails."""
        if not target_recs:
            QMessageBox.information(self, "Login", "Vui l\u00f2ng ch\u1ecdn email.")
            return

        from ui.email_login_worker import HotmailLoginThread, EmailBrowserManager

        if not hasattr(self, '_email_browser_mgr'):
            self._email_browser_mgr = EmailBrowserManager()

        headless = login_type != "chrome"

        for rec in target_recs:
            eid = rec.get("id", "")
            thread = self._email_browser_mgr.start_login(rec, login_type, headless)
            thread.status_update.connect(self._on_login_status)
            thread.login_done.connect(self._on_login_done)
            thread.error_signal.connect(self._on_login_error)
            thread.start()
            self._update_email_row_status(eid, "Dang khoi dong...")

    def _do_login_add_recovery(self, target_recs):
        """Login Hotmail with add recovery email option."""
        if not target_recs:
            QMessageBox.information(self, "Login", "Vui l\u00f2ng ch\u1ecdn email.")
            return

        from ui.email_login_worker import RecoveryDomainDialog, EmailBrowserManager, build_recovery_email

        dlg = RecoveryDomainDialog(self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        provider, domain, suffix = dlg.get_result()

        if not hasattr(self, '_email_browser_mgr'):
            self._email_browser_mgr = EmailBrowserManager()

        for rec in target_recs:
            eid = rec.get("id", "")
            thread = self._email_browser_mgr.start_login(
                rec, "token_recovery", headless=True,
                recovery_domain=domain, recovery_provider=provider,
                recovery_suffix=suffix
            )
            thread.status_update.connect(self._on_login_status)
            thread.login_done.connect(self._on_login_done)
            thread.error_signal.connect(self._on_login_error)
            thread.start()
            self._update_email_row_status(eid, "Dang khoi dong (add recovery)...")

    def _do_close_browser(self, target_recs):
        """Close browser sessions for selected emails."""
        if not hasattr(self, '_email_browser_mgr'):
            return
        for rec in target_recs:
            eid = rec.get("id", "")
            self._email_browser_mgr.stop_session(eid)
            self._update_email_row_status(eid, "Da dong trinh duyet")

    def _on_login_status(self, email_id, status):
        """Handle login status update."""
        self.em.update_email(email_id, {"status": status})
        self._update_email_row_status(email_id, status)

    def _on_login_done(self, email_id, result):
        """Handle login completion."""
        status = result.get("status", "Login done")
        updates = {"status": status, "live": "Live" if "OK" in status else ""}
        if result.get("recovery_email"):
            updates["email_recovery"] = result["recovery_email"]
        self.em.update_email(email_id, updates)
        self._update_email_row_status(email_id, status)
        if "OK" in status:
            self._update_email_row_color(email_id, "Live")
        self.load_data()

    def _on_login_error(self, email_id, msg):
        """Handle login error."""
        self.em.update_email(email_id, {"status": msg, "live": "Out"})
        self._update_email_row_status(email_id, msg)
        self._update_email_row_color(email_id, "Token Out")

    def _check_tokens(self, target_recs):
        """Check refresh tokens in bulk for selected emails."""
        if not target_recs:
            QMessageBox.information(self, "Check Token", "Vui l\u00f2ng ch\u1ecdn email.")
            return
        
        # Filter only those with tokens
        recs_with_token = [r for r in target_recs if r.get("token_hotmail")]
        if not recs_with_token:
            QMessageBox.information(self, "Check Token", "Kh\u00f4ng c\u00f3 email n\u00e0o c\u00f3 token.")
            return
        
        from ui.email_reader import TokenCheckThread
        self._token_check_thread = TokenCheckThread(recs_with_token)
        self._token_check_thread.status_update.connect(self._on_token_check_status)
        self._token_check_thread.finished_all.connect(self._on_token_check_done)
        self._token_check_thread.start()
        
        # Update status to "Checking..."
        for r in recs_with_token:
            self._update_email_row_status(r["id"], "\u0110ang ki\u1ec3m tra token...")

    def _on_token_check_status(self, email_id, status, live_val, method=""):
        """Handle token check result for one email."""
        updates = {"status": status}
        if live_val:
            updates["live"] = live_val
        if method:
            updates["status"] = f"{status}"
        self.em.update_email(email_id, updates)
        self._update_email_row_status(email_id, status)
        # Update row color
        self._update_email_row_color(email_id, live_val)

    def _on_token_check_done(self):
        self.load_data()

    def _update_email_row_status(self, email_id, status):
        """Update status column for a specific email row."""
        emails = self.em.get_all_emails(category=self._current_category)
        self.table.blockSignals(True)
        for row_idx, rec in enumerate(emails):
            if rec.get("id") == email_id:
                if row_idx < self.table.rowCount():
                    status_col = next((i for i, (k, _) in enumerate(EMAIL_COLUMNS) if k == "status"), -1)
                    if status_col >= 0:
                        item = QTableWidgetItem(status)
                        self.table.setItem(row_idx, status_col, item)
                    live_col = next((i for i, (k, _) in enumerate(EMAIL_COLUMNS) if k == "live"), -1)
                    if live_col >= 0:
                        live_val = rec.get("live", "")
                        item = QTableWidgetItem(live_val)
                        self.table.setItem(row_idx, live_col, item)
                break
        self.table.blockSignals(False)

    def _update_email_row_color(self, email_id, live_val):
        """Update row background color based on token check result."""
        emails = self.em.get_all_emails(category=self._current_category)
        self.table.blockSignals(True)
        for row_idx, rec in enumerate(emails):
            if rec.get("id") == email_id:
                if row_idx < self.table.rowCount():
                    lv = (live_val or "").lower()
                    if "live" in lv:
                        bg = QColor("#1a3a2a")  # Dark green
                        fg = QColor("#4ade80")
                    elif "out" in lv or "token out" in lv:
                        bg = QColor("#3b1a1a")  # Dark red
                        fg = QColor("#f87171")
                    elif "no token" in lv:
                        bg = QColor("#3b2f00")  # Dark yellow
                        fg = QColor("#fbbf24")
                    else:
                        bg = QColor("#1a2744")  # Default
                        fg = QColor("#e2e8f0")
                    for c in range(self.table.columnCount()):
                        it = self.table.item(row_idx, c)
                        if it:
                            it.setBackground(bg)
                            it.setForeground(fg)
                break
        self.table.blockSignals(False)

    def _on_imap_status(self, email_id, status):
        self.em.update_email(email_id, {"status": status})
        # Update the row live
        emails = self.em.get_all_emails(category=self._current_category)
        self.table.blockSignals(True)
        for row_idx, rec in enumerate(emails):
            if rec.get("id") == email_id:
                if row_idx < self.table.rowCount():
                    status_col = next((i for i, (k, _) in enumerate(EMAIL_COLUMNS) if k == "status"), -1)
                    if status_col >= 0:
                        item = QTableWidgetItem(status)
                        self.table.setItem(row_idx, status_col, item)
                break
        self.table.blockSignals(False)
