"""Post Cleaner Widget — Multi-UID scanner with thread control."""
from datetime import date
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QTextEdit,
    QPushButton, QProgressBar, QDateEdit, QSpinBox, QGroupBox,
    QMessageBox
)
from PyQt6.QtCore import Qt, QDate, pyqtSignal
from core.profile_manager import ProfileManager


class EditProfileWidget(QWidget):
    """Post Cleaner tab — scan and trash posts for multiple UIDs."""
    profile_saved = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.profile_manager = ProfileManager()
        self.workers = []
        self.all_scanned = {}  # uid -> list of post dicts
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(10, 10, 10, 10)

        # ── Title ──
        title = QLabel("🧹 Post Cleaner — Quét & xóa bài viết Facebook")
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: #a78bfa;")
        layout.addWidget(title)

        # ── UID Input (multi-line) ──
        uid_group = QGroupBox("UIDs (mỗi dòng 1 UID)")
        uid_group.setStyleSheet("QGroupBox { color: #e2e8f0; font-weight: bold; border: 1px solid #475569; border-radius: 6px; margin-top: 6px; padding-top: 14px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }")
        uid_layout = QVBoxLayout(uid_group)

        self.input_uids = QTextEdit()
        self.input_uids.setPlaceholderText(
            "Nhập UID Facebook, mỗi dòng 1 UID.\n"
            "Ví dụ:\n100012345678\n100098765432\n\n"
            "Tool sẽ tự tìm cookie từ Quản lý Profile.")
        self.input_uids.setMaximumHeight(90)
        self.input_uids.setStyleSheet("font-family: Consolas; font-size: 12px; padding: 4px;")
        uid_layout.addWidget(self.input_uids)
        layout.addWidget(uid_group)

        # ── Date Range + Thread count ──
        ctrl_row = QHBoxLayout()
        ctrl_row.setSpacing(12)

        DATE_STYLE = """
            QDateEdit {
                padding: 4px 8px; font-size: 12px;
                background: #2d3748; color: #f7fafc;
                border: 1px solid #4a5568; border-radius: 4px;
                min-width: 110px;
            }
            QDateEdit::drop-down {
                subcontrol-origin: padding; subcontrol-position: top right;
                width: 20px; border-left: 1px solid #4a5568;
                background: #3a4a5c; border-top-right-radius: 4px;
                border-bottom-right-radius: 4px;
            }
            QDateEdit::down-arrow { image: none; border: none; width: 0; }
            QCalendarWidget {
                background: #2d3748; color: #f7fafc;
            }
            QCalendarWidget QAbstractItemView {
                background: #1e2533; color: #f7fafc;
                selection-background-color: #8b5cf6;
                selection-color: white;
                alternate-background-color: #232d3f;
                outline: none;
            }
            QCalendarWidget QAbstractItemView:enabled {
                color: #f7fafc;
            }
            QCalendarWidget QAbstractItemView:disabled {
                color: #718096;
            }
            QCalendarWidget QWidget#qt_calendar_navigationbar {
                background: #2d3748;
            }
            QCalendarWidget QToolButton {
                color: #f7fafc; background: #3a4a5c;
                border: 1px solid #4a5568; border-radius: 3px;
                padding: 4px 8px; font-weight: bold;
            }
            QCalendarWidget QToolButton:hover {
                background: #4a5a6e;
            }
            QCalendarWidget QSpinBox {
                background: #2d3748; color: #f7fafc;
                border: 1px solid #4a5568; border-radius: 3px;
            }
            QCalendarWidget QMenu {
                background: #2d3748; color: #f7fafc;
                border: 1px solid #4a5568;
            }
            QCalendarWidget QMenu::item:selected {
                background: #8b5cf6; color: white;
            }
        """
        LBL_STYLE = "color: #f7fafc; font-weight: bold; font-size: 12px;"

        lbl_from = QLabel("Từ ngày:")
        lbl_from.setStyleSheet(LBL_STYLE)
        ctrl_row.addWidget(lbl_from)
        self.date_start = QDateEdit()
        self.date_start.setCalendarPopup(True)
        self.date_start.setDate(QDate(2020, 1, 1))
        self.date_start.setDisplayFormat("dd/MM/yyyy")
        self.date_start.setStyleSheet(DATE_STYLE)
        ctrl_row.addWidget(self.date_start)

        lbl_to = QLabel("Đến ngày:")
        lbl_to.setStyleSheet(LBL_STYLE)
        ctrl_row.addWidget(lbl_to)
        self.date_end = QDateEdit()
        self.date_end.setCalendarPopup(True)
        self.date_end.setDate(QDate.currentDate())
        self.date_end.setDisplayFormat("dd/MM/yyyy")
        self.date_end.setStyleSheet(DATE_STYLE)
        ctrl_row.addWidget(self.date_end)

        lbl_thread = QLabel("Luồng:")
        lbl_thread.setStyleSheet(LBL_STYLE)
        ctrl_row.addWidget(lbl_thread)
        self.spin_threads = QSpinBox()
        self.spin_threads.setRange(1, 10)
        self.spin_threads.setValue(2)
        self.spin_threads.setFixedWidth(50)
        self.spin_threads.setStyleSheet("padding: 4px; font-size: 12px; background: #2d3748; color: #f7fafc; border: 1px solid #4a5568; border-radius: 4px;")
        ctrl_row.addWidget(self.spin_threads)

        ctrl_row.addStretch()
        layout.addLayout(ctrl_row)

        # ── Buttons ──
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        self.btn_scan = QPushButton("▶ Quét bài viết")
        self.btn_scan.setFixedHeight(36)
        self.btn_scan.setMinimumWidth(130)
        self.btn_scan.setStyleSheet("""
            QPushButton { background: #4CAF50; color: white; border-radius: 6px;
                font-weight: bold; font-size: 13px; padding: 0 14px; }
            QPushButton:hover { background: #388E3C; }
            QPushButton:disabled { background: #ccc; color: #888; }
        """)
        self.btn_scan.clicked.connect(self._start_scan)
        btn_row.addWidget(self.btn_scan)

        self.btn_stop = QPushButton("⏹ Dừng")
        self.btn_stop.setFixedHeight(36)
        self.btn_stop.setMinimumWidth(70)
        self.btn_stop.setEnabled(False)
        self.btn_stop.setStyleSheet("""
            QPushButton { background: #FF9800; color: white; border-radius: 6px;
                font-weight: bold; font-size: 13px; padding: 0 14px; }
            QPushButton:hover { background: #F57C00; }
            QPushButton:disabled { background: #ccc; color: #888; }
        """)
        self.btn_stop.clicked.connect(self._stop_all)
        btn_row.addWidget(self.btn_stop)

        self.btn_delete = QPushButton("🗑️ Xóa bài đã quét")
        self.btn_delete.setFixedHeight(36)
        self.btn_delete.setMinimumWidth(150)
        self.btn_delete.setEnabled(False)
        self.btn_delete.setStyleSheet("""
            QPushButton { background: #f44336; color: white; border-radius: 6px;
                font-weight: bold; font-size: 13px; padding: 0 14px; }
            QPushButton:hover { background: #d32f2f; }
            QPushButton:disabled { background: #ccc; color: #888; }
        """)
        self.btn_delete.clicked.connect(self._start_delete)
        btn_row.addWidget(self.btn_delete)

        btn_row.addStretch()
        self.lbl_stats = QLabel("📊 Chưa quét")
        self.lbl_stats.setStyleSheet("font-size: 13px; font-weight: bold; color: #94a3b8;")
        btn_row.addWidget(self.lbl_stats)
        layout.addLayout(btn_row)

        # ── Progress ──
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFixedHeight(14)
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        # ── Log ──
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("""
            QTextEdit { background: #1e1e1e; color: #d4d4d4;
                font-family: Consolas, 'Courier New', monospace;
                font-size: 11px; padding: 6px;
                border: 1px solid #333; border-radius: 4px; }
        """)
        self.log_output.setPlaceholderText("Log hiển thị ở đây...")
        layout.addWidget(self.log_output, stretch=1)

    # ─────────────────────────────────────────
    #  Helpers
    # ─────────────────────────────────────────
    def _get_uid_cookie_pairs(self):
        """Parse UIDs from text and look up cookies from profile manager."""
        text = self.input_uids.toPlainText().strip()
        if not text:
            return []

        uids = [line.strip() for line in text.splitlines() if line.strip()]
        profiles = self.profile_manager.get_all_profiles()
        pairs = []

        for uid in uids:
            profile = next(
                (p for p in profiles
                 if p.get("fb_uid") == uid or p.get("name") == uid or p.get("id") == uid),
                None
            )
            if profile and profile.get("fb_cookie"):
                pairs.append((uid, profile["fb_cookie"]))
                self._log(f"✅ UID {uid}: Cookie tìm thấy")
            else:
                self._log(f"❌ UID {uid}: Không tìm thấy cookie → bỏ qua")

        return pairs

    def _log(self, msg):
        self.log_output.append(msg)
        sb = self.log_output.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _get_dates(self):
        qs = self.date_start.date()
        qe = self.date_end.date()
        return (
            date(qs.year(), qs.month(), qs.day()),
            date(qe.year(), qe.month(), qe.day())
        )

    # ─────────────────────────────────────────
    #  SCAN
    # ─────────────────────────────────────────
    def _start_scan(self):
        self.log_output.clear()
        self.all_scanned = {}
        self.btn_delete.setEnabled(False)

        pairs = self._get_uid_cookie_pairs()
        if not pairs:
            QMessageBox.warning(self, "Lỗi",
                "Không tìm thấy UID nào có cookie!\nNhập UID và đảm bảo profile đã lưu cookie.")
            return

        start_d, end_d = self._get_dates()
        if start_d > end_d:
            QMessageBox.warning(self, "Lỗi", "Ngày bắt đầu phải trước ngày kết thúc!")
            return

        self.btn_scan.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.lbl_stats.setText("📊 Đang quét...")
        self._total_found = 0

        # Launch workers (limited by thread count)
        max_threads = self.spin_threads.value()
        self._pending_uids = list(pairs)
        self._active_workers = 0
        self._max_threads = max_threads
        self._scan_mode = True
        self._launch_next_workers("scan", start_d, end_d)

    def _launch_next_workers(self, mode, start_d, end_d):
        from modules.post_cleaner_worker import PostCleanerWorker

        while self._pending_uids and self._active_workers < self._max_threads:
            uid, cookie = self._pending_uids.pop(0)
            self._active_workers += 1

            if mode == "scan":
                worker = PostCleanerWorker(cookie, uid, start_d, end_d, mode="scan")
                worker.post_found.connect(lambda d, u=uid: self._on_post_found(u, d))
                worker.scan_complete.connect(lambda n, u=uid: self._on_uid_scan_done(u, n))
            else:
                posts = self.all_scanned.get(uid, [])
                worker = PostCleanerWorker(cookie, uid, start_d, end_d,
                                            mode="delete", posts_to_delete=posts)
                worker.delete_complete.connect(lambda d, e, u=uid: self._on_uid_delete_done(u, d, e))

            worker.log_signal.connect(lambda msg, u=uid: self._log(f"[{u}] {msg}"))
            worker.progress_signal.connect(self.progress.setValue)
            worker.error_signal.connect(lambda msg, u=uid: self._log(f"[{u}] ❌ {msg}"))
            worker.finished_signal.connect(lambda: self._on_worker_finished(mode, start_d, end_d))
            
            self.workers.append(worker)
            worker.start()

    def _on_post_found(self, uid, post_data):
        if uid not in self.all_scanned:
            self.all_scanned[uid] = []
        self.all_scanned[uid].append(post_data)
        self._total_found = sum(len(v) for v in self.all_scanned.values())
        self.lbl_stats.setText(f"📊 Tìm thấy: {self._total_found} bài")

    def _on_uid_scan_done(self, uid, total):
        self._log(f"[{uid}] ✅ Quét xong: {total} bài")

    def _on_worker_finished(self, mode, start_d, end_d):
        self._active_workers -= 1
        if self._pending_uids:
            self._launch_next_workers(mode, start_d, end_d)
        elif self._active_workers <= 0:
            self._on_all_done(mode)

    def _on_all_done(self, mode):
        self.workers = []
        self.btn_scan.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.progress.setVisible(False)

        if mode == "scan":
            total = sum(len(v) for v in self.all_scanned.values())
            self.lbl_stats.setText(f"📊 Tổng: {total} bài viết")
            self.lbl_stats.setStyleSheet("font-size: 13px; font-weight: bold; color: #4CAF50;")
            if total > 0:
                self.btn_delete.setEnabled(True)
            self._log(f"\n{'='*40}")
            self._log(f"📊 TỔNG KẾT: {total} bài viết trong {len(self.all_scanned)} profile")
            self._log(f"{'='*40}")
        elif mode == "delete":
            self.lbl_stats.setStyleSheet("font-size: 13px; font-weight: bold; color: #f44336;")
            self._log(f"\n🏁 Hoàn tất xóa bài!")

    # ─────────────────────────────────────────
    #  DELETE
    # ─────────────────────────────────────────
    def _start_delete(self):
        total = sum(len(v) for v in self.all_scanned.values())
        if total == 0:
            QMessageBox.warning(self, "Lỗi", "Chưa có bài quét!")
            return

        reply = QMessageBox.question(
            self, "Xác nhận xóa",
            f"Xóa {total} bài viết trên {len(self.all_scanned)} profile?\n"
            "Bài sẽ vào Thùng rác hoặc Kho lưu trữ.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        self.btn_delete.setEnabled(False)
        self.btn_scan.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.lbl_stats.setText("🗑️ Đang xóa...")

        start_d, end_d = self._get_dates()
        self._pending_uids = []
        profiles = self.profile_manager.get_all_profiles()
        for uid in self.all_scanned:
            profile = next((p for p in profiles if p.get("fb_uid") == uid), None)
            if profile and profile.get("fb_cookie"):
                self._pending_uids.append((uid, profile["fb_cookie"]))
        
        self._active_workers = 0
        self._scan_mode = False
        self._launch_next_workers("delete", start_d, end_d)

    def _on_uid_delete_done(self, uid, deleted, errors):
        self._log(f"[{uid}] 🗑️ Xóa: {deleted} thành công, {errors} lỗi")
        self.lbl_stats.setText(f"🗑️ [{uid}] {deleted} xóa, {errors} lỗi")

    # ─────────────────────────────────────────
    #  STOP
    # ─────────────────────────────────────────
    def _stop_all(self):
        self._pending_uids = []
        for w in self.workers:
            if w.isRunning():
                w.stop()
        self._log("⏹️ Đang dừng tất cả...")

    def load_profiles(self):
        """No-op for tab compatibility."""
        pass
