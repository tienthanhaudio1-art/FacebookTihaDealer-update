"""
Gmail Manager Widget — UI Tab for managing Gmail accounts.
Similar to EmailManagerWidget but focused on Gmail login management.
"""
import json
import os
from ui.copyable_table import CopyableTable
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QDialog, QFormLayout, QLineEdit,
    QDialogButtonBox, QLabel, QMessageBox, QTabWidget, QTextEdit, QMenu,
    QComboBox, QSpinBox, QCheckBox, QInputDialog, QScrollArea, QApplication
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QColor
from core.i18n import tr
from core.gmail_manager import GmailManager

# ─── Column definitions for Gmail table ───
GMAIL_COLUMNS = [
    ("chk",              ""),
    ("stt",              "STT"),
    ("gmail",            "Gmail"),
    ("password",         "Password"),
    ("app_password",     "App Password"),
    ("recovery_email",   "Recovery Email"),
    ("recovery_phone",   "Recovery Phone"),
    ("2fa_secret",       "2FA Secret"),
    ("live",             "Live"),
    ("session",          "Session"),
    ("category",         "Danh mục"),
    ("note",             "Ghi Chú"),
    ("status",           "Trạng thái"),
    ("proxy",            "Proxy"),
]

def gmail_profile_dir(gid: str) -> str:
    """Return persistent Chrome profile directory for a Gmail account.
    Must match core.gmail_manager.GMAIL_PROFILES_DIR/{gid} exactly.
    """
    from core.gmail_manager import GMAIL_PROFILES_DIR
    base = os.path.join(GMAIL_PROFILES_DIR, gid)
    os.makedirs(base, exist_ok=True)
    return base


# ═══════════════════════════════════════════
#  Gmail IMAP Login Check Thread
# ═══════════════════════════════════════════
class GmailImapThread(QThread):
    status_update = pyqtSignal(str, str)  # gmail_id, status_message
    finished_one = pyqtSignal(str)
    finished_all = pyqtSignal()

    def __init__(self, accounts: list):
        super().__init__()
        self.accounts = accounts
        self._running = True

    def run(self):
        import imaplib
        for rec in self.accounts:
            if not self._running:
                break

            gid = rec.get("id", "")
            gmail = rec.get("gmail", "")
            password = rec.get("app_password", "") or rec.get("password", "")

            if not gmail or not password:
                self.status_update.emit(gid, "Thiếu Gmail/Password")
                self.finished_one.emit(gid)
                continue

            try:
                self.status_update.emit(gid, "Đang kết nối IMAP...")
                mail = imaplib.IMAP4_SSL("imap.gmail.com", 993, timeout=30)
                mail.login(gmail, password)
                mail.logout()
                self.status_update.emit(gid, "✅ Login Gmail thành công")
            except imaplib.IMAP4.error as e:
                err = str(e)[:60]
                if "AUTHENTICATIONFAILED" in str(e).upper():
                    self.status_update.emit(gid, "❌ Sai pass/App Password")
                else:
                    self.status_update.emit(gid, f"❌ Lỗi: {err}")
            except Exception as e:
                self.status_update.emit(gid, f"❌ Lỗi: {str(e)[:60]}")

            self.finished_one.emit(gid)

        self.finished_all.emit()

    def stop(self):
        self._running = False


# ═══════════════════════════════════════════
#  Gmail Browser Login Thread (Playwright)
#  Supports auto-fill recovery email on Google's
#  "Đảm bảo rằng bạn luôn có thể đăng nhập" page
# ═══════════════════════════════════════════
class GmailBrowserLoginThread(QThread):
    status_update = pyqtSignal(str, str)
    finished_one = pyqtSignal(str)
    finished_all = pyqtSignal()
    recovery_added = pyqtSignal(str, str)  # gmail_id, recovery_email

    live_status = pyqtSignal(str, str)      # gmail_id, "Live" or "Out"

    def __init__(self, accounts: list, headless=False,
                 recovery_domain="", recovery_suffix=""):
        super().__init__()
        self.accounts = accounts
        self.headless = headless
        self.recovery_domain = recovery_domain
        self.recovery_suffix = recovery_suffix
        self._running = True

    def _build_recovery(self, gmail_addr):
        """Build recovery email: username + suffix + @domain.
        Example: buian286684@gmail.com → buian286684abc@tempmail.com"""
        if not self.recovery_domain:
            return ""
        username = gmail_addr.split("@")[0] if "@" in gmail_addr else gmail_addr
        return f"{username}{self.recovery_suffix}@{self.recovery_domain}"

    def run(self):
        import time
        try:
            from playwright.sync_api import sync_playwright
            from core.browser_manager import setup_playwright
            setup_playwright()
        except Exception as e:
            for rec in self.accounts:
                self.status_update.emit(rec.get("id", ""), f"Lỗi Playwright: {str(e)[:50]}")
                self.finished_one.emit(rec.get("id", ""))
            self.finished_all.emit()
            return

        from playwright.sync_api import sync_playwright

        for rec in self.accounts:
            if not self._running:
                break

            gid = rec.get("id", "")
            gmail = rec.get("gmail", "")
            password = rec.get("password", "")
            twofa_secret = rec.get("2fa_secret", "").strip()

            if not gmail or not password:
                self.status_update.emit(gid, "Thiếu Gmail/Password")
                self.finished_one.emit(gid)
                continue

            try:
                self.status_update.emit(gid, "Đang mở trình duyệt...")

                with sync_playwright() as p:
                    # ── Launch Chrome subprocess + CDP connect ──
                    # Google blocks Playwright.launch() → use subprocess Chrome instead
                    import subprocess as sp_sub, socket
                    from core.browser_manager import SmartBrowserDetector

                    def _find_free_port():
                        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                            s.bind(("", 0))
                            return s.getsockname()[1]

                    chrome_exe = SmartBrowserDetector.find_browser("Google Chrome")
                    if not chrome_exe:
                        chrome_exe = SmartBrowserDetector.find_browser("Microsoft Edge")
                    
                    # Get window params for this browser (thread-safe auto-increment)
                    from core.browser_manager import next_browser_window_params
                    wp = next_browser_window_params()
                    
                    if not chrome_exe:
                        # Fallback: Playwright chromium direct (may get blocked by Google)
                        self.status_update.emit(gid, "⚠️ Chrome/Edge not found, dùng Playwright Chromium")
                        browser = p.chromium.launch(
                            headless=self.headless,
                            args=["--disable-blink-features=AutomationControlled",
                                  "--no-sandbox", "--disable-dev-shm-usage"] + wp["chrome_args"]
                        )
                        context = browser.new_context(
                            viewport={"width": wp["win_w"], "height": wp["win_h"]},
                            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                        )
                        page = context.new_page()
                        chrome_proc = None
                    else:
                        cdp_port = _find_free_port()
                        user_data = rec.get("data_dir", "")
                        if not user_data:
                            user_data = gmail_profile_dir(gid)
                        os.makedirs(user_data, exist_ok=True)

                        chrome_args = [
                            chrome_exe,
                            f"--remote-debugging-port={cdp_port}",
                            f"--user-data-dir={user_data}",
                            "--no-first-run",
                            "--no-default-browser-check",
                            "--disable-popup-blocking",
                            "--disable-extensions",
                            "--disable-session-crashed-bubble",
                            "--hide-crash-restore-bubble",
                        ] + wp["chrome_args"]
                        if self.headless:
                            chrome_args.append("--window-position=-32000,-32000")
                        chrome_args.append("about:blank")

                        chrome_proc = sp_sub.Popen(
                            chrome_args,
                            stdout=sp_sub.DEVNULL,
                            stderr=sp_sub.DEVNULL
                        )
                        time.sleep(3)  # Wait for Chrome

                        try:
                            browser = p.chromium.connect_over_cdp(
                                f"http://localhost:{cdp_port}"
                            )
                        except Exception as e:
                            self.status_update.emit(gid, f"❌ Không kết nối được Chrome: {str(e)[:50]}")
                            chrome_proc.terminate()
                            self.finished_one.emit(gid)
                            continue

                        context = browser.contexts[0] if browser.contexts else browser.new_context()
                        page = context.pages[0] if context.pages else context.new_page()

                    # ── Pre-check: Is Gmail already logged in? ──
                    self.status_update.emit(gid, "🔍 Kiểm tra session hiện tại...")
                    skip_email_step = False
                    skip_password_step = False
                    try:
                        page.goto("https://mail.google.com/mail/u/0/#inbox",
                                  wait_until="domcontentloaded", timeout=15000)
                        time.sleep(4)
                        check_url = page.url.lower()
                        check_body = ""
                        try:
                            check_body = page.inner_text("body", timeout=3000)[:1500].lower()
                        except:
                            pass

                        if ("mail.google.com/mail" in check_url and
                            "signin" not in check_url and
                            "accounts.google.com" not in check_url):
                            # ✅ Case 1: Already logged in!
                            self.status_update.emit(gid, "✅ Gmail đã login sẵn! Lưu session...")
                            self.live_status.emit(gid, "Live")
                            time.sleep(3)
                            self.status_update.emit(gid, "✅ Session đã có sẵn — bỏ qua login")
                            try:
                                browser.close()
                            except:
                                pass
                            if chrome_proc:
                                time.sleep(1)
                                chrome_proc.terminate()
                                try: chrome_proc.wait(timeout=10)
                                except: chrome_proc.kill()
                            self.finished_one.emit(gid)
                            continue

                        elif ("accounts.google.com" in check_url and
                              any(kw in check_body for kw in [
                                  "verify it", "xác minh",
                                  "sign in again", "đăng nhập lại",
                                  "please sign in again to continue",
                              ])):
                            # ✅ Case 2: "Verify it's you — sign in again" page
                            self.status_update.emit(gid, "🔄 Phát hiện 'Verify it's you' — đang xử lý...")

                            # Click Next button
                            for btn_sel in [
                                'button:has-text("Next")', 'button:has-text("Tiếp theo")',
                                'button:has-text("OK")', 'button:has-text("Continue")',
                                'button:has-text("Tiếp tục")',
                                '#next button', 'button[type="submit"]',
                            ]:
                                try:
                                    btn = page.locator(btn_sel)
                                    if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                                        btn.first.click()
                                        self.status_update.emit(gid, "✅ Đã click Next trên Verify page")
                                        time.sleep(4)
                                        break
                                except:
                                    continue

                            # Now we might be on password page, email page, or challenge
                            skip_email_step = True  # Email is already selected

                        elif "accounts.google.com" in check_url:
                            # ✅ Case 3: Redirected to login page — stay here, don't re-navigate
                            self.status_update.emit(gid, "🔄 Chưa login — tiếp tục đăng nhập...")
                            # Check if email is already showing (no email input needed)
                            try:
                                email_inp = page.locator('input[type="email"]')
                                if email_inp.count() == 0 or not email_inp.first.is_visible(timeout=2000):
                                    skip_email_step = True
                            except:
                                pass

                    except Exception as e:
                        self.status_update.emit(gid, f"⚠️ Pre-check lỗi: {str(e)[:40]}, tiếp tục login...")

                    # ── Step 1: Enter email (skip if already on password/challenge page) ──
                    if not skip_email_step:
                        # If we're not on a Google page yet, navigate to login
                        try:
                            cur = page.url.lower()
                            if "accounts.google.com" not in cur:
                                page.goto("https://accounts.google.com/signin/v2/identifier?service=mail",
                                          wait_until="domcontentloaded", timeout=30000)
                                time.sleep(2)
                        except:
                            page.goto("https://accounts.google.com/signin/v2/identifier?service=mail",
                                      wait_until="domcontentloaded", timeout=30000)
                            time.sleep(2)

                        self.status_update.emit(gid, "Đang nhập Gmail...")
                        email_filled = False
                        for sel in ['input[type="email"]', 'input[name="identifier"]', '#identifierId']:
                            try:
                                inp = page.locator(sel)
                                if inp.count() > 0:
                                    inp.first.wait_for(state="visible", timeout=8000)
                                    inp.first.fill(gmail)
                                    email_filled = True
                                    break
                            except:
                                continue

                        if not email_filled:
                            # Maybe we're already past email step
                            current_url = page.url.lower()
                            if "myaccount.google" in current_url or "mail.google" in current_url:
                                self.status_update.emit(gid, "✅ Login Gmail thành công!")
                                self.live_status.emit(gid, "Live")
                                browser.close()
                                if chrome_proc: chrome_proc.terminate()
                                self.finished_one.emit(gid)
                                continue
                            # Check if password field is visible (email already submitted)
                            try:
                                pw_inp = page.locator('input[name="Passwd"]')
                                if pw_inp.count() > 0 and pw_inp.first.is_visible(timeout=2000):
                                    skip_email_step = True  # Already on password page
                                else:
                                    self.status_update.emit(gid, "❌ Không tìm thấy ô nhập email")
                                    browser.close()
                                    if chrome_proc: chrome_proc.terminate()
                                    self.finished_one.emit(gid)
                                    continue
                            except:
                                self.status_update.emit(gid, "❌ Không tìm thấy ô nhập email")
                                browser.close()
                                if chrome_proc: chrome_proc.terminate()
                                self.finished_one.emit(gid)
                                continue

                    # Initialize handler flags (needed for status checks later)
                    signin_choice = False
                    handled = False
                    twofa_handled = False

                    # ── Email Click Next + post-email reCAPTCHA (ONLY if email was entered) ──
                    if not skip_email_step:
                        # Click Next after email entry
                        time.sleep(0.5)
                        for sel in ['#identifierNext', '#identifierNext button',
                                    'button:has-text("Tiếp theo")', 'button:has-text("Next")']:
                            try:
                                btn = page.locator(sel)
                                if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                                    btn.first.click()
                                    break
                            except:
                                continue

                        # Wait for page transition
                        time.sleep(4)

                        # Check for reCAPTCHA after email entry
                        captcha_after_email = self._handle_recaptcha(page, gid)
                        if captcha_after_email:
                            time.sleep(3)

                    # ── Step 2: Enter password ──
                    self.status_update.emit(gid, "Đang nhập mật khẩu...")
                    pass_filled = False
                    for attempt in range(3):
                        for sel in ['input[name="Passwd"]', 'input[type="password"]',
                                    'input[name="password"]', '#password input']:
                            try:
                                inp = page.locator(sel)
                                if inp.count() > 0:
                                    inp.first.wait_for(state="visible", timeout=8000)
                                    inp.first.fill(password)
                                    pass_filled = True
                                    break
                            except:
                                continue
                        if pass_filled:
                            break
                        self.status_update.emit(gid, f"Chờ ô password... (lần {attempt+2})")
                        time.sleep(3)

                    if not pass_filled:
                        current_url = page.url.lower()
                        if "myaccount.google" in current_url or "mail.google" in current_url:
                            self.status_update.emit(gid, "✅ Login Gmail thành công (không cần password)!")
                            self.live_status.emit(gid, "Live")
                            browser.close()
                            if chrome_proc: chrome_proc.terminate()
                            self.finished_one.emit(gid)
                            continue
                        # Check for rejection
                        if "rejected" in current_url:
                            self.status_update.emit(gid, "❌ Google từ chối đăng nhập (browser bị chặn)")
                        else:
                            self.status_update.emit(gid, "❌ Không tìm thấy ô nhập password")
                        browser.close()
                        if chrome_proc: chrome_proc.terminate()
                        self.finished_one.emit(gid)
                        continue

                    # Click password Next
                    time.sleep(0.5)
                    for sel in ['#passwordNext', '#passwordNext button',
                                'button:has-text("Tiếp theo")', 'button:has-text("Next")']:
                        try:
                            btn = page.locator(sel)
                            if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                                btn.first.click()
                                break
                        except:
                            continue

                    # Wait for login processing
                    time.sleep(5)

                    # ── Check for reCAPTCHA Challenge ──
                    captcha_handled = self._handle_recaptcha(page, gid)

                    # ── Check for 2FA Verification Page ──
                    twofa_handled = self._handle_2fa_page(page, gid, twofa_secret)

                    # ── Check for "Choose how you want to sign in" page ──
                    signin_choice = self._handle_signin_choice_page(page, gid, rec, twofa_secret)

                    # ── Check for Google Recovery Page ──
                    handled = self._handle_recovery_page(page, gid, gmail)

                    # ── Handle additional verification pages (address, birthday, phone) ──
                    for _attempt in range(3):  # Up to 3 verification screens
                        if not self._handle_verification_pages(page, gid):
                            break
                        time.sleep(2)

                    # Check result — re-read URL after all handlers may have navigated
                    time.sleep(2)
                    try:
                        current_url = page.url
                    except:
                        current_url = ""
                    if "myaccount.google" in current_url or "mail.google" in current_url:
                        self.status_update.emit(gid, "✅ Login Gmail thành công!")
                        self.live_status.emit(gid, "Live")

                        # ── Auto-confirm device login security alerts ──
                        self._handle_security_alert(page, gid)

                        # ── Navigate to inbox to establish Gmail session cookies ──
                        try:
                            page.goto("https://mail.google.com/mail/u/0/#inbox", timeout=15000)
                            time.sleep(3)
                        except:
                            pass

                        # ── Wait for Chrome to flush cookies to disk ──
                        self.status_update.emit(gid, "💾 Đang lưu session...")
                        time.sleep(3)

                        # ── Auto-setup 2FA if not already configured ──
                        if not twofa_secret:
                            try:
                                secret = self._setup_2fa_after_login(page, gid, gmail)
                                if secret:
                                    twofa_secret = secret
                                    # Update the record so the table can reflect it
                                    rec["2fa_secret"] = secret
                            except Exception as e:
                                self.status_update.emit(gid, f"⚠️ Lỗi bật 2FA: {str(e)[:40]}")

                    elif "challenge" in current_url and not twofa_handled and not signin_choice:
                        self.status_update.emit(gid, "⚠️ Cần xác minh 2 bước (thiếu 2FA secret)")
                        self.live_status.emit(gid, "Out")
                    elif "signin" in current_url and not handled and not signin_choice:
                        self.status_update.emit(gid, "❌ Sai mật khẩu hoặc bị khóa")
                        self.live_status.emit(gid, "Out")
                    elif not handled and not signin_choice:
                        self.status_update.emit(gid, f"⚠️ Trang: {current_url[:60]}")

                    # ── Close browser gracefully ──
                    try:
                        browser.close()
                    except:
                        pass
                    if chrome_proc:
                        time.sleep(2)
                        chrome_proc.terminate()
                        try: chrome_proc.wait(timeout=10)
                        except: chrome_proc.kill()

                    # Final status update after session saved
                    if "myaccount.google" in current_url or "mail.google" in current_url:
                        self.status_update.emit(gid, "✅ Login Gmail thành công! Session đã lưu")

            except Exception as e:
                self.status_update.emit(gid, f"❌ Lỗi: {str(e)[:60]}")

            self.finished_one.emit(gid)

        self.finished_all.emit()

    def _handle_recaptcha(self, page, gid):
        """Detect and auto-solve reCAPTCHA using global CAPTCHA solver."""
        try:
            from core.captcha_solver import handle_captcha_on_page
            return handle_captcha_on_page(
                page,
                status_callback=lambda msg: self.status_update.emit(gid, msg)
            )
        except Exception as e:
            self.status_update.emit(gid, f"⚠️ Lỗi CAPTCHA: {str(e)[:50]}")
            return False

    def _handle_2fa_page(self, page, gid, twofa_secret):
        """Detect Google's 2FA verification page and auto-fill TOTP code.
        Page shows: 'Xác minh 2 bước' with 'Nhập mã' input.
        Uses pyotp to generate TOTP from the 2fa_secret.
        Returns True if 2FA page was detected and handled."""
        import time
        try:
            body_text = ""
            try:
                body_text = page.inner_text("body", timeout=3000)[:1500].lower()
            except:
                return False

            # Detect 2FA page patterns
            is_2fa_page = any(kw in body_text for kw in [
                "xác minh 2 bước",
                "2-step verification",
                "enter the code",
                "google authenticator",
                "authenticator app",
                "nhận mã xác minh từ ứng dụng",
                "enter a code from the google authenticator",
                "get a verification code from the google authenticator",
            ])

            # Exclude phone verification pages (NOT 2FA TOTP)
            is_phone_page = any(kw in body_text for kw in [
                "phone number", "số điện thoại",
                "send a text message", "gửi tin nhắn",
                "enter the phone number", "nhập số điện thoại",
                "verify your phone", "xác minh điện thoại",
            ])

            if not is_2fa_page or is_phone_page:
                return False

            # Also check URL for safety — TOTP pages typically have 'totp' in URL
            page_url = page.url.lower()
            has_totp_url = 'totp' in page_url or 'authenticator' in page_url

            self.status_update.emit(gid, "🔐 Phát hiện trang xác minh 2 bước")

            if not twofa_secret:
                self.status_update.emit(gid, "⚠️ Cần 2FA nhưng thiếu 2FA Secret trong profile")
                return True

            # Generate TOTP code
            try:
                import pyotp
                # Clean up secret: remove spaces, dashes
                clean_secret = twofa_secret.replace(" ", "").replace("-", "").strip()
                totp = pyotp.TOTP(clean_secret)
                code = totp.now()
                self.status_update.emit(gid, f"🔑 Đã tạo mã TOTP: {code}")
            except Exception as e:
                self.status_update.emit(gid, f"❌ Lỗi tạo TOTP: {str(e)[:50]}")
                return True

            # Find and fill the TOTP input (prioritize named TOTP inputs)
            filled = False
            for selector in [
                'input[name="totpPin"]',
                'input[id="totpPin"]',
                '#totpPin',
                'input[name="pin"]',
                'input[autocomplete="one-time-code"]',
                'input[aria-label*="code"]',
                'input[aria-label*="mã"]',
            ]:
                try:
                    inp = page.locator(selector)
                    if inp.count() > 0 and inp.first.is_visible(timeout=2000):
                        inp.first.fill(code)
                        filled = True
                        self.status_update.emit(gid, f"✅ Đã điền mã 2FA: {code}")
                        break
                except:
                    continue

            if not filled:
                # Fallback: try visible text input that's empty (NOT tel to avoid phone fields)
                try:
                    for sel in ['input[type="text"]']:
                        inputs = page.locator(sel)
                        for i in range(inputs.count()):
                            inp = inputs.nth(i)
                            if inp.is_visible() and not inp.input_value():
                                inp.fill(code)
                                filled = True
                                self.status_update.emit(gid, f"✅ Đã điền mã 2FA (fallback): {code}")
                                break
                        if filled:
                            break
                except:
                    pass
            if not filled and has_totp_url:
                # Last resort: try tel input ONLY if URL confirms this is a TOTP page
                try:
                    tel_inp = page.locator('input[type="tel"]')
                    if tel_inp.count() > 0 and tel_inp.first.is_visible(timeout=2000):
                        tel_inp.first.fill(code)
                        filled = True
                        self.status_update.emit(gid, f"✅ Đã điền mã 2FA (tel): {code}")
                except:
                    pass

            if not filled:
                self.status_update.emit(gid, "❌ Không tìm thấy ô nhập mã 2FA")
                return True

            # Submit: click "Tiếp theo" / "Next"
            time.sleep(1)
            for btn_sel in [
                'button:has-text("Tiếp theo")',
                'button:has-text("Next")',
                'button:has-text("Verify")',
                'button:has-text("Xác minh")',
                '#totpNext',
                'button[type="submit"]',
            ]:
                try:
                    btn = page.locator(btn_sel)
                    if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                        btn.first.click()
                        time.sleep(5)  # Wait for verification
                        self.status_update.emit(gid, "✅ Đã xác minh 2FA thành công!")
                        return True
                except:
                    continue

            # Fallback: press Enter
            page.keyboard.press("Enter")
            time.sleep(5)
            self.status_update.emit(gid, "✅ Đã gửi mã 2FA")
            return True

        except Exception as e:
            self.status_update.emit(gid, f"⚠️ Lỗi xử lý 2FA: {str(e)[:50]}")
            return False

    def _handle_signin_choice_page(self, page, gid, rec, twofa_secret=""):
        """Handle Google's 'Choose how you want to sign in' page.
        Supports two flows:
        1. Google Authenticator → click, then enter 2FA TOTP code
        2. Confirm recovery email → enter recovery email(s)
        Returns True if the page was detected and handled."""
        import time
        try:
            body_text = ""
            try:
                body_text = page.inner_text("body", timeout=3000)[:2000].lower()
            except:
                return False

            # Detect "Choose how you want to sign in" page
            is_choice_page = any(kw in body_text for kw in [
                "choose how you want to sign in",
                "confirm your recovery email",
                "chọn cách bạn muốn đăng nhập",
                "xác nhận email khôi phục",
                "get a verification code at",
                "use another phone or computer",
                "try another way",
                "google authenticator",
                "use your passkey",
                "tap yes on your phone",
            ])

            if not is_choice_page:
                return False

            self.status_update.emit(gid, "🔐 Phát hiện trang chọn phương thức đăng nhập")

            # ── Priority 1: Google Authenticator (if 2FA secret available) ──
            has_authenticator = any(kw in body_text for kw in [
                "google authenticator",
                "authenticator app",
                "ứng dụng authenticator",
            ])

            if has_authenticator and twofa_secret:
                self.status_update.emit(gid, "🔑 Chọn Google Authenticator...")

                # Click "Get a verification code from the Google Authenticator app"
                clicked_auth = False
                for kw in [
                    "Get a verification code from the Google Authenticator app",
                    "Google Authenticator",
                    "Authenticator app",
                    "Ứng dụng Authenticator",
                    "authenticator",
                ]:
                    try:
                        el = page.get_by_text(kw, exact=False)
                        if el.count() > 0 and el.first.is_visible(timeout=3000):
                            el.first.click()
                            clicked_auth = True
                            self.status_update.emit(gid, "✅ Đã chọn Google Authenticator")
                            time.sleep(3)
                            break
                    except:
                        continue

                if not clicked_auth:
                    # Try CSS selectors
                    for sel in [
                        'div:has-text("Google Authenticator")',
                        'div:has-text("Authenticator app")',
                        'li:has-text("Authenticator")',
                    ]:
                        try:
                            el = page.locator(sel)
                            if el.count() > 0 and el.first.is_visible(timeout=2000):
                                el.first.click()
                                clicked_auth = True
                                self.status_update.emit(gid, "✅ Đã chọn Authenticator option")
                                time.sleep(3)
                                break
                        except:
                            continue

                if clicked_auth:
                    # Now the 2FA input page should appear — delegate to _handle_2fa_page
                    self.status_update.emit(gid, "🔑 Nhập mã 2FA từ Authenticator...")
                    result = self._handle_2fa_page(page, gid, twofa_secret)
                    if result:
                        return True
                    # If 2FA handler didn't find input, it might still be loading
                    time.sleep(3)
                    result = self._handle_2fa_page(page, gid, twofa_secret)
                    return True
                else:
                    self.status_update.emit(gid, "⚠️ Không click được Google Authenticator")

            elif has_authenticator and not twofa_secret:
                self.status_update.emit(gid, "⚠️ Cần 2FA secret nhưng chưa có trong dữ liệu!")
                # Fall through to recovery email if available

            # ── Priority 2: Recovery Email ──
            has_recovery_option = any(kw in body_text for kw in [
                "confirm your recovery email",
                "xác nhận email khôi phục",
            ])

            # Get recovery emails from account data
            raw_recovery = rec.get("recovery_email", "").strip()
            if not raw_recovery and not has_recovery_option:
                self.status_update.emit(gid, "⚠️ Không có phương thức đăng nhập khả dụng!")
                return True
            if not raw_recovery:
                self.status_update.emit(gid, "⚠️ Thiếu Recovery Email trong dữ liệu!")
                return True

            # Parse multiple recovery emails (separated by | , ; or space)
            import re
            recovery_list = [e.strip() for e in re.split(r'[|,;\s]+', raw_recovery) if '@' in e.strip()]
            if not recovery_list:
                self.status_update.emit(gid, f"⚠️ Recovery email không hợp lệ: {raw_recovery}")
                return True

            self.status_update.emit(gid, f"📧 Có {len(recovery_list)} recovery email")

            # Step 1: Click "Confirm your recovery email" option
            clicked_option = False
            for kw in [
                "Confirm your recovery email",
                "Xác nhận email khôi phục",
                "recovery email",
            ]:
                try:
                    el = page.get_by_text(kw, exact=False)
                    if el.count() > 0 and el.first.is_visible(timeout=3000):
                        el.first.click()
                        clicked_option = True
                        self.status_update.emit(gid, "✅ Đã chọn 'Confirm recovery email'")
                        time.sleep(3)
                        break
                except:
                    continue

            if not clicked_option:
                # Try clicking any element containing the recovery option text
                for sel in [
                    'div:has-text("Confirm your recovery email")',
                    'div:has-text("Xác nhận email khôi phục")',
                    'li:has-text("recovery email")',
                    'button:has-text("recovery email")',
                ]:
                    try:
                        el = page.locator(sel)
                        if el.count() > 0 and el.first.is_visible(timeout=2000):
                            el.first.click()
                            clicked_option = True
                            self.status_update.emit(gid, "✅ Đã chọn recovery email option")
                            time.sleep(3)
                            break
                    except:
                        continue

            if not clicked_option:
                self.status_update.emit(gid, "⚠️ Không tìm thấy nút 'Confirm recovery email'")
                return True

            # Step 2: Try each recovery email
            for idx, recovery_email in enumerate(recovery_list):
                self.status_update.emit(
                    gid,
                    f"📝 Thử recovery #{idx+1}: {recovery_email}"
                )

                # Wait for and fill the recovery email input
                filled = False
                for selector in [
                    'input[type="email"]',
                    'input[name="knowledgePreregisteredEmailResponse"]',
                    'input[aria-label*="email"]',
                    'input[aria-label*="Email"]',
                    'input[type="text"]',
                ]:
                    try:
                        inp = page.locator(selector)
                        if inp.count() > 0 and inp.first.is_visible(timeout=5000):
                            inp.first.fill("")
                            time.sleep(0.3)
                            inp.first.fill(recovery_email)
                            filled = True
                            break
                    except:
                        continue

                if not filled:
                    self.status_update.emit(gid, "❌ Không tìm thấy ô nhập email")
                    continue

                # Click Next / Submit
                time.sleep(0.5)
                submitted = False
                for btn_sel in [
                    'button:has-text("Next")',
                    'button:has-text("Tiếp theo")',
                    'button[type="submit"]',
                    '#next',
                ]:
                    try:
                        btn = page.locator(btn_sel)
                        if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                            btn.first.click()
                            submitted = True
                            break
                    except:
                        continue

                if not submitted:
                    page.keyboard.press("Enter")

                time.sleep(5)

                # Check result: did we get past the page?
                try:
                    new_url = page.url.lower()
                    new_body = page.inner_text("body", timeout=3000)[:1500].lower()

                    # Check for error messages FIRST
                    has_error = any(err in new_body for err in [
                        "incorrect", "wrong answer", "doesn't match",
                        "try again", "sai", "không đúng", "thử lại",
                        "email you entered is incorrect",
                    ])

                    if has_error:
                        self.status_update.emit(
                            gid,
                            f"❌ Recovery #{idx+1} sai: {recovery_email}"
                        )
                        if idx < len(recovery_list) - 1:
                            self.status_update.emit(gid, "🔄 Thử recovery email tiếp...")
                            # Clear the input and enter next email
                            time.sleep(2)
                            continue
                        else:
                            self.status_update.emit(gid, "❌ Tất cả recovery email đều sai")
                            return True

                    # No error — check if moved to success page
                    if ("myaccount.google" in new_url or
                        "mail.google" in new_url):
                        self.status_update.emit(
                            gid,
                            f"✅ Recovery email #{idx+1} thành công!"
                        )
                        return True

                    # Still on challenge page but no error = might need more steps
                    if "challenge" in new_url and not has_error:
                        self.status_update.emit(
                            gid,
                            f"✅ Recovery email #{idx+1} đã gửi, đang xử lý..."
                        )
                        return True

                    # Unknown state
                    self.status_update.emit(
                        gid,
                        f"⚠️ Trạng thái không rõ sau recovery #{idx+1}"
                    )
                    return True

                except Exception:
                    self.status_update.emit(gid, "✅ Đã gửi recovery email")
                    return True

            self.status_update.emit(gid, "❌ Không xác minh được bằng recovery email")
            return True

        except Exception as e:
            self.status_update.emit(gid, f"⚠️ Lỗi xử lý sign-in choice: {str(e)[:50]}")
            return False

    def _handle_recovery_page(self, page, gid, gmail):
        """Detect and handle Google's recovery info page.
        The page asks: 'Thêm email khôi phục' with input field.
        Auto-fills recovery email if recovery_domain is configured.
        Returns True if recovery page was handled."""
        import time
        try:
            body_text = ""
            try:
                body_text = page.inner_text("body", timeout=3000)[:1000].lower()
            except:
                return False

            # Detect recovery page patterns (Vietnamese + English)
            is_recovery_page = any(kw in body_text for kw in [
                "email khôi phục",
                "thêm email khôi phục",
                "đảm bảo rằng bạn",
                "luôn có thể đăng nhập",
                "recovery email",
                "add a recovery email",
                "ways to verify",
                "make sure you can always",
                "nhập địa chỉ email khôi phục",
            ])

            if not is_recovery_page:
                return False

            self.status_update.emit(gid, "📋 Phát hiện trang thêm email khôi phục")

            if not self.recovery_domain:
                self.status_update.emit(gid, "⚠️ Trang recovery - chưa cấu hình domain")
                # Try to skip/dismiss
                self._try_skip_recovery(page, gid)
                return True

            # Build recovery email
            recovery_email = self._build_recovery(gmail)
            self.status_update.emit(gid, f"📝 Điền recovery: {recovery_email}")

            # Find and fill the recovery email input
            filled = False
            for selector in [
                'input[name="recovery"]',
                'input[aria-label*="khôi phục"]',
                'input[aria-label*="recovery"]',
                'input[type="email"]:not([name="identifier"])',
                'input[placeholder*="email khôi phục"]',
                'input[placeholder*="recovery"]',
                '#recoveryEmailId',
                'input[name="recoveryEmail"]',
            ]:
                try:
                    inp = page.locator(selector)
                    if inp.count() > 0 and inp.first.is_visible(timeout=2000):
                        inp.first.fill(recovery_email)
                        filled = True
                        self.status_update.emit(gid, f"✅ Đã điền: {recovery_email}")
                        break
                except:
                    continue

            if not filled:
                # Fallback: try any visible email-type input that's empty
                try:
                    inputs = page.locator('input[type="email"]')
                    for i in range(inputs.count()):
                        inp = inputs.nth(i)
                        if inp.is_visible() and not inp.input_value():
                            inp.fill(recovery_email)
                            filled = True
                            self.status_update.emit(gid, f"✅ Đã điền (fallback): {recovery_email}")
                            break
                except:
                    pass

            if not filled:
                self.status_update.emit(gid, "❌ Không tìm thấy ô nhập recovery email")
                self._try_skip_recovery(page, gid)
                return True

            # Submit: click "Lưu" / "Save" / "Next" button
            time.sleep(1)
            for btn_sel in [
                'button:has-text("Lưu")',
                'button:has-text("Save")',
                'button:has-text("Next")',
                'button:has-text("Tiếp")',
                '#next',
                'button[type="submit"]',
            ]:
                try:
                    btn = page.locator(btn_sel)
                    if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                        btn.first.click()
                        time.sleep(3)
                        self.status_update.emit(gid, f"✅ Đã lưu recovery: {recovery_email}")
                        self.recovery_added.emit(gid, recovery_email)
                        return True
                except:
                    continue

            # If no submit button found, try Enter
            page.keyboard.press("Enter")
            time.sleep(3)
            self.status_update.emit(gid, f"✅ Đã gửi recovery: {recovery_email}")
            self.recovery_added.emit(gid, recovery_email)
            return True

        except Exception as e:
            self.status_update.emit(gid, f"⚠️ Lỗi xử lý recovery: {str(e)[:50]}")
            return False

    def _try_skip_recovery(self, page, gid):
        """Try to skip the recovery info page."""
        import time
        for sel in [
            'button:has-text("Bỏ qua")',
            'button:has-text("Skip")',
            'button:has-text("Huỷ")',
            'button:has-text("Cancel")',
            'a:has-text("Bỏ qua")',
            'a:has-text("Skip")',
            '#skip',
        ]:
            try:
                el = page.locator(sel)
                if el.count() > 0 and el.first.is_visible(timeout=1500):
                    el.first.click()
                    time.sleep(2)
                    self.status_update.emit(gid, "⏭️ Bỏ qua trang recovery")
                    return
            except:
                continue

    def _handle_verification_pages(self, page, gid):
        """Handle Google verification pages: address, birthday, phone, security prompts.
        Returns True if a verification page was detected and handled."""
        import time
        import random
        try:
            body_text = ""
            try:
                body_text = page.inner_text("body", timeout=3000)[:2000].lower()
            except:
                return False

            current_url = page.url.lower()

            # Already logged in? Stop.
            if "myaccount.google" in current_url or "mail.google" in current_url:
                return False

            skip_keywords = [
                "bỏ qua", "skip", "not now", "để sau", "không phải bây giờ",
                "huỷ", "cancel", "dismiss", "no thanks", "remind me later",
                "nhắc tôi sau", "done", "hoàn tất", "xong",
            ]

            # ── Birthday verification ──
            if any(kw in body_text for kw in [
                "ngày sinh", "date of birth", "birthday", "sinh nhật",
                "năm sinh", "tháng sinh",
            ]):
                self.status_update.emit(gid, "📋 Phát hiện trang xác minh ngày sinh")
                year = random.randint(1985, 2000)
                month = random.randint(1, 12)
                day = random.randint(1, 28)
                for sel, val in [
                    ('select[name="month"], #month', str(month)),
                    ('input[name="day"], #day', str(day)),
                    ('input[name="year"], #year', str(year)),
                ]:
                    for s in sel.split(', '):
                        try:
                            el = page.locator(s)
                            if el.count() > 0 and el.first.is_visible(timeout=2000):
                                if 'select' in s:
                                    el.first.select_option(value=val)
                                else:
                                    el.first.fill(val)
                                break
                        except:
                            continue
                self._click_next_or_submit(page, gid)
                return True

            # ── Phone verification — try skip, then auto-verify if configured ──
            # IMPORTANT: Must run BEFORE address check, because phone page has
            # country-code selector containing "country" which falsely triggers address.
            # BUT must NOT match 2FA/TOTP pages (those have "authenticator", "2-step", etc.)
            is_2fa_like = any(kw in body_text for kw in [
                "authenticator", "2-step", "totp", "xác minh 2 bước",
                "google authenticator", "authenticator app",
            ])
            if not is_2fa_like and any(kw in body_text for kw in [
                "số điện thoại", "phone number", "verify your phone",
                "xác minh số", "add phone", "thêm số điện thoại",
                "enter a phone number", "nhập số điện thoại",
                "confirm your phone",
                "text message with a verification",
            ]):
                self.status_update.emit(gid, "📱 Phát hiện trang xác minh SĐT")

                # Step 1: Try to skip first
                skipped = False
                for kw in skip_keywords:
                    for tag in ['button', 'a', 'span']:
                        try:
                            el = page.locator(f'{tag}:has-text("{kw}")')
                            if el.count() > 0 and el.first.is_visible(timeout=1500):
                                el.first.click()
                                time.sleep(3)
                                # Check if we actually moved past phone page
                                try:
                                    new_body = page.inner_text("body", timeout=2000)[:1500].lower()
                                    if not any(pk in new_body for pk in ["phone number", "số điện thoại", "nhập số", "enter a phone"]):
                                        self.status_update.emit(gid, "⏭️ Đã bỏ qua xác minh SĐT")
                                        skipped = True
                                        break
                                except:
                                    pass
                        except:
                            continue
                    if skipped:
                        break

                if skipped:
                    return True

                # Step 2: Auto-verify using phone rental service
                # Guard against re-entry: only try once per account
                if not hasattr(self, '_phone_verified_gids'):
                    self._phone_verified_gids = set()
                if gid in self._phone_verified_gids:
                    self.status_update.emit(gid, "⚠️ Đã thử xác minh SĐT rồi — bỏ qua")
                    return False  # Don't retry
                self._phone_verified_gids.add(gid)
                self._handle_phone_verification(page, gid)
                return False  # Stop outer loop — phone verification done (success or fail)

            # ── Address / location verification ──
            if any(kw in body_text for kw in [
                "địa chỉ", "address", "street", "city", "state", "zip",
                "nơi ở", "quốc gia",
            ]):
                self.status_update.emit(gid, "📋 Phát hiện trang xác minh địa chỉ")
                addresses = [
                    {"street": "123 Main St", "city": "New York", "state": "NY", "zip": "10001"},
                    {"street": "456 Oak Ave", "city": "Los Angeles", "state": "CA", "zip": "90001"},
                    {"street": "789 Pine Rd", "city": "Chicago", "state": "IL", "zip": "60601"},
                    {"street": "321 Elm St", "city": "Houston", "state": "TX", "zip": "77001"},
                    {"street": "654 Maple Dr", "city": "Phoenix", "state": "AZ", "zip": "85001"},
                ]
                addr = random.choice(addresses)
                for sel_group, val in [
                    (['input[name*="street"]', 'input[name*="address"]', 'input[autocomplete="street-address"]'], addr["street"]),
                    (['input[name*="city"]', 'input[autocomplete="address-level2"]'], addr["city"]),
                    (['input[name*="state"]', 'select[name*="state"]', 'input[autocomplete="address-level1"]'], addr["state"]),
                    (['input[name*="zip"]', 'input[name*="postal"]', 'input[autocomplete="postal-code"]'], addr["zip"]),
                ]:
                    for s in sel_group:
                        try:
                            el = page.locator(s)
                            if el.count() > 0 and el.first.is_visible(timeout=1500):
                                if 'select' in s:
                                    el.first.select_option(label=val)
                                else:
                                    el.first.fill(val)
                                break
                        except:
                            continue
                self._click_next_or_submit(page, gid)
                return True


            # ── Device login security alert (red warning) ──
            # Google shows "Google đã chặn hoạt động đăng nhập đáng ngờ"
            # with buttons: "Có, tôi hoạt thao tác" / "Không, bảo mật tài khoản"
            if any(kw in body_text for kw in [
                "đăng nhập đáng ngờ", "suspicious sign-in", "suspicious activity",
                "blocked a sign-in", "chặn hoạt động đăng nhập",
                "đã chặn hoạt động", "critical security alert",
                "cảnh báo bảo mật quan trọng", "cảnh báo bảo mật",
                "was it you", "bạn có phải",
                "review your devices", "xem lại thiết bị",
            ]) or "/notifications/" in current_url:
                self.status_update.emit(gid, "🔴 Phát hiện cảnh báo bảo mật — đang xác nhận thiết bị...")
                confirmed = False
                # Try clicking "Yes, it was me" / "Có, tôi hoạt thao tác"
                for kw in [
                    "Có, tôi hoạt thao tác", "Yes, it was me", "Yes, that was me",
                    "Có, đó là tôi", "Có", "Yes",
                    "It was me", "tôi hoạt thao tác", "tôi đã thao tác",
                ]:
                    for tag in ['button', 'a', 'span', 'div']:
                        try:
                            el = page.locator(f'{tag}:has-text("{kw}")')
                            if el.count() > 0 and el.first.is_visible(timeout=1500):
                                el.first.click()
                                time.sleep(3)
                                self.status_update.emit(gid, f"✅ Đã xác nhận thiết bị đăng nhập")
                                confirmed = True
                                break
                        except:
                            continue
                    if confirmed:
                        break
                if not confirmed:
                    # Fallback: click any green/primary button
                    try:
                        page.evaluate("""() => {
                            var btns = document.querySelectorAll('button, a[role="button"]');
                            for (var b of btns) {
                                var s = getComputedStyle(b);
                                var bg = s.backgroundColor || '';
                                // Green buttons (confirm) typically have green bg
                                if ((bg.indexOf('rgb(26') >= 0 || bg.indexOf('rgb(34') >= 0 || bg.indexOf('#1') >= 0) && b.offsetWidth > 0) {
                                    b.click(); return true;
                                }
                            }
                            // Just click the first visible button that's not red/danger
                            for (var b of btns) {
                                if (b.offsetWidth > 80 && b.offsetHeight > 25) {
                                    var t = (b.textContent || '').toLowerCase();
                                    if (t.indexOf('không') < 0 && t.indexOf('no') < 0 && t.indexOf('bảo mật') < 0) {
                                        b.click(); return true;
                                    }
                                }
                            }
                            return false;
                        }""")
                        self.status_update.emit(gid, "✅ Đã xác nhận cảnh báo bảo mật")
                        confirmed = True
                    except:
                        pass
                    time.sleep(2)
                return True

            # ── Generic security / account protection prompts ──
            if any(kw in body_text for kw in [
                "bảo mật tài khoản", "account security", "protect your account",
                "bảo vệ tài khoản", "keep your account safe",
                "confirm your identity", "xác nhận danh tính",
                "unusual activity", "hoạt động bất thường",
            ]):
                self.status_update.emit(gid, "🔒 Phát hiện trang bảo mật — thử bỏ qua")
                for kw in skip_keywords:
                    for tag in ['button', 'a', 'span']:
                        try:
                            el = page.locator(f'{tag}:has-text("{kw}")')
                            if el.count() > 0 and el.first.is_visible(timeout=1500):
                                el.first.click()
                                time.sleep(2)
                                self.status_update.emit(gid, "⏭️ Đã bỏ qua trang bảo mật")
                                return True
                        except:
                            continue
                self._click_next_or_submit(page, gid)
                return True

            return False

        except Exception as e:
            self.status_update.emit(gid, f"⚠️ Lỗi xử lý verification: {str(e)[:50]}")
            return False

    def _click_next_or_submit(self, page, gid):
        """Click Next/Submit/Continue button on verification pages."""
        import time
        time.sleep(1)
        for sel in [
            'button:has-text("Tiếp theo")', 'button:has-text("Next")',
            'button:has-text("Lưu")', 'button:has-text("Save")',
            'button:has-text("Xác nhận")', 'button:has-text("Confirm")',
            'button:has-text("Gửi")', 'button:has-text("Submit")',
            'button:has-text("Verify")', 'button:has-text("Xác minh")',
            'button:has-text("Send")',
            'button[type="submit"]', '#next',
        ]:
            try:
                btn = page.locator(sel)
                if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                    btn.first.click()
                    time.sleep(3)
                    self.status_update.emit(gid, "✅ Đã submit verification")
                    return
            except:
                continue
        page.keyboard.press("Enter")
        time.sleep(3)

    def _handle_security_alert(self, page, gid):
        """Auto-confirm device login security alert.
        Google shows red 'Cảnh báo bảo mật quan trọng' with 'Có, tôi hoạt thao tác' button.
        URL pattern: myaccount.google.com/notifications/eid/...
        """
        import time
        try:
            url = page.url.lower()
            # Not a notification page? Check current page content
            if "/notifications/" not in url:
                try:
                    body = page.inner_text("body", timeout=2000)[:1500].lower()
                except:
                    return False
                if not any(kw in body for kw in [
                    "đăng nhập đáng ngờ", "suspicious sign-in", "blocked a sign-in",
                    "chặn hoạt động đăng nhập", "đã chặn hoạt động",
                    "cảnh báo bảo mật quan trọng", "critical security alert",
                    "was it you",
                ]):
                    return False

            self.status_update.emit(gid, "🔴 Phát hiện cảnh báo bảo mật — xác nhận thiết bị...")

            # Try clicking "Có, tôi hoạt thao tác" / "Yes, it was me"
            for kw in [
                "Có, tôi hoạt thao tác", "Yes, it was me", "Yes, that was me",
                "Có, đó là tôi", "Có", "Yes", "It was me",
                "tôi hoạt thao tác", "tôi đã thao tác",
            ]:
                for tag in ['button', 'a', 'span', 'div[role="button"]']:
                    try:
                        el = page.locator(f'{tag}:has-text("{kw}")')
                        if el.count() > 0 and el.first.is_visible(timeout=1500):
                            el.first.click()
                            time.sleep(3)
                            self.status_update.emit(gid, "✅ Đã xác nhận thiết bị đăng nhập")
                            return True
                    except:
                        continue

            # Fallback: click green/primary button (not "Không")
            try:
                result = page.evaluate("""() => {
                    var btns = document.querySelectorAll('button, a[role="button"]');
                    for (var b of btns) {
                        if (b.offsetWidth > 80 && b.offsetHeight > 25) {
                            var t = (b.textContent || '').toLowerCase();
                            if (t.indexOf('không') < 0 && t.indexOf('no') < 0 && t.indexOf('bảo mật') < 0 && t.indexOf('secure') < 0) {
                                b.click(); return true;
                            }
                        }
                    }
                    return false;
                }""")
                if result:
                    self.status_update.emit(gid, "✅ Đã xác nhận cảnh báo bảo mật")
                    time.sleep(3)
                    return True
            except:
                pass

            return False
        except:
            return False

    def _handle_phone_verification(self, page, gid):
        """Auto-verify phone number using phone rental service from PhoneSettings."""
        import time
        try:
            from core.phone_settings import PhoneSettings
            ps = PhoneSettings.instance()

            # Check if auto-verify is enabled
            if not ps.auto_verify_phone:
                self.status_update.emit(gid, "⚠️ Xác minh SĐT tự động đã TẮT (bật trong Setting Phone)")
                return

            # Get phone service
            svc = ps.get_current_service()
            if svc is None:
                self.status_update.emit(gid, "⚠️ Chưa cấu hình dịch vụ thuê SĐT (Setting Phone)")
                return

            api_key = ps.get_api_key()
            if not api_key:
                self.status_update.emit(gid, f"⚠️ Thiếu API Key cho {ps.selected_site} (Setting Phone)")
                return

            max_retries = ps.max_retries
            timeout = ps.wait_timeout
            poll_interval = ps.poll_interval

            for attempt in range(max_retries):
                if attempt > 0:
                    self.status_update.emit(gid, f"📱 Thử số mới ({attempt + 1}/{max_retries})...")
                    time.sleep(2)

                # Step 1: Rent a number
                self.status_update.emit(gid, f"📱 Đang thuê SĐT từ {svc.name}...")
                phone_number, order_id = svc.rent_number(service="google", country=ps.country)

                if not phone_number or not order_id:
                    self.status_update.emit(gid, f"❌ Không thuê được SĐT từ {svc.name}")
                    continue

                self.status_update.emit(gid, f"📱 SĐT: {phone_number} (orderId: {order_id[:20]})")

                # Step 2a: Select the correct country code in Google's dropdown
                COUNTRY_MAP_GOOGLE = {
                    "vn": ("Vietnam", "+84"),
                    "us": ("United States", "+1"),
                    "uk": ("United Kingdom", "+44"),
                    "ru": ("Russia", "+7"),
                    "in": ("India", "+91"),
                    "id": ("Indonesia", "+62"),
                    "ph": ("Philippines", "+63"),
                }
                country_info = COUNTRY_MAP_GOOGLE.get(ps.country, ("Vietnam", "+84"))
                country_name, country_code = country_info

                try:
                    # Use JS to find and click the country code selector
                    # Google's phone page uses custom divs, not <select>
                    country_selected = page.evaluate("""(countryName) => {
                        // Step 1: Find the flag/country-code clickable area
                        // It's a div showing "+1" near the phone input
                        var allDivs = document.querySelectorAll('div');
                        var flagParent = null;
                        for (var d of allDivs) {
                            var text = (d.textContent || '').trim();
                            // Find the div that shows just the country code like "+1"
                            if (text.match(/^\\+\\d{1,3}$/) && d.offsetWidth > 0) {
                                // Go up to find the clickable parent
                                var parent = d.parentElement;
                                for (var i = 0; i < 3 && parent; i++) {
                                    if (parent.getAttribute('jsaction') || parent.getAttribute('tabindex') || parent.onclick) {
                                        flagParent = parent;
                                        break;
                                    }
                                    parent = parent.parentElement;
                                }
                                if (!flagParent) flagParent = d.parentElement;
                                break;
                            }
                        }
                        
                        if (!flagParent) return 'no_flag_found';
                        
                        // Click to open dropdown
                        flagParent.click();
                        return 'clicked';
                    }""", country_name)

                    if country_selected == 'clicked':
                        self.status_update.emit(gid, f"📱 Đã mở dropdown quốc gia")
                        time.sleep(1.5)

                        # Now click the correct country from the dropdown list
                        selected = page.evaluate("""(countryName) => {
                            // Google's dropdown shows country list items
                            // Look for li elements or div items containing the country name
                            var items = document.querySelectorAll('li, div[role="option"], ul > div');
                            for (var item of items) {
                                var text = (item.textContent || '').trim();
                                if (text.toLowerCase().indexOf(countryName.toLowerCase()) >= 0 && item.offsetWidth > 0) {
                                    item.click();
                                    return 'selected: ' + text.substring(0, 40);
                                }
                            }
                            return 'not_found';
                        }""", country_name)

                        if selected.startswith('selected'):
                            self.status_update.emit(gid, f"📱 Đã chọn: {selected[10:]}")
                        else:
                            # Try typing the country name to filter
                            try:
                                page.keyboard.type(country_name[:3], delay=100)
                                time.sleep(1)
                                page.evaluate("""(countryName) => {
                                    var items = document.querySelectorAll('li, div[role="option"]');
                                    for (var item of items) {
                                        if ((item.textContent||'').toLowerCase().indexOf(countryName.toLowerCase()) >= 0 && item.offsetWidth > 0) {
                                            item.click();
                                            return true;
                                        }
                                    }
                                    return false;
                                }""", country_name)
                                self.status_update.emit(gid, f"📱 Đã chọn quốc gia: {country_name}")
                            except:
                                self.status_update.emit(gid, f"⚠️ Không chọn được {country_name}")
                                # Press Escape to close dropdown
                                try:
                                    page.keyboard.press("Escape")
                                except:
                                    pass
                        time.sleep(1)
                    else:
                        self.status_update.emit(gid, "⚠️ Không tìm thấy nút chọn quốc gia")

                except Exception as ce:
                    self.status_update.emit(gid, f"⚠️ Lỗi chọn quốc gia: {str(ce)[:40]}")

                # Step 2b: Format phone number correctly
                # Vietnamese local numbers start with 0 (e.g. 0376698684)
                # Need to strip leading 0 when country code is already selected
                clean_phone = phone_number.lstrip("+")
                # If number starts with country code digits, remove them
                code_digits = country_code.lstrip("+")
                if clean_phone.startswith(code_digits):
                    clean_phone = clean_phone[len(code_digits):]
                # If number starts with 0 (local format), strip the leading 0
                if clean_phone.startswith("0"):
                    clean_phone = clean_phone[1:]

                # Step 2c: Enter phone number on page
                entered = False
                phone_selectors = [
                    'input[type="tel"]',
                    'input[name="phoneNumber"]',
                    'input[name="phone"]',
                    'input[id="phoneNumberId"]',
                    'input[autocomplete="tel"]',
                    'input[aria-label*="phone" i]',
                    'input[aria-label*="điện thoại" i]',
                ]
                for sel in phone_selectors:
                    try:
                        inp = page.locator(sel)
                        if inp.count() > 0 and inp.first.is_visible(timeout=2000):
                            inp.first.click()
                            time.sleep(0.3)
                            inp.first.fill("")
                            time.sleep(0.3)
                            inp.first.fill(clean_phone)
                            entered = True
                            self.status_update.emit(gid, f"📱 Đã nhập SĐT: {country_code}{clean_phone}")
                            break
                    except:
                        continue

                if not entered:
                    self.status_update.emit(gid, "❌ Không tìm thấy ô nhập SĐT trên trang")
                    try:
                        svc.cancel_order(order_id)
                    except:
                        pass
                    continue

                # Step 3: Click Send/Next to request OTP
                time.sleep(1)
                send_clicked = False
                for sel in [
                    'button:has-text("Send")', 'button:has-text("Gửi")',
                    'button:has-text("Next")', 'button:has-text("Tiếp theo")',
                    'button:has-text("Verify")', 'button:has-text("Xác minh")',
                    'button:has-text("Get code")', 'button:has-text("Lấy mã")',
                    'button:has-text("Continue")',
                    'button[type="submit"]',
                ]:
                    try:
                        btn = page.locator(sel)
                        if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                            btn.first.click()
                            send_clicked = True
                            self.status_update.emit(gid, "📱 Đã gửi yêu cầu OTP, đang chờ mã...")
                            break
                    except:
                        continue

                if not send_clicked:
                    page.keyboard.press("Enter")
                    self.status_update.emit(gid, "📱 Đã nhấn Enter, đang chờ mã...")

                time.sleep(1.5)

                # Check IMMEDIATELY if Google rejected the number
                try:
                    err_body = page.inner_text("body", timeout=2000)[:2000].lower()
                    error_keywords = [
                        "this phone number cannot be used",
                        "this phone number has already been used",
                        "already been used too many times",
                        "used too many times",
                        "số điện thoại này không thể",
                        "số này đã được sử dụng",
                        "couldn't verify",
                        "number not valid",
                        "invalid phone",
                        "too many attempts",
                        "use another phone number",
                        "try again",
                        "please enter a valid phone",
                        "number is not valid",
                    ]
                    if any(ek in err_body for ek in error_keywords):
                        self.status_update.emit(gid, f"⚠️ Google từ chối SĐT {phone_number}, đổi số mới...")
                        try:
                            svc.cancel_order(order_id)
                        except:
                            pass
                        # Clear the phone input for next attempt
                        try:
                            for sel in ['input[type="tel"]', 'input[id="phoneNumberId"]']:
                                inp = page.locator(sel)
                                if inp.count() > 0 and inp.first.is_visible(timeout=1000):
                                    inp.first.fill("")
                                    break
                        except:
                            pass
                        time.sleep(1)
                        continue
                except:
                    pass

                # Step 4: Wait for OTP
                self.status_update.emit(gid, f"📱 Chờ OTP từ {svc.name} (tối đa {timeout}s)...")
                otp_code = svc.wait_for_sms(order_id, timeout_seconds=timeout, poll_interval=poll_interval)

                if not otp_code:
                    self.status_update.emit(gid, f"❌ Hết thời gian chờ OTP ({timeout}s)")
                    try:
                        svc.cancel_order(order_id)
                    except:
                        pass
                    continue

                self.status_update.emit(gid, f"📱 Nhận OTP: {otp_code}")

                # Step 5: Enter OTP code on page
                otp_entered = False
                otp_selectors = [
                    'input[type="tel"]',
                    'input[name="code"]',
                    'input[name="otp"]',
                    'input[name="pin"]',
                    'input[aria-label*="code" i]',
                    'input[aria-label*="mã" i]',
                    'input[autocomplete="one-time-code"]',
                ]
                for sel in otp_selectors:
                    try:
                        inp = page.locator(sel)
                        if inp.count() > 0 and inp.first.is_visible(timeout=2000):
                            inp.first.click()
                            time.sleep(0.3)
                            inp.first.fill(otp_code)
                            otp_entered = True
                            self.status_update.emit(gid, f"📱 Đã nhập OTP: {otp_code}")
                            break
                    except:
                        continue

                if not otp_entered:
                    self.status_update.emit(gid, "⚠️ Không tìm thấy ô nhập OTP")
                    continue

                # Step 6: Submit OTP
                time.sleep(1)
                self._click_next_or_submit(page, gid)
                time.sleep(3)

                # Step 7: Check result
                try:
                    result_url = page.url.lower()
                    result_body = page.inner_text("body", timeout=2000)[:1000].lower()

                    if "myaccount.google" in result_url or "mail.google" in result_url:
                        self.status_update.emit(gid, "✅ Xác minh SĐT thành công!")
                        return

                    # Check if still on verification page
                    if any(kw in result_body for kw in ["wrong code", "mã sai", "incorrect", "invalid code"]):
                        self.status_update.emit(gid, "❌ Mã OTP sai, thử lại...")
                        try:
                            svc.cancel_order(order_id)
                        except:
                            pass
                        continue

                    # Probably moved on
                    self.status_update.emit(gid, "✅ Đã vượt qua xác minh SĐT")
                    return

                except:
                    self.status_update.emit(gid, "✅ Đã hoàn thành xác minh SĐT")
                    return

            # All retries exhausted
            self.status_update.emit(gid, f"❌ Không thể xác minh SĐT sau {max_retries} lần thử")

        except Exception as e:
            self.status_update.emit(gid, f"❌ Lỗi xác minh SĐT: {str(e)[:60]}")

    def _setup_2fa_after_login(self, page, gid, gmail):
        """Enable 2FA via Authenticator App. Decodes QR code with cv2 to get TOTP secret."""
        import time, re, base64, json
        try:
            self.status_update.emit(gid, "🔐 Bắt đầu bật 2FA...")

            # Step 1: Go to authenticator setup page
            page.goto("https://myaccount.google.com/two-step-verification/authenticator",
                      wait_until="domcontentloaded", timeout=20000)
            time.sleep(5)

            # Step 2: Re-enter password if needed
            try:
                pw_inp = page.locator('input[type="password"]')
                if pw_inp.count() > 0 and pw_inp.first.is_visible(timeout=2000):
                    self.status_update.emit(gid, "🔐 Nhập lại mật khẩu...")
                    data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "gmails.json")
                    profiles = json.load(open(data_path, "r", encoding="utf-8"))
                    pw = ""
                    for p in profiles:
                        if p.get("gmail") == gmail:
                            pw = p.get("password", "")
                            break
                    if pw:
                        pw_inp.first.fill(pw)
                        time.sleep(0.5)
                        self._click_next_or_submit(page, gid)
                        time.sleep(4)
            except:
                pass

            # Step 3: Click "Thiết lập ứng dụng xác thực" / "Set up authenticator"
            # Use text-based matching to avoid clicking "skip to content" button
            self.status_update.emit(gid, "🔐 Nhấn 'Thiết lập'...")
            setup_clicked = False
            for sel in [
                'button:has-text("Set up authenticator")',
                'button:has-text("Thiết lập ứng dụng xác thực")',
                'button:has-text("Thiết lập")',
                'button:has-text("Set up")',
                'button:has-text("Add authenticator")',
                'button:has-text("Thêm ứng dụng")',
            ]:
                try:
                    btn = page.locator(sel)
                    if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                        btn.first.click()
                        setup_clicked = True
                        break
                except:
                    continue

            if not setup_clicked:
                # Fallback: click the widest button (setup btn is ~252px, skip btn is ~204px)
                setup_clicked = page.evaluate("""() => {
                    var btns = document.querySelectorAll('button');
                    var best = null, bestW = 0;
                    for (var b of btns) {
                        if (b.offsetWidth > bestW && b.offsetWidth > 200 && b.offsetHeight > 30 && b.offsetWidth < 400) {
                            bestW = b.offsetWidth;
                            best = b;
                        }
                    }
                    if (best) { best.click(); return true; }
                    return false;
                }""")

            if not setup_clicked:
                self.status_update.emit(gid, "⚠️ Không tìm thấy nút thiết lập")
                return None

            time.sleep(5)

            # Step 4: Get QR code image and decode with cv2
            self.status_update.emit(gid, "🔐 Đang đọc QR code...")
            totp_secret = None

            qr_src = page.evaluate("""() => {
                var imgs = document.querySelectorAll('img');
                for (var img of imgs) {
                    if ((img.src || '').startsWith('data:image') && img.offsetWidth > 100)
                        return img.src;
                }
                return null;
            }""")

            if qr_src:
                try:
                    import numpy as np
                    import cv2
                    b64_data = qr_src.split(",", 1)[1] if "," in qr_src else qr_src
                    img_bytes = base64.b64decode(b64_data)
                    nparr = np.frombuffer(img_bytes, np.uint8)
                    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                    detector = cv2.QRCodeDetector()
                    data, _, _ = detector.detectAndDecode(img)
                    if data:
                        m = re.search(r'secret=([A-Z2-7]+)', data, re.I)
                        if m:
                            totp_secret = m.group(1)
                            self.status_update.emit(gid, f"🔐 Secret: {totp_secret[:8]}...")
                except ImportError:
                    self.status_update.emit(gid, "⚠️ Thiếu opencv! pip install opencv-python-headless")
                except Exception as e:
                    self.status_update.emit(gid, f"⚠️ Lỗi QR: {str(e)[:40]}")

            if not totp_secret:
                # Fallback: look for text-based secret
                totp_secret = page.evaluate("""() => {
                    var els = document.querySelectorAll('div, span, code, pre');
                    for (var el of els) {
                        var t = (el.textContent || '').trim().replace(/\\s+/g, '');
                        if (t.match(/^[A-Z2-7]{16,64}$/) && el.offsetWidth > 0) return t;
                    }
                    return null;
                }""")

            if not totp_secret:
                self.status_update.emit(gid, "⚠️ Không tìm thấy TOTP secret")
                return None

            # Step 5: Generate TOTP and enter it
            try:
                import pyotp
                code = pyotp.TOTP(totp_secret).now()
                self.status_update.emit(gid, f"🔐 Mã TOTP: {code}")

                for sel in ['input[type="tel"]', 'input[type="text"]', 'input[name="totpPin"]', 'input[name="code"]']:
                    try:
                        inp = page.locator(sel)
                        if inp.count() > 0 and inp.first.is_visible(timeout=2000):
                            inp.first.click()
                            time.sleep(0.3)
                            inp.first.fill(code)
                            break
                    except:
                        continue

                time.sleep(1)
                self._click_next_or_submit(page, gid)
                time.sleep(5)

                # Click "Turn on" / "Done"
                for sel in ['button:has-text("Turn on")', 'button:has-text("Bật")',
                           'button:has-text("Done")', 'button:has-text("Xong")', 'button:has-text("OK")']:
                    try:
                        btn = page.locator(sel)
                        if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                            btn.first.click()
                            time.sleep(2)
                            break
                    except:
                        continue

            except ImportError:
                self.status_update.emit(gid, "⚠️ Thiếu pyotp!")
            except Exception as e:
                self.status_update.emit(gid, f"⚠️ Lỗi TOTP: {str(e)[:40]}")

            # Step 6: Save secret to profile
            try:
                data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "gmails.json")
                profiles = json.load(open(data_path, "r", encoding="utf-8"))
                for p in profiles:
                    if p.get("gmail") == gmail:
                        p["2fa_secret"] = totp_secret
                        break
                json.dump(profiles, open(data_path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
                self.status_update.emit(gid, f"✅ 2FA đã bật! Secret: {totp_secret[:8]}...")
                return totp_secret
            except Exception as e:
                self.status_update.emit(gid, f"⚠️ Lỗi lưu: {str(e)[:40]}")
                return totp_secret

        except Exception as e:
            self.status_update.emit(gid, f"❌ Lỗi bật 2FA: {str(e)[:60]}")
            return None


# ═══════════════════════════════════════════
#  Gmail Setup 2FA Thread (standalone)
# ═══════════════════════════════════════════
class GmailSetup2FAThread(QThread):
    """Enable 2FA for Gmail accounts using stored Chrome session.
    Uses real Chrome with --remote-debugging-port + stored profile dir."""
    status_update = pyqtSignal(str, str)   # gmail_id, message
    live_status   = pyqtSignal(str, str)   # gmail_id, 'Live'|'Out'
    finished_one  = pyqtSignal(str)
    finished_all  = pyqtSignal()

    def __init__(self, accounts: list):
        super().__init__()
        self.accounts = accounts
        self._running = True

    def _launch_chrome_cdp(self, profile_dir):
        """Launch real Chrome with CDP and return (subprocess, cdp_port)."""
        import subprocess as sp_sub, socket
        from core.browser_manager import SmartBrowserDetector, next_browser_window_params

        chrome_exe = SmartBrowserDetector.find_browser("Google Chrome")
        if not chrome_exe:
            chrome_exe = SmartBrowserDetector.find_browser("Microsoft Edge")
        if not chrome_exe:
            return None, None

        # Find free port
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("", 0))
            cdp_port = s.getsockname()[1]

        wp = next_browser_window_params()
        args = [
            chrome_exe,
            f"--remote-debugging-port={cdp_port}",
            f"--user-data-dir={profile_dir}",
            "--no-first-run", "--no-default-browser-check",
            "--disable-popup-blocking", "--disable-extensions",
        ] + wp["chrome_args"] + ["about:blank"]

        proc = sp_sub.Popen(args, stdout=sp_sub.DEVNULL, stderr=sp_sub.DEVNULL)
        return proc, cdp_port

    def run(self):
        import time, re, base64, json
        from playwright.sync_api import sync_playwright
        from core.captcha_solver import detect_recaptcha_page, handle_captcha_on_page

        for rec in self.accounts:
            if not self._running:
                break

            gid = rec.get("id", "")
            gmail = rec.get("gmail", "")
            password = rec.get("password", "")
            twofa_secret = rec.get("2fa_secret", "").strip()
            user_data = rec.get("data_dir", "") or gmail_profile_dir(gid)

            if not gmail or not password:
                self.status_update.emit(gid, "Thiếu Gmail/Password")
                self.finished_one.emit(gid)
                continue

            if twofa_secret:
                self.status_update.emit(gid, f"✅ 2FA đã có: {twofa_secret[:8]}...")
                self.finished_one.emit(gid)
                continue

            self.status_update.emit(gid, "🔐 Đang mở Chrome để bật 2FA...")
            chrome_proc = None

            try:
                # Launch real Chrome with stored session profile
                chrome_proc, cdp_port = self._launch_chrome_cdp(user_data)
                if not chrome_proc or not cdp_port:
                    self.status_update.emit(gid, "❌ Không tìm thấy Chrome/Edge")
                    self.finished_one.emit(gid)
                    continue

                time.sleep(3)

                with sync_playwright() as p:
                    browser = p.chromium.connect_over_cdp(f"http://localhost:{cdp_port}")
                    ctx = browser.contexts[0] if browser.contexts else browser.new_context()
                    page = ctx.pages[0] if ctx.pages else ctx.new_page()

                    # ── Navigate to 2FA setup page (using stored session) ──
                    self.status_update.emit(gid, "🔐 Mở trang Xác minh 2 bước...")
                    page.goto("https://myaccount.google.com/signinoptions/two-step-verification",
                              wait_until="domcontentloaded", timeout=25000)
                    time.sleep(4)

                    # Check if password re-entry needed
                    try:
                        pw_inp = page.locator('input[type="password"]')
                        if pw_inp.count() > 0 and pw_inp.first.is_visible(timeout=3000):
                            self.status_update.emit(gid, "🔐 Nhập lại mật khẩu...")
                            pw_inp.first.fill(password)
                            time.sleep(0.5)
                            for sel in ['#passwordNext', 'button:has-text("Next")', 'button:has-text("Tiếp theo")', 'button[type="submit"]']:
                                try:
                                    btn = page.locator(sel)
                                    if btn.count() > 0 and btn.first.is_visible(timeout=1500):
                                        btn.first.click()
                                        break
                                except:
                                    continue
                            time.sleep(5)
                    except:
                        pass

                    # Check if re-login needed (session expired)
                    url_now = page.url.lower()
                    if "accounts.google.com/signin" in url_now or "identifier" in url_now:
                        self.status_update.emit(gid, "🔑 Session hết hạn, đăng nhập lại...")
                        try:
                            page.locator('#identifierId, input[type="email"]').first.fill(gmail)
                            time.sleep(0.5)
                            page.locator('#identifierNext').first.click()
                            time.sleep(4)

                            # CAPTCHA
                            if detect_recaptcha_page(page):
                                self.status_update.emit(gid, "🔄 Giải CAPTCHA...")
                                handle_captcha_on_page(page, status_callback=lambda m: self.status_update.emit(gid, m), max_attempts=2)
                                time.sleep(2)

                            pw_inp = page.locator('input[type="password"]')
                            if pw_inp.count() > 0 and pw_inp.first.is_visible(timeout=5000):
                                pw_inp.first.fill(password)
                                time.sleep(0.5)
                                page.locator('#passwordNext, button:has-text("Next")').first.click()
                                time.sleep(5)

                            # Wait for login
                            for _ in range(15):
                                time.sleep(2)
                                url2 = page.url.lower()
                                if "myaccount.google" in url2 or "mail.google" in url2:
                                    break
                                if detect_recaptcha_page(page):
                                    handle_captcha_on_page(page, status_callback=lambda m: self.status_update.emit(gid, m), max_attempts=2)

                            # Re-navigate to 2FA page
                            page.goto("https://myaccount.google.com/signinoptions/two-step-verification",
                                      wait_until="domcontentloaded", timeout=20000)
                            time.sleep(4)

                            # Re-enter password if needed again
                            try:
                                pw2 = page.locator('input[type="password"]')
                                if pw2.count() > 0 and pw2.first.is_visible(timeout=3000):
                                    pw2.first.fill(password)
                                    time.sleep(0.5)
                                    page.locator('#passwordNext, button:has-text("Next"), button[type="submit"]').first.click()
                                    time.sleep(4)
                            except:
                                pass
                        except Exception as e:
                            self.status_update.emit(gid, f"❌ Login thất bại: {str(e)[:40]}")
                            self.live_status.emit(gid, "Out")
                            try: browser.close()
                            except: pass
                            chrome_proc.terminate()
                            self.finished_one.emit(gid)
                            continue

                    self.status_update.emit(gid, "✅ Đã vào trang 2FA")
                    self.live_status.emit(gid, "Live")

                    # ── Check current page body for 2FA status ──
                    time.sleep(2)
                    try:
                        body_text = page.inner_text("body", timeout=5000)[:2000].lower()
                    except:
                        body_text = ""

                    # ── Click "Bật tính năng" / "Get started" / "Turn on" ──
                    self.status_update.emit(gid, "🔐 Nhấn 'Bật tính năng Xác minh 2 bước'...")
                    enable_clicked = False
                    for sel in [
                        'button:has-text("Bật tính năng Xác minh 2 bước")',
                        'button:has-text("Turn on 2-Step Verification")',
                        'button:has-text("Get started")',
                        'button:has-text("Bắt đầu")',
                        'button:has-text("Bật")',
                        'button:has-text("Turn on")',
                    ]:
                        try:
                            btn = page.locator(sel)
                            if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                                btn.first.click()
                                enable_clicked = True
                                self.status_update.emit(gid, f"   Clicked: {sel}")
                                break
                        except:
                            continue

                    if not enable_clicked:
                        # JS fallback: find widest prominent button
                        enable_clicked = page.evaluate("""() => {
                            var btns = document.querySelectorAll('button');
                            var best = null, bestW = 0;
                            for (var b of btns) {
                                var t = (b.textContent || '').trim().toLowerCase();
                                if (b.offsetWidth > 150 && b.offsetHeight > 30 &&
                                    (t.indexOf('bật') >= 0 || t.indexOf('turn on') >= 0 || t.indexOf('get started') >= 0)) {
                                    if (b.offsetWidth > bestW) { bestW = b.offsetWidth; best = b; }
                                }
                            }
                            if (best) { best.click(); return true; }
                            return false;
                        }""")

                    time.sleep(5)

                    # ── Re-enter password if prompted again ──
                    try:
                        pw3 = page.locator('input[type="password"]')
                        if pw3.count() > 0 and pw3.first.is_visible(timeout=2000):
                            self.status_update.emit(gid, "🔐 Nhập lại mật khẩu...")
                            pw3.first.fill(password)
                            time.sleep(0.5)
                            page.locator('#passwordNext, button:has-text("Next"), button[type="submit"]').first.click()
                            time.sleep(5)
                    except:
                        pass

                    # ── Navigate to Authenticator setup ──
                    self.status_update.emit(gid, "🔐 Mở Authenticator setup...")
                    try:
                        # Try navigating to authenticator setup page
                        page.goto("https://myaccount.google.com/two-step-verification/authenticator",
                                  wait_until="domcontentloaded", timeout=20000)
                        time.sleep(5)
                    except:
                        pass

                    # Re-enter password if needed
                    try:
                        pw4 = page.locator('input[type="password"]')
                        if pw4.count() > 0 and pw4.first.is_visible(timeout=2000):
                            pw4.first.fill(password)
                            time.sleep(0.5)
                            page.locator('#passwordNext, button:has-text("Next"), button[type="submit"]').first.click()
                            time.sleep(4)
                    except:
                        pass

                    # Click "Set up authenticator" / "Thiết lập"
                    self.status_update.emit(gid, "🔐 Nhấn 'Thiết lập'...")
                    setup_clicked = False
                    for sel in [
                        'button:has-text("Set up authenticator")',
                        'button:has-text("Thiết lập ứng dụng xác thực")',
                        'button:has-text("Thiết lập")',
                        'button:has-text("Set up")',
                    ]:
                        try:
                            btn = page.locator(sel)
                            if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                                btn.first.click()
                                setup_clicked = True
                                break
                        except:
                            continue

                    if not setup_clicked:
                        setup_clicked = page.evaluate("""() => {
                            var btns = document.querySelectorAll('button');
                            var best = null, bestW = 0;
                            for (var b of btns) {
                                if (b.offsetWidth > bestW && b.offsetWidth > 200 && b.offsetHeight > 30 && b.offsetWidth < 400) {
                                    bestW = b.offsetWidth; best = b;
                                }
                            }
                            if (best) { best.click(); return true; }
                            return false;
                        }""")

                    time.sleep(5)

                    # ── Decode QR code ──
                    self.status_update.emit(gid, "🔐 Đang đọc QR code...")
                    totp_secret = None

                    # Try to find QR image in page
                    qr_src = page.evaluate("""() => {
                        var imgs = document.querySelectorAll('img');
                        for (var img of imgs) {
                            if ((img.src || '').startsWith('data:image') && img.offsetWidth > 100)
                                return img.src;
                        }
                        return null;
                    }""")

                    if qr_src:
                        try:
                            import numpy as np
                            import cv2
                            b64_data = qr_src.split(",", 1)[1] if "," in qr_src else qr_src
                            img_bytes = base64.b64decode(b64_data)
                            nparr = np.frombuffer(img_bytes, np.uint8)
                            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                            detector = cv2.QRCodeDetector()
                            data, _, _ = detector.detectAndDecode(img)
                            if data:
                                m = re.search(r'secret=([A-Z2-7]+)', data, re.I)
                                if m:
                                    totp_secret = m.group(1)
                                    self.status_update.emit(gid, f"🔐 QR decoded: {totp_secret[:8]}...")
                        except Exception as e:
                            self.status_update.emit(gid, f"⚠️ Lỗi QR: {str(e)[:40]}")

                    if not totp_secret:
                        # Fallback: find text-based secret on page
                        totp_secret = page.evaluate("""() => {
                            var els = document.querySelectorAll('div, span, code, pre');
                            for (var el of els) {
                                var t = (el.textContent || '').trim().replace(/\\s+/g, '');
                                if (t.match(/^[A-Z2-7]{16,64}$/) && el.offsetWidth > 0) return t;
                            }
                            return null;
                        }""")

                    if not totp_secret:
                        # Take screenshot for debugging
                        try:
                            page.screenshot(path=os.path.join("data", f"2fa_fail_{gid[:8]}.png"))
                        except: pass
                        self.status_update.emit(gid, "⚠️ Không tìm thấy TOTP secret")
                        try: browser.close()
                        except: pass
                        chrome_proc.terminate()
                        self.finished_one.emit(gid)
                        continue

                    # ── Enter TOTP code to verify ──
                    self.status_update.emit(gid, f"🔐 Secret: {totp_secret[:8]}...")
                    try:
                        import pyotp
                        code = pyotp.TOTP(totp_secret).now()
                        self.status_update.emit(gid, f"🔐 Mã TOTP: {code}")

                        for sel in ['input[type="tel"]', 'input[type="text"]', 'input[name="totpPin"]']:
                            try:
                                inp = page.locator(sel)
                                if inp.count() > 0 and inp.first.is_visible(timeout=2000):
                                    inp.first.fill(code)
                                    break
                            except:
                                continue

                        time.sleep(1)
                        for sel in ['button:has-text("Verify")', 'button:has-text("Xác minh")',
                                    'button:has-text("Next")', 'button:has-text("Tiếp theo")',
                                    'button[type="submit"]']:
                            try:
                                btn = page.locator(sel)
                                if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                                    btn.first.click()
                                    break
                            except:
                                continue
                        time.sleep(5)

                        # Click Done/Turn on/Bật
                        for sel in ['button:has-text("Turn on")', 'button:has-text("Done")',
                                   'button:has-text("Bật")', 'button:has-text("OK")',
                                   'button:has-text("Xong")', 'button:has-text("Hoàn tất")']:
                            try:
                                btn = page.locator(sel)
                                if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                                    btn.first.click()
                                    time.sleep(2)
                                    break
                            except:
                                continue
                    except Exception as e:
                        self.status_update.emit(gid, f"⚠️ Lỗi TOTP: {str(e)[:40]}")

                    # ── Save secret to gmails.json ──
                    data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "gmails.json")
                    try:
                        profiles = json.load(open(data_path, "r", encoding="utf-8"))
                        for prof in profiles:
                            if prof.get("gmail") == gmail:
                                prof["2fa_secret"] = totp_secret
                                break
                        json.dump(profiles, open(data_path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
                    except:
                        pass

                    rec["2fa_secret"] = totp_secret
                    self.status_update.emit(gid, f"✅ 2FA đã bật! Secret: {totp_secret[:8]}...")

                    # Close browser
                    try: browser.close()
                    except: pass
                    time.sleep(1)
                    chrome_proc.terminate()
                    try: chrome_proc.wait(timeout=10)
                    except: chrome_proc.kill()

            except Exception as e:
                self.status_update.emit(gid, f"❌ Lỗi: {str(e)[:60]}")
                if chrome_proc:
                    try: chrome_proc.terminate()
                    except: pass

            self.finished_one.emit(gid)

        self.finished_all.emit()

    def stop(self):
        self._running = False


# ═══════════════════════════════════════════
#  Gmail Check Session Thread
# ═══════════════════════════════════════════
class GmailCheckSessionThread(QThread):
    """Open stored Chrome session and check if Gmail is still logged in."""
    status_update = pyqtSignal(str, str)  # gid, message
    live_status = pyqtSignal(str, str)    # gid, "Live"/"Out"
    session_status = pyqtSignal(str, str) # gid, "Saved"/"Empty"
    finished_one = pyqtSignal(str)
    finished_all = pyqtSignal()

    def __init__(self, accounts, parent=None):
        super().__init__(parent)
        self.accounts = accounts
        self._running = True

    def run(self):
        import time, os, subprocess as sp_sub, socket
        from playwright.sync_api import sync_playwright
        from core.browser_manager import SmartBrowserDetector

        def _find_free_port():
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("", 0))
                return s.getsockname()[1]

        chrome_exe = SmartBrowserDetector.find_browser("Google Chrome")
        if not chrome_exe:
            chrome_exe = SmartBrowserDetector.find_browser("Microsoft Edge")

        for rec in self.accounts:
            if not self._running:
                break

            gid = rec.get("id", "")
            gmail = rec.get("gmail", "")

            try:
                user_data = rec.get("data_dir", "") or gmail_profile_dir(gid)

                # Check if profile directory exists and has data
                if not os.path.isdir(user_data):
                    self.status_update.emit(gid, "❌ Chưa có session (chưa login lần nào)")
                    self.live_status.emit(gid, "Out")
                    self.session_status.emit(gid, "Empty")
                    self.finished_one.emit(gid)
                    continue

                self.status_update.emit(gid, "🔍 Đang kiểm tra session...")

                with sync_playwright() as p:
                    chrome_proc = None
                    browser = None

                    try:
                        if chrome_exe:
                            cdp_port = _find_free_port()
                            chrome_args = [
                                chrome_exe,
                                f"--remote-debugging-port={cdp_port}",
                                f"--user-data-dir={user_data}",
                                "--no-first-run",
                                "--no-default-browser-check",
                                "--disable-popup-blocking",
                                "--disable-extensions",
                                "--window-position=-32000,-32000",
                                "--window-size=800,600",
                                "about:blank",
                            ]
                            chrome_proc = sp_sub.Popen(
                                chrome_args, stdout=sp_sub.DEVNULL, stderr=sp_sub.DEVNULL
                            )
                            time.sleep(3)

                            browser = p.chromium.connect_over_cdp(f"http://localhost:{cdp_port}")
                            context = browser.contexts[0] if browser.contexts else browser.new_context()
                            page = context.pages[0] if context.pages else context.new_page()
                        else:
                            self.status_update.emit(gid, "❌ Không tìm thấy Chrome/Edge")
                            self.live_status.emit(gid, "Out")
                            self.finished_one.emit(gid)
                            continue

                        # Navigate to Google Account page to check login
                        self.status_update.emit(gid, "🔍 Truy cập Google Account...")
                        page.goto("https://myaccount.google.com/", wait_until="domcontentloaded", timeout=20000)
                        time.sleep(3)

                        url = page.url.lower()
                        body = ""
                        try:
                            body = page.inner_text("body", timeout=3000)[:2000].lower()
                        except:
                            pass

                        # Check if still logged in
                        if "myaccount.google.com" in url and "signin" not in url:
                            # Verify it's the right account
                            if gmail.split("@")[0].lower() in body or gmail.lower() in body:
                                self.status_update.emit(gid, f"✅ Session hoạt động — {gmail}")
                                self.live_status.emit(gid, "Live")
                                self.session_status.emit(gid, "Saved")
                            else:
                                # Logged in but maybe different account
                                self.status_update.emit(gid, "✅ Session hoạt động (đã đăng nhập)")
                                self.live_status.emit(gid, "Live")
                                self.session_status.emit(gid, "Saved")
                        elif "accounts.google.com" in url or "signin" in url or "/account/about" in url:
                            self.status_update.emit(gid, "❌ Session hết hạn — cần login lại")
                            self.live_status.emit(gid, "Out")
                            self.session_status.emit(gid, "Saved")
                        else:
                            # Try navigating to Gmail directly
                            try:
                                page.goto("https://mail.google.com/mail/u/0/", wait_until="domcontentloaded", timeout=15000)
                                time.sleep(3)
                                url2 = page.url.lower()
                                if "mail.google.com" in url2 and "signin" not in url2:
                                    self.status_update.emit(gid, "✅ Session hoạt động")
                                    self.live_status.emit(gid, "Live")
                                    self.session_status.emit(gid, "Saved")
                                else:
                                    self.status_update.emit(gid, "❌ Session hết hạn")
                                    self.live_status.emit(gid, "Out")
                                    self.session_status.emit(gid, "Saved")
                            except:
                                self.status_update.emit(gid, "⚠️ Không thể kiểm tra session")
                                self.live_status.emit(gid, "Out")

                    except Exception as e:
                        self.status_update.emit(gid, f"❌ Lỗi kiểm tra: {str(e)[:50]}")
                        self.live_status.emit(gid, "Out")
                    finally:
                        try:
                            if browser: browser.close()
                        except: pass
                        if chrome_proc:
                            chrome_proc.terminate()
                            try: chrome_proc.wait(timeout=5)
                            except: chrome_proc.kill()

            except Exception as e:
                self.status_update.emit(gid, f"❌ Lỗi: {str(e)[:50]}")

            self.finished_one.emit(gid)

        self.finished_all.emit()

    def stop(self):
        self._running = False


# ═══════════════════════════════════════════
#  Gmail Verify Recovery Email Thread
# ═══════════════════════════════════════════
class GmailVerifyRecoveryThread(QThread):
    """Verify recovery email in Gmail settings. If domain email, fetch code from webmail."""
    status_update = pyqtSignal(str, str)
    live_status = pyqtSignal(str, str)
    finished_one = pyqtSignal(str)
    finished_all = pyqtSignal()

    def __init__(self, accounts, parent=None):
        super().__init__(parent)
        self.accounts = accounts
        self._running = True

    def run(self):
        import time, os, re, subprocess as sp_sub, socket
        from playwright.sync_api import sync_playwright
        from core.browser_manager import SmartBrowserDetector

        def _find_free_port():
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("", 0))
                return s.getsockname()[1]

        chrome_exe = SmartBrowserDetector.find_browser("Google Chrome")
        if not chrome_exe:
            chrome_exe = SmartBrowserDetector.find_browser("Microsoft Edge")

        for rec in self.accounts:
            if not self._running:
                break

            gid = rec.get("id", "")
            gmail = rec.get("gmail", "")
            password = rec.get("password", "")
            recovery_email = rec.get("recovery_email", "").strip()

            if not recovery_email:
                self.status_update.emit(gid, "⚠️ Chưa có recovery email")
                self.finished_one.emit(gid)
                continue

            try:
                user_data = rec.get("data_dir", "") or gmail_profile_dir(gid)
                self.status_update.emit(gid, f"📧 Xác minh recovery: {recovery_email}")

                with sync_playwright() as p:
                    chrome_proc = None
                    browser = None

                    try:
                        if not chrome_exe:
                            self.status_update.emit(gid, "❌ Không tìm thấy Chrome/Edge")
                            self.finished_one.emit(gid)
                            continue

                        cdp_port = _find_free_port()
                        from core.browser_manager import next_browser_window_params
                        wp = next_browser_window_params()

                        chrome_args = [
                            chrome_exe,
                            f"--remote-debugging-port={cdp_port}",
                            f"--user-data-dir={user_data}",
                            "--no-first-run",
                            "--no-default-browser-check",
                            "--disable-popup-blocking",
                            "--disable-extensions",
                        ] + wp["chrome_args"]
                        chrome_args.append("about:blank")

                        chrome_proc = sp_sub.Popen(
                            chrome_args, stdout=sp_sub.DEVNULL, stderr=sp_sub.DEVNULL
                        )
                        time.sleep(3)

                        browser = p.chromium.connect_over_cdp(f"http://localhost:{cdp_port}")
                        context = browser.contexts[0] if browser.contexts else browser.new_context()
                        page = context.pages[0] if context.pages else context.new_page()

                        # Step 1: Navigate to recovery email settings
                        self.status_update.emit(gid, "📧 Mở cài đặt recovery...")
                        page.goto("https://myaccount.google.com/recovery/email",
                                  wait_until="domcontentloaded", timeout=20000)
                        time.sleep(3)

                        url = page.url.lower()

                        # Google may redirect to re-auth page (signin/challenge/pwd)
                        # This is NOT session expiry — it's identity re-confirmation
                        # Always try re-auth with password first
                        try:
                            pw_inp = page.locator('input[type="password"]')
                            if pw_inp.count() > 0 and pw_inp.first.is_visible(timeout=3000):
                                self.status_update.emit(gid, "🔑 Nhập lại mật khẩu xác thực...")
                                pw_inp.first.fill(password)
                                time.sleep(0.5)
                                clicked_next = False
                                for sel in ['#passwordNext', '#passwordNext button',
                                            'button:has-text("Next")', 'button:has-text("Tiếp theo")',
                                            'button:has-text("Tiep theo")', 'button[type="submit"]']:
                                    try:
                                        btn = page.locator(sel)
                                        if btn.count() > 0 and btn.first.is_visible(timeout=1500):
                                            btn.first.click()
                                            clicked_next = True
                                            break
                                    except:
                                        continue
                                if not clicked_next:
                                    # JS fallback click
                                    try:
                                        page.evaluate("""() => {
                                            const btns = document.querySelectorAll('button');
                                            for (const b of btns) {
                                                const t = (b.textContent || '').toLowerCase();
                                                if (t.includes('next') || t.includes('ti')) { b.click(); break; }
                                            }
                                        }""")
                                    except:
                                        pass
                                time.sleep(8)

                                # Check if re-auth succeeded by looking at page CONTENT
                                # (Google's URL lags behind content by ~10s)
                                try:
                                    body_check = page.inner_text("body", timeout=5000)[:2000].lower()
                                except:
                                    body_check = ""

                                if "khôi phục" in body_check or "recovery" in body_check or "email khôi phục" in body_check:
                                    self.status_update.emit(gid, "✅ Xác thực thành công")
                                else:
                                    # Check URL as fallback
                                    url_after = page.url.lower()
                                    if "myaccount.google.com" in url_after:
                                        self.status_update.emit(gid, "✅ Xác thực thành công")
                                    elif "signin" in url_after:
                                        # Truly stuck — wait 5 more seconds
                                        time.sleep(5)
                                        try:
                                            body_recheck = page.inner_text("body", timeout=5000)[:2000].lower()
                                        except:
                                            body_recheck = ""
                                        if "khôi phục" in body_recheck or "recovery" in body_recheck:
                                            self.status_update.emit(gid, "✅ Xác thực thành công")
                                        else:
                                            self.status_update.emit(gid, "❌ Không thể xác thực — kiểm tra mật khẩu")
                                            self.finished_one.emit(gid)
                                            try: browser.close()
                                            except: pass
                                            if chrome_proc: chrome_proc.terminate()
                                            continue
                        except:
                            pass

                        # Wait for recovery page to fully load
                        time.sleep(3)

                        # Step 2: Check the recovery email shown on page
                        self.status_update.emit(gid, "📧 Kiểm tra recovery email trên Google...")
                        time.sleep(2)

                        body = ""
                        try:
                            body = page.inner_text("body", timeout=5000)[:3000]
                        except:
                            pass
                        body_lower = body.lower()

                        # Check if recovery email matches
                        if recovery_email.lower() in body_lower:
                            self.status_update.emit(gid, f"✅ Recovery khớp: {recovery_email}")
                        else:
                            # Check if there's ANY recovery email shown
                            import re as _re
                            emails_on_page = _re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', body)
                            # Filter out the gmail itself and google system emails
                            other_emails = [e for e in emails_on_page if e.lower() != gmail.lower() and "google" not in e.lower()]

                            if other_emails:
                                actual = other_emails[0]
                                self.status_update.emit(gid, f"❌ Recovery KHÔNG KHỚP! Tool: {recovery_email} | Google: {actual}")
                                self.finished_one.emit(gid)
                                try: browser.close()
                                except: pass
                                if chrome_proc: chrome_proc.terminate()
                                continue
                            else:
                                self.status_update.emit(gid, "⚠️ Không tìm thấy recovery email trên trang")

                        # Step 3: Click verify button if available
                        verified = False
                        # Vietnamese diacritics text for verify link
                        for kw in ["Xác minh địa chỉ", "Xác minh", "Verify your recovery",
                                   "Verify", "Confirm", "Xác nhận"]:
                            for tag in ['a', 'button', 'span', 'div[role="link"]']:
                                try:
                                    el = page.locator(f'{tag}:has-text("{kw}")')
                                    if el.count() > 0 and el.first.is_visible(timeout=1500):
                                        el.first.click()
                                        time.sleep(3)
                                        self.status_update.emit(gid, f"📧 Đã click xác minh — chờ mã...")
                                        verified = True
                                        break
                                except:
                                    continue
                            if verified:
                                break

                        if not verified:
                            # JS fallback: find any clickable element with verify text
                            try:
                                clicked_js = page.evaluate("""() => {
                                    const all = document.querySelectorAll('a, button, span[role="link"], div[role="link"], [data-action]');
                                    for (const el of all) {
                                        const t = (el.textContent || '').toLowerCase();
                                        if (t.includes('xác minh') || t.includes('verify') || t.includes('xac minh')) {
                                            el.click();
                                            return true;
                                        }
                                    }
                                    return false;
                                }""")
                                if clicked_js:
                                    time.sleep(3)
                                    self.status_update.emit(gid, "📧 Đã click xác minh (JS) — chờ mã...")
                                    verified = True
                            except:
                                pass

                        if not verified:
                            self.status_update.emit(gid, "✅ Recovery email đã xác minh hoặc không cần xác minh")
                            self.finished_one.emit(gid)
                            try: browser.close()
                            except: pass
                            if chrome_proc: chrome_proc.terminate()
                            continue

                        # Step 4: For domain emails, fetch verification code
                        recovery_domain = recovery_email.split("@")[-1].lower() if "@" in recovery_email else ""

                        if recovery_domain and recovery_domain not in ["gmail.com", "googlemail.com"]:
                            self.status_update.emit(gid, f"📧 Lấy mã xác minh từ {recovery_domain}...")

                            # Open new tab to fetch code from domain webmail
                            try:
                                mail_page = context.new_page()
                                # Try homepage first (for services like smvmail.com),
                                # then common webmail URLs
                                webmail_urls = [
                                    f"https://{recovery_domain}",
                                    f"https://{recovery_domain}/email",
                                    f"https://{recovery_domain}/login",
                                    f"https://mail.{recovery_domain}",
                                    f"https://webmail.{recovery_domain}",
                                    f"https://{recovery_domain}/mail",
                                    f"https://{recovery_domain}/webmail",
                                    f"https://{recovery_domain}/roundcube",
                                ]

                                mail_opened = False
                                for wurl in webmail_urls:
                                    try:
                                        mail_page.goto(wurl, wait_until="domcontentloaded", timeout=10000)
                                        time.sleep(2)
                                        # Check page content for 404 errors
                                        page_body = ""
                                        try:
                                            page_body = mail_page.inner_text("body", timeout=3000)[:500].lower()
                                        except:
                                            pass
                                        is_404 = ("404" in mail_page.url or
                                                  "not found" in page_body or
                                                  "page could not be found" in page_body or
                                                  "does not exist" in page_body)
                                        if not is_404:
                                            self.status_update.emit(gid, f"📧 Đã mở webmail: {wurl}")
                                            mail_opened = True
                                            break
                                    except:
                                        continue

                                if mail_opened:
                                    # Detect form type:
                                    # Type 1: Email-only form (smvmail.com) — just enter email + View Inbox
                                    # Type 2: Login form with password — enter user + password + Login
                                    email_inp = mail_page.locator('input[name="email"], input[type="email"], input[placeholder*="mail"], input[placeholder*="Email"], input[placeholder*="address"]')
                                    pw_inp = mail_page.locator('input[name="password"], input[type="password"]')

                                    if email_inp.count() > 0 and pw_inp.count() == 0:
                                        # Type 1: Email-only form (smvmail.com style)
                                        self.status_update.emit(gid, f"📧 Nhập email: {recovery_email}...")
                                        email_inp.first.fill(recovery_email)
                                        time.sleep(0.5)
                                        # Click View Inbox / Submit
                                        for sel in ['button:has-text("View")', 'button:has-text("Inbox")',
                                                    'button:has-text("View Inbox")', 'button:has-text("Access")',
                                                    'button:has-text("Submit")', 'button[type="submit"]',
                                                    'input[type="submit"]']:
                                            try:
                                                btn = mail_page.locator(sel)
                                                if btn.count() > 0 and btn.first.is_visible(timeout=1500):
                                                    btn.first.click()
                                                    break
                                            except:
                                                continue
                                        time.sleep(5)
                                        self.status_update.emit(gid, "📧 Đã mở inbox — đọc email...")

                                    elif email_inp.count() > 0 and pw_inp.count() > 0:
                                        # Type 2: Login form — fill with credentials
                                        recovery_user = recovery_email.split("@")[0] if "@" in recovery_email else recovery_email
                                        self.status_update.emit(gid, f"🔑 Đăng nhập webmail: {recovery_user}...")
                                        email_inp.first.fill(recovery_user)
                                        time.sleep(0.3)
                                        pw_inp.first.fill(password)
                                        time.sleep(0.3)
                                        for sel in ['button:has-text("Login")', 'button:has-text("Sign in")',
                                                    'button:has-text("Đăng nhập")', 'button[type="submit"]',
                                                    'input[type="submit"]']:
                                            try:
                                                btn = mail_page.locator(sel)
                                                if btn.count() > 0 and btn.first.is_visible(timeout=1500):
                                                    btn.first.click()
                                                    break
                                            except:
                                                continue
                                        time.sleep(5)
                                        self.status_update.emit(gid, "📧 Đã đăng nhập — đọc inbox...")

                                    # Wait for inbox/code to load
                                    time.sleep(5)
                                    mail_body = ""
                                    try:
                                        mail_body = mail_page.inner_text("body", timeout=5000)[:3000]
                                    except:
                                        pass

                                    # Search for verification code (usually 6 digits)
                                    code_match = re.search(r'\b(\d{6})\b', mail_body)
                                    if code_match:
                                        verify_code = code_match.group(1)
                                        self.status_update.emit(gid, f"📧 Mã xác minh: {verify_code}")

                                        # Enter code on Gmail page
                                        page.bring_to_front()
                                        time.sleep(2)

                                        # Google's verify popup uses input#c1
                                        filled = False
                                        for sel in ['#c1', 'input#c1',
                                                    'input[type="tel"]', 'input[type="number"]']:
                                            try:
                                                inp = page.locator(sel)
                                                if inp.count() > 0 and inp.first.is_visible(timeout=2000):
                                                    inp.first.fill(verify_code)
                                                    filled = True
                                                    break
                                            except:
                                                continue

                                        if not filled:
                                            # Fallback: find visible text input that's NOT the search bar
                                            try:
                                                all_inp = page.locator('input[type="text"]')
                                                for idx in range(all_inp.count()):
                                                    el = all_inp.nth(idx)
                                                    if el.is_visible(timeout=1000):
                                                        aria = el.get_attribute("aria-label") or ""
                                                        if "Tìm" not in aria and "Search" not in aria:
                                                            el.fill(verify_code)
                                                            filled = True
                                                            break
                                            except:
                                                pass

                                        if not filled:
                                            # JS fallback
                                            try:
                                                page.evaluate(f"""() => {{
                                                    const c1 = document.getElementById('c1');
                                                    if (c1) {{
                                                        c1.value = '{verify_code}';
                                                        c1.dispatchEvent(new Event('input', {{bubbles: true}}));
                                                        c1.dispatchEvent(new Event('change', {{bubbles: true}}));
                                                        return;
                                                    }}
                                                    const inputs = document.querySelectorAll('input[type="text"], input[type="tel"], input[type="number"]');
                                                    for (const inp of inputs) {{
                                                        if (inp.offsetParent !== null && !inp.getAttribute('aria-label')?.includes('Tìm')) {{
                                                            inp.value = '{verify_code}';
                                                            inp.dispatchEvent(new Event('input', {{bubbles: true}}));
                                                            inp.dispatchEvent(new Event('change', {{bubbles: true}}));
                                                            break;
                                                        }}
                                                    }}
                                                }}""")
                                                filled = True
                                            except:
                                                pass

                                        if filled:
                                            self.status_update.emit(gid, f"📧 Đã nhập mã: {verify_code}")

                                        time.sleep(1)
                                        # Click verify/next button in Google popup
                                        # Use :text-is() for exact match to avoid clicking the page link
                                        btn_clicked = False
                                        for sel in ['button:text-is("Xác minh")', 'button:text-is("Verify")',
                                                    'button:text-is("Xác nhận")', 'button:text-is("Next")',
                                                    'button:text-is("Tiếp theo")', 'button:text-is("Gửi")',
                                                    'button:text-is("Submit")', 'button[type="submit"]']:
                                            try:
                                                btn = page.locator(sel)
                                                if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                                                    btn.first.click()
                                                    btn_clicked = True
                                                    break
                                            except:
                                                continue

                                        if not btn_clicked:
                                            # JS: find button with shortest text matching 'xác minh'
                                            try:
                                                page.evaluate("""() => {
                                                    const btns = document.querySelectorAll('button, span[role="button"]');
                                                    let best = null;
                                                    let bestLen = 999;
                                                    for (const b of btns) {
                                                        const t = (b.textContent || '').trim();
                                                        const tl = t.toLowerCase();
                                                        if ((tl.includes('xác minh') || tl.includes('verify'))
                                                            && b.offsetParent !== null && t.length < bestLen) {
                                                            best = b;
                                                            bestLen = t.length;
                                                        }
                                                    }
                                                    if (best) best.click();
                                                }""")
                                            except:
                                                pass
                                        time.sleep(5)
                                        self.status_update.emit(gid, "✅ Đã xác minh recovery email")
                                    else:
                                        self.status_update.emit(gid, "⚠️ Không tìm thấy mã xác minh trong webmail")
                                else:
                                    self.status_update.emit(gid, f"⚠️ Không thể mở webmail của {recovery_domain}")

                                try: mail_page.close()
                                except: pass

                            except Exception as me:
                                self.status_update.emit(gid, f"⚠️ Lỗi lấy mã: {str(me)[:40]}")
                        else:
                            # Gmail-based recovery — Google sends code to the recovery gmail
                            self.status_update.emit(gid, "✅ Google đã gửi mã đến recovery email")

                    except Exception as e:
                        self.status_update.emit(gid, f"❌ Lỗi: {str(e)[:50]}")
                    finally:
                        try:
                            if browser: browser.close()
                        except: pass
                        if chrome_proc:
                            chrome_proc.terminate()
                            try: chrome_proc.wait(timeout=5)
                            except: chrome_proc.kill()

            except Exception as e:
                self.status_update.emit(gid, f"❌ Lỗi: {str(e)[:50]}")

            self.finished_one.emit(gid)

        self.finished_all.emit()

    def stop(self):
        self._running = False


# ═══════════════════════════════════════════
#  Gmail Read Mail Thread (IMAP → Browser Fallback)
# ═══════════════════════════════════════════
class GmailReadMailThread(QThread):
    """Read Gmail inbox. Priority: IMAP password → browser scrape fallback."""
    mail_loaded = pyqtSignal(list)       # list of mail dicts
    error = pyqtSignal(str)
    status_msg = pyqtSignal(str)
    method_detected = pyqtSignal(str)    # 'IMAP' or 'Browser'

    def __init__(self, gmail_addr, password="", app_password="", max_messages=10, gmail_id="", data_dir=""):
        super().__init__()
        self.gmail_addr = gmail_addr
        self.password = password
        self.app_password = app_password
        self.max_messages = max_messages
        self.gmail_id = gmail_id
        self.data_dir = data_dir

    def run(self):
        import imaplib
        import email as email_lib
        from email.header import decode_header
        import re

        # ── Try IMAP with App Password first ──
        imap_pass = self.app_password or self.password
        if imap_pass:
            try:
                self.status_msg.emit("Đang kết nối IMAP Gmail...")
                mail = imaplib.IMAP4_SSL("imap.gmail.com", 993, timeout=30)
                mail.login(self.gmail_addr, imap_pass)
                mail.select("INBOX")

                status, messages = mail.search(None, "ALL")
                if status == "OK":
                    msg_ids = messages[0].split()
                    latest_ids = msg_ids[-self.max_messages:] if len(msg_ids) > self.max_messages else msg_ids
                    latest_ids.reverse()

                    results = []
                    for msg_id in latest_ids:
                        try:
                            st, msg_data = mail.fetch(msg_id, "(RFC822)")
                            if st != "OK":
                                continue
                            raw = msg_data[0][1]
                            msg = email_lib.message_from_bytes(raw)
                            parsed = self._parse_message(msg)
                            if parsed:
                                results.append(parsed)
                        except:
                            continue

                    mail.logout()
                    self.method_detected.emit("IMAP")
                    self.mail_loaded.emit(results)
                    return
                mail.logout()
            except Exception as e:
                err = str(e)[:80]
                self.status_msg.emit(f"IMAP lỗi: {err}, thử Browser...")

        # ── Fallback: browser scrape ──
        self.status_msg.emit("Đang mở Gmail qua Browser...")
        try:
            self._read_via_browser()
        except Exception as e:
            self.error.emit(f"Lỗi: {str(e)[:150]}")

    def _read_via_browser(self):
        """Open Gmail in browser using stored login profile, scrape inbox."""
        import time
        import re
        import os
        import subprocess as sp_sub

        # Check for stored login profile — use data_dir from record
        user_data = self.data_dir
        if not user_data and self.gmail_id:
            user_data = gmail_profile_dir(self.gmail_id)
        if not user_data or not os.path.isdir(user_data) or not os.listdir(user_data):
            self.error.emit("Chưa đăng nhập Gmail — cần Login Browser trước rồi mới Đọc thư được.")
            return

        try:
            from playwright.sync_api import sync_playwright
            from core.browser_manager import setup_playwright
            setup_playwright()
        except Exception as e:
            self.error.emit(f"Playwright lỗi: {str(e)[:80]}")
            return

        # Find Chrome
        chrome_exe = None
        for path in [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        ]:
            if os.path.isfile(path):
                chrome_exe = path
                break
        if not chrome_exe:
            self.error.emit("Không tìm thấy Chrome!")
            return

        # Find free port for CDP
        import socket
        def _find_free_port():
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('', 0))
                return s.getsockname()[1]
        cdp_port = _find_free_port()
        chrome_proc = sp_sub.Popen([
            chrome_exe,
            f"--remote-debugging-port={cdp_port}",
            f"--user-data-dir={user_data}",
            "--no-first-run",
            "--no-default-browser-check",
            "--window-position=-32000,-32000",
            "about:blank",
        ], stdout=sp_sub.DEVNULL, stderr=sp_sub.DEVNULL)
        time.sleep(3)

        from playwright.sync_api import sync_playwright

        try:
            with sync_playwright() as p:
                try:
                    browser = p.chromium.connect_over_cdp(f"http://localhost:{cdp_port}")
                except Exception as e:
                    self.error.emit(f"Không kết nối được Chrome: {str(e)[:80]}")
                    chrome_proc.terminate()
                    return

                context = browser.contexts[0] if browser.contexts else browser.new_context()
                page = context.new_page()

                try:
                    page.goto("https://mail.google.com/mail/u/0/#inbox",
                              wait_until="domcontentloaded", timeout=20000)
                    time.sleep(5)

                    # Check if logged in
                    if "signin" in page.url.lower() or "accounts.google" in page.url.lower():
                        self.error.emit("Chưa đăng nhập Gmail — cần Login Browser trước.")
                        return

                    # Scrape email list
                    self.status_msg.emit("Đang đọc thư...")
                    results = []

                    rows = page.locator('tr.zA').all()
                    count = min(len(rows), self.max_messages)

                    for i in range(count):
                        try:
                            row = rows[i]
                            sender = subject = date = body_preview = ""

                            try:
                                sender_el = row.locator('.yX.xY .yW span')
                                if sender_el.count() > 0:
                                    sender = sender_el.first.inner_text(timeout=2000)
                            except:
                                pass
                            try:
                                subj_el = row.locator('.y6 span:first-child')
                                if subj_el.count() > 0:
                                    subject = subj_el.first.inner_text(timeout=2000)
                            except:
                                pass
                            try:
                                date_el = row.locator('.xW.xY span')
                                if date_el.count() > 0:
                                    date = date_el.first.get_attribute("title") or date_el.first.inner_text(timeout=2000)
                            except:
                                pass
                            try:
                                snippet_el = row.locator('.y2')
                                if snippet_el.count() > 0:
                                    body_preview = snippet_el.first.inner_text(timeout=2000)
                            except:
                                pass

                            codes = self._extract_codes(subject, body_preview)
                            results.append({
                                "subject": subject[:200],
                                "sender": sender[:100],
                                "date": date[:50],
                                "body_preview": body_preview[:500],
                                "codes": codes,
                            })
                        except:
                            continue

                    self.method_detected.emit("Browser")
                    self.mail_loaded.emit(results)

                finally:
                    page.close()
                    browser.close()
        finally:
            try:
                chrome_proc.terminate()
            except:
                pass

    def _parse_message(self, msg):
        """Parse email.message into our dict format."""
        from email.header import decode_header
        import re

        subject = ""
        raw_subj = msg.get("Subject", "")
        if raw_subj:
            for part, enc in decode_header(raw_subj):
                if isinstance(part, bytes):
                    subject += part.decode(enc or "utf-8", errors="replace")
                else:
                    subject += str(part)

        sender = msg.get("From", "")
        date_str = msg.get("Date", "")

        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                ct = part.get_content_type()
                if ct == "text/plain":
                    try:
                        cs = part.get_content_charset() or "utf-8"
                        body = part.get_payload(decode=True).decode(cs, errors="replace")
                    except:
                        body = str(part.get_payload(decode=True))
                    break
                elif ct == "text/html" and not body:
                    try:
                        cs = part.get_content_charset() or "utf-8"
                        html = part.get_payload(decode=True).decode(cs, errors="replace")
                        body = re.sub(r'<[^>]+>', ' ', html)
                        body = re.sub(r'\s+', ' ', body).strip()
                    except:
                        pass
        else:
            try:
                cs = msg.get_content_charset() or "utf-8"
                body = msg.get_payload(decode=True).decode(cs, errors="replace")
            except:
                body = str(msg.get_payload(decode=True))

        codes = self._extract_codes(subject, body)

        return {
            "subject": subject[:200],
            "sender": sender[:100],
            "date": date_str[:50],
            "body_preview": body[:500],
            "codes": codes,
        }

    def _extract_codes(self, subject, body):
        """Extract verification codes (4-8 digits)."""
        import re
        codes = re.findall(r'\b(\d{4,8})\b', body)
        code_kw = ["code", "verify", "confirmation", "otp", "pin", "security",
                    "reset", "password", "mã", "xác minh"]
        combined = (subject + " " + body).lower()
        if not any(kw in combined for kw in code_kw):
            codes = []
        return codes[:5]


# ═══════════════════════════════════════════
#  Gmail Read Mail Dialog
# ═══════════════════════════════════════════
class GmailReadMailDialog(QDialog):
    """Dark-themed popup showing 10 recent Gmail emails with code extraction."""
    def __init__(self, parent=None, gmail_addr="", password="", app_password="", gmail_id="", gm=None, data_dir=""):
        super().__init__(parent)
        self.gmail_addr = gmail_addr
        self.password = password
        self.app_password = app_password
        self.gmail_id = gmail_id
        self.gm = gm
        self.data_dir = data_dir
        self.setWindowTitle(f"Hộp thư - {gmail_addr}")
        self.resize(720, 580)
        self.setStyleSheet("""
            QDialog { background-color: #1a1d23; }
            QLabel { color: #e0e0e0; font-family: 'Segoe UI', Arial; }
            QScrollArea { border: none; background: #1a1d23; }
            QPushButton { background: #2d3748; border: 1px solid #4a5568; border-radius: 4px;
                          padding: 5px 10px; color: #e0e0e0; font-weight: bold; }
            QPushButton:hover { background: #4a5568; }
        """)
        layout = QVBoxLayout(self)

        header = QLabel(f"📧 {gmail_addr}")
        header.setStyleSheet("font-size: 16px; font-weight: bold; color: #a78bfa; padding: 5px;")
        layout.addWidget(header)

        self.method_lbl = QLabel("")
        self.method_lbl.setStyleSheet("color: #b794f4; font-size: 11px; padding: 0 5px;")
        layout.addWidget(self.method_lbl)

        self.status_lbl = QLabel("⏳ Đang tải hộp thư...")
        self.status_lbl.setStyleSheet("color: #fbd38d; font-size: 12px; padding: 2px 5px;")
        layout.addWidget(self.status_lbl)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.mail_container = QWidget()
        self.mail_container.setStyleSheet("background: #1a1d23;")
        self.mail_layout = QVBoxLayout(self.mail_container)
        self.mail_layout.setSpacing(6)
        self.mail_layout.setContentsMargins(4, 4, 4, 4)
        self.mail_layout.addStretch()
        scroll.setWidget(self.mail_container)
        layout.addWidget(scroll, 1)

        btn_row = QHBoxLayout()
        btn_refresh = QPushButton("🔄 Làm mới")
        btn_refresh.clicked.connect(self._start_loading)
        btn_close = QPushButton("Đóng")
        btn_close.clicked.connect(self.close)
        btn_row.addWidget(btn_refresh)
        btn_row.addStretch()
        btn_row.addWidget(btn_close)
        layout.addLayout(btn_row)

        self._start_loading()

    def _start_loading(self):
        self.status_lbl.setText("⏳ Đang kết nối...")
        self.status_lbl.setStyleSheet("color: #fbd38d; font-size: 12px;")
        self.method_lbl.setText("")
        while self.mail_layout.count() > 1:
            item = self.mail_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        self.reader_thread = GmailReadMailThread(
            self.gmail_addr, self.password, self.app_password, 10,
            gmail_id=self.gmail_id, data_dir=self.data_dir
        )
        self.reader_thread.mail_loaded.connect(self._on_mail_loaded)
        self.reader_thread.error.connect(self._on_error)
        self.reader_thread.status_msg.connect(self._on_status)
        self.reader_thread.method_detected.connect(self._on_method)
        self.reader_thread.start()

    def _on_status(self, msg):
        self.status_lbl.setText(f"⏳ {msg}")

    def _on_method(self, method):
        self.method_lbl.setText(f"🔌 Phương thức: {method}")

    def _on_mail_loaded(self, mails):
        if not mails:
            self.status_lbl.setText("📭 Hộp thư trống.")
            self.status_lbl.setStyleSheet("color: #a0aec0; font-size: 12px;")
            return
        self.status_lbl.setText(f"✅ Đã tải {len(mails)} thư")
        self.status_lbl.setStyleSheet("color: #68d391; font-size: 12px;")
        for md in mails:
            card = self._create_mail_card(md)
            self.mail_layout.insertWidget(self.mail_layout.count() - 1, card)

    def _on_error(self, msg):
        self.status_lbl.setText(f"❌ {msg}")
        self.status_lbl.setStyleSheet("color: #fc8181; font-size: 12px;")

    def _create_mail_card(self, md):
        card = QWidget()
        has_codes = bool(md.get("codes"))
        bg = "#2a4365" if has_codes else "#2d3748"
        border = "#a78bfa" if has_codes else "#4a5568"
        card.setStyleSheet(
            f"QWidget {{ background: {bg}; border: 1px solid {border}; "
            f"border-radius: 6px; padding: 8px; }} "
            f"QLabel {{ border: none; padding: 0; }}")
        cl = QVBoxLayout(card)
        cl.setSpacing(3)
        cl.setContentsMargins(8, 6, 8, 6)

        subj = md.get("subject", "(No subject)")
        lbl_s = QLabel(f"📌 {subj}")
        lbl_s.setStyleSheet("font-weight: bold; font-size: 13px; color: #e2e8f0;")
        lbl_s.setWordWrap(True)
        cl.addWidget(lbl_s)

        info = QHBoxLayout()
        lbl_from = QLabel(f"👤 {md.get('sender', '')}")
        lbl_from.setStyleSheet("font-size: 11px; color: #a0aec0;")
        lbl_date = QLabel(f"📅 {md.get('date', '')}")
        lbl_date.setStyleSheet("font-size: 11px; color: #a0aec0;")
        info.addWidget(lbl_from, 1)
        info.addWidget(lbl_date, 0)
        cl.addLayout(info)

        body = md.get("body_preview", "")[:300]
        if body:
            lbl_b = QLabel(body)
            lbl_b.setStyleSheet("font-size: 11px; color: #cbd5e0;")
            lbl_b.setWordWrap(True)
            lbl_b.setMaximumHeight(60)
            cl.addWidget(lbl_b)

        codes = md.get("codes", [])
        if codes:
            cr = QHBoxLayout()
            code_lbl = QLabel("🔑 Code:")
            code_lbl.setStyleSheet("color: #fbd38d; font-weight: bold;")
            cr.addWidget(code_lbl)
            for code in codes:
                btn = QPushButton(f"📋 {code}")
                btn.setStyleSheet(
                    "QPushButton { background: #48bb78; color: white; font-weight: bold; "
                    "font-size: 13px; border-radius: 4px; padding: 4px 12px; border: none; } "
                    "QPushButton:hover { background: #38a169; }")
                btn.setFixedHeight(28)
                btn.clicked.connect(lambda checked, c=code: self._copy_code(c))
                cr.addWidget(btn)
            cr.addStretch()
            cl.addLayout(cr)
        return card

    def _copy_code(self, code):
        QApplication.clipboard().setText(code)
        self.status_lbl.setText(f"✅ Copied: {code}")
        self.status_lbl.setStyleSheet("color: #68d391; font-size: 12px; font-weight: bold;")


# ═══════════════════════════════════════════
#  Import Gmail Dialog (with auto-detect)
# ═══════════════════════════════════════════
class ImportGmailDialog(QDialog):
    def __init__(self, parent=None, categories=None):
        super().__init__(parent)
        self.setWindowTitle("Import Gmail")
        self.resize(900, 560)
        self.categories = categories or ["Mới"]

        self.setStyleSheet("""
            QDialog { background-color: #1e293b; color: #e2e8f0; }
            QLabel { color: #e2e8f0; font-size: 13px; }
            QComboBox { border: 1px solid #475569; border-radius: 3px; padding: 3px 6px;
                        background: #334155; color: #e2e8f0; min-width: 70px; font-size: 12px; }
            QComboBox::drop-down { border-left: 1px solid #475569; width: 18px; background: #475569; }
            QComboBox QAbstractItemView { background: #334155; color: #e2e8f0; border: 1px solid #475569;
                                          selection-background-color: #3b82f6; }
            QTextEdit { border: 1px solid #475569; border-radius: 3px; background: #0f172a;
                        color: #e2e8f0; font-family: Consolas, monospace; font-size: 12px; }
            QPushButton#OkBtn { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #4bbdf5, stop:1 #1a8dfb);
                                color: white; font-weight: bold; border-radius: 4px; min-width: 120px;
                                min-height: 35px; font-size: 13px; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 12, 20, 12)
        layout.setSpacing(6)

        # ── Row 1: Category ──
        cat_row = QHBoxLayout()
        cat_row.addWidget(QLabel("Chọn danh mục"))
        self.combo_cat = QComboBox()
        self.combo_cat.setFixedWidth(200)
        self.combo_cat.addItems(self.categories)
        cat_row.addWidget(self.combo_cat)
        cat_row.addStretch()
        layout.addLayout(cat_row)

        # ── Row 2: Format Preset ──
        fmt_row = QHBoxLayout()
        fmt_row.addWidget(QLabel("Định dạng nhập"))
        self.combo_fmt = QComboBox()
        self.combo_fmt.addItem("Tự nhận dạng", [])
        self.combo_fmt.addItem("Gmail|Password", ["gmail", "password"])
        self.combo_fmt.addItem("Gmail|Password|App Password", ["gmail", "password", "app_password"])
        self.combo_fmt.addItem("Gmail|Password|Recovery Email", ["gmail", "password", "recovery_email"])
        self.combo_fmt.addItem("Gmail|Password|App Password|Recovery Email|2FA", ["gmail", "password", "app_password", "recovery_email", "2fa_secret"])
        self.combo_fmt.addItem("Gmail|Password|App Password|Recovery Email|Recovery Phone|2FA|Proxy|Note",
                               ["gmail", "password", "app_password", "recovery_email", "recovery_phone", "2fa_secret", "proxy", "note"])
        self.combo_fmt.currentIndexChanged.connect(self._on_format_changed)
        fmt_row.addWidget(self.combo_fmt)
        fmt_row.addStretch()
        layout.addLayout(fmt_row)

        # ── Row 3: Column Mapping Combos ──
        field_options = [
            ("Bỏ qua", ""),
            ("Gmail", "gmail"),
            ("Password", "password"),
            ("App Password", "app_password"),
            ("Recovery Email", "recovery_email"),
            ("Recovery Phone", "recovery_phone"),
            ("2FA Secret", "2fa_secret"),
            ("Proxy", "proxy"),
            ("Note", "note"),
        ]
        self.mapping_combos = []
        map_layout = QHBoxLayout()
        map_layout.setSpacing(2)
        for i in range(12):
            cb = QComboBox()
            for lbl, key in field_options:
                cb.addItem(lbl, key)
            cb.setFixedWidth(95)
            self.mapping_combos.append(cb)
            map_layout.addWidget(cb)
            if i < 11:
                sep = QLabel("|")
                sep.setFixedWidth(10)
                sep.setAlignment(Qt.AlignmentFlag.AlignCenter)
                sep.setStyleSheet("color: #64748b;")
                map_layout.addWidget(sep)
        map_layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(50)
        scroll.setStyleSheet("QScrollArea { border: none; }")
        map_container = QWidget()
        map_container.setLayout(map_layout)
        scroll.setWidget(map_container)
        layout.addWidget(scroll)

        # ── Row 4: Auto-detect label ──
        self.auto_detect_lbl = QLabel("")
        self.auto_detect_lbl.setStyleSheet("color: #38bdf8; font-size: 11px; font-weight: bold; padding: 2px;")
        self.auto_detect_lbl.setWordWrap(True)
        layout.addWidget(self.auto_detect_lbl)

        # ── Text area ──
        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText(
            "Dán Gmail vào đây, chia cách bởi dấu '|'...\n"
            "Ví dụ:\n"
            "user@gmail.com|password123\n"
            "user2@gmail.com|pass456|app_pass|recovery@email.com|0912345678|JBSWY3DPEHPK3PXP"
        )
        self.text_edit.textChanged.connect(self._auto_detect_format)
        layout.addWidget(self.text_edit)

        # ── Bottom ──
        bottom = QHBoxLayout()
        btn_ok = QPushButton("OK")
        btn_ok.setObjectName("OkBtn")
        btn_ok.clicked.connect(self.accept)
        bottom.addWidget(btn_ok)
        bottom.addStretch()
        layout.addLayout(bottom)

        self._on_format_changed(0)

    def _on_format_changed(self, idx):
        keys = self.combo_fmt.currentData() or []
        if not keys:
            return  # "Tự nhận dạng" — don't change combos
        for cb in self.mapping_combos:
            cb.setCurrentIndex(0)
        for i, key in enumerate(keys):
            if i < len(self.mapping_combos):
                idx_found = self.mapping_combos[i].findData(key)
                if idx_found >= 0:
                    self.mapping_combos[i].setCurrentIndex(idx_found)

    def _auto_detect_format(self):
        """Auto-detect column format from first non-empty line and set mapping combos."""
        # Only auto-detect if preset is "Tự nhận dạng"
        if self.combo_fmt.currentIndex() != 0:
            return

        text = self.text_edit.toPlainText().strip()
        if not text:
            self.auto_detect_lbl.setText("")
            return

        first_line = ""
        for line in text.split("\n"):
            if line.strip():
                first_line = line.strip()
                break
        if not first_line:
            return

        parts = first_line.split("|")
        num_parts = len(parts)

        import re as _re

        def looks_like_gmail(s):
            s = s.strip()
            return "@" in s and ("gmail" in s.lower() or "google" in s.lower())

        def looks_like_email(s):
            return "@" in s and "." in s

        def looks_like_phone(s):
            s = s.strip().replace("+", "").replace(" ", "").replace("-", "")
            return s.isdigit() and 8 <= len(s) <= 15

        def looks_like_proxy(s):
            s = s.strip()
            if _re.match(r'^(socks[45]|https?)://', s, _re.IGNORECASE):
                return True
            if _re.match(r'^\d+\.\d+\.\d+\.\d+:\d+', s):
                return True
            return False

        def looks_like_2fa(s):
            s = s.strip().replace(" ", "").replace("-", "")
            # Must be base32 (A-Z, 2-7), 16-40 chars, but NOT a 16-char all-lowercase (app password)
            if len(s) == 16 and s.isalpha() and s.islower():
                return False  # This is an app password, not a 2FA secret
            return len(s) >= 16 and len(s) <= 40 and _re.match(r'^[A-Za-z2-7]+=*$', s)

        def looks_like_app_password(s):
            s = s.strip().replace(" ", "")
            # Google App passwords are 16 lowercase letters (e.g. "abcdefghijklmnop")
            return len(s) == 16 and s.isalpha() and s.islower()

        def looks_like_password(s):
            s = s.strip()
            return 1 <= len(s) <= 64 and not looks_like_proxy(s) and not looks_like_2fa(s) and not looks_like_app_password(s)

        # Detect each column
        detected_keys = []
        detected_names = []
        gmail_found = False
        password_found = False
        app_pw_found = False
        recovery_email_found = False

        for i, part in enumerate(parts):
            p = part.strip()
            if not p:
                detected_keys.append("")
                detected_names.append("Bỏ qua")
                continue

            if looks_like_gmail(p) and not gmail_found:
                detected_keys.append("gmail")
                detected_names.append("Gmail")
                gmail_found = True
            elif looks_like_phone(p):
                detected_keys.append("recovery_phone")
                detected_names.append("Recovery Phone")
            elif looks_like_proxy(p):
                detected_keys.append("proxy")
                detected_names.append("Proxy")
            elif looks_like_app_password(p) and password_found and not app_pw_found:
                detected_keys.append("app_password")
                detected_names.append("App Password")
                app_pw_found = True
            elif looks_like_2fa(p):
                detected_keys.append("2fa_secret")
                detected_names.append("2FA Secret")
            elif looks_like_email(p) and gmail_found and not recovery_email_found:
                detected_keys.append("recovery_email")
                detected_names.append("Recovery Email")
                recovery_email_found = True
            elif looks_like_email(p) and gmail_found and recovery_email_found:
                # Second recovery email — also map as recovery_email (will be merged with |)
                detected_keys.append("recovery_email")
                detected_names.append("Recovery Email 2")
            elif looks_like_email(p) and not gmail_found:
                detected_keys.append("gmail")
                detected_names.append("Gmail")
                gmail_found = True
            elif looks_like_password(p) and not password_found:
                detected_keys.append("password")
                detected_names.append("Password")
                password_found = True
            elif looks_like_password(p) and password_found and not app_pw_found:
                detected_keys.append("app_password")
                detected_names.append("App Password")
                app_pw_found = True
            else:
                detected_keys.append("note")
                detected_names.append("Note")

        # Apply detected mappings
        for cb in self.mapping_combos:
            cb.setCurrentIndex(0)
        for i, key in enumerate(detected_keys):
            if i < len(self.mapping_combos) and key:
                idx_found = self.mapping_combos[i].findData(key)
                if idx_found >= 0:
                    self.mapping_combos[i].setCurrentIndex(idx_found)

        # Show detection result
        total_lines = len([l for l in text.split("\n") if l.strip()])
        fmt_str = " | ".join(detected_names[:num_parts])
        self.auto_detect_lbl.setText(f"📡 Tự nhận dạng {num_parts} cột, {total_lines} dòng: {fmt_str}")

    def get_parsed_data(self):
        text = self.text_edit.toPlainText().strip()
        if not text:
            return None, []

        category = self.combo_cat.currentText()
        mappings = [cb.currentData() for cb in self.mapping_combos]

        results = []
        for line in text.split('\n'):
            line = line.strip()
            if not line:
                continue
            parts = line.split('|')
            record = {"category": category}
            for i, part in enumerate(parts):
                if i < len(mappings) and mappings[i]:
                    key = mappings[i]
                    val = part.strip()
                    if key == "recovery_email" and key in record and record[key]:
                        # Merge multiple recovery emails with | separator
                        record[key] = record[key] + "|" + val
                    else:
                        record[key] = val
            if record.get("gmail"):
                results.append(record)
        return category, results


# ═══════════════════════════════════════════
#  Main Gmail Manager Widget
# ═══════════════════════════════════════════
class GmailManagerWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.gm = GmailManager()
        self.login_threads = []
        self._current_category = "Tất cả"
        self._init_ui()
        self.load_data()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(6, 6, 6, 0)
        main_layout.setSpacing(4)

        # ── Sub-Tabs ──
        self.sub_tabs = QTabWidget()

        # Tab 1: Gmail List (main)
        self.gmail_list_tab = QWidget()
        self._build_gmail_list_tab()
        self.sub_tabs.addTab(self.gmail_list_tab, "Danh sách Gmail")

        # Tab 2: Login Gmail
        login_tab = QWidget()
        self._build_login_tab(login_tab)
        self.sub_tabs.addTab(login_tab, "Login Gmail")

        # Tab 3: Phone Settings (shared)
        from ui.phone_settings_widget import PhoneSettingsWidget
        self.phone_settings_tab = PhoneSettingsWidget(self)
        self.sub_tabs.addTab(self.phone_settings_tab, "📱 Setting Phone")

        main_layout.addWidget(self.sub_tabs, 1)

        # ── Status Bar ──
        status_bar = QWidget()
        status_bar.setStyleSheet("background: #1a202c; border-top: 1px solid #4a5568; padding: 4px 10px;")
        status_layout = QHBoxLayout(status_bar)
        status_layout.setContentsMargins(10, 2, 10, 2)
        self.lbl_total = QLabel("Tổng số Gmail: 0")
        self.lbl_selected = QLabel("Tích Chọn: 0")
        self.lbl_total.setStyleSheet("color: #e2e8f0;")
        self.lbl_selected.setStyleSheet("color: #e2e8f0;")
        status_layout.addWidget(self.lbl_total)
        status_layout.addSpacing(20)
        status_layout.addWidget(self.lbl_selected)
        status_layout.addStretch()
        main_layout.addWidget(status_bar, 0)

    def _build_gmail_list_tab(self):
        layout = QVBoxLayout(self.gmail_list_tab)
        layout.setContentsMargins(6, 6, 6, 0)
        layout.setSpacing(4)

        BTN_H = 30

        def make_btn(label, obj_name=None, min_w=90):
            b = QPushButton(label)
            if obj_name:
                b.setObjectName(obj_name)
            b.setMinimumWidth(min_w)
            b.setFixedHeight(BTN_H)
            return b

        # ── Row 1: Action Buttons ──
        row1 = QHBoxLayout()
        row1.setSpacing(4)

        self.btn_login_browser = make_btn("Login Browser", "PrimaryBtn", 110)
        self.btn_login_recovery = make_btn("Login + Add Recovery", "PrimaryBtn", 150)
        self.btn_login_headless = make_btn("Login Ẩn", "PrimaryBtn", 90)
        self.btn_open_profile = make_btn("Open Profile", "PrimaryBtn", 100)
        self.btn_read_mail = make_btn("📧 Đọc thư", "PrimaryBtn", 100)
        self.btn_2fa = make_btn("🔐 Bật 2FA", "PrimaryBtn", 100)
        self.btn_2fa.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #7e22ce, stop:1 #581c87);
                border: 1px solid #a855f7;
                border-radius: 5px;
                color: #e9d5ff;
                font-weight: 700;
                font-size: 11px;
            }
            QPushButton:hover {
                background: #a855f7;
                color: #3b0764;
            }
        """)
        self.btn_verify_recovery = make_btn("📧 XM Recovery", "PrimaryBtn", 110)
        self.btn_verify_recovery.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #0d9488, stop:1 #0f766e);
                border: 1px solid #2dd4bf;
                border-radius: 5px;
                color: #ccfbf1;
                font-weight: 700;
                font-size: 11px;
            }
            QPushButton:hover {
                background: #14b8a6;
                color: #042f2e;
            }
        """)
        self.btn_stop = make_btn("Stop", "DeleteBtn", 60)
        self.btn_find = make_btn("Find", "PrimaryBtn", 70)
        self.btn_delete = make_btn("Xóa", "DeleteBtn", 60)
        self.btn_refresh = make_btn("Refresh", None, 80)
        self.btn_refresh.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #166534, stop:1 #14532d);
                border: 1px solid #22c55e;
                border-radius: 5px;
                color: #bbf7d0;
                font-weight: 700;
                font-size: 11px;
            }
            QPushButton:hover {
                background: #22c55e;
                color: #052e16;
            }
        """)

        # Thread count spinner
        lbl_threads = QLabel("Số luồng:")
        lbl_threads.setStyleSheet("font-weight: bold; color: #e2e8f0;")
        self.spin_threads = QSpinBox()
        self.spin_threads.setRange(1, 20)
        self.spin_threads.setValue(3)
        self.spin_threads.setFixedWidth(60)
        self.spin_threads.setFixedHeight(BTN_H)

        self.btn_login_browser.clicked.connect(lambda: self._login_browser(headless=False))
        self.btn_login_recovery.clicked.connect(self._login_add_recovery)
        self.btn_login_headless.clicked.connect(lambda: self._login_browser(headless=True))
        self.btn_open_profile.clicked.connect(self._open_profile)
        self.btn_read_mail.clicked.connect(self._read_mail)
        self.btn_2fa.clicked.connect(self._setup_2fa_selected)
        self.btn_verify_recovery.clicked.connect(self._verify_recovery_selected)
        self.btn_stop.clicked.connect(self._stop_all)
        self.btn_find.clicked.connect(self._find_gmail)
        self.btn_delete.clicked.connect(self._delete_selected)
        self.btn_refresh.clicked.connect(self.load_data)

        for btn in [self.btn_login_browser,
                     self.btn_login_recovery, self.btn_login_headless,
                     self.btn_open_profile, self.btn_read_mail,
                     self.btn_2fa, self.btn_verify_recovery, self.btn_stop, self.btn_find,
                     self.btn_delete, self.btn_refresh]:
            row1.addWidget(btn)
        row1.addSpacing(10)
        row1.addWidget(lbl_threads)
        row1.addWidget(self.spin_threads)
        row1.addStretch()
        layout.addLayout(row1)

        # ── Row 2: Category Management ──
        row2 = QHBoxLayout()
        row2.setSpacing(4)

        lbl_folder = QLabel("Thư mục")
        lbl_folder.setStyleSheet("font-weight: bold; color: #e2e8f0;")
        self.combo_cat = QComboBox()
        self.combo_cat.setMinimumWidth(140)
        self.combo_cat.setFixedHeight(BTN_H)
        self.combo_cat.currentTextChanged.connect(self._on_cat_changed)

        self.btn_add_cat = make_btn("Add", "PrimaryBtn", 50)
        self.btn_edit_cat = make_btn("Edit", "PrimaryBtn", 50)
        self.btn_del_cat = make_btn("Delete", "DeleteBtn", 55)
        self.btn_move_cat = make_btn("Move", "PrimaryBtn", 55)

        self.btn_add_cat.clicked.connect(self._add_category)
        self.btn_edit_cat.clicked.connect(self._edit_category)
        self.btn_del_cat.clicked.connect(self._delete_category)
        self.btn_move_cat.clicked.connect(self._move_to_category)

        row2.addWidget(lbl_folder)
        row2.addWidget(self.combo_cat)
        row2.addWidget(self.btn_add_cat)
        row2.addWidget(self.btn_edit_cat)
        row2.addWidget(self.btn_del_cat)
        row2.addWidget(self.btn_move_cat)
        row2.addStretch()
        layout.addLayout(row2)

        # ── Table ──
        self.table = CopyableTable()
        self.table.setAlternatingRowColors(False)
        # Force item backgrounds to render despite CSS (Qt stylesheet override fix)
        from ui.copyable_table import BackgroundDelegate
        self.table.setItemDelegate(BackgroundDelegate(self.table))
        self.table.setEditTriggers(QTableWidget.EditTrigger.DoubleClicked)
        self.table.verticalHeader().setVisible(False)
        self.table.cellChanged.connect(self._on_cell_changed)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._context_menu)

        # Spacebar toggle override
        self.table.keyPressEvent = self._table_key_press_event

        self._setup_columns()
        layout.addWidget(self.table)

    def _build_login_tab(self, tab):
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        title = QLabel("🔐 Gmail Login Manager")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #a78bfa; margin-bottom: 10px;")
        layout.addWidget(title)

        desc = QLabel(
            "Đăng nhập Gmail qua IMAP hoặc Browser (Playwright).\n\n"
            "• Kiểm IMAP: Check login qua imap.gmail.com (cần App Password nếu bật 2FA)\n"
            "• Login Browser: Mở Chrome tự động điền Email + Password\n"
            "• Login Ẩn: Giống Login Browser nhưng chạy headless (không hiện cửa sổ)\n\n"
            "Lưu ý: Nếu Gmail đã bật 2FA, cần tạo App Password tại:\n"
            "https://myaccount.google.com/apppasswords"
        )
        desc.setStyleSheet("color: #94a3b8; font-size: 12px; line-height: 1.6;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # Quick login form
        form_box = QWidget()
        form_box.setStyleSheet("""
            QWidget { background: #1e2a3a; border: 1px solid #4a5568; border-radius: 8px; padding: 15px; }
            QLabel { color: #c4b5fd; font-weight: 700; border: none; }
            QLineEdit { background: #2d3748; border: 1px solid #4a5568; border-radius: 6px;
                         color: #f7fafc; padding: 8px; font-size: 12px; }
            QLineEdit:focus { border-color: #a78bfa; }
        """)
        form_layout = QFormLayout(form_box)
        form_layout.setSpacing(10)

        self.inp_gmail = QLineEdit()
        self.inp_gmail.setPlaceholderText("user@gmail.com")
        self.inp_pass = QLineEdit()
        self.inp_pass.setPlaceholderText("Mật khẩu Gmail")
        self.inp_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self.inp_app_pass = QLineEdit()
        self.inp_app_pass.setPlaceholderText("App Password (nếu có 2FA)")
        self.inp_app_pass.setEchoMode(QLineEdit.EchoMode.Password)

        form_layout.addRow("Gmail:", self.inp_gmail)
        form_layout.addRow("Password:", self.inp_pass)
        form_layout.addRow("App Password:", self.inp_app_pass)

        btn_row = QHBoxLayout()
        btn_quick_imap = QPushButton("Check IMAP")
        btn_quick_imap.setStyleSheet("background: #2563eb; color: white; font-weight: bold; border-radius: 5px; padding: 8px 20px;")
        btn_quick_browser = QPushButton("Login Browser")
        btn_quick_browser.setStyleSheet("background: #059669; color: white; font-weight: bold; border-radius: 5px; padding: 8px 20px;")
        self.lbl_quick_status = QLabel("")
        self.lbl_quick_status.setStyleSheet("color: #fbbf24; font-size: 12px; border: none;")

        btn_quick_imap.clicked.connect(self._quick_imap_check)
        btn_quick_browser.clicked.connect(self._quick_browser_login)

        btn_row.addWidget(btn_quick_imap)
        btn_row.addWidget(btn_quick_browser)
        btn_row.addWidget(self.lbl_quick_status)
        btn_row.addStretch()
        form_layout.addRow("", btn_row)

        layout.addWidget(form_box)
        layout.addStretch()

    def _setup_columns(self):
        self.table.setColumnCount(len(GMAIL_COLUMNS))
        headers = [col[1] for col in GMAIL_COLUMNS]
        self.table.setHorizontalHeaderLabels(headers)

        self._select_all_chk = QCheckBox(self.table.horizontalHeader())
        self._select_all_chk.setTristate(False)
        self._select_all_chk.stateChanged.connect(self._toggle_select_all)
        self._select_all_chk.setStyleSheet("QCheckBox::indicator { width: 14px; height: 14px; }")

        header = self.table.horizontalHeader()
        header.setMinimumSectionSize(24)
        header.setSectionsMovable(True)

        # 3-step sort
        self.sort_states = {}
        self.current_sort_col = -1
        header.sectionClicked.connect(self._on_header_clicked)

        self.table.setColumnWidth(0, 30)
        self.table.setColumnWidth(1, 40)
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)

        for i, (key, _) in enumerate(GMAIL_COLUMNS):
            if key in ["chk", "stt"]:
                continue
            header.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            if key == "gmail":
                self.table.setColumnWidth(i, 200)
            elif key in ["status"]:
                self.table.setColumnWidth(i, 220)
            elif key in ["recovery_email"]:
                self.table.setColumnWidth(i, 180)
            else:
                self.table.setColumnWidth(i, 110)

        self._reposition_chk()

    def _reposition_chk(self):
        header = self.table.horizontalHeader()
        x = header.sectionPosition(0)
        w = header.sectionSize(0)
        h = header.height()
        cw, ch = 16, 16
        self._select_all_chk.setGeometry(x + (w - cw) // 2, (h - ch) // 2, cw, ch)
        self._select_all_chk.raise_()
        self._select_all_chk.show()

    def _toggle_select_all(self, state):
        checked = state == 2
        self.table.blockSignals(True)
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item:
                item.setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
        self.table.blockSignals(False)
        self._update_status()

    # ─── Data Loading ───

    def load_data(self):
        self.table.blockSignals(True)
        self.table.setRowCount(0)
        self._refresh_cats()

        records = self.gm.get_all(category=self._current_category)

        # Apply sorting if active
        if self.current_sort_col > 0:
            sort_key_name = GMAIL_COLUMNS[self.current_sort_col][0]
            sort_state = self.sort_states.get(self.current_sort_col, 0)
            if sort_state in (1, 2):
                reverse = (sort_state == 2)
                def sort_key(rec):
                    val = str(rec.get(sort_key_name, ""))
                    num = self._parse_numeric_for_sort(val)
                    if num != -999999999:
                        return (0, num, val.lower())
                    return (1, 0, val.lower())
                records = sorted(records, key=sort_key, reverse=reverse)

        for row_idx, rec in enumerate(records):
            self.table.insertRow(row_idx)

            live_val = rec.get("live", "").lower()

            # ── Color ONLY based on Live column ──
            row_bg = QColor("#e0f2fe") if (row_idx % 2 == 0) else QColor("#ffffff")
            row_fg = QColor("#0f172a")

            if any(x in live_val for x in ["dead", "die", "disabled", "locked", "banned", "khóa", "cp282", "cp956", "checkpoint", "xác minh"]):
                row_bg = QColor("#ff6b6b")
            elif "out" in live_val:
                row_bg = QColor("#ffec8b")
            elif "live" in live_val:
                row_bg = QColor("#81c784")

            # Check session status
            import os as _os
            session_status = ""
            has_session = False
            dd = rec.get("data_dir", "")
            if dd and _os.path.isdir(dd):
                default_dir = _os.path.join(dd, "Default")
                if _os.path.isdir(default_dir) and len(_os.listdir(default_dir)) > 5:
                    session_status = "✅ Saved"
                    has_session = True
                elif len(_os.listdir(dd)) > 5:
                    session_status = "✅ Saved"
                    has_session = True
                else:
                    session_status = "❌ Empty"
            else:
                session_status = "❌ Empty"

            for col_idx, (key, _) in enumerate(GMAIL_COLUMNS):
                if key == "chk":
                    item = QTableWidgetItem()
                    item.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                    item.setCheckState(Qt.CheckState.Unchecked)
                    item.setData(Qt.ItemDataRole.UserRole, rec.get("id", ""))
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                elif key == "stt":
                    item = QTableWidgetItem(str(row_idx + 1))
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                elif key == "session":
                    item = QTableWidgetItem(session_status)
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                else:
                    item = QTableWidgetItem(str(rec.get(key, "")))

                item.setBackground(row_bg)
                item.setForeground(row_fg)
                self.table.setItem(row_idx, col_idx, item)

        self.table.blockSignals(False)
        self._reposition_chk()
        self._select_all_chk.blockSignals(True)
        self._select_all_chk.setCheckState(Qt.CheckState.Unchecked)
        self._select_all_chk.blockSignals(False)
        self._update_status()

    def _refresh_cats(self):
        self.combo_cat.blockSignals(True)
        current = self.combo_cat.currentText()
        self.combo_cat.clear()
        self.combo_cat.addItem("Tất cả")
        for c in self.gm.get_categories():
            self.combo_cat.addItem(c)
        idx = self.combo_cat.findText(current)
        if idx >= 0:
            self.combo_cat.setCurrentIndex(idx)
        self.combo_cat.blockSignals(False)

    def _update_status(self):
        total = self.table.rowCount()
        sel = len(self._get_checked_ids())
        self.lbl_total.setText(f"Tổng số Gmail: {total}")
        self.lbl_selected.setText(f"Tích Chọn: {sel}")

    # ─── Helpers ───

    def _get_record_at_row(self, row):
        chk = self.table.item(row, 0)
        if not chk:
            return None
        rid = chk.data(Qt.ItemDataRole.UserRole)
        if not rid:
            return None
        for r in self.gm.get_all(category=self._current_category):
            if r.get("id") == rid:
                return r
        return None

    def _get_checked_ids(self):
        ids = []
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item and item.checkState() == Qt.CheckState.Checked:
                rid = item.data(Qt.ItemDataRole.UserRole)
                if rid:
                    ids.append(rid)
        return ids

    def _get_checked_records(self):
        checked_ids = self._get_checked_ids()
        if not checked_ids:
            return []
        id_set = set(checked_ids)
        recs = []
        for r in self.gm.get_all(category=self._current_category):
            if r.get("id") in id_set:
                recs.append(r)
        return recs

    # ─── Slots ───

    def _on_cat_changed(self, text):
        self._current_category = text
        self.load_data()

    def _on_cell_changed(self, row, col):
        if row < 0 or col < 0:
            return
        key = GMAIL_COLUMNS[col][0]
        if key in ["chk", "stt"]:
            self._update_status()
            return
        new_val = self.table.item(row, col).text()
        rec = self._get_record_at_row(row)
        if rec:
            self.gm.update(rec["id"], {key: new_val})

    def _table_key_press_event(self, event):
        """Spacebar toggles checkboxes for selected rows."""
        from PyQt6.QtGui import QKeySequence
        if event.matches(QKeySequence.StandardKey.Copy):
            self.table._copy_selection()
            return
        if event.key() == Qt.Key.Key_Space:
            selected_items = self.table.selectedItems()
            if not selected_items:
                return
            selected_rows = set(item.row() for item in selected_items)
            self.table.blockSignals(True)
            for row in selected_rows:
                chk_item = self.table.item(row, 0)
                if chk_item:
                    current = chk_item.checkState()
                    new_state = Qt.CheckState.Unchecked if current == Qt.CheckState.Checked else Qt.CheckState.Checked
                    chk_item.setCheckState(new_state)
            self.table.blockSignals(False)
            self._update_status()
            event.accept()
        else:
            QTableWidget.keyPressEvent(self.table, event)

    def _on_header_clicked(self, logicalIndex):
        """3-state sort: None -> Asc -> Desc -> None"""
        if logicalIndex == 0:
            return
        for idx in list(self.sort_states.keys()):
            if idx != logicalIndex:
                self.sort_states[idx] = 0
        current_state = self.sort_states.get(logicalIndex, 0)
        new_state = (current_state + 1) % 3
        self.sort_states[logicalIndex] = new_state
        self.current_sort_col = logicalIndex if new_state != 0 else -1
        self.load_data()

    def _parse_numeric_for_sort(self, val_str):
        import re
        val_str = str(val_str).lower().strip()
        if not val_str:
            return -999999999
        multiplier = 1
        if 'k' in val_str: multiplier = 1000
        elif 'm' in val_str: multiplier = 1000000
        num_match = re.search(r'[\d,.]+', val_str)
        if num_match:
            try:
                num_str = num_match.group(0).replace(',', '.')
                parts = num_str.split('.')
                if len(parts) > 2: num_str = parts[0] + '.' + ''.join(parts[1:])
                return float(num_str) * multiplier
            except ValueError:
                pass
        return -999999999

    def _import_gmail(self):
        cats = self.gm.get_categories()
        dlg = ImportGmailDialog(self, categories=cats)
        if dlg.exec():
            category, parsed = dlg.get_parsed_data()
            if not parsed:
                return

            # ── Auto-dedup: collect existing emails ──
            existing_emails = set()
            for r in self.gm.get_all():
                g = r.get("gmail", "").strip().lower()
                if g:
                    existing_emails.add(g)

            count = 0
            skipped = 0
            seen_in_batch = set()
            for rec in parsed:
                gmail_addr = rec.get("gmail", "").strip().lower()
                if not gmail_addr:
                    skipped += 1
                    continue
                # Skip if already in DB or already seen in this batch
                if gmail_addr in existing_emails or gmail_addr in seen_in_batch:
                    skipped += 1
                    continue
                seen_in_batch.add(gmail_addr)

                cat = rec.pop("category", category)
                self.gm.add_gmail(
                    gmail=rec.get("gmail", ""),
                    password=rec.get("password", ""),
                    category=cat,
                    **{k: v for k, v in rec.items() if k not in ["gmail", "password", "category"]}
                )
                count += 1

            # Switch view to the imported category so data shows immediately
            self._current_category = category
            self.combo_cat.blockSignals(True)
            self._refresh_cats()
            idx = self.combo_cat.findText(category)
            if idx >= 0:
                self.combo_cat.setCurrentIndex(idx)
            self.combo_cat.blockSignals(False)
            self.load_data()
            msg = f"Đã nhập thành công {count} Gmail vào '{category}'."
            if skipped:
                msg += f"\nĐã bỏ qua {skipped} Gmail trùng lặp."
            QMessageBox.information(self, "Import", msg)

    def _check_imap(self):
        recs = self._get_checked_records()
        if not recs:
            QMessageBox.information(self, "Check IMAP", "Vui lòng chọn Gmail cần kiểm tra.")
            return

        thread = GmailImapThread(recs)
        thread.status_update.connect(self._update_row_status)
        thread.finished_all.connect(lambda: QMessageBox.information(self, "IMAP", "Kiểm tra IMAP hoàn tất!"))
        thread.start()
        self.login_threads.append(thread)

    def _login_browser(self, headless=False, recovery_domain="", recovery_suffix=""):
        recs = self._get_checked_records()
        if not recs:
            QMessageBox.information(self, "Login", "Vui lòng chọn Gmail cần login.")
            return

        num_threads = self.spin_threads.value()
        # Split accounts into chunks for parallel execution
        chunks = [[] for _ in range(min(num_threads, len(recs)))]
        for i, rec in enumerate(recs):
            chunks[i % len(chunks)].append(rec)

        self._login_done_count = 0
        self._login_total_threads = len(chunks)

        def _on_thread_done():
            self._login_done_count += 1
            if self._login_done_count >= self._login_total_threads:
                self.load_data()
                QMessageBox.information(self, "Login", "Login hoàn tất!")

        # Reset browser grid position counter for this batch
        from core.browser_manager import reset_browser_positions
        reset_browser_positions()

        for chunk in chunks:
            if not chunk:
                continue
            thread = GmailBrowserLoginThread(
                chunk, headless=headless,
                recovery_domain=recovery_domain, recovery_suffix=recovery_suffix
            )
            thread.status_update.connect(self._update_row_status)
            thread.recovery_added.connect(self._on_recovery_added)

            thread.live_status.connect(self._on_live_status)
            thread.finished_all.connect(_on_thread_done)
            thread.start()
            self.login_threads.append(thread)

    def _login_add_recovery(self):
        """Login Gmail and auto-add recovery email using selected domain."""
        recs = self._get_checked_records()
        if not recs:
            QMessageBox.information(self, "Login", "Vui lòng chọn Gmail cần login.")
            return

        from ui.email_login_worker import RecoveryDomainDialog
        dlg = RecoveryDomainDialog(self)
        if dlg.exec():
            provider, domain, suffix = dlg.get_result()
            if not domain:
                QMessageBox.warning(self, "Lỗi", "Chưa chọn domain recovery!")
                return

            # Show preview
            sample = recs[0].get("gmail", "user@gmail.com")
            sample_user = sample.split("@")[0] if "@" in sample else sample
            recovery_preview = f"{sample_user}{suffix}@{domain}"
            reply = QMessageBox.question(
                self, "Xác nhận",
                f"Recovery email sẽ có dạng:\n{recovery_preview}\n\n"
                f"Chạy Login + Add Recovery cho {len(recs)} Gmail?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

            self._login_browser(
                headless=False,
                recovery_domain=domain,
                recovery_suffix=suffix
            )

    def _on_recovery_added(self, gmail_id, recovery_email):
        """Update the recovery_email column when auto-fill succeeds."""
        self.gm.update(gmail_id, {"recovery_email": recovery_email})
        # Refresh table row
        records = self.gm.get_all(category=self._current_category)
        recovery_col = None
        for ci, (k, _) in enumerate(GMAIL_COLUMNS):
            if k == "recovery_email":
                recovery_col = ci
                break
        if recovery_col is not None:
            for row_idx, rec in enumerate(records):
                if rec.get("id") == gmail_id and row_idx < self.table.rowCount():
                    item = self.table.item(row_idx, recovery_col)
                    if item:
                        item.setText(recovery_email)
                    break

    def _setup_2fa_selected(self):
        """Enable 2FA (Authenticator App) for selected Gmail accounts."""
        recs = self._get_checked_records()
        if not recs:
            QMessageBox.information(self, "2FA", "Vui lòng chọn Gmail cần bật 2FA.")
            return

        # Filter out accounts that already have 2FA
        recs_need = [r for r in recs if not r.get("2fa_secret", "").strip()]
        if not recs_need:
            QMessageBox.information(self, "2FA", "Tất cả Gmail đã có 2FA Secret.")
            return

        reply = QMessageBox.question(
            self, "Bật 2FA",
            f"Bật xác thực 2FA cho {len(recs_need)} Gmail?\n"
            f"(Bỏ qua {len(recs) - len(recs_need)} Gmail đã có 2FA)",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        num_threads = self.spin_threads.value()
        chunks = [[] for _ in range(min(num_threads, len(recs_need)))]
        for i, rec in enumerate(recs_need):
            chunks[i % len(chunks)].append(rec)

        self._login_done_count = 0
        self._login_total_threads = len(chunks)

        def _on_2fa_done():
            self._login_done_count += 1
            if self._login_done_count >= self._login_total_threads:
                self.load_data()
                QMessageBox.information(self, "2FA", "Bật 2FA hoàn tất!")

        from core.browser_manager import reset_browser_positions
        reset_browser_positions()

        for chunk in chunks:
            if not chunk:
                continue
            thread = GmailSetup2FAThread(chunk)
            thread.status_update.connect(self._update_row_status)
            thread.live_status.connect(self._on_live_status)
            thread.finished_all.connect(_on_2fa_done)
            thread.start()
            self.login_threads.append(thread)


    def _check_session_selected(self):
        """Check if stored sessions are still valid for selected Gmail accounts."""
        recs = self._get_checked_records()
        if not recs:
            QMessageBox.information(self, "Session", "Vui lòng chọn Gmail cần kiểm tra session.")
            return

        self.lbl_total.setText(f"🔍 Kiểm tra session {len(recs)} Gmail...")

        num_threads = min(self.spin_threads.value(), len(recs))
        chunks = [[] for _ in range(num_threads)]
        for i, rec in enumerate(recs):
            chunks[i % num_threads].append(rec)

        self._login_done_count = 0
        self._login_total_threads = num_threads

        def _on_check_done():
            self._login_done_count += 1
            if self._login_done_count >= self._login_total_threads:
                self.load_data()
                self.lbl_total.setText("✅ Kiểm tra session hoàn tất")

        for chunk in chunks:
            if not chunk:
                continue
            thread = GmailCheckSessionThread(chunk)
            thread.status_update.connect(self._update_row_status)
            thread.live_status.connect(self._on_live_status)
            thread.session_status.connect(self._on_session_status)
            thread.finished_all.connect(_on_check_done)
            thread.start()
            self.login_threads.append(thread)

    def _on_session_status(self, gid, status):
        """Update the session column when check session completes."""
        # Find the 'session' column index
        session_col = -1
        for c in range(self.table.columnCount()):
            h = self.table.horizontalHeaderItem(c)
            if h and h.data(Qt.ItemDataRole.UserRole) == "session":
                session_col = c
                break

        if session_col < 0:
            return

        for row_idx in range(self.table.rowCount()):
            id_col = 0  # chk column stores gid
            item_chk = self.table.item(row_idx, id_col)
            if item_chk and item_chk.data(Qt.ItemDataRole.UserRole) == gid:
                from PyQt6.QtWidgets import QTableWidgetItem
                sess_item = self.table.item(row_idx, session_col)
                if not sess_item:
                    sess_item = QTableWidgetItem(status)
                    self.table.setItem(row_idx, session_col, sess_item)
                else:
                    sess_item.setText(status)
                break

    def _verify_recovery_selected(self):
        """Verify recovery email for selected Gmail accounts."""
        recs = self._get_checked_records()
        if not recs:
            QMessageBox.information(self, "Recovery", "Vui lòng chọn Gmail cần xác minh recovery.")
            return

        # Filter only those with recovery email
        recs_with_recovery = [r for r in recs if r.get("recovery_email", "").strip()]
        if not recs_with_recovery:
            QMessageBox.information(self, "Recovery", "Không có Gmail nào có Recovery Email.")
            return

        reply = QMessageBox.question(
            self, "Xác minh Recovery",
            f"Xác minh recovery email cho {len(recs_with_recovery)} Gmail?\n"
            f"(Bỏ qua {len(recs) - len(recs_with_recovery)} Gmail chưa có recovery)",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        self.lbl_total.setText(f"📧 Xác minh recovery {len(recs_with_recovery)} Gmail...")

        num_threads = min(self.spin_threads.value(), len(recs_with_recovery))
        chunks = [[] for _ in range(num_threads)]
        for i, rec in enumerate(recs_with_recovery):
            chunks[i % num_threads].append(rec)

        self._login_done_count = 0
        self._login_total_threads = num_threads

        def _on_recovery_done():
            self._login_done_count += 1
            if self._login_done_count >= self._login_total_threads:
                self.load_data()
                self.lbl_total.setText("✅ Xác minh recovery hoàn tất")

        from core.browser_manager import reset_browser_positions
        reset_browser_positions()

        for chunk in chunks:
            if not chunk:
                continue
            thread = GmailVerifyRecoveryThread(chunk)
            thread.status_update.connect(self._update_row_status)
            thread.live_status.connect(self._on_live_status)
            thread.finished_all.connect(_on_recovery_done)
            thread.start()
            self.login_threads.append(thread)

    def _open_profile(self):
        """Open Chrome with stored login profile for selected Gmail (like Open Profile)."""
        recs = self._get_checked_records()
        if not recs:
            QMessageBox.information(self, "Open Profile", "Vui lòng chọn Gmail cần mở Profile.")
            return
        import subprocess as sp_sub
        import os
        import time
        from core.browser_manager import (SmartBrowserDetector, next_browser_window_params,
                                          reset_browser_positions, force_chrome_window_placement,
                                          reposition_browser_window)

        chrome_exe = SmartBrowserDetector.find_browser("Google Chrome")
        if not chrome_exe:
            chrome_exe = SmartBrowserDetector.find_browser("Microsoft Edge")
        if not chrome_exe:
            QMessageBox.warning(self, "Open Profile", "Không tìm thấy Chrome hoặc Edge!")
            return

        reset_browser_positions()

        for rec in recs:
            gid = rec.get("id", "")
            user_data = rec.get("data_dir", "")
            if not user_data:
                user_data = gmail_profile_dir(gid)
            if not os.path.isdir(user_data) or len(os.listdir(user_data)) == 0:
                self._update_row_status(gid, "⚠️ Chưa login — cần Login Browser trước")
                continue

            wp = next_browser_window_params()
            chrome_args = wp["chrome_args"]

            # Force window placement via Preferences file (Chrome ignores --window-size for saved profiles)
            force_chrome_window_placement(user_data, chrome_args)

            try:
                proc = sp_sub.Popen([
                    chrome_exe,
                    f"--user-data-dir={user_data}",
                    "--no-first-run",
                    "--no-default-browser-check",
                ] + chrome_args + [
                    "https://mail.google.com/mail/u/0/#inbox",
                ], stdout=sp_sub.DEVNULL, stderr=sp_sub.DEVNULL)

                # Force window position via Windows API after Chrome starts
                time.sleep(2)
                reposition_browser_window(proc.pid, chrome_args)

                self._update_row_status(gid, "✅ Đã mở Chrome")
            except Exception as e:
                self._update_row_status(gid, f"❌ Lỗi: {str(e)[:50]}")

    def _read_mail(self):
        """Open mail reader dialog for the first checked Gmail."""
        recs = self._get_checked_records()
        if not recs:
            QMessageBox.information(self, "Đọc thư", "Vui lòng chọn Gmail cần đọc thư.")
            return
        rec = recs[0]  # Read first selected
        dlg = GmailReadMailDialog(
            parent=self,
            gmail_addr=rec.get("gmail", ""),
            password=rec.get("password", ""),
            app_password=rec.get("app_password", ""),
            gmail_id=rec.get("id", ""),
            gm=self.gm,
            data_dir=rec.get("data_dir", ""),
        )
        dlg.exec()

    def _stop_all(self):
        """Stop all running threads and kill associated browser processes."""
        import subprocess as _sp
        stopped_count = 0
        for t in self.login_threads:
            try:
                t.stop()
                stopped_count += 1
            except:
                pass
            # Force terminate if still running
            if t.isRunning():
                try:
                    t.terminate()
                    t.wait(2000)
                except:
                    pass
        self.login_threads.clear()

        # Kill any Chrome processes spawned by this tool (debugging ports)
        try:
            result = _sp.run(
                ['taskkill', '/F', '/FI', 'IMAGENAME eq chrome.exe', '/FI', 'WINDOWTITLE eq *'],
                capture_output=True, timeout=5
            )
        except:
            pass

        # Update status
        self.lbl_total.setText(f"🛑 Đã dừng {stopped_count} luồng")
        QMessageBox.information(self, "Stop", f"Đã dừng {stopped_count} luồng và tất cả trình duyệt.")

    def _delete_selected(self):
        ids = self._get_checked_ids()
        if not ids:
            QMessageBox.information(self, "Xóa", "Chọn Gmail cần xóa.")
            return
        reply = QMessageBox.question(self, "Xóa", f"Xóa {len(ids)} Gmail?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.gm.delete_many(ids)
            self.load_data()

    def _find_gmail(self):
        """Open filter dialog directly (like Profile Manager's Find UID)."""
        # Get categories from all records
        all_records = self.gm.get_all()
        cats = sorted(set(r.get("category", "Default") for r in all_records))
        if not cats:
            cats = ["Default"]

        FILTER_MODES = [
            "Lọc theo Gmail",
            "Lọc theo Password",
            "Lọc theo Recovery Email",
            "Lọc theo Ghi chú",
            "Lọc nhiều danh mục",
            "Lọc theo 2FA Secret",
            "Lọc theo domain Gmail",
            "Lọc theo domain Recovery",
            "Lọc theo Proxy",
            "Lọc theo Live",
            "Lọc theo Session",
        ]

        dlg = QDialog(self)
        dlg.setWindowTitle("Lọc Gmail --- Điền từ khóa để lọc (có thể nhập nhiều dòng)")
        dlg.resize(650, 560)
        dlg.setMinimumSize(500, 400)
        dlg.setStyleSheet("""
            QDialog { background: #1a202c; color: #f7fafc; border: 1px solid #4a5568; border-radius: 10px; }
            QTextEdit { background: #2d3748; border: 1px solid #4a5568; border-radius: 6px; color: #f7fafc; padding: 8px; font-size: 12px; }
            QTextEdit:focus { border-color: #a78bfa; }
            QTableWidget { background: #1e2533; gridline-color: #334155; border: 1px solid #4a5568; border-radius: 6px; color: #f7fafc; }
            QTableWidget::item { padding: 4px; border-bottom: 1px solid #334155; }
            QHeaderView::section { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #2d3748, stop:1 #252f3f); color: #c4b5fd; padding: 5px; border: none; border-bottom: 2px solid #7c3aed; font-weight: 700; }
            QComboBox { background: #2d3748; border: 1px solid #4a5568; border-radius: 6px; color: #f7fafc; padding: 6px 10px; font-size: 12px; }
            QComboBox:focus { border-color: #a78bfa; }
            QComboBox::drop-down { border-left: 1px solid #4a5568; width: 22px; background: #3a4a5c; }
            QComboBox QAbstractItemView { background: #2d3748; border: 1px solid #4a5568; selection-background-color: #8b5cf6; color: #f7fafc; }
            QCheckBox { color: #f7fafc; }
            QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #718096; border-radius: 3px; background: #2d3748; }
            QCheckBox::indicator:checked { background: #8b5cf6; border-color: #a78bfa; }
        """)
        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(10)

        lbl_input = QLabel("Nhập nội dung tìm kiếm hoặc Gmail")
        lbl_input.setStyleSheet("color: #93c5fd; font-weight: 700; font-size: 12px;")
        layout.addWidget(lbl_input)

        text_input = QTextEdit()
        text_input.setPlaceholderText("Nhập gmail, từ khóa... mỗi dòng một giá trị")
        text_input.setMinimumHeight(120)
        layout.addWidget(text_input)

        # Category table
        lbl_cat = QLabel("Chọn danh mục")
        lbl_cat.setStyleSheet("color: #93c5fd; font-weight: 700; font-size: 12px;")
        layout.addWidget(lbl_cat)

        cat_table = QTableWidget()
        cat_table.setColumnCount(3)
        cat_table.setHorizontalHeaderLabels(["", "ID", "Category"])
        cat_table.verticalHeader().setVisible(False)
        cat_table.setMinimumHeight(120)
        header = cat_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        cat_table.setColumnWidth(0, 34)
        cat_table.setColumnWidth(1, 50)
        cat_table.setRowCount(len(cats))
        cat_checkboxes = []
        for i, cat in enumerate(cats):
            chk = QCheckBox()
            chk.setChecked(True)
            cat_checkboxes.append(chk)
            chk_w = QWidget()
            chk_l = QHBoxLayout(chk_w)
            chk_l.addWidget(chk)
            chk_l.setAlignment(Qt.AlignmentFlag.AlignCenter)
            chk_l.setContentsMargins(0, 0, 0, 0)
            cat_table.setCellWidget(i, 0, chk_w)
            id_item = QTableWidgetItem(str(i + 1))
            id_item.setFlags(id_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            id_item.setForeground(QColor("#a78bfa"))
            cat_table.setItem(i, 1, id_item)
            cat_item = QTableWidgetItem(cat)
            cat_item.setFlags(cat_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            cat_item.setForeground(QColor("#f7fafc"))
            cat_table.setItem(i, 2, cat_item)
        layout.addWidget(cat_table)

        # Filter mode combo
        combo_mode = QComboBox()
        combo_mode.addItems(FILTER_MODES)
        combo_mode.setMinimumHeight(30)
        layout.addWidget(combo_mode)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_show_all = QPushButton("Hiện tất cả")
        btn_show_all.setMinimumWidth(110)
        btn_show_all.setFixedHeight(34)
        btn_show_all.setStyleSheet("""
            QPushButton { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #4a5568, stop:1 #3a4a5c);
                border: 1px solid #718096; border-radius: 6px; color: #f7fafc; font-weight: 700; padding: 0 16px; }
            QPushButton:hover { background: #718096; }
        """)
        btn_ok = QPushButton("OK — Lọc")
        btn_ok.setMinimumWidth(130)
        btn_ok.setFixedHeight(34)
        btn_ok.setStyleSheet("""
            QPushButton { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #2563eb, stop:1 #1d4ed8);
                border: 1px solid #3b82f6; border-radius: 6px; color: #ffffff; font-weight: 700; font-size: 13px; padding: 0 20px; }
            QPushButton:hover { background: #3b82f6; }
        """)
        btn_show_all.clicked.connect(lambda: (self.load_data(), dlg.reject()))
        btn_ok.clicked.connect(dlg.accept)
        btn_layout.addWidget(btn_show_all)
        btn_layout.addSpacing(10)
        btn_layout.addWidget(btn_ok)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        query_text = text_input.toPlainText().strip()
        query_lines = [l.strip() for l in query_text.split('\n') if l.strip()] if query_text else []
        filter_mode = combo_mode.currentText()
        selected_cats = [cats[i] for i, chk in enumerate(cat_checkboxes) if chk.isChecked() and i < len(cats)]

        if not query_lines and not selected_cats:
            return

        # Map filter mode to column key
        mode_key_map = {
            "Lọc theo Gmail": "gmail",
            "Lọc theo Password": "password",
            "Lọc theo Recovery Email": "recovery_email",
            "Lọc theo Ghi chú": "note",
            "Lọc nhiều danh mục": "_category",
            "Lọc theo 2FA Secret": "2fa_secret",
            "Lọc theo domain Gmail": "gmail",
            "Lọc theo domain Recovery": "recovery_email",
            "Lọc theo Proxy": "proxy",
            "Lọc theo Live": "live",
            "Lọc theo Session": "session",
        }
        data_key = mode_key_map.get(filter_mode, "gmail")
        is_domain = "domain" in filter_mode
        is_category = filter_mode == "Lọc nhiều danh mục"

        target_col = -1
        for col_idx, (key, _) in enumerate(GMAIL_COLUMNS):
            if key == data_key:
                target_col = col_idx
                break

        gmail_records = self.gm.get_all(category=self._current_category)
        for row in range(self.table.rowCount()):
            show = False
            if is_category:
                if row < len(gmail_records):
                    p_cat = gmail_records[row].get("category", "Default")
                    if not selected_cats or p_cat in selected_cats:
                        show = True
            elif target_col >= 0 and query_lines:
                item = self.table.item(row, target_col)
                if item:
                    value = item.text().strip().lower()
                    if is_domain and "@" in value:
                        value = value.split("@")[1]
                    for q in query_lines:
                        if q.strip().lower() in value:
                            show = True
                            break
            elif not query_lines and selected_cats:
                if row < len(gmail_records):
                    p_cat = gmail_records[row].get("category", "Default")
                    if p_cat in selected_cats:
                        show = True
            else:
                show = True
            self.table.setRowHidden(row, not show)

        # Count visible
        visible = sum(1 for r in range(self.table.rowCount()) if not self.table.isRowHidden(r))
        self.lbl_total.setText(f"Tổng số Gmail: {visible} (lọc từ {self.table.rowCount()})")

    def _export_gmail(self):
        """Export selected (or all) Gmail accounts with custom format dialog."""
        # Get records: checked only, or all in category
        recs = self._get_checked_records()
        source = "đã chọn"
        if not recs:
            recs = self.gm.get_all(category=self._current_category)
            source = f"'{self._current_category}'"
        if not recs:
            QMessageBox.information(self, "Export", "Không có Gmail nào để export.")
            return

        # ── Export format dialog ──
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Export Gmail — {len(recs)} tài khoản {source}")
        dlg.resize(500, 200)
        dlg.setStyleSheet("""
            QDialog { background-color: #1e293b; color: #e2e8f0; }
            QLabel { color: #e2e8f0; font-size: 13px; }
            QComboBox { border: 1px solid #475569; border-radius: 3px; padding: 3px 6px;
                        background: #334155; color: #e2e8f0; font-size: 12px; }
            QComboBox::drop-down { border-left: 1px solid #475569; width: 18px; background: #475569; }
            QComboBox QAbstractItemView { background: #334155; color: #e2e8f0; border: 1px solid #475569;
                                          selection-background-color: #3b82f6; }
            QPushButton { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #4bbdf5, stop:1 #1a8dfb);
                          color: white; font-weight: bold; border-radius: 4px; min-width: 120px;
                          min-height: 32px; font-size: 13px; }
            QPushButton:hover { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #38bdf8, stop:1 #0ea5e9); }
        """)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(20, 12, 20, 12)
        lay.setSpacing(10)

        lay.addWidget(QLabel(f"📋 Xuất {len(recs)} Gmail {source} vào Clipboard"))

        # Format presets
        fmt_row = QHBoxLayout()
        fmt_row.addWidget(QLabel("Định dạng xuất:"))
        combo = QComboBox()
        FORMATS = [
            ("Gmail|Password", ["gmail", "password"]),
            ("Gmail|Password|Recovery Email", ["gmail", "password", "recovery_email"]),
            ("Gmail|Password|Recovery Email|2FA", ["gmail", "password", "recovery_email", "2fa_secret"]),
            ("Gmail|Password|App Password|Recovery Email", ["gmail", "password", "app_password", "recovery_email"]),
            ("Gmail|Password|App Password|Recovery Email|Recovery Phone|2FA", ["gmail", "password", "app_password", "recovery_email", "recovery_phone", "2fa_secret"]),
            ("Gmail|Password|App Password|Recovery Email|Recovery Phone|2FA|Proxy|Note", ["gmail", "password", "app_password", "recovery_email", "recovery_phone", "2fa_secret", "proxy", "note"]),
        ]
        for label, keys in FORMATS:
            combo.addItem(label, keys)
        fmt_row.addWidget(combo, 1)
        lay.addLayout(fmt_row)

        # Preview
        preview_lbl = QLabel("")
        preview_lbl.setStyleSheet("color: #94a3b8; font-size: 11px;")
        preview_lbl.setWordWrap(True)
        lay.addWidget(preview_lbl)

        def update_preview():
            keys = combo.currentData()
            if keys and recs:
                sample = "|".join(str(recs[0].get(k, "")) for k in keys)
                preview_lbl.setText(f"Ví dụ: {sample[:120]}")
        combo.currentIndexChanged.connect(lambda: update_preview())
        update_preview()

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_copy = QPushButton("📋 Copy vào Clipboard")
        btn_copy.clicked.connect(dlg.accept)
        btn_row.addWidget(btn_copy)
        lay.addLayout(btn_row)

        if dlg.exec():
            keys = combo.currentData()
            lines = []
            for r in recs:
                line = "|".join(str(r.get(k, "")) for k in keys)
                lines.append(line)
            QApplication.clipboard().setText("\n".join(lines))
            QMessageBox.information(self, "Export",
                                    f"Đã copy {len(lines)} Gmail vào Clipboard.\n"
                                    f"Format: {combo.currentText()}")

    def _add_category(self):
        text, ok = QInputDialog.getText(self, "Thêm Thư mục", "Tên thư mục:")
        if ok and text and text.strip():
            name = text.strip()
            self.gm.add_category(name)
            self._current_category = name
            self._refresh_cats()
            idx = self.combo_cat.findText(name)
            if idx >= 0:
                self.combo_cat.setCurrentIndex(idx)
            else:
                self.combo_cat.addItem(name)
                self.combo_cat.setCurrentText(name)

    def _edit_category(self):
        current = self.combo_cat.currentText()
        if current == "Tất cả":
            QMessageBox.warning(self, "Edit", "Không thể sửa thư mục mặc định!")
            return
        new_name, ok = QInputDialog.getText(self, "Sửa Thư mục", "Tên mới:", text=current)
        if ok and new_name and new_name.strip() != current:
            self.gm.rename_category(current, new_name.strip())
            self.load_data()

    def _delete_category(self):
        current = self.combo_cat.currentText()
        if current == "Tất cả":
            QMessageBox.warning(self, "Delete", "Không thể xóa thư mục mặc định!")
            return
        reply = QMessageBox.question(self, "Xóa Thư mục",
                                     f"Xóa thư mục '{current}' và chuyển Gmail về 'Mới'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.gm.delete_category_name(current, "Mới")
            self.combo_cat.setCurrentText("Tất cả")
            self.load_data()

    def _move_to_category(self):
        ids = self._get_checked_ids()
        if not ids:
            QMessageBox.information(self, "Move", "Vui lòng chọn Gmail cần di chuyển.")
            return
        cats = self.gm.get_categories()
        cat, ok = QInputDialog.getItem(self, "Move", "Chọn thư mục đích:", cats, 0, False)
        if ok and cat:
            self.gm.move(ids, cat)
            self.load_data()

    def _update_row_status(self, gmail_id, status_msg):
        # Update in data
        self.gm.update(gmail_id, {"status": status_msg})
        # Find the correct table row by scanning UserRole IDs
        for row_idx in range(self.table.rowCount()):
            chk = self.table.item(row_idx, 0)
            if not chk or chk.data(Qt.ItemDataRole.UserRole) != gmail_id:
                continue
            # Found matching row — read live value from live column
            live_val = ""
            for ci, (k, _) in enumerate(GMAIL_COLUMNS):
                if k == "live":
                    li = self.table.item(row_idx, ci)
                    if li:
                        live_val = li.text().lower()
                    break
            row_bg = QColor("#e0f2fe") if (row_idx % 2 == 0) else QColor("#ffffff")
            row_fg = QColor("#0f172a")
            if any(x in live_val for x in ["dead", "die", "disabled", "locked", "banned", "khóa", "cp282", "cp956", "checkpoint", "xác minh"]):
                row_bg = QColor("#ff6b6b")
            elif "out" in live_val:
                row_bg = QColor("#ffec8b")
            elif "live" in live_val:
                row_bg = QColor("#81c784")
            # Update status cell
            for ci, (k, _) in enumerate(GMAIL_COLUMNS):
                if k == "status":
                    item = self.table.item(row_idx, ci)
                    if item:
                        item.setText(status_msg)
                    break
            # Repaint ALL cells in the row
            for c in range(self.table.columnCount()):
                it = self.table.item(row_idx, c)
                if it:
                    it.setBackground(row_bg)
                    it.setForeground(row_fg)
            break



    def _on_live_status(self, gmail_id, status):
        """Handle live status from browser login — update 'live' column with Live/Out."""
        self.gm.update(gmail_id, {"live": status})
        # Find the correct table row by scanning UserRole IDs
        for row_idx in range(self.table.rowCount()):
            chk = self.table.item(row_idx, 0)
            if not chk or chk.data(Qt.ItemDataRole.UserRole) != gmail_id:
                continue
            live_val = status.lower()
            row_bg = QColor("#e0f2fe") if (row_idx % 2 == 0) else QColor("#ffffff")
            row_fg = QColor("#0f172a")
            if any(x in live_val for x in ["dead", "die", "disabled", "locked", "banned", "khóa", "cp282", "cp956", "checkpoint", "xác minh"]):
                row_bg = QColor("#ff6b6b")
            elif "out" in live_val:
                row_bg = QColor("#ffec8b")
            elif "live" in live_val:
                row_bg = QColor("#81c784")
            # Update live column
            for ci, (k, _) in enumerate(GMAIL_COLUMNS):
                if k == "live":
                    item = self.table.item(row_idx, ci)
                    if item:
                        item.setText(status)
                    break
            # Repaint ALL cells
            for c in range(self.table.columnCount()):
                it = self.table.item(row_idx, c)
                if it:
                    it.setBackground(row_bg)
                    it.setForeground(row_fg)
            break

    def _context_menu(self, pos):
        row = self.table.rowAt(pos.y())
        rec = None
        if row >= 0:
            rec = self._get_record_at_row(row)

        menu = QMenu()
        menu.setStyleSheet("""
            QMenu { background-color: #1e293b; border: 2px solid #3b82f6; border-radius: 4px; padding: 4px; }
            QMenu::item { padding: 6px 20px; font-size: 13px; color: #e2e8f0; }
            QMenu::item:selected { background-color: #334155; color: #a78bfa; }
            QMenu::separator { height: 1px; background: #475569; margin: 4px 0px; }
        """)

        # Copy actions (multi-row)
        menu_copy = menu.addMenu("📋 Copy")
        copy_gmail = menu_copy.addAction("Gmail")
        copy_gp = menu_copy.addAction("Gmail|Password")
        copy_gpa = menu_copy.addAction("Gmail|Password|App Password")
        copy_gpar = menu_copy.addAction("Gmail|Password|App Password|Recovery")
        copy_gparr = menu_copy.addAction("Gmail|Password|Recovery|Recovery Phone")
        copy_json = menu_copy.addAction("JSON (toàn bộ thông tin)")

        menu.addSeparator()
        action_login = menu.addAction("🌐 Login Browser (selected)")
        action_login_recovery = menu.addAction("🔐 Login + Add Recovery (selected)")
        action_headless = menu.addAction("👻 Login Ẩn (selected)")
        action_open_profile = menu.addAction("📂 Open Profile (selected)")

        menu.addSeparator()
        action_sync_fb = menu.addAction("🔄 Đồng bộ vào quản lý Profile Facebook")
        action_close_all = menu.addAction("🛑 Đóng tất cả Browser")

        menu.addSeparator()
        action_check_session = menu.addAction("🔍 Kiểm tra Session")

        menu.addSeparator()
        # Xuất/Nhập dữ liệu
        data_menu = menu.addMenu("📥 Xuất/Nhập dữ liệu")
        action_import = data_menu.addAction("📥 Import Gmail")
        action_export = data_menu.addAction("📤 Export Gmail")

        # Quản lý thư mục
        cat_menu = menu.addMenu("📁 Quản lý Thư mục")
        action_add_cat = cat_menu.addAction("➕ Thêm thư mục")
        action_edit_cat = cat_menu.addAction("✏️ Sửa thư mục")
        action_del_cat = cat_menu.addAction("❌ Xóa thư mục")
        action_move_cat = cat_menu.addAction("📦 Move vào thư mục")

        menu.addSeparator()
        action_delete = menu.addAction("🗑️ Xóa (selected)")
        menu.addSeparator()
        action_refresh = menu.addAction("🔄 Làm mới")

        action = menu.exec(self.table.viewport().mapToGlobal(pos))
        if not action:
            return

        # Handle actions that don't need selection
        if action == action_import:
            self._import_gmail()
            return
        if action == action_refresh:
            self.load_data()
            return
        if action == action_export:
            self._export_gmail()
            return
        if action == action_add_cat:
            self._add_category()
            return
        if action == action_edit_cat:
            self._edit_category()
            return
        if action == action_del_cat:
            self._delete_category()
            return
        if action == action_move_cat:
            self._move_to_category()
            return
        if action == action_close_all:
            self._close_all_browsers()
            return

        # Get target records (checked or right-clicked)
        ids = self._get_checked_ids()
        recs = self._get_checked_records()
        if rec and rec.get("id") not in ids:
            ids = [rec["id"]]
            recs = [rec]
        if not recs:
            recs = []

        # Copy actions — multi-row
        import json as _json
        if action in [copy_gmail, copy_gp, copy_gpa, copy_gpar, copy_gparr, copy_json]:
            if not recs:
                QMessageBox.information(self, "Copy", "Vui lòng chọn Gmail trước.")
                return
            text_lines = []
            for r in recs:
                if action == copy_gmail:
                    text_lines.append(r.get("gmail", ""))
                elif action == copy_gp:
                    text_lines.append(f'{r.get("gmail","")}|{r.get("password","")}')
                elif action == copy_gpa:
                    text_lines.append(f'{r.get("gmail","")}|{r.get("password","")}|{r.get("app_password","")}')
                elif action == copy_gpar:
                    text_lines.append(f'{r.get("gmail","")}|{r.get("password","")}|{r.get("app_password","")}|{r.get("recovery_email","")}')
                elif action == copy_gparr:
                    text_lines.append(f'{r.get("gmail","")}|{r.get("password","")}|{r.get("recovery_email","")}|{r.get("recovery_phone","")}')
                elif action == copy_json:
                    text_lines.append(_json.dumps(r, ensure_ascii=False))
            QApplication.clipboard().setText("\n".join(text_lines))
            QMessageBox.information(self, "Copy", f"Đã copy {len(text_lines)} dòng vào Clipboard.")
            return

        # Actions needing checked items
        if action == action_login:
            self._login_browser(headless=False)
        elif action == action_login_recovery:
            self._login_add_recovery()
        elif action == action_headless:
            self._login_browser(headless=True)
        elif action == action_open_profile:
            self._open_profile()
        elif action == action_delete:
            self._delete_selected()
        elif action == action_sync_fb:
            self._sync_to_facebook(recs)
        elif action == action_check_session:
            self._check_session_selected()

    def _sync_to_facebook(self, recs):
        """Sync Gmail data into Profile Manager (Facebook profiles)."""
        if not recs:
            QMessageBox.information(self, "Đồng bộ", "Vui lòng chọn Gmail cần đồng bộ.")
            return
        try:
            from core.profile_manager import ProfileManager
            pm = ProfileManager()
            count_updated = 0
            count_created = 0
            for r in recs:
                gmail_addr = r.get("gmail", "")
                if not gmail_addr:
                    continue
                # Find existing profile by email
                existing = None
                for p in pm.get_all_profiles():
                    if p.get("email", "") == gmail_addr:
                        existing = p
                        break
                if existing:
                    pm.update_profile(existing["id"], {
                        "email": gmail_addr,
                        "pass_email": r.get("password", ""),
                        "email_recovery": r.get("recovery_email", ""),
                    })
                    count_updated += 1
                else:
                    pm.add_profile(
                        name=gmail_addr.split("@")[0],
                        email=gmail_addr,
                        pass_email=r.get("password", ""),
                        email_recovery=r.get("recovery_email", ""),
                    )
                    count_created += 1
            msg = f"Đồng bộ thành công!\n• Cập nhật: {count_updated} profile\n• Tạo mới: {count_created} profile"
            QMessageBox.information(self, "Đồng bộ", msg)
        except Exception as e:
            QMessageBox.warning(self, "Lỗi", f"Không thể đồng bộ: {str(e)}")

    def _close_all_browsers(self):
        """Close all Chrome browser instances that were opened by this tool."""
        import subprocess
        try:
            # Kill all Chrome processes that use our profile directories
            import psutil
            data_dir_base = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data"))
            killed = 0
            for proc in psutil.process_iter(['name', 'cmdline']):
                try:
                    name = (proc.info.get('name') or '').lower()
                    if 'chrome' in name or 'msedge' in name:
                        cmdline = ' '.join(proc.info.get('cmdline') or [])
                        if data_dir_base in cmdline or 'gmail_profiles' in cmdline or 'email_profiles' in cmdline:
                            proc.kill()
                            killed += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            QMessageBox.information(self, "Close All", f"Đã đóng {killed} tiến trình browser.")
        except Exception as e:
            QMessageBox.warning(self, "Lỗi", f"Lỗi đóng browser: {str(e)}")

    # ─── Quick Login (from Login tab) ───

    def _quick_imap_check(self):
        gmail = self.inp_gmail.text().strip()
        password = self.inp_app_pass.text().strip() or self.inp_pass.text().strip()
        if not gmail or not password:
            self.lbl_quick_status.setText("Nhập Gmail + Password trước!")
            return

        self.lbl_quick_status.setText("Đang kiểm tra IMAP...")
        self.lbl_quick_status.setStyleSheet("color: #a78bfa; font-size: 12px; border: none;")

        import imaplib
        try:
            mail = imaplib.IMAP4_SSL("imap.gmail.com", 993, timeout=15)
            mail.login(gmail, password)
            mail.logout()
            self.lbl_quick_status.setText("✅ Login IMAP thành công!")
            self.lbl_quick_status.setStyleSheet("color: #4ade80; font-size: 12px; border: none;")
        except Exception as e:
            self.lbl_quick_status.setText(f"❌ {str(e)[:60]}")
            self.lbl_quick_status.setStyleSheet("color: #f87171; font-size: 12px; border: none;")

    def _quick_browser_login(self):
        gmail = self.inp_gmail.text().strip()
        password = self.inp_pass.text().strip()
        if not gmail or not password:
            self.lbl_quick_status.setText("Nhập Gmail + Password trước!")
            return

        self.lbl_quick_status.setText("Đang mở Browser...")
        self.lbl_quick_status.setStyleSheet("color: #a78bfa; font-size: 12px; border: none;")

        rec = {"id": "quick", "gmail": gmail, "password": password}
        thread = GmailBrowserLoginThread([rec], headless=False)
        thread.status_update.connect(lambda _, msg: self.lbl_quick_status.setText(msg))
        thread.start()
        self.login_threads.append(thread)
