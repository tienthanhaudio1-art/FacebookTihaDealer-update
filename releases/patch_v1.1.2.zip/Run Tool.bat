@echo off
title Facebook THE TIHA DEALER
cd /d "%~dp0"

:: Try py launcher first (most reliable on Windows)
py --version >nul 2>&1
if %errorlevel% equ 0 (
    py main.py
    if %errorlevel% neq 0 (
        echo.
        echo [!] Co loi xay ra. Hay chay "Setup.bat" truoc.
        pause
    )
    goto :eof
)

:: Try python
python --version >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PYVER=%%i
    echo %PYVER% | findstr /C:"Python 3" >nul 2>&1
    if %errorlevel% equ 0 (
        python main.py
        if %errorlevel% neq 0 (
            echo.
            echo [!] Co loi xay ra. Hay chay "Setup.bat" truoc.
            pause
        )
        goto :eof
    )
)

echo.
echo [X] Python chua duoc cai dat!
echo     Hay chay "Setup.bat" truoc.
echo.
pause
