@echo off
title Facebook THE TIHA DEALER - Setup
echo.
echo ========================================
echo   Facebook THE TIHA DEALER - Setup
echo ========================================
echo.

:: Check if Python actually works (not just Windows Store alias)
python --version >nul 2>&1
if %errorlevel% equ 0 (
    :: Verify it's real Python, not Store redirect
    for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PYVER=%%i
    echo %PYVER% | findstr /C:"Python 3" >nul 2>&1
    if %errorlevel% equ 0 (
        set PYCMD=python
        goto :found_python
    )
)

py --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYCMD=py
    goto :found_python
)

:: Python not found - download installer
echo [X] Python chua duoc cai dat!
echo.
echo Dang tai Python installer...
echo.

:: Download Python installer using PowerShell
powershell -Command "& { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.5/python-3.12.5-amd64.exe' -OutFile '%TEMP%\python_installer.exe' }"

if exist "%TEMP%\python_installer.exe" (
    echo [OK] Da tai Python installer!
    echo.
    echo Dang cai Python tu dong...
    echo (Vui long cho vai phut)
    echo.
    "%TEMP%\python_installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1
    echo.
    echo [OK] Python da cai xong!
    echo.
    echo ** VUI LONG DONG CUA SO NAY VA CHAY LAI Setup.bat **
    echo.
    del "%TEMP%\python_installer.exe" >nul 2>&1
    pause
    exit /b
) else (
    echo [X] Khong the tai Python tu dong.
    echo.
    echo Vui long tai thu cong tai: https://www.python.org/downloads/
    echo Luu y: Tich chon "Add Python to PATH" khi cai!
    echo.
    start https://www.python.org/downloads/
    pause
    exit /b
)

:found_python
echo [OK] Python da cai: %PYVER%
echo Su dung lenh: %PYCMD%
echo.
echo Dang cai dat thu vien...
echo.

%PYCMD% -m pip install --upgrade pip
%PYCMD% -m pip install PyQt6 requests pyotp playwright opencv-python-headless numpy

echo.
echo Cai dat Playwright browsers...
%PYCMD% -m playwright install chromium

echo.
echo ========================================
echo   [OK] Cai dat hoan tat!
echo.
echo   Double-click "Run Tool.bat" de chay
echo ========================================
echo.
pause
