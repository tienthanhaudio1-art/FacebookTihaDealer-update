"""
Phone Settings — Persistent configuration for phone rental services.

Settings are stored in data/phone_settings.json, shared across all tabs.
"""

import json
import os
from typing import Dict, Optional

SETTINGS_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "phone_settings.json")

DEFAULT_SETTINGS = {
    "selected_site": "smspool.net",
    "country": "vn",
    "api_keys": {},           # {site_name: api_key}
    "wait_timeout": 120,      # seconds to wait for OTP code
    "max_retries": 3,         # max phone numbers to try if Gmail rejects
    "poll_interval": 5,       # seconds between SMS polls
    "auto_verify_phone": True,  # auto-start phone verification when needed
}


class PhoneSettings:
    """Singleton-like settings manager for phone rental configuration."""

    _instance: Optional["PhoneSettings"] = None

    def __init__(self):
        self._settings = dict(DEFAULT_SETTINGS)
        self._load()

    @classmethod
    def instance(cls) -> "PhoneSettings":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _load(self):
        try:
            if os.path.exists(SETTINGS_FILE):
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                    self._settings.update(saved)
        except Exception:
            pass

    def save(self):
        try:
            os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(self._settings, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    @property
    def selected_site(self) -> str:
        return self._settings.get("selected_site", "smspool.net")

    @selected_site.setter
    def selected_site(self, value: str):
        self._settings["selected_site"] = value
        self.save()

    @property
    def country(self) -> str:
        return self._settings.get("country", "vn")

    @country.setter
    def country(self, value: str):
        self._settings["country"] = value
        self.save()

    @property
    def api_keys(self) -> Dict[str, str]:
        return self._settings.get("api_keys", {})

    def set_api_key(self, site: str, key: str):
        self._settings.setdefault("api_keys", {})[site] = key
        self.save()

    def get_api_key(self, site: str = None) -> str:
        if site is None:
            site = self.selected_site
        return self._settings.get("api_keys", {}).get(site, "")

    @property
    def wait_timeout(self) -> int:
        return self._settings.get("wait_timeout", 120)

    @wait_timeout.setter
    def wait_timeout(self, value: int):
        self._settings["wait_timeout"] = max(30, min(300, value))
        self.save()

    @property
    def max_retries(self) -> int:
        return self._settings.get("max_retries", 3)

    @max_retries.setter
    def max_retries(self, value: int):
        self._settings["max_retries"] = max(1, min(10, value))
        self.save()

    @property
    def poll_interval(self) -> int:
        return self._settings.get("poll_interval", 5)

    @property
    def auto_verify_phone(self) -> bool:
        return self._settings.get("auto_verify_phone", True)

    @auto_verify_phone.setter
    def auto_verify_phone(self, value: bool):
        self._settings["auto_verify_phone"] = value
        self.save()

    def get_current_service(self):
        """Get a PhoneService instance for the currently selected site."""
        from core.phone_service import get_service
        return get_service(self.selected_site, self.get_api_key())
