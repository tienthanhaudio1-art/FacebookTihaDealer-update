"""
Gmail Data Manager — JSON storage for Gmail accounts.
"""
import json
import os
import uuid

GMAIL_DATA_FILE = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "gmails.json"))
GMAIL_PROFILES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "gmail_profiles"))

class GmailManager:
    """
    Centralized Gmail account manager using flat JSON storage.
    Fields: id, gmail, password, recovery_email, recovery_phone,
            app_password, 2fa_secret, proxy, category, note, status, live
    """

    def __init__(self):
        self._ensure_data_file()
        self._migrate_add_data_dir()

    def _ensure_data_file(self):
        os.makedirs(os.path.dirname(GMAIL_DATA_FILE), exist_ok=True)
        os.makedirs(GMAIL_PROFILES_DIR, exist_ok=True)
        if not os.path.exists(GMAIL_DATA_FILE):
            self._save([])

    def _migrate_add_data_dir(self):
        """Migration: add/normalize data_dir field for all records."""
        try:
            with open(GMAIL_DATA_FILE, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if not isinstance(raw, list):
                return
            changed = False
            for rec in raw:
                rec_id = rec.get("id", str(uuid.uuid4()))
                expected = os.path.join(GMAIL_PROFILES_DIR, rec_id)
                current = rec.get("data_dir", "")
                # Add or fix data_dir if missing, empty, or not normalized
                if not current or os.path.abspath(current) != current or ".." in current:
                    rec["data_dir"] = expected
                    changed = True
                os.makedirs(rec.get("data_dir", expected), exist_ok=True)
            if changed:
                self._save(raw)
        except Exception:
            pass

    def _load(self) -> list:
        try:
            with open(GMAIL_DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return [self._normalize(r) for r in data]
            return []
        except Exception:
            return []

    def _save(self, records: list):
        os.makedirs(os.path.dirname(GMAIL_DATA_FILE), exist_ok=True)
        with open(GMAIL_DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2, ensure_ascii=False)

    def _normalize(self, record: dict) -> dict:
        defaults = {
            "id": str(uuid.uuid4()),
            "gmail": "",
            "password": "",
            "recovery_email": "",
            "recovery_phone": "",
            "app_password": "",
            "2fa_secret": "",
            "proxy": "",
            "category": "Mới",
            "note": "",
            "status": "",
            "live": "",
        }
        for k, v in defaults.items():
            if k not in record:
                record[k] = v
        # Ensure data_dir exists (persistent Chrome profile directory)
        if "data_dir" not in record or not record["data_dir"]:
            record["data_dir"] = os.path.join(GMAIL_PROFILES_DIR, record["id"])
        os.makedirs(record["data_dir"], exist_ok=True)
        return record

    # ─── CRUD ───

    def add_gmail(self, gmail="", password="", category="Mới", **extra) -> dict:
        records = self._load()
        rec_id = str(uuid.uuid4())
        data_dir = os.path.join(GMAIL_PROFILES_DIR, rec_id)
        os.makedirs(data_dir, exist_ok=True)
        rec = {
            "id": rec_id,
            "gmail": gmail,
            "password": password,
            "recovery_email": extra.pop("recovery_email", ""),
            "recovery_phone": extra.pop("recovery_phone", ""),
            "app_password": extra.pop("app_password", ""),
            "2fa_secret": extra.pop("2fa_secret", ""),
            "proxy": extra.pop("proxy", ""),
            "category": category,
            "note": extra.pop("note", ""),
            "status": "",
            "live": "",
            "data_dir": data_dir,
        }
        rec.update(extra)
        records.append(rec)
        self._save(records)
        return rec

    def get_all(self, category=None) -> list:
        records = self._load()
        if category and category not in ["Tất cả", "All"]:
            return [r for r in records if r.get("category") == category]
        return records

    def get_one(self, gmail_id: str) -> dict:
        for r in self._load():
            if r.get("id") == gmail_id:
                return r
        return None

    def update(self, gmail_id: str, updates: dict):
        records = self._load()
        for r in records:
            if r.get("id") == gmail_id:
                r.update(updates)
                break
        self._save(records)

    def delete(self, gmail_id: str):
        records = self._load()
        records = [r for r in records if r.get("id") != gmail_id]
        self._save(records)

    def delete_many(self, ids: list):
        id_set = set(ids)
        records = self._load()
        records = [r for r in records if r.get("id") not in id_set]
        self._save(records)

    def find(self, query: str) -> list:
        q = query.lower().strip()
        if not q:
            return self.get_all()
        return [r for r in self._load()
                if q in f"{r.get('gmail','')} {r.get('note','')} {r.get('recovery_email','')}".lower()]

    def _cats_file(self):
        return os.path.join(os.path.dirname(GMAIL_DATA_FILE), "gmail_categories.json")

    def _load_stored_cats(self) -> list:
        try:
            with open(self._cats_file(), "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return ["Mới"]

    def _save_stored_cats(self, cats: list):
        os.makedirs(os.path.dirname(self._cats_file()), exist_ok=True)
        with open(self._cats_file(), "w", encoding="utf-8") as f:
            json.dump(cats, f, ensure_ascii=False, indent=2)

    def get_categories(self) -> list:
        """Return unique categories from stored list + all records."""
        stored = set(self._load_stored_cats())
        for r in self._load():
            c = r.get("category", "Mới")
            if c:
                stored.add(c)
        if not stored:
            stored.add("Mới")
        return sorted(stored)

    def add_category(self, name: str):
        """Add a new category to persistent storage."""
        cats = self._load_stored_cats()
        if name not in cats:
            cats.append(name)
            self._save_stored_cats(cats)

    def rename_category(self, old_name: str, new_name: str):
        """Rename category in stored list and all records."""
        cats = self._load_stored_cats()
        if old_name in cats:
            cats = [new_name if c == old_name else c for c in cats]
            self._save_stored_cats(cats)
        records = self._load()
        for r in records:
            if r.get("category") == old_name:
                r["category"] = new_name
        self._save(records)

    def delete_category_name(self, name: str, fallback: str = "Mới"):
        """Delete category from stored list and move records to fallback."""
        cats = self._load_stored_cats()
        if name in cats:
            cats.remove(name)
            self._save_stored_cats(cats)
        records = self._load()
        for r in records:
            if r.get("category") == name:
                r["category"] = fallback
        self._save(records)

    def move(self, ids: list, new_cat: str):
        self.add_category(new_cat)
        id_set = set(ids)
        records = self._load()
        for r in records:
            if r.get("id") in id_set:
                r["category"] = new_cat
        self._save(records)
