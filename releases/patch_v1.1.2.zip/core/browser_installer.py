import os
import subprocess
import sys
from PyQt6.QtCore import QThread, pyqtSignal


class BrowserInstallerWorker(QThread):
    """One-click browser install/update worker for ALL browsers."""
    progress = pyqtSignal(int, str)   # (percent, message)
    finished = pyqtSignal(bool, str)  # (success, message)

    def __init__(self, browser_name: str, action: str = "install"):
        super().__init__()
        self.browser_name = browser_name
        self.action = action  # "install" or "update"

    def run(self):
        try:
            if self.browser_name == "Chromium":
                self._install_playwright("chromium")
            elif self.browser_name == "Firefox":
                self._install_playwright("firefox")
            elif self.browser_name == "Google Chrome":
                self._install_download(
                    "https://dl.google.com/chrome/install/latest/chrome_installer.exe",
                    "chrome_installer.exe",
                    ["/silent", "/install"]
                )
            elif self.browser_name == "Microsoft Edge":
                self._install_winget("Microsoft.Edge", "Microsoft Edge")
            elif self.browser_name == "Brave":
                self._install_winget("Brave.Brave", "Brave Browser")
            else:
                self.finished.emit(False, f"Không hỗ trợ cài đặt {self.browser_name}")
        except Exception as e:
            self.finished.emit(False, f"Lỗi: {str(e)}")

    # ═══════════════════════════════════════════
    #  Method 1: Playwright Install (Chromium/Firefox)
    # ═══════════════════════════════════════════
    def _install_playwright(self, browser_type):
        self.progress.emit(10, f"Đang cài đặt {self.browser_name} qua Playwright...")
        try:
            python = sys.executable
            result = subprocess.run(
                [python, "-m", "playwright", "install", browser_type],
                capture_output=True, text=True, timeout=300
            )
            if result.returncode == 0:
                self.progress.emit(100, "Hoàn tất!")
                self.finished.emit(True, f"{self.browser_name} đã cài đặt/cập nhật thành công!")
            else:
                err = result.stderr[:200] if result.stderr else "Unknown error"
                self.finished.emit(False, f"Lỗi Playwright: {err}")
        except subprocess.TimeoutExpired:
            self.finished.emit(False, "Quá thời gian cài đặt (5 phút)")
        except Exception as e:
            self.finished.emit(False, f"Lỗi: {str(e)}")

    # ═══════════════════════════════════════════
    #  Method 2: Direct Download (Cốc Cốc/GoLogin)
    # ═══════════════════════════════════════════
    def _install_download(self, url, filename, install_args):
        import requests

        temp_dir = os.path.join(os.environ.get("TEMP", "C:\\temp"), "BrowserInstallers")
        os.makedirs(temp_dir, exist_ok=True)
        installer_path = os.path.join(temp_dir, filename)

        # Clean corrupted downloads
        if os.path.exists(installer_path) and os.path.getsize(installer_path) < 1_000_000:
            os.remove(installer_path)

        # Download
        if not os.path.exists(installer_path):
            self.progress.emit(10, f"Đang tải {self.browser_name}...")
            try:
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                }
                with requests.get(url, headers=headers, stream=True, timeout=60) as r:
                    r.raise_for_status()
                    total = int(r.headers.get('content-length', 0))
                    dl = 0
                    with open(installer_path, 'wb') as f:
                        for chunk in r.iter_content(chunk_size=8192):
                            dl += len(chunk)
                            f.write(chunk)
                            if total > 0:
                                pct = min(int((dl / total) * 70) + 10, 80)
                                self.progress.emit(pct, f"Đang tải {self.browser_name}... {pct}%")
            except Exception as e:
                self.finished.emit(False, f"Lỗi tải: {str(e)}")
                return

        # Validate download
        if os.path.getsize(installer_path) < 1_000_000:
            os.remove(installer_path)
            self.finished.emit(False, "File tải về bị lỗi (quá nhỏ)")
            return

        # Install
        self.progress.emit(85, f"Đang cài đặt {self.browser_name}...")
        try:
            result = subprocess.run(
                [installer_path] + install_args,
                check=False, timeout=180, capture_output=True
            )
            # Some installers return non-zero even on success
            self.progress.emit(100, "Hoàn tất!")
            self.finished.emit(True, f"{self.browser_name} đã cài đặt! Nhấn 'Quét lại' để kiểm tra.")
        except subprocess.TimeoutExpired:
            self.finished.emit(True, "Bộ cài đặt đang chạy ngầm, vui lòng đợi và nhấn 'Quét lại'.")
        except Exception as e:
            self.finished.emit(False, f"Lỗi cài đặt: {str(e)}")

    # ═══════════════════════════════════════════
    #  Method 3: Winget Install (Edge/Brave)
    # ═══════════════════════════════════════════
    def _install_winget(self, package_id, display_name):
        self.progress.emit(10, f"Đang kiểm tra winget...")

        # Check if winget is available
        try:
            subprocess.run(["winget", "--version"], capture_output=True, timeout=10)
        except FileNotFoundError:
            # Winget not available, try direct download
            self.progress.emit(20, f"Winget không có, tải trực tiếp...")
            if package_id == "Microsoft.Edge":
                self._install_download(
                    "https://go.microsoft.com/fwlink/?linkid=2108834&Channel=Stable&language=en",
                    "edge_installer.exe",
                    ["/silent", "/install"]
                )
            elif package_id == "Brave.Brave":
                self._install_download(
                    "https://laptop-updates.brave.com/latest/winx64",
                    "brave_installer.exe",
                    ["/silent", "/install"]
                )
            return

        # Use winget
        cmd_word = "upgrade" if self.action == "update" else "install"
        self.progress.emit(30, f"Đang {cmd_word} {display_name} qua winget...")

        try:
            result = subprocess.run(
                ["winget", cmd_word, package_id,
                 "--accept-source-agreements", "--accept-package-agreements",
                 "--silent"],
                capture_output=True, text=True, timeout=300
            )
            output = (result.stdout + result.stderr)[:300]
            
            if result.returncode == 0 or "already installed" in output.lower() or "No available upgrade" in output:
                self.progress.emit(100, "Hoàn tất!")
                self.finished.emit(True, f"{display_name} đã cài đặt/cập nhật!")
            else:
                self.finished.emit(False, f"Winget lỗi: {output[:150]}")
        except subprocess.TimeoutExpired:
            self.finished.emit(True, "Đang cài đặt ngầm, vui lòng đợi...")
        except Exception as e:
            self.finished.emit(False, f"Lỗi winget: {str(e)}")
