import json
import os
import uuid

PROFILES_FILE = "data/profiles.json"
DATA_DIR = "data/profiles"

class ProfileManager:
    def __init__(self):
        self._ensure_directories()
        self.profiles = self._load_profiles()

    def _ensure_directories(self):
        os.makedirs(DATA_DIR, exist_ok=True)
        if not os.path.exists(PROFILES_FILE):
            with open(PROFILES_FILE, "w", encoding="utf-8") as f:
                json.dump([], f)

    def _load_profiles(self):
        try:
            with open(PROFILES_FILE, "r", encoding="utf-8") as f:
                profiles = json.load(f)
                
            # Ensure backwards compatibility for category
            changed = False
            for p in profiles:
                if "category" not in p:
                    p["category"] = "Default"
                    changed = True
            if changed:
                self.profiles = profiles
                self._save_profiles()
                
            return profiles
        except Exception:
            return []

    def _save_profiles(self):
        with open(PROFILES_FILE, "w", encoding="utf-8") as f:
            json.dump(self.profiles, f, ensure_ascii=False, indent=4)

    def get_all_profiles(self, category=None):
        if category and category != "All Categories":
            return [p for p in self.profiles if p.get("category", "Default") == category]
        return self.profiles

    def add_profile(self, name, description="", fb_uid="", fb_pass="", fb_2fa="", fb_email="", category="Default"):
        profile_id = str(uuid.uuid4())
        new_profile = {
            "id": profile_id,
            "name": name,
            "description": description,
            "category": category,
            # Login credentials
            "fb_uid": fb_uid,
            "fb_email": fb_email,
            "fb_pass": fb_pass,
            "fb_2fa": fb_2fa,
            # Scraped / manually filled fields
            "fb_name": "",
            "fb_gender": "",
            "fb_friends": "",
            "fb_live": "",
            "fb_location": "",
            "fb_dob": "",
            "fb_created": "",
            "fb_level": "",
            "fb_pass_email": "",
            "fb_email_recovery": "",
            "fb_old_pass": "",
            "fb_spend": "",
            "fb_proxy": "",
            "fb_cookie": "",
            "fb_pass_lim": "",
            "fb_uid_target": "",
            "fb_useragent": "",
            "fb_useragent_android": "",
            "fb_token": "",
            "fb_token_hotmail": "",
            "fb_backup": "",
            # System
            "data_dir": os.path.join(DATA_DIR, profile_id),
            "status": "Stopped"
        }
        self.profiles.append(new_profile)
        self._save_profiles()
        return new_profile

    def update_profile(self, profile_id: str, fields: dict):
        """Merge fields dict into the profile and save."""
        for p in self.profiles:
            if p["id"] == profile_id:
                p.update(fields)
                self._save_profiles()
                return True
        return False

    def delete_profile(self, profile_id):
        self.profiles = [p for p in self.profiles if p["id"] != profile_id]
        self._save_profiles()

    def get_profile(self, profile_id):
        for p in self.profiles:
            if p["id"] == profile_id:
                return p
        return None

