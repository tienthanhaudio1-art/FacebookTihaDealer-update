import json
import os
import uuid

EMAIL_DATA_FILE = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "emails.json"))
EMAIL_PROFILES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "email_profiles"))

class GlobalEmailManager:
    """
    Centralized email manager using flat JSON storage.
    Each email record has fields matching the MetaMax reference UI:
      id, uid, email, pass_email, email_recovery, pass_em,
      live, category, note, status, proxy, token_hotmail
    """

    def __init__(self):
        self._ensure_data_file()
        self._migrate_add_data_dir()

    def _ensure_data_file(self):
        os.makedirs(os.path.dirname(EMAIL_DATA_FILE), exist_ok=True)
        os.makedirs(EMAIL_PROFILES_DIR, exist_ok=True)
        if not os.path.exists(EMAIL_DATA_FILE):
            self._save([])

    def _migrate_add_data_dir(self):
        """Migration: add/normalize data_dir field for all records."""
        try:
            with open(EMAIL_DATA_FILE, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if not isinstance(raw, list):
                return
            changed = False
            for rec in raw:
                rec_id = rec.get("id", str(uuid.uuid4()))
                expected = os.path.join(EMAIL_PROFILES_DIR, rec_id)
                current = rec.get("data_dir", "")
                if not current or os.path.abspath(current) != current or ".." in current:
                    rec["data_dir"] = expected
                    changed = True
                os.makedirs(rec.get("data_dir", expected), exist_ok=True)
            if changed:
                self._save(raw)
        except Exception:
            pass

    def _load(self) -> list:
        try:
            with open(EMAIL_DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            # Migration: if old format (dict with hotmail/gmail keys), flatten it  
            if isinstance(data, dict):
                flat = []
                for key in ["hotmail", "gmail"]:
                    for item in data.get(key, []):
                        flat.append(self._normalize(item))
                self._save(flat)
                return flat
            return [self._normalize(e) for e in data]
        except Exception:
            return []

    def _save(self, emails: list):
        os.makedirs(os.path.dirname(EMAIL_DATA_FILE), exist_ok=True)
        with open(EMAIL_DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(emails, f, indent=2, ensure_ascii=False)

    def _normalize(self, record: dict) -> dict:
        """Ensure all required fields exist with defaults."""
        defaults = {
            "id": str(uuid.uuid4()),
            "uid": "",
            "email": "",
            "pass_email": "",
            "email_recovery": "",
            "pass_em": "",
            "live": "",
            "category": "Mới",
            "note": "",
            "status": "",
            "proxy": "",
            "token_hotmail": ""
        }
        for k, v in defaults.items():
            if k not in record:
                record[k] = v
        # Ensure data_dir exists (persistent Chrome profile directory)
        if "data_dir" not in record or not record["data_dir"]:
            record["data_dir"] = os.path.join(EMAIL_PROFILES_DIR, record["id"])
        os.makedirs(record["data_dir"], exist_ok=True)
        # Migration: map old 'password' -> 'pass_email'  
        if "password" in record and not record.get("pass_email"):
            record["pass_email"] = record.pop("password")
        elif "password" in record:
            record.pop("password", None)
        # Migration: map old 'twofa' -> keep as-is or drop
        record.pop("twofa", None)
        return record

    # ─── CRUD ───

    def add_email(self, email: str = "", password: str = "", recovery: str = "",
                  uid: str = "", category: str = "Mới", **extra) -> dict:
        emails = self._load()
        rec_id = str(uuid.uuid4())
        data_dir = os.path.join(EMAIL_PROFILES_DIR, rec_id)
        os.makedirs(data_dir, exist_ok=True)
        record = {
            "id": rec_id,
            "uid": uid if uid else "",
            "email": email,
            "pass_email": password,
            "email_recovery": recovery,
            "pass_em": extra.pop("pass_em", ""),
            "live": extra.pop("live", ""),
            "category": category,
            "note": extra.pop("note", ""),
            "status": "",
            "proxy": extra.pop("proxy", ""),
            "token_hotmail": extra.pop("token_hotmail", ""),
            "data_dir": data_dir,
        }
        record.update(extra)
        emails.append(record)
        self._save(emails)
        return record

    def get_all_emails(self, category: str = None) -> list:
        emails = self._load()
        if category and category not in ["Tất cả", "All Categories"]:
            return [e for e in emails if e.get("category") == category]
        return emails

    def get_email(self, email_id: str) -> dict:
        for e in self._load():
            if e.get("id") == email_id:
                return e
        return None

    def update_email(self, email_id: str, updates: dict):
        emails = self._load()
        for e in emails:
            if e.get("id") == email_id:
                e.update(updates)
                break
        self._save(emails)

    def delete_email(self, email_id: str):
        emails = self._load()
        emails = [e for e in emails if e.get("id") != email_id]
        self._save(emails)

    def delete_emails(self, email_ids: list):
        id_set = set(email_ids)
        emails = self._load()
        emails = [e for e in emails if e.get("id") not in id_set]
        self._save(emails)

    def import_emails(self, lines: list, mappings: list = None, category: str = "Mới") -> int:
        """
        Import emails from raw text lines.
        Default format: UID|Email|Pass Email|Email Recovery|PassEm|Proxy|Token
        Custom mappings can override field order.
        """
        default_mappings = ["uid", "email", "pass_email", "email_recovery", "pass_em", "proxy", "token_hotmail"]
        if not mappings:
            mappings = default_mappings

        count = 0
        for line in lines:
            line = line.strip()
            if not line:
                continue
            parts = line.split("|")
            record = {"category": category}
            for i, part in enumerate(parts):
                if i < len(mappings) and mappings[i]:
                    record[mappings[i]] = part.strip()
            if record.get("email") or record.get("uid"):
                self.add_email(
                    email=record.get("email", ""),
                    password=record.get("pass_email", ""),
                    recovery=record.get("email_recovery", ""),
                    uid=record.get("uid", ""),
                    category=category,
                    pass_em=record.get("pass_em", ""),
                    proxy=record.get("proxy", ""),
                    token_hotmail=record.get("token_hotmail", ""),
                    note=record.get("note", "")
                )
                count += 1
        return count

    def find_email(self, query: str) -> list:
        """Search emails by UID, email address, or note content."""
        q = query.lower().strip()
        if not q:
            return self.get_all_emails()
        results = []
        for e in self._load():
            searchable = f"{e.get('uid','')} {e.get('email','')} {e.get('note','')}".lower()
            if q in searchable:
                results.append(e)
        return results

    def _cats_file(self):
        return os.path.join(os.path.dirname(EMAIL_DATA_FILE), "email_categories.json")

    def _load_stored_cats(self) -> list:
        try:
            with open(self._cats_file(), "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return ["Mới"]

    def _save_stored_cats(self, cats: list):
        os.makedirs(os.path.dirname(self._cats_file()), exist_ok=True)
        with open(self._cats_file(), "w", encoding="utf-8") as f:
            json.dump(cats, f, ensure_ascii=False, indent=2)

    def get_categories(self) -> list:
        """Return unique categories from stored list + all emails."""
        stored = set(self._load_stored_cats())
        for e in self._load():
            cat = e.get("category", "Mới")
            if cat:
                stored.add(cat)
        if not stored:
            stored.add("Mới")
        return sorted(stored)

    def add_category(self, name: str):
        """Add a new category to persistent storage."""
        cats = self._load_stored_cats()
        if name not in cats:
            cats.append(name)
            self._save_stored_cats(cats)

    def rename_category(self, old_name: str, new_name: str):
        """Rename category in stored list and all email records."""
        cats = self._load_stored_cats()
        if old_name in cats:
            cats = [new_name if c == old_name else c for c in cats]
            self._save_stored_cats(cats)
        emails = self._load()
        for e in emails:
            if e.get("category") == old_name:
                e["category"] = new_name
        self._save(emails)

    def delete_category_name(self, name: str, fallback: str = "Mới"):
        """Delete category from stored list and move records to fallback."""
        cats = self._load_stored_cats()
        if name in cats:
            cats.remove(name)
            self._save_stored_cats(cats)
        emails = self._load()
        for e in emails:
            if e.get("category") == name:
                e["category"] = fallback
        self._save(emails)

    def move_emails(self, email_ids: list, new_category: str):
        """Move selected emails to a new category."""
        self.add_category(new_category)
        id_set = set(email_ids)
        emails = self._load()
        for e in emails:
            if e.get("id") in id_set:
                e["category"] = new_category
        self._save(emails)
