import hashlib
import subprocess
import os
import json

from datetime import datetime, timedelta

def get_hwid():
    """Generates a unique HWID for the Windows machine."""
    try:
        # Get CPU Serial Number
        cpu_cmd = "wmic cpu get processorid"
        cpu_id = subprocess.check_output(cpu_cmd, shell=True).decode().split('\n')[1].strip()
        
        # Get Disk Serial Number
        disk_cmd = "wmic diskdrive get serialnumber"
        disk_id = subprocess.check_output(disk_cmd, shell=True).decode().split('\n')[1].strip()
        
        combined = f"{cpu_id}-{disk_id}"
        return hashlib.sha256(combined.encode()).hexdigest()[:16].upper()
    except Exception:
        # Fallback to a simpler method if wmic fails
        import uuid
        return hashlib.sha256(str(uuid.getnode()).encode()).hexdigest()[:16].upper()

def generate_key(hwid, expiry_date_str):
    """Generates an activation key for a given HWID and expiry date (YYYYMMDD).
    The key will be: HASH(hwid + expiry + secret)[:12] + expiry
    """
    secret = "FB_TOOL_SECRET_SALT_2026"
    combined = f"{hwid}:{expiry_date_str}:{secret}"
    signature = hashlib.sha256(combined.encode()).hexdigest()[:8].upper()
    return f"{signature}-{expiry_date_str}"

def verify_license(key):
    """Verifies if the provided key is valid for the current machine and hasn't expired."""
    if not key or "-" not in key:
        return False
    
    try:
        signature, expiry_str = key.split("-")
        hwid = get_hwid()
        
        # Verify signature
        secret = "FB_TOOL_SECRET_SALT_2026"
        combined = f"{hwid}:{expiry_str}:{secret}"
        expected_signature = hashlib.sha256(combined.encode()).hexdigest()[:8].upper()
        
        if signature != expected_signature:
            return False
            
        # Check Expiry
        if expiry_str == "99991231": # Lifetime
            return True
            
        expiry_date = datetime.strptime(expiry_str, "%Y%m%d")
        if datetime.now() > expiry_date:
            return False # Expired
            
        return True
    except Exception:
        return False

def get_expiry_date_str(key):
    """Extracts expiration date from key/license."""
    if not key or "-" not in key:
        return "Unknown"
    try:
        _, expiry_str = key.split("-")
        if expiry_str == "99991231":
            return "Lifetime"
        expiry_date = datetime.strptime(expiry_str, "%Y%m%d")
        return expiry_date.strftime("%d/%m/%Y")
    except:
        return "Unknown"

LICENSE_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "license.json")

def get_stored_license():
    if os.path.exists(LICENSE_FILE):
        try:
            with open(LICENSE_FILE, "r") as f:
                return json.load(f).get("key")
        except:
            pass
    return None

def save_license(key):
    os.makedirs(os.path.dirname(LICENSE_FILE), exist_ok=True)
    with open(LICENSE_FILE, "w") as f:
        json.dump({"key": key}, f)
