import requests
import re
from PyQt6.QtCore import QThread, pyqtSignal, QObject

def extract_form_data(html):
    inputs = {}
    # Extract all hidden or pre-filled input fields
    for match in re.finditer(r'<input[^>]+name=["\']([^"\']+)["\'][^>]*>', html):
        name = match.group(1)
        val_match = re.search(r'value=["\']([^"\']*)["\']', match.group(0))
        val = val_match.group(1) if val_match else ""
        if name not in inputs:
            inputs[name] = val
            
    # Extract form action
    action = ""
    action_match = re.search(r'<form[^>]+action=["\']([^"\']+)["\']', html)
    if action_match:
        action = action_match.group(1).replace("&amp;", "&")
    return action, inputs

class ApiLoginThread(QThread):
    info_ready = pyqtSignal(str, dict)
    status_ready = pyqtSignal(str, str)
    
    def __init__(self, profile):
        super().__init__()
        self.profile = profile
        
    def run(self):
        pid = self.profile.get("id")
        uid = self.profile.get("fb_uid") or self.profile.get("fb_email")
        pwd = self.profile.get("fb_pass")
        tfa = self.profile.get("fb_2fa")
        
        if not uid or not pwd:
            self.status_ready.emit(pid, "Lỗi: Thiếu tài khoản")
            return
            
        session = requests.Session()
        session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9",
        })
        
        try:
            # Step 1: Request Login Page
            resp = session.get("https://mbasic.facebook.com/login", timeout=15)
            action, data = extract_form_data(resp.text)
            
            data['email'] = uid
            data['pass'] = pwd
            data['login'] = 'Log In'
            
            if not action:
                self.status_ready.emit(pid, "Lỗi: Không tìm thấy Form")
                return
                
            if not action.startswith('http'):
                action = "https://mbasic.facebook.com" + action
                
            resp2 = session.post(action, data=data, timeout=15)
            
            # Step 2: Handle 2FA if checkpoint
            if "checkpoint" in resp2.url or "approvals_code" in resp2.text:
                if not tfa:
                    self.status_ready.emit(pid, "Checkpoint: Cần 2FA")
                    return
                # Get 2FA Code
                tfa_resp = requests.get(f"https://2fa.live/tok/{tfa.replace(' ', '')}", timeout=10)
                if tfa_resp.status_code == 200:
                    code = tfa_resp.json().get("token", "")
                    if code:
                        action2, data2 = extract_form_data(resp2.text)
                        data2['approvals_code'] = code
                        # submit 2fa
                        if action2 and not action2.startswith('http'): 
                            action2 = "https://mbasic.facebook.com" + action2
                        resp3 = session.post(action2, data=data2, timeout=15)
                        
                        # Bypass "Save Device" / "Review Recent Login"
                        for _ in range(2):
                            action3, data3 = extract_form_data(resp3.text)
                            # Often it's 'name="submit[Continue]"' or 'name="submit[This was me]"'
                            # We just submit the form as is with the first submit button we find
                            submit_match = re.search(r'<input[^>]+type=["\']submit["\'][^>]+name=["\']([^"\']+)["\'][^>]*value=["\']([^"\']+)["\']', resp3.text)
                            if submit_match:
                                data3[submit_match.group(1)] = submit_match.group(2)
                                
                            if action3:
                                if not action3.startswith('http'): action3 = "https://mbasic.facebook.com" + action3
                                resp3 = session.post(action3, data=data3, timeout=15)
                            else:
                                break
            
            # Step 3: Verify Login & Extract Data
            cookies = session.cookies.get_dict()
            if 'c_user' in cookies:
                # Logged in
                cookie_str = "; ".join([f"{k}={v}" for k, v in cookies.items()])
                
                # Try to fetch Name from Profile
                fb_name = ""
                try:
                    p_resp = session.get("https://mbasic.facebook.com/me", timeout=15)
                    title_match = re.search(r'<title>(.*?)</title>', p_resp.text)
                    if title_match:
                        fb_name = title_match.group(1).replace(" | Facebook", "").strip()
                except Exception:
                    pass
                
                scraped = {
                    "fb_cookie": cookie_str,
                    "fb_name": fb_name,
                    "status": "Live (API)"
                }
                if 'xs' in cookies:
                    scraped["fb_token"] = cookies['xs'][:20] + "..." # Token placeholder or actual extraction
                
                self.info_ready.emit(pid, scraped)
                self.status_ready.emit(pid, "Đã Đăng Nhập")
            else:
                self.status_ready.emit(pid, "Lỗi Đăng Nhập (Sai MK/Die)")
                
        except Exception as e:
            self.status_ready.emit(pid, f"Lỗi Mạng: {str(e)}")


class ApiLoginManager(QObject):
    info_ready = pyqtSignal(str, dict)
    status_ready = pyqtSignal(str, str)
    
    def __init__(self):
        super().__init__()
        self.threads = []
        
    def start_login(self, profile):
        # Remove dead threads
        self.threads = [t for t in self.threads if t.isRunning()]
        t = ApiLoginThread(profile)
        t.info_ready.connect(self.info_ready.emit)
        t.status_ready.connect(self.status_ready.emit)
        self.threads.append(t)
        t.start()
