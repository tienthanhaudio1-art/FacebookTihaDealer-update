"""
Hotmail Login Worker — Background login automation for email accounts.
Supports 4 login methods: Password, Recovery, Token+AddRecovery, Chrome.
All headless except Chrome mode.

Uses Playwright for browser automation.
"""
import json
import random
import string
import time
import urllib.request
import urllib.parse
import re

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QComboBox, QLineEdit, QMessageBox
)
from PyQt6.QtCore import QThread, pyqtSignal, Qt


# ═══════════════════════════
#  Temp Mail Domain Providers
# ═══════════════════════════

TEMP_MAIL_DOMAINS = {
    "temp-mail.io": [
        "greencafe24.com", "waterisgone.com", "klovenode.com", "drowblock.com",
        "dishcatfish.com", "superblobby.com", "happy2023year.com", "gixenmixen.com",
        "bloheyz.com", "zipcatfish.com", "myinfoline.com", "skygazerhub.com",
        "stolkar.com", "pirolsnet.com"
    ],
    "mail.tm": [],
    "inboxes": [
        "blondmail.com", "chapsmail.com", "clowmail.com", "dropjar.com",
        "fivemail.com", "getairmail.com", "getnada.com", "getmule.com",
        "gimpmail.com", "glrymail.com", "guysmail.com", "inboxbear.com"
    ],
    "tempm.com": [
        "tempm.com"
    ],
    "emailfake.com": [],
    "fvia": [
        "fviadropinbox.com", "fviainboxes.com", "fviamail.work",
        "dropinboxes.com"
    ],
    "donglaomail.com": [
        "abmdigital.pro", "adhsrobotics.info", "adriannesa.info",
        "adwuizrus.live", "althavarior.live"
    ],
    "moakt": [
        "teml.net", "tmpeml.com", "tmpbox.net", "mockit.cc",
        "disbox.net", "tmpmail.org", "tmpmail.net", "tmails.net",
        "disbox.org", "mockt.co", "mockit.ws", "tmail.ws"
    ],
    "smvmail.com": [],
    "upxmail.com": [
        "upxmail.com"
    ],
    "etempmail.com": [
        "dunkos.xyz", "smallintm.lol", "undeep.xyz"
    ],
    "tp-mail.net": [
        "tp-mail.net", "tp-mail.cc", "tp-mail.org",
        "tp-mail.xyz", "pt-mail.org", "ro-games.com"
    ],
    "5smail.email": [
        "5smail.email"
    ],
    "tempmail.lol": [
        "tempmail.lol"
    ],
    "tempmail.plus": [
        "mailto.plus", "fexpost.com", "fexbox.org",
        "mailbox.in.ua", "rover.info", "chitthi.in",
        "fextemp.com", "any.pink", "merepost.com"
    ],
    "mail.cx": [
        "qabq.com", "nqmo.com", "end.tw", "ouf.me", "yxm.de"
    ],
    "unlimitmail": [],
    "hotmail9.com": [
        "hotmail9.com", "mail8u.com"
    ],
    "mailngon.top": [
        "mailngon.top", "mailngon.net", "mailngon.com"
    ],
    "getmails.cc": [
        "email10p.org", "email10.org", "email10.net", "email10.email",
        "ecominone.com", "getnode.com"
    ],
    "sichvummo.org": [
        "sichvummo.org"
    ],
    "byom.de": [],
    "custom site": [],
}


def generate_random_email(domain: str) -> str:
    """Generate a random email address for the given domain."""
    username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=12))
    return f"{username}@{domain}"


def build_recovery_email(main_email: str, domain: str, suffix: str = "") -> str:
    """Build recovery email from main email username + suffix + domain.
    Example: main=12345@hotmail.com, suffix=TTT, domain=smvmail.com -> 12345TTT@smvmail.com"""
    username = main_email.split("@")[0] if "@" in main_email else main_email
    return f"{username}{suffix}@{domain}"


# ═══════════════════════════
#  Recovery Domain Dialog
# ═══════════════════════════

class RecoveryDomainDialog(QDialog):
    """Dialog for selecting temp mail domain and suffix for recovery email.
    Recovery email format: {main_email_username}{suffix}@{selected_domain}
    Example: 12345@hotmail.com + suffix 'TTT' + domain 'smvmail.com' = 12345TTT@smvmail.com
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Chon site Email Recovery")
        self.setFixedSize(400, 260)
        self.setStyleSheet("""
            QDialog { background: #e8f4fc; }
            QLabel { color: #333; font-size: 13px; font-weight: bold; }
            QComboBox { padding: 6px; font-size: 13px; min-height: 28px; }
            QLineEdit { padding: 6px; font-size: 13px; border: 1px solid #91caff;
                        border-radius: 4px; }
            QPushButton { background: #1890ff; color: white; font-weight: bold;
                          font-size: 14px; border-radius: 4px; padding: 8px 30px; }
            QPushButton:hover { background: #40a9ff; }
        """)

        layout = QVBoxLayout(self)

        # Provider dropdown
        lbl1 = QLabel("Chon site Email Recovery:")
        layout.addWidget(lbl1)
        self.combo_provider = QComboBox()
        for provider in TEMP_MAIL_DOMAINS.keys():
            self.combo_provider.addItem(provider)
        self.combo_provider.currentTextChanged.connect(self._on_provider_changed)
        layout.addWidget(self.combo_provider)

        # Domain dropdown (sub-domains)
        self.combo_domain = QComboBox()
        self.combo_domain.setEditable(True)
        layout.addWidget(self.combo_domain)

        # Suffix input
        lbl2 = QLabel("Ky tu them sau ten email (suffix):")
        layout.addWidget(lbl2)
        self.suffix_input = QLineEdit()
        self.suffix_input.setPlaceholderText("VD: TTT (12345@hotmail -> 12345TTT@domain)")
        layout.addWidget(self.suffix_input)

        # Preview
        self.preview_lbl = QLabel("")
        self.preview_lbl.setStyleSheet("color: #1890ff; font-size: 11px; font-weight: normal;")
        layout.addWidget(self.preview_lbl)

        # OK button
        btn = QPushButton("OK")
        btn.clicked.connect(self.accept)
        layout.addWidget(btn, alignment=Qt.AlignmentFlag.AlignCenter)

        self._on_provider_changed(self.combo_provider.currentText())
        self.suffix_input.textChanged.connect(self._update_preview)
        self.combo_domain.currentTextChanged.connect(self._update_preview)

        self.selected_provider = ""
        self.selected_domain = ""
        self.selected_suffix = ""

    def _on_provider_changed(self, provider):
        self.combo_domain.clear()
        domains = TEMP_MAIL_DOMAINS.get(provider, [])
        if domains:
            self.combo_domain.addItems(domains)
        else:
            self.combo_domain.setEditText(provider)
        self._update_preview()

    def _update_preview(self):
        domain = self.combo_domain.currentText().strip() or "domain.com"
        suffix = self.suffix_input.text().strip()
        self.preview_lbl.setText(f"VD: 12345{suffix}@{domain}")

    def accept(self):
        self.selected_provider = self.combo_provider.currentText()
        self.selected_domain = self.combo_domain.currentText().strip()
        self.selected_suffix = self.suffix_input.text().strip()
        if not self.selected_domain:
            self.selected_domain = self.selected_provider
        super().accept()

    def get_result(self):
        return self.selected_provider, self.selected_domain, self.selected_suffix


# ═══════════════════════════
#  Hotmail Login Thread
# ═══════════════════════════

class HotmailLoginThread(QThread):
    """Background thread for Hotmail login automation.
    
    login_type: 'password' | 'recovery' | 'token_recovery' | 'chrome'
    headless: True for all except 'chrome'
    """
    status_update = pyqtSignal(str, str)      # email_id, status
    login_done = pyqtSignal(str, dict)         # email_id, result {cookies, token, status}
    error_signal = pyqtSignal(str, str)        # email_id, error_msg

    def __init__(self, email_rec, login_type="password", headless=True,
                 recovery_domain="", recovery_provider="", recovery_suffix=""):
        super().__init__()
        self.rec = email_rec
        self.login_type = login_type
        self.headless = headless
        self.recovery_domain = recovery_domain
        self.recovery_provider = recovery_provider
        self.recovery_suffix = recovery_suffix
        self._running = True

    def run(self):
        eid = self.rec.get("id", "")
        email_addr = self.rec.get("email", "")
        password = self.rec.get("pass_email", "")
        token = self.rec.get("token_hotmail", "")

        try:
            from playwright.sync_api import sync_playwright

            self.status_update.emit(eid, "Khoi dong trinh duyet...")

            # Get persistent profile directory from record
            user_data = self.rec.get("data_dir", "")
            if not user_data:
                from core.email_manager import EMAIL_PROFILES_DIR
                import os as _os
                user_data = _os.path.join(EMAIL_PROFILES_DIR, eid)
                _os.makedirs(user_data, exist_ok=True)

            with sync_playwright() as p:
                from core.browser_manager import next_browser_window_params, SmartBrowserDetector
                import subprocess as sp_sub
                import socket
                import os as _os
                wp = next_browser_window_params()

                chrome_proc = None

                if self.login_type == "chrome":
                    # Chrome mode: use subprocess Chrome + CDP for persistent profile
                    chrome_exe = SmartBrowserDetector.find_browser("Google Chrome")
                    if not chrome_exe:
                        chrome_exe = SmartBrowserDetector.find_browser("Microsoft Edge")

                    if chrome_exe:
                        def _find_free_port():
                            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                                s.bind(('', 0))
                                return s.getsockname()[1]
                        cdp_port = _find_free_port()
                        _os.makedirs(user_data, exist_ok=True)
                        chrome_args = [
                            chrome_exe,
                            f"--remote-debugging-port={cdp_port}",
                            f"--user-data-dir={user_data}",
                            "--no-first-run",
                            "--no-default-browser-check",
                            "--disable-popup-blocking",
                        ] + wp["chrome_args"] + [
                            "https://login.live.com/"
                        ]
                        chrome_proc = sp_sub.Popen(chrome_args, stdout=sp_sub.DEVNULL, stderr=sp_sub.DEVNULL)
                        import time as _time
                        _time.sleep(3)
                        browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{cdp_port}")
                        context = browser.contexts[0]
                        page = context.pages[0] if context.pages else context.new_page()
                    else:
                        # Fallback: Playwright with persistent context
                        browser = p.chromium.launch_persistent_context(
                            user_data_dir=user_data,
                            headless=False,
                            args=["--disable-blink-features=AutomationControlled",
                                  "--no-sandbox", "--disable-dev-shm-usage"] + wp["chrome_args"],
                            viewport={"width": wp["win_w"], "height": wp["win_h"]},
                            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                        )
                        context = browser
                        page = context.new_page()
                else:
                    # Headless modes: use Playwright with persistent context for data_dir
                    browser = p.chromium.launch_persistent_context(
                        user_data_dir=user_data,
                        headless=self.headless,
                        args=["--disable-blink-features=AutomationControlled",
                              "--no-sandbox", "--disable-dev-shm-usage"] + wp["chrome_args"],
                        viewport={"width": wp["win_w"], "height": wp["win_h"]},
                        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                    )
                    context = browser
                    page = context.new_page()

                if self.login_type == "password":
                    self._login_password(page, eid, email_addr, password)
                elif self.login_type == "recovery":
                    self._login_recovery(page, eid, email_addr, password)
                elif self.login_type == "token_recovery":
                    self._login_token_add_recovery(page, eid, email_addr, password, token)
                elif self.login_type == "chrome":
                    self._login_chrome(page, eid, email_addr, password)

                if self.login_type != "chrome":
                    context.close()
                    if not chrome_proc:
                        pass  # persistent context closes itself
                else:
                    # Chrome mode: wait for user to close
                    self.status_update.emit(eid, "Chrome dang mo - dong de hoan tat")
                    try:
                        page.wait_for_event("close", timeout=0)
                    except:
                        pass
                    try:
                        cookies = context.cookies()
                        self.login_done.emit(eid, {"cookies": cookies, "status": "Chrome closed"})
                    except:
                        pass
                    try:
                        context.close()
                        browser.close()
                    except:
                        pass

        except Exception as e:
            self.error_signal.emit(eid, f"Loi: {str(e)[:150]}")

    def _click_next(self, page):
        """Click the Next/Submit button on Microsoft login page."""
        # Try multiple selectors in order of specificity
        for selector in [
            'button:has-text("Next")',
            'button:has-text("Sign in")',
            'button:has-text("Yes")',
            '#idSIButton9',
            'input[type="submit"]',
        ]:
            try:
                btn = page.locator(selector)
                if btn.count() > 0 and btn.first.is_visible(timeout=1500):
                    btn.first.click()
                    return
            except:
                continue
        # Fallback: press Enter (most reliable)
        page.keyboard.press("Enter")

    def _login_password(self, page, eid, email_addr, password):
        """Login using email + password (headless)."""
        if not password:
            self.error_signal.emit(eid, "Khong co password")
            return

        self.status_update.emit(eid, "Truy cap login.live.com...")
        page.goto("https://login.live.com/", wait_until="networkidle", timeout=30000)
        page.wait_for_load_state("domcontentloaded")
        time.sleep(2)

        # Enter email
        self.status_update.emit(eid, "Nhap email...")
        try:
            email_input = page.locator('input[type="email"]')
            email_input.wait_for(state="visible", timeout=10000)
            email_input.fill(email_addr)
            time.sleep(0.5)
            self._click_next(page)
            page.wait_for_load_state("domcontentloaded")
            time.sleep(3)
        except Exception as e:
            self.error_signal.emit(eid, f"Loi nhap email: {str(e)[:80]}")
            return

        # Check for error
        if self._check_error(page, eid):
            return

        # Handle "Verify your email" page — click "Use your password" if present
        self._handle_verify_page(page, eid)

        # Enter password
        self.status_update.emit(eid, "Nhap password...")
        try:
            pass_input = page.locator('input[type="password"]')
            pass_input.wait_for(state="visible", timeout=15000)
            pass_input.fill(password)
            time.sleep(0.5)
            self._click_next(page)
            page.wait_for_load_state("domcontentloaded")
            time.sleep(3)
        except Exception as e:
            self.error_signal.emit(eid, f"Loi nhap password: {str(e)[:80]}")
            return

        # Check for error after password
        if self._check_error(page, eid):
            return

        # ── Check for CAPTCHA challenge ──
        try:
            from core.captcha_solver import handle_captcha_on_page
            handle_captcha_on_page(
                page,
                status_callback=lambda msg: self.status_update.emit(eid, msg)
            )
        except Exception:
            pass

        # Handle "Stay signed in?" prompt
        self._handle_stay_signed_in(page, eid)

        # Handle add recovery email prompt if appears
        self._handle_add_recovery_prompt(page, eid)

        # Check final state
        self._check_login_result(page, eid)

    def _login_recovery(self, page, eid, email_addr, password):
        """Login using recovery email verification (headless)."""
        self.status_update.emit(eid, "Truy cap login.live.com...")
        page.goto("https://login.live.com/", wait_until="domcontentloaded", timeout=30000)
        time.sleep(2)

        # Enter email
        self.status_update.emit(eid, "Nhap email...")
        try:
            email_input = page.locator('input[type="email"]')
            email_input.wait_for(state="visible", timeout=10000)
            email_input.fill(email_addr)
            time.sleep(0.5)
            self._click_next(page)
            page.wait_for_load_state("domcontentloaded")
            time.sleep(3)
        except:
            self.error_signal.emit(eid, "Loi nhap email")
            return

        # Look for "forgot password" or "other ways to sign in"
        self.status_update.emit(eid, "Tim lien ket khoi phuc...")
        try:
            forgot_link = page.locator('#idA_PWD_ForgotPassword, a:has-text("Forgot"), a:has-text("forgot")')
            if forgot_link.count() > 0:
                forgot_link.first.click()
                time.sleep(3)
        except:
            pass

        # Look for email recovery option
        self.status_update.emit(eid, "Chon phuong thuc khoi phuc qua email...")
        try:
            # Select email verification option
            email_opt = page.locator('div[data-bind*="email"], #iSelectProofOption1, input[value*="Email"]')
            if email_opt.count() > 0:
                email_opt.first.click()
                time.sleep(2)
        except:
            pass

        self.status_update.emit(eid, "Cho ma xac minh tu email khoi phuc...")
        # This step requires reading the recovery email inbox
        # For now, we report the status
        current_url = page.url
        if "recover" in current_url or "proof" in current_url:
            self.status_update.emit(eid, "Dang cho nhap ma xac minh recovery")
        else:
            self._check_login_result(page, eid)

    def _login_token_add_recovery(self, page, eid, email_addr, password, token):
        """Login using password, then add recovery email if prompted (headless)."""
        if not password:
            self.error_signal.emit(eid, "Khong co password")
            return

        # First login with password
        self._login_password(page, eid, email_addr, password)

        # After login, check if recovery prompt appears
        time.sleep(2)
        current_url = page.url.lower()
        page_text = ""
        try:
            page_text = page.inner_text("body").lower()
        except:
            pass

        needs_recovery = (
            "proofs" in current_url or
            "security" in current_url or
            "recovery" in page_text or
            "add email" in page_text or
            "alternate email" in page_text or
            "security info" in page_text
        )

        if needs_recovery and self.recovery_domain:
            self.status_update.emit(eid, "Can them email khoi phuc...")
            recovery_email = build_recovery_email(email_addr, self.recovery_domain, self.recovery_suffix)
            self.status_update.emit(eid, f"Them recovery: {recovery_email}")

            # Try to fill recovery email
            try:
                # Look for email input for recovery
                recovery_input = page.locator(
                    'input[name="EmailAddress"], '
                    'input[placeholder*="email"], '
                    'input[aria-label*="email"], '
                    'input[type="email"]'
                ).last
                if recovery_input.is_visible(timeout=5000):
                    recovery_input.fill(recovery_email)
                    time.sleep(0.5)
                    # Click next/submit
                    page.locator(
                        '#idSIButton9, '
                        'input[type="submit"], '
                        'button:has-text("Next"), '
                        'button:has-text("Send code")'
                    ).first.click()
                    time.sleep(3)
                    self.status_update.emit(eid, f"Da gui code den {recovery_email}")

                    # Result with recovery info
                    self.login_done.emit(eid, {
                        "status": "Add recovery - cho code",
                        "recovery_email": recovery_email,
                        "recovery_domain": self.recovery_domain,
                        "recovery_provider": self.recovery_provider,
                    })
                    return
            except Exception as e:
                self.status_update.emit(eid, f"Loi add recovery: {str(e)[:60]}")

        self._check_login_result(page, eid)

    def _login_chrome(self, page, eid, email_addr, password):
        """Open Chrome visible for user to login manually."""
        self.status_update.emit(eid, "Mo Chrome...")
        page.goto("https://login.live.com/", wait_until="domcontentloaded", timeout=30000)
        time.sleep(1)

        # Pre-fill email if available
        if email_addr:
            try:
                email_input = page.locator('input[type="email"], input[name="loginfmt"]')
                if email_input.is_visible(timeout=3000):
                    email_input.fill(email_addr)
            except:
                pass

        self.status_update.emit(eid, "Chrome dang mo - dang nhap thu cong")

    def _handle_verify_page(self, page, eid):
        """Handle 'Verify your email' page — click 'Use your password' link.
        Uses page.get_by_text() because the element is a Fluent UI <span role='button'>."""
        time.sleep(1)
        try:
            body_text = page.inner_text("body")[:500].lower()
            
            # Check for "Use your password" on the page
            if "use your password" in body_text or "use a password" in body_text:
                self.status_update.emit(eid, "Chuyen sang dang nhap password...")
                # Use get_by_text — the link is a <span role="button" class="fui-Link">
                el = page.get_by_text("Use your password", exact=True)
                if el.count() > 0:
                    el.first.click()
                    page.wait_for_load_state("domcontentloaded")
                    time.sleep(3)
                    return
                # Fallback: try "Use a password"
                el2 = page.get_by_text("Use a password", exact=True)
                if el2.count() > 0:
                    el2.first.click()
                    page.wait_for_load_state("domcontentloaded")
                    time.sleep(3)
                    return
        except:
            pass

    def _handle_stay_signed_in(self, page, eid):
        """Handle 'Stay signed in?' prompt."""
        time.sleep(1)
        try:
            stay_btn = page.locator('#idSIButton9, #idBtn_Back, button:has-text("Yes"), button:has-text("No")')
            if stay_btn.count() > 0:
                current_url = page.url.lower()
                if "kmsi" in current_url or "stay" in page.inner_text("body").lower():
                    self.status_update.emit(eid, "Chon 'Yes' stay signed in...")
                    page.locator('#idSIButton9, button:has-text("Yes")').first.click()
                    time.sleep(2)
        except:
            pass

    def _handle_add_recovery_prompt(self, page, eid):
        """Handle Microsoft's prompt to add recovery info after login."""
        time.sleep(1)
        try:
            # Check for "looks like you need to update" or skip prompts
            skip_btn = page.locator(
                'a:has-text("Skip"), '
                'button:has-text("Skip"), '
                '#iCancel, '
                'a:has-text("skip for now")'
            )
            if skip_btn.count() > 0:
                self.status_update.emit(eid, "Bo qua prompt cap nhat...")
                skip_btn.first.click()
                time.sleep(2)
        except:
            pass

    def _check_error(self, page, eid):
        """Check for login error messages. Returns True if error found."""
        try:
            error_el = page.locator('#usernameError, #passwordError, #error, .alert-error, #idTD_Error')
            if error_el.count() > 0:
                error_text = error_el.first.inner_text()[:100]
                if error_text.strip():
                    self.error_signal.emit(eid, f"Login Failed - {error_text}")
                    return True
        except:
            pass

        # Check URL for known error patterns
        try:
            url = page.url.lower()
            if "error" in url or "lockout" in url or "cancel" in url:
                self.error_signal.emit(eid, f"Login Failed - URL: {url[:60]}")
                return True
        except:
            pass

        return False

    def _check_login_result(self, page, eid):
        """Check if login succeeded by examining final URL."""
        time.sleep(2)
        try:
            url = page.url.lower()
            if "outlook.live.com" in url or "outlook.office" in url or "mail.live.com" in url:
                self.status_update.emit(eid, "Login OK")
                self.login_done.emit(eid, {"status": "Login OK"})
            elif "account.live.com" in url or "account.microsoft.com" in url:
                self.status_update.emit(eid, "Login OK - Account page")
                self.login_done.emit(eid, {"status": "Login OK"})
            elif "login.live.com" in url or "login.microsoftonline" in url:
                # Still on login page = failed
                page_text = ""
                try:
                    page_text = page.inner_text("body")[:200]
                except:
                    pass
                self.error_signal.emit(eid, f"Login chua thanh cong - van o trang login")
            else:
                self.status_update.emit(eid, f"Login - {url[:40]}")
                self.login_done.emit(eid, {"status": "Login completed", "url": url})
        except:
            self.error_signal.emit(eid, "Khong the kiem tra ket qua login")


# ═══════════════════════════
#  Email Browser Manager
# ═══════════════════════════

class EmailBrowserManager:
    """Track and manage active browser sessions for email accounts."""
    def __init__(self):
        self.active_threads = {}  # email_id -> HotmailLoginThread

    def start_login(self, email_rec, login_type, headless=True,
                    recovery_domain="", recovery_provider="", recovery_suffix=""):
        eid = email_rec.get("id", "")
        # Stop existing session if any
        self.stop_session(eid)

        thread = HotmailLoginThread(
            email_rec, login_type, headless,
            recovery_domain, recovery_provider, recovery_suffix
        )
        self.active_threads[eid] = thread
        return thread

    def stop_session(self, email_id):
        if email_id in self.active_threads:
            thread = self.active_threads[email_id]
            thread._running = False
            try:
                thread.terminate()
            except:
                pass
            del self.active_threads[email_id]

    def stop_all(self):
        for eid in list(self.active_threads.keys()):
            self.stop_session(eid)
