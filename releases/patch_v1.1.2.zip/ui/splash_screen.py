"""
Splash Screen — Premium animated startup with particles, rotating ring, and loading bar.
Deep dark gradient with tech holographic depth effect.
"""
import os
import math
import random
from PyQt6.QtWidgets import QSplashScreen, QApplication
from PyQt6.QtCore import Qt, QTimer, QPointF
from PyQt6.QtGui import (
    QPainter, QColor, QFont, QLinearGradient, QRadialGradient,
    QPixmap, QPen, QBrush, QConicalGradient, QPainterPath
)


class Particle:
    """Floating particle for background effect."""
    def __init__(self, w, h):
        self.x = random.uniform(0, w)
        self.y = random.uniform(0, h)
        self.vx = random.uniform(-0.3, 0.3)
        self.vy = random.uniform(-0.5, -0.1)
        self.size = random.uniform(1.0, 3.0)
        self.alpha = random.randint(30, 100)
        self.w = w
        self.h = h

    def update(self):
        self.x += self.vx
        self.y += self.vy
        if self.y < -5:
            self.y = self.h + 5
            self.x = random.uniform(0, self.w)
        if self.x < -5:
            self.x = self.w + 5
        elif self.x > self.w + 5:
            self.x = -5


class SplashScreen(QSplashScreen):
    def __init__(self):
        self._w, self._h = 580, 400
        pix = QPixmap(self._w, self._h)
        pix.fill(Qt.GlobalColor.transparent)
        super().__init__(pix)
        self.setWindowFlags(
            Qt.WindowType.SplashScreen
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self._progress = 0
        self._status_text = "Đang khởi tạo..."
        self._opacity = 0.0
        self._angle = 0.0  # For rotating ring
        self._particles = [Particle(self._w, self._h) for _ in range(40)]

        # Fade in timer
        self._fade_timer = QTimer(self)
        self._fade_timer.setInterval(16)
        self._fade_timer.timeout.connect(self._fade_step)

        # Animation timer (particles + ring rotation + progress)
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(25)
        self._anim_timer.timeout.connect(self._anim_step)

        # Logo
        self._logo_pix = None
        logo_path = os.path.join(
            os.path.dirname(__file__), "..", "assets", "logo_circle.png"
        )
        if not os.path.exists(logo_path):
            logo_path = os.path.join(
                os.path.dirname(__file__), "..", "assets", "logo.png"
            )
        if os.path.exists(logo_path):
            self._logo_pix = QPixmap(logo_path).scaled(
                72, 72,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

    def show(self):
        super().show()
        self._fade_timer.start()

    def _fade_step(self):
        self._opacity = min(self._opacity + 0.035, 1.0)
        self.repaint()
        if self._opacity >= 1.0:
            self._fade_timer.stop()
            self._anim_timer.start()

    def _anim_step(self):
        self._angle = (self._angle + 2.0) % 360
        self._progress = min(self._progress + 0.8, 100)

        if self._progress < 20:
            self._status_text = "Đang tải module..."
        elif self._progress < 40:
            self._status_text = "Kiểm tra bản quyền..."
        elif self._progress < 60:
            self._status_text = "Khởi tạo Profile Manager..."
        elif self._progress < 80:
            self._status_text = "Khởi tạo giao diện..."
        else:
            self._status_text = "Sẵn sàng khởi động!"

        for p in self._particles:
            p.update()

        self.repaint()

        if self._progress >= 100:
            self._anim_timer.stop()

    def is_done(self):
        return self._progress >= 100

    def drawContents(self, painter: QPainter):
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setOpacity(self._opacity)

        w, h = self._w, self._h
        cx, cy = w / 2, h * 0.38

        # ─── Background ───
        bg = QLinearGradient(0, 0, w, h)
        bg.setColorAt(0.0, QColor(8, 10, 20))
        bg.setColorAt(0.3, QColor(12, 16, 35))
        bg.setColorAt(0.7, QColor(10, 14, 30))
        bg.setColorAt(1.0, QColor(6, 8, 16))
        painter.setBrush(QBrush(bg))
        painter.setPen(QPen(QColor(40, 60, 120, 100), 1.5))
        painter.drawRoundedRect(0, 0, w, h, 18, 18)

        # ─── Inner border glow ───
        inner_pen = QPen(QColor(59, 130, 246, 40), 1)
        painter.setPen(inner_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(2, 2, w - 4, h - 4, 16, 16)

        # ─── Particles ───
        for p in self._particles:
            painter.setPen(Qt.PenStyle.NoPen)
            c = QColor(96, 165, 250, p.alpha)
            painter.setBrush(c)
            painter.drawEllipse(QPointF(p.x, p.y), p.size, p.size)

        # ─── Radial glow (large) ───
        glow = QRadialGradient(cx, cy, w * 0.4)
        glow.setColorAt(0.0, QColor(59, 130, 246, 25))
        glow.setColorAt(0.3, QColor(59, 130, 246, 10))
        glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        painter.setBrush(QBrush(glow))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(cx, cy), w * 0.4, w * 0.4)

        # ─── Rotating ring ───
        painter.save()
        painter.translate(cx, cy - 10)
        painter.rotate(self._angle)

        ring_r = 52
        ring_grad = QConicalGradient(0, 0, 0)
        ring_grad.setColorAt(0.0, QColor(59, 130, 246, 180))
        ring_grad.setColorAt(0.3, QColor(96, 165, 250, 100))
        ring_grad.setColorAt(0.6, QColor(147, 197, 253, 40))
        ring_grad.setColorAt(1.0, QColor(59, 130, 246, 0))

        ring_pen = QPen(QBrush(ring_grad), 2.5)
        painter.setPen(ring_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(QPointF(0, 0), ring_r, ring_r)

        # Second ring (slower, larger)
        painter.rotate(-self._angle * 0.6)
        ring_pen2 = QPen(QColor(147, 197, 253, 30), 1)
        painter.setPen(ring_pen2)
        painter.drawEllipse(QPointF(0, 0), ring_r + 12, ring_r + 12)

        # Dot on ring
        dot_x = ring_r * math.cos(math.radians(0))
        dot_y = ring_r * math.sin(math.radians(0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(96, 165, 250, 200))
        painter.drawEllipse(QPointF(dot_x, dot_y), 4, 4)

        painter.restore()

        # ─── Logo (centered in ring, circular clip) ───
        if self._logo_pix:
            logo_size = 72
            lx = int(cx - logo_size / 2)
            ly = int(cy - logo_size / 2 - 10)

            # Circular clip path
            clip = QPainterPath()
            clip.addEllipse(float(lx), float(ly), float(logo_size), float(logo_size))
            painter.save()
            painter.setClipPath(clip)
            painter.drawPixmap(lx, ly, self._logo_pix)
            painter.restore()

            # Blue circle border
            painter.setPen(QPen(QColor(59, 130, 246, 180), 2.5))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawEllipse(lx, ly, logo_size, logo_size)

        # ─── Title ───
        font_title = QFont("Segoe UI", 24, QFont.Weight.Bold)
        font_title.setLetterSpacing(QFont.SpacingType.PercentageSpacing, 105)
        painter.setFont(font_title)

        # Text shadow
        painter.setPen(QColor(0, 0, 0, 80))
        painter.drawText(0, int(cy + 62), w, 36, Qt.AlignmentFlag.AlignCenter, "THE TIHA DEALER")
        # Main text
        painter.setPen(QColor(241, 245, 249))
        painter.drawText(0, int(cy + 60), w, 36, Qt.AlignmentFlag.AlignCenter, "THE TIHA DEALER")

        # ─── Subtitle ───
        font_sub = QFont("Segoe UI", 10)
        font_sub.setLetterSpacing(QFont.SpacingType.PercentageSpacing, 120)
        painter.setFont(font_sub)
        painter.setPen(QColor(148, 163, 184))
        painter.drawText(0, int(cy + 90), w, 20, Qt.AlignmentFlag.AlignCenter,
                         "FACEBOOK AUTOMATION PLATFORM")

        # ─── Decorative horizontal lines ───
        line_y = int(cy + 115)
        painter.setPen(QPen(QColor(59, 130, 246, 50), 1))
        painter.drawLine(60, line_y, int(cx) - 40, line_y)
        painter.drawLine(int(cx) + 40, line_y, w - 60, line_y)
        # Center diamond
        painter.setBrush(QColor(59, 130, 246, 80))
        pts = [QPointF(cx, line_y - 4), QPointF(cx + 4, line_y),
               QPointF(cx, line_y + 4), QPointF(cx - 4, line_y)]
        painter.drawPolygon(pts)

        # ─── Progress bar ───
        bar_x, bar_y = 50, h - 80
        bar_w, bar_h = w - 100, 4

        # Track
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(30, 41, 59, 150))
        painter.drawRoundedRect(bar_x, bar_y, bar_w, bar_h, 2, 2)

        # Fill with gradient
        fill_w = int(bar_w * self._progress / 100)
        if fill_w > 0:
            fg = QLinearGradient(bar_x, 0, bar_x + fill_w, 0)
            fg.setColorAt(0.0, QColor(59, 130, 246))
            fg.setColorAt(0.5, QColor(96, 165, 250))
            fg.setColorAt(1.0, QColor(147, 197, 253))
            painter.setBrush(QBrush(fg))
            painter.drawRoundedRect(bar_x, bar_y, fill_w, bar_h, 2, 2)

            # Glow on tip
            glow_tip = QRadialGradient(bar_x + fill_w, bar_y + 2, 12)
            glow_tip.setColorAt(0.0, QColor(96, 165, 250, 80))
            glow_tip.setColorAt(1.0, QColor(0, 0, 0, 0))
            painter.setBrush(QBrush(glow_tip))
            painter.drawEllipse(QPointF(bar_x + fill_w, bar_y + 2), 12, 12)

        # ─── Status text ───
        font_s = QFont("Segoe UI", 9)
        painter.setFont(font_s)
        painter.setPen(QColor(148, 163, 184))
        painter.drawText(bar_x, bar_y + 10, bar_w, 20,
                         Qt.AlignmentFlag.AlignLeft, self._status_text)

        pct = f"{int(self._progress)}%"
        painter.setPen(QColor(96, 165, 250))
        painter.drawText(bar_x, bar_y + 10, bar_w, 20,
                         Qt.AlignmentFlag.AlignRight, pct)

        # ─── Version & contact ───
        painter.setPen(QColor(71, 85, 105))
        font_v = QFont("Segoe UI", 8)
        painter.setFont(font_v)
        painter.drawText(0, h - 30, w - 20, 20,
                         Qt.AlignmentFlag.AlignRight,
                         "v1.0.1  •  t.me/ingredientthetiha")

        # ─── Scan lines (subtle CRT effect) ───
        painter.setPen(QColor(255, 255, 255, 3))
        for y in range(0, h, 3):
            painter.drawLine(0, y, w, y)
