import os
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, 
    QLabel, QComboBox, QCheckBox, QWidget, QMessageBox
)
from PyQt6.QtCore import Qt

class ImportDialog(QDialog):
    def __init__(self, parent=None, current_category="Default", all_categories=None):
        super().__init__(parent)
        self.setWindowTitle("Import Dữ liệu")
        self.resize(900, 600)
        self.current_category = current_category
        self.all_categories = all_categories or ["Default"]
        self._is_auto_detecting = False
        
        self.setStyleSheet("""
            QDialog {
                background-color: #1e293b;
                color: #e2e8f0;
            }
            QLabel {
                font-size: 13px;
                color: #e2e8f0;
            }
            QComboBox {
                border: 1px solid #475569;
                border-radius: 3px;
                padding: 3px 6px;
                background: #334155;
                color: #e2e8f0;
                min-width: 70px;
                font-size: 12px;
            }
            QComboBox::drop-down {
                border-left: 1px solid #475569;
                width: 18px;
                background: #475569;
            }
            QComboBox::down-arrow {
                width: 10px; height: 10px;
            }
            QComboBox QAbstractItemView {
                background: #334155;
                color: #e2e8f0;
                border: 1px solid #475569;
                selection-background-color: #3b82f6;
            }
            QTextEdit {
                border: 1px solid #475569;
                border-radius: 3px;
                background: #0f172a;
                color: #e2e8f0;
                font-family: Consolas, monospace;
                font-size: 12px;
            }
            QCheckBox {
                color: #e2e8f0;
                font-size: 12px;
            }
            QCheckBox::indicator {
                width: 16px; height: 16px;
                border: 2px solid #475569;
                border-radius: 3px;
                background: #0f172a;
            }
            QCheckBox::indicator:checked {
                background: #3b82f6;
                border-color: #3b82f6;
            }
            QPushButton#OkBtn {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #4bbdf5, stop:1 #1a8dfb);
                color: white;
                font-weight: bold;
                border: 1px solid #1a8dfb;
                border-radius: 4px;
                min-width: 150px;
                min-height: 35px;
                font-size: 13px;
            }
            QPushButton#OkBtn:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #5ecafb, stop:1 #2b9dff);
            }
        """)

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)

        # ── Top Row 1: Category ──
        row1 = QHBoxLayout()
        row1.setContentsMargins(0, 0, 0, 0)
        lbl_cat = QLabel("Chọn danh mục")
        lbl_cat.setFixedWidth(120)
        self.combo_cat = QComboBox()
        self.combo_cat.setFixedWidth(250)
        self.combo_cat.addItems(["Tất cả"] + [c for c in self.all_categories if c != "All Categories"])
        
        idx = self.combo_cat.findText(self.current_category)
        if idx >= 0:
            self.combo_cat.setCurrentIndex(idx)
        else:
            self.combo_cat.setCurrentIndex(0)
            
        row1.addWidget(lbl_cat)
        row1.addWidget(self.combo_cat)
        row1.addStretch()
        layout.addLayout(row1)

        # ── Top Row 2: Import Format Preset ──
        row2 = QHBoxLayout()
        row2.setContentsMargins(0, 0, 0, 0)
        lbl_fmt = QLabel("Định dạng nhập")
        lbl_fmt.setFixedWidth(120)
        self.combo_fmt = QComboBox()
        self.combo_fmt.setFixedWidth(250)
        # Add presets
        self.combo_fmt.addItem("All định dạng", [])
        self.combo_fmt.addItem("UID|PASS|2FA", ["fb_uid", "fb_pass", "fb_2fa"])
        self.combo_fmt.addItem("UID|PASS|2FA|Email|Pass Email", ["fb_uid", "fb_pass", "fb_2fa", "fb_email", "fb_pass_email"])
        self.combo_fmt.addItem("UID|PASS|2FA|Cookie|Token", ["fb_uid", "fb_pass", "fb_2fa", "fb_cookie", "fb_token"])
        self.combo_fmt.currentIndexChanged.connect(self.on_format_changed)
        
        row2.addWidget(lbl_fmt)
        row2.addWidget(self.combo_fmt)
        row2.addStretch()
        layout.addLayout(row2)

        layout.addSpacing(10)

        # ── Dynamic Mapping Combos Row ──
        map_layout = QHBoxLayout()
        map_layout.setSpacing(2)
        map_layout.setContentsMargins(0, 0, 0, 0)
        self.mapping_combos = []
        
        # Available fields to map
        mapping_options = [
            ("Bỏ qua", ""),
            ("UID", "fb_uid"),
            ("PASS", "fb_pass"),
            ("2FA", "fb_2fa"),
            ("Email", "fb_email"),
            ("Pass Email", "fb_pass_email"),
            ("Mail Reco", "fb_email_recovery"),
            ("Proxy", "fb_proxy"),
            ("Cookie", "fb_cookie"),
            ("UserAgent", "fb_useragent"),
            ("Token", "fb_token"),
            ("Birthday", "fb_dob"),
            ("UID Target", "fb_uid_target"),
            ("Note", "fb_note"),
            ("Friend", "fb_friends"),
            ("Ngày tạo", "fb_created"),
            ("Email Old", "fb_old_pass"),
            ("Gender", "fb_gender")
        ]
        
        # Create 18 mapping comboboxes
        for _ in range(18):
            cb = QComboBox()
            for text, data_key in mapping_options:
                cb.addItem(text, data_key)
            self.mapping_combos.append(cb)
            map_layout.addWidget(cb)
            
        # Add a small separator line visual if needed, but the layout naturally flows
        map_layout.addStretch()
        layout.addLayout(map_layout)

        # ── Text Area ──
        self.text_edit = QTextEdit()
        # Add slight margin top so it separates from combos
        self.text_edit.setStyleSheet("margin-top: 5px;")
        self.text_edit.textChanged.connect(self.auto_detect_format)
        layout.addWidget(self.text_edit)

        layout.addSpacing(10)

        # ── Bottom Row ──
        bottom_layout = QHBoxLayout()
        bottom_layout.setContentsMargins(0, 0, 0, 0)
        
        self.btn_ok = QPushButton("OK")
        self.btn_ok.setObjectName("OkBtn")
        self.btn_ok.clicked.connect(self.accept)
        
        self.chk_no_useragent = QCheckBox("Không lấy UserAgent từ cookie")
        
        self.combo_random_ua = QComboBox()
        self.combo_random_ua.setFixedWidth(250)
        self.combo_random_ua.addItems([
            "Random UserAgent Chrome Android",
            "Random UserAgent Chrome iOS",
            "Random UserAgent Chrome PC"
        ])
        
        # Position them tightly like the image
        bottom_layout.addWidget(self.btn_ok)
        bottom_layout.addSpacing(60) # Gap visually shown after button
        bottom_layout.addWidget(self.chk_no_useragent)
        bottom_layout.addSpacing(20)
        bottom_layout.addWidget(self.combo_random_ua)
        bottom_layout.addStretch()
        
        layout.addLayout(bottom_layout)
        
        # Init default format
        self.on_format_changed(0)

    def on_format_changed(self, index):
        if self._is_auto_detecting: return
        keys = self.combo_fmt.currentData()
        
        # Reset all to "Bỏ qua"
        for cb in self.mapping_combos:
            cb.setCurrentIndex(0)
            
        if keys:
            for i, key in enumerate(keys):
                if i < len(self.mapping_combos):
                    idx = self.mapping_combos[i].findData(key)
                    if idx >= 0:
                        self.mapping_combos[i].setCurrentIndex(idx)

    def auto_detect_format(self):
        if self._is_auto_detecting: return
        self._is_auto_detecting = True
        
        text = self.text_edit.toPlainText().strip()
        lines = [line for line in text.split('\n') if line.strip()]
        if not lines: 
            self._is_auto_detecting = False
            return
            
        first = lines[0]
        if '|' not in first:
            self._is_auto_detecting = False
            return
            
        parts = first.split('|')
        import re
        
        guessed_keys = []
        for i, p_str in enumerate(parts):
            p = p_str.strip()
            if re.match(r'^\d+$', p) and len(p) >= 6:
                guessed_keys.append("fb_uid")
            elif "c_user=" in p:
                guessed_keys.append("fb_cookie")
            elif p.startswith("EAAB"):
                guessed_keys.append("fb_token")
            elif "@" in p and "." in p:
                guessed_keys.append("fb_email")
            elif re.match(r'^[A-Z2-7]{16,32}$', p) or (re.match(r'^[A-Z0-9]{16,32}$', p) and len(p) >= 16):
                guessed_keys.append("fb_2fa")
            else:
                if i == 1:
                    guessed_keys.append("fb_pass")
                elif i == 4 and len(guessed_keys) > 3 and guessed_keys[3] == "fb_email":
                    guessed_keys.append("fb_pass_email")
                else:
                    guessed_keys.append("")

        # Update the UI
        self.combo_fmt.blockSignals(True)
        self.combo_fmt.setCurrentIndex(0) # Switch to custom
        self.combo_fmt.blockSignals(False)
        
        # Block signals on combos
        for cb in self.mapping_combos: cb.blockSignals(True)
        
        for i, cb in enumerate(self.mapping_combos):
            if i < len(guessed_keys):
                key = guessed_keys[i]
                idx = cb.findData(key) if key else 0
                cb.setCurrentIndex(idx if idx >= 0 else 0)
            else:
                cb.setCurrentIndex(0)
                
        for cb in self.mapping_combos: cb.blockSignals(False)
                
        self._is_auto_detecting = False

    def get_parsed_data(self):
        text = self.text_edit.toPlainText().strip()
        if not text:
            return None, []
            
        category = self.combo_cat.currentText()
        if category in ("All Categories", "Tất cả"): category = "Default"
        
        mappings = [cb.currentData() for cb in self.mapping_combos]
        results = []
        
        # Handle UserAgent randomness config
        generate_ua = not self.chk_no_useragent.isChecked()
        ua_type = self.combo_random_ua.currentText()
        
        for line in text.split('\n'):
            line = line.strip()
            if not line: continue
            
            parts = line.split('|')
            profile_data = {"category": category}
            
            for i, part in enumerate(parts):
                if i < len(mappings):
                    key = mappings[i]
                    if key: # Not empty / 'Bỏ qua'
                        profile_data[key] = part.strip()
            
            if generate_ua and not profile_data.get("fb_useragent"):
                if "Android" in ua_type:
                    profile_data["fb_useragent"] = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                elif "iOS" in ua_type:
                    profile_data["fb_useragent"] = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/120.0.6099.119 Mobile/15E148 Safari/604.1"
                else:
                    profile_data["fb_useragent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            
            # Use sensible name default
            if not profile_data.get("name"):
                profile_data["name"] = profile_data.get("fb_uid", profile_data.get("fb_email", "New Profile"))
                
            results.append(profile_data)
            
        return category, results
