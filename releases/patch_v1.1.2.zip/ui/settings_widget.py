"""
SettingsWidget — Embeddable settings panel (QWidget) for use as a main tab.
Reuses the same logic as SettingsDialog but as a QWidget, not QDialog.
"""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel,
    QPushButton, QLineEdit, QCheckBox, QComboBox, QSpinBox,
    QScrollArea, QGroupBox, QGridLayout, QButtonGroup,
    QRadioButton, QProgressBar, QMessageBox
)
from PyQt6.QtCore import Qt, pyqtSignal
from ui.settings_dialog import (
    load_settings, save_settings, ALL_COLUMNS, tr, set_language,
    install_chromium
)
from core.updater import check_for_update, download_and_install, apply_update


class SettingsWidget(QWidget):
    """Embeddable settings widget with sub-tabs. Emits settings_changed when saved."""
    settings_changed = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.settings = load_settings()
        self.column_settings = self.settings.get("columns", {})
        self.checkboxes = {}

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(4, 4, 4, 4)

        self.tabs = QTabWidget()
        self.tab_chung = QWidget()
        self.tab_browser = QWidget()
        self.tab_browser_type = QWidget()
        self.tab_columns = QWidget()

        self.tabs.addTab(self.tab_chung, "Cài đặt chung")
        self.tabs.addTab(self.tab_browser, "Trình duyệt")
        self.tabs.addTab(self.tab_browser_type, "Loại trình duyệt")
        self.tabs.addTab(self.tab_columns, "Hiển thị cột")

        self._init_tab_chung()
        self._init_tab_browser()
        self._init_tab_browser_type()
        self._init_tab_columns()

        main_layout.addWidget(self.tabs)

        # Save button
        btn_layout = QHBoxLayout()
        self.btn_save = QPushButton("Lưu cài đặt")
        self.btn_save.setObjectName("SaveAllBtn")
        self.btn_save.setMinimumHeight(36)
        self.btn_save.setMinimumWidth(140)
        self.btn_save.setStyleSheet("""
            QPushButton#SaveAllBtn {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #33bbf6, stop:1 #0f7bf8);
                color: white; font-weight: bold; font-size: 13px;
                border: 1px solid #0056b3; border-radius: 4px;
            }
            QPushButton#SaveAllBtn:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #4dc6fb, stop:1 #218cff);
            }
        """)
        self.btn_save.clicked.connect(self._on_save)
        btn_layout.addWidget(self.btn_save)
        btn_layout.addStretch()
        main_layout.addLayout(btn_layout)

    # ═══════════════════════════════════════════
    #  Tab 1: General Settings
    # ═══════════════════════════════════════════
    def _init_tab_chung(self):
        layout = QVBoxLayout(self.tab_chung)
        layout.setSpacing(10)

        # Chrome Scale
        scale_lay = QHBoxLayout()
        scale_lay.addWidget(QLabel("Kích thước browser (% màn hình, vd 0.25 = 4 tab/hàng)"))
        self.input_scale = QLineEdit()
        self.input_scale.setText(self.settings.get("chrome_scale", "0.9"))
        self.input_scale.setFixedWidth(80)
        scale_lay.addWidget(self.input_scale)
        layout.addLayout(scale_lay)

        # Network timeout
        timeout_lay = QHBoxLayout()
        timeout_lay.addWidget(QLabel("Thời gian chờ mạng (ms)"))
        self.input_timeout = QLineEdit()
        self.input_timeout.setText(str(self.settings.get("network_timeout", "30000")))
        self.input_timeout.setFixedWidth(80)
        timeout_lay.addWidget(self.input_timeout)
        layout.addLayout(timeout_lay)

        # Startup URL
        url_lay = QHBoxLayout()
        url_lay.addWidget(QLabel("URL khởi động"))
        self.input_urls = QLineEdit()
        self.input_urls.setText(self.settings.get("startup_urls", "https://www.facebook.com"))
        url_lay.addWidget(self.input_urls)
        layout.addLayout(url_lay)

        # Chrome Profile Base Path
        path_lay = QHBoxLayout()
        path_lay.addWidget(QLabel("Thư mục lưu Profile Chrome"))
        self.input_profile_path = QLineEdit()
        self.input_profile_path.setText(self.settings.get("chrome_profile_base_path", ""))
        self.input_profile_path.setPlaceholderText("Để trống = mặc định (data/profiles/)")
        path_lay.addWidget(self.input_profile_path)
        layout.addLayout(path_lay)

        # Cookie method
        cookie_lay = QHBoxLayout()
        cookie_lay.addWidget(QLabel("Phương thức Login Cookie"))
        self.combo_cookie_method = QComboBox()
        self.combo_cookie_method.addItems(["Playwright (chính xác)", "Fetch API (nhanh)"])
        current_method = self.settings.get("cookie_login_method", "Playwright (chính xác)")
        idx = self.combo_cookie_method.findText(current_method)
        if idx >= 0:
            self.combo_cookie_method.setCurrentIndex(idx)
        cookie_lay.addWidget(self.combo_cookie_method)
        layout.addLayout(cookie_lay)

        layout.addStretch()

    # ═══════════════════════════════════════════
    #  Tab 2: Browser Settings (checkboxes)
    # ═══════════════════════════════════════════
    def _init_tab_browser(self):
        layout = QVBoxLayout(self.tab_browser)

        # ═══════════════════════════════════════════
        # CAPTCHA Settings Group (prominent, at top)
        # ═══════════════════════════════════════════
        captcha_group = QGroupBox("🤖 Cài đặt giải CAPTCHA tự động")
        captcha_group.setStyleSheet("""
            QGroupBox {
                border: 2px solid #3b82f6;
                border-radius: 6px;
                margin-top: 1.5ex;
                padding: 10px 8px 8px 8px;
                background-color: #1a2744;
                font-weight: bold;
                font-size: 13px;
                color: #93c5fd;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 6px;
                color: #60a5fa;
            }
            QLabel { color: #e2e8f0; }
            QLineEdit {
                background: #0f172a; color: #f1f5f9;
                border: 1px solid #3b82f6; border-radius: 3px;
                padding: 4px 6px;
            }
            QComboBox {
                background: #0f172a; color: #f1f5f9;
                border: 1px solid #3b82f6; border-radius: 3px;
                padding: 2px 6px;
            }
            QSpinBox {
                background: #0f172a; color: #f1f5f9;
                border: 1px solid #3b82f6; border-radius: 3px;
                padding: 2px 4px;
            }
        """)
        captcha_lay = QVBoxLayout(captcha_group)
        captcha_lay.setSpacing(6)

        # API Key row
        key_row = QHBoxLayout()
        key_row.addWidget(QLabel("API Key:"))
        self.captcha_key_input = QLineEdit()
        self.captcha_key_input.setText(self.settings.get("two_captcha_key", ""))
        self.captcha_key_input.setPlaceholderText("API Key (2captcha / anti-captcha / capsolver)")
        key_row.addWidget(self.captcha_key_input)
        captcha_lay.addLayout(key_row)

        # OmoCaptcha Key row
        omo_row = QHBoxLayout()
        omo_row.addWidget(QLabel("OmoCaptcha:"))
        self.omocaptcha_key_input = QLineEdit()
        self.omocaptcha_key_input.setText(self.settings.get("omocaptcha_key", ""))
        self.omocaptcha_key_input.setPlaceholderText("OmoCaptcha API Key (omocaptcha.com)")
        omo_row.addWidget(self.omocaptcha_key_input)
        captcha_lay.addLayout(omo_row)

        # Provider + Timeout + Retries row
        opts_row = QHBoxLayout()
        opts_row.addWidget(QLabel("Provider:"))
        self.combo_captcha_provider = QComboBox()
        self.combo_captcha_provider.addItems(["2captcha", "omocaptcha", "anti-captcha", "capsolver"])
        self.combo_captcha_provider.setCurrentText(self.settings.get("captcha_provider", "2captcha"))
        self.combo_captcha_provider.setFixedWidth(120)
        opts_row.addWidget(self.combo_captcha_provider)
        opts_row.addSpacing(10)
        opts_row.addWidget(QLabel("Timeout:"))
        self.spin_captcha_timeout = QSpinBox()
        self.spin_captcha_timeout.setRange(30, 300)
        self.spin_captcha_timeout.setValue(int(self.settings.get("captcha_timeout", 120)))
        self.spin_captcha_timeout.setSuffix("s")
        self.spin_captcha_timeout.setFixedWidth(75)
        opts_row.addWidget(self.spin_captcha_timeout)
        opts_row.addSpacing(10)
        opts_row.addWidget(QLabel("Retries:"))
        self.spin_captcha_retries = QSpinBox()
        self.spin_captcha_retries.setRange(1, 5)
        self.spin_captcha_retries.setValue(int(self.settings.get("captcha_retries", 2)))
        self.spin_captcha_retries.setFixedWidth(50)
        opts_row.addWidget(self.spin_captcha_retries)
        opts_row.addStretch()
        captcha_lay.addLayout(opts_row)

        layout.addWidget(captcha_group)
        layout.addSpacing(6)

        # ═══════════════════════════════════════════
        # Browser checkboxes
        # ═══════════════════════════════════════════
        self.chk_mute_chrome = QCheckBox("Tắt tiếng chrome")
        self.chk_mute_chrome.setChecked(self.settings.get("mute_chrome", True))
        layout.addWidget(self.chk_mute_chrome)

        self.chk_close_chrome = QCheckBox("Tắt chrome sau khi Login/SetCookie")
        self.chk_close_chrome.setChecked(self.settings.get("close_chrome_after_login", True))
        layout.addWidget(self.chk_close_chrome)

        self.chk_disable_notif = QCheckBox("Tắt thông báo khi xong")
        self.chk_disable_notif.setChecked(self.settings.get("disable_done_notification", False))
        layout.addWidget(self.chk_disable_notif)

        self.chk_check_cp = QCheckBox("Kiểm tra Checkpoint khi Check Cookie")
        self.chk_check_cp.setChecked(self.settings.get("check_cp_when_checking_cookie", True))
        layout.addWidget(self.chk_check_cp)

        self.chk_del_chrome = QCheckBox("Xóa folder Chrome sau khi Login")
        self.chk_del_chrome.setChecked(self.settings.get("delete_chrome_folder_after_login", False))
        layout.addWidget(self.chk_del_chrome)

        self.chk_incognito = QCheckBox("Chế độ ẩn danh (Incognito)")
        self.chk_incognito.setChecked(self.settings.get("incognito_mode", False))
        layout.addWidget(self.chk_incognito)

        self.chk_check_info_api = QCheckBox("Kiểm tra thông tin sau Login API")
        self.chk_check_info_api.setChecked(self.settings.get("check_info_after_api_login", False))
        layout.addWidget(self.chk_check_info_api)

        self.chk_del_profile = QCheckBox("Xóa Chrome Profile khi xóa tài khoản")
        self.chk_del_profile.setChecked(self.settings.get("delete_chrome_profile_on_delete_acc", True))
        layout.addWidget(self.chk_del_profile)

        self.chk_use_captcha = QCheckBox("Sử dụng bypass captcha (www)")
        self.chk_use_captcha.setChecked(self.settings.get("use_captcha_bypass_www", False))
        layout.addWidget(self.chk_use_captcha)

        self.chk_disable_webrtc = QCheckBox("Tắt WebRTC (ẩn IP thật khi dùng Proxy/VPN)")
        self.chk_disable_webrtc.setChecked(self.settings.get("disable_webrtc", False))
        layout.addWidget(self.chk_disable_webrtc)

        # Fix Browser button
        btn_fix = QPushButton("Fix Browser (Cài lại Chromium)")
        btn_fix.clicked.connect(self._fix_browser)
        layout.addWidget(btn_fix)

        layout.addStretch()

    # ═══════════════════════════════════════════
    #  Tab 3: Browser Type Selection
    # ═══════════════════════════════════════════
    def _init_tab_browser_type(self):
        layout = QVBoxLayout(self.tab_browser_type)
        layout.setSpacing(6)

        title = QLabel("Chọn loại trình duyệt mặc định cho Tool")
        title.setStyleSheet("font-weight: bold; font-size: 13px;")
        layout.addWidget(title)

        self.browser_group = QButtonGroup(self)
        browsers_info = [
            ("Chromium", "Playwright built-in — Hỗ trợ đầy đủ"),
            ("Firefox", "Playwright built-in — Hỗ trợ đầy đủ"),
            ("Google Chrome", "Phổ biến nhất, hỗ trợ đa profile"),
            ("Microsoft Edge", "Chromium-based, nhẹ và nhanh"),
            ("Brave", "Bảo mật cao, chặn quảng cáo"),
        ]
        stored_browser = self.settings.get("selected_browser", "Chromium")

        self.radio_buttons = {}
        self.browser_status_labels = {}
        self.browser_install_buttons = {}

        for name, desc in browsers_info:
            # Row: [RadioButton] [Status Label] [Install/Update Button]
            row = QHBoxLayout()
            row.setSpacing(8)
            
            rb = QRadioButton(name)
            if name == stored_browser:
                rb.setChecked(True)
            self.radio_buttons[name] = rb
            self.browser_group.addButton(rb)
            rb.setStyleSheet("font-weight: bold; min-width: 110px;")
            rb.setFixedWidth(130)
            row.addWidget(rb)

            # Status label per browser
            status_lbl = QLabel("")
            status_lbl.setStyleSheet("font-size: 10px; color: #888;")
            status_lbl.setMinimumWidth(200)
            self.browser_status_labels[name] = status_lbl
            row.addWidget(status_lbl, stretch=1)

            # Install/Update button
            btn = QPushButton("Cài đặt")
            btn.setFixedWidth(80)
            btn.setFixedHeight(26)
            btn.setStyleSheet("""
                QPushButton { 
                    background: #2196F3; color: white; border-radius: 4px;
                    font-size: 11px; font-weight: bold; 
                }
                QPushButton:hover { background: #1976D2; }
                QPushButton:disabled { background: #ccc; color: #888; }
            """)
            btn.clicked.connect(lambda checked, n=name: self._install_browser(n))
            self.browser_install_buttons[name] = btn
            row.addWidget(btn)

            layout.addLayout(row)

        layout.addSpacing(10)

        # Global progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedHeight(18)
        layout.addWidget(self.progress_bar)

        # Global status + rescan
        status_row = QHBoxLayout()
        self.lbl_install_status = QLabel("")
        self.lbl_install_status.setWordWrap(True)
        self.lbl_install_status.setStyleSheet("font-size: 11px;")
        self.btn_rescan = QPushButton("🔍 Quét lại tất cả")
        self.btn_rescan.setFixedWidth(120)
        self.btn_rescan.clicked.connect(self._scan_all_browsers)
        status_row.addWidget(self.lbl_install_status, stretch=1)
        status_row.addWidget(self.btn_rescan)
        layout.addLayout(status_row)

        layout.addStretch()

        self.browser_group.buttonClicked.connect(self._on_browser_selection_changed)
        self._installing = False
        
        # Initial scan
        self._scan_all_browsers()

    # ═══════════════════════════════════════════
    #  Tab 4: Column Visibility
    # ═══════════════════════════════════════════
    def _init_tab_columns(self):
        layout = QVBoxLayout(self.tab_columns)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("""
            QScrollArea { 
                background-color: #1e293b; 
                border: 1px solid #334155; 
                border-radius: 4px; 
            }
        """)
        container = QWidget()
        container.setStyleSheet("""
            QWidget { background-color: #1e293b; }
            QCheckBox { 
                color: #e2e8f0; 
                font-size: 12px; 
                spacing: 8px; 
                padding: 4px 2px; 
            }
            QCheckBox::indicator {
                width: 16px; height: 16px;
                border: 2px solid #475569;
                border-radius: 3px;
                background: #0f172a;
            }
            QCheckBox::indicator:checked {
                background: #3b82f6;
                border-color: #3b82f6;
            }
            QCheckBox::indicator:hover {
                border-color: #a78bfa;
            }
        """)
        grid = QGridLayout(container)
        grid.setSpacing(6)

        for i, (key, label, default) in enumerate(ALL_COLUMNS):
            if key == "stt":
                continue
            chk = QCheckBox(label)
            chk.setChecked(self.column_settings.get(key, default))
            self.checkboxes[key] = chk
            grid.addWidget(chk, i // 2, i % 2)

        scroll.setWidget(container)
        layout.addWidget(scroll)

        btn_row = QHBoxLayout()
        btn_all = QPushButton("Chọn tất cả")
        btn_all.clicked.connect(lambda: [c.setChecked(True) for c in self.checkboxes.values()])
        btn_none = QPushButton("Bỏ chọn tất cả")
        btn_none.clicked.connect(lambda: [c.setChecked(False) for c in self.checkboxes.values()])
        btn_row.addWidget(btn_all)
        btn_row.addWidget(btn_none)
        btn_row.addStretch()
        layout.addLayout(btn_row)

    # ═══════════════════════════════════════════
    #  Browser Detection & Install
    # ═══════════════════════════════════════════
    def _scan_all_browsers(self):
        """Scan all browsers and update individual status labels & buttons."""
        import os
        from core.browser_manager import SmartBrowserDetector

        pw_dir = os.path.join(os.environ.get("LOCALAPPDATA", ""), "ms-playwright")
        
        for name, lbl in self.browser_status_labels.items():
            btn = self.browser_install_buttons[name]
            found = False
            path_info = ""

            if name == "Chromium":
                if os.path.isdir(pw_dir):
                    for d in os.listdir(pw_dir):
                        if d.startswith("chromium-"):
                            ch = os.path.join(pw_dir, d, "chrome-win64", "chrome.exe")
                            if not os.path.exists(ch):
                                ch = os.path.join(pw_dir, d, "chrome-win", "chrome.exe")
                            if os.path.exists(ch):
                                found = True
                                path_info = ch
                                break

            elif name == "Firefox":
                if os.path.isdir(pw_dir):
                    for d in os.listdir(pw_dir):
                        if d.startswith("firefox-"):
                            ff = os.path.join(pw_dir, d, "firefox", "firefox.exe")
                            if os.path.exists(ff):
                                found = True
                                path_info = ff
                                break
            else:
                path = SmartBrowserDetector.find_browser(name)
                if path:
                    found = True
                    path_info = path

            if found:
                short_path = path_info.replace("\\", "/").split("/")[-3:]
                lbl.setText(f"✅ .../{'/'.join(short_path)}")
                lbl.setStyleSheet("font-size: 10px; color: green;")
                btn.setText("Cập nhật")
                btn.setStyleSheet("""
                    QPushButton { 
                        background: #4CAF50; color: white; border-radius: 4px;
                        font-size: 11px; font-weight: bold; 
                    }
                    QPushButton:hover { background: #388E3C; }
                    QPushButton:disabled { background: #ccc; color: #888; }
                """)
            else:
                lbl.setText("❌ Chưa cài đặt")
                lbl.setStyleSheet("font-size: 10px; color: red;")
                btn.setText("Cài đặt")
                btn.setStyleSheet("""
                    QPushButton { 
                        background: #2196F3; color: white; border-radius: 4px;
                        font-size: 11px; font-weight: bold; 
                    }
                    QPushButton:hover { background: #1976D2; }
                    QPushButton:disabled { background: #ccc; color: #888; }
                """)

    def _on_browser_selection_changed(self):
        """Just save the selection — no detection needed (scan does that)."""
        pass  # Selection is saved when user clicks Save

    def _install_browser(self, browser_name):
        """One-click install/update for any browser."""
        if self._installing:
            return
        self._installing = True
        
        # Disable all install buttons
        for btn in self.browser_install_buttons.values():
            btn.setEnabled(False)

        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.lbl_install_status.setText(f"Đang cài đặt/cập nhật {browser_name}...")
        self.lbl_install_status.setStyleSheet("color: #2196F3; font-weight: bold;")

        from core.browser_installer import BrowserInstallerWorker
        is_update = self.browser_install_buttons[browser_name].text() == "Cập nhật"
        self.installer_worker = BrowserInstallerWorker(browser_name, action="update" if is_update else "install")
        self.installer_worker.progress.connect(self._on_install_progress)
        self.installer_worker.finished.connect(self._on_install_finished)
        self.installer_worker.start()

    def _on_install_progress(self, val, msg):
        self.progress_bar.setValue(val)
        self.lbl_install_status.setText(msg)

    def _on_install_finished(self, success, msg):
        self._installing = False
        self.progress_bar.setValue(100 if success else 0)
        self.progress_bar.setVisible(False)
        
        # Re-enable all install buttons
        for btn in self.browser_install_buttons.values():
            btn.setEnabled(True)

        if success:
            self.lbl_install_status.setText(f"✅ {msg}")
            self.lbl_install_status.setStyleSheet("color: green; font-weight: bold;")
        else:
            self.lbl_install_status.setText(f"❌ {msg}")
            self.lbl_install_status.setStyleSheet("color: red; font-weight: bold;")
        
        # Rescan to update status
        self._scan_all_browsers()

    def _fix_browser(self):
        QMessageBox.information(self, "Fix Browser", "Đang cài lại Chromium...")
        if install_chromium():
            QMessageBox.information(self, "Fix Browser", "Cài đặt Chromium thành công!")
        else:
            QMessageBox.warning(self, "Fix Browser", "Không thể cài đặt Chromium.")

    # ═══════════════════════════════════════════
    #  Save Settings
    # ═══════════════════════════════════════════
    def _on_save(self):
        new_columns = {key: chk.isChecked() for key, chk in self.checkboxes.items()}
        new_columns["stt"] = True

        new_settings = {
            "columns": new_columns,
            "language": "vi",
            "omocaptcha_key": "",
            "categories": self.settings.get("categories", ["Default"]),

            "chrome_scale": self.input_scale.text().strip(),
            "network_timeout": self.input_timeout.text().strip(),
            "startup_urls": self.input_urls.text().strip(),
            "chrome_profile_base_path": self.input_profile_path.text().strip(),

            "mute_chrome": self.chk_mute_chrome.isChecked(),
            "close_chrome_after_login": self.chk_close_chrome.isChecked(),
            "disable_done_notification": self.chk_disable_notif.isChecked(),
            "check_cp_when_checking_cookie": self.chk_check_cp.isChecked(),
            "delete_chrome_folder_after_login": self.chk_del_chrome.isChecked(),
            "incognito_mode": self.chk_incognito.isChecked(),
            "check_info_after_api_login": self.chk_check_info_api.isChecked(),
            "delete_chrome_profile_on_delete_acc": self.chk_del_profile.isChecked(),
            "use_captcha_bypass_www": self.chk_use_captcha.isChecked(),
            "disable_webrtc": self.chk_disable_webrtc.isChecked(),
            "cookie_login_method": self.combo_cookie_method.currentText(),
            "selected_browser": self.browser_group.checkedButton().text()
                if hasattr(self, 'browser_group') else "Chromium",

            # CAPTCHA Settings
            "two_captcha_key": self.captcha_key_input.text().strip() if hasattr(self, 'captcha_key_input') else self.settings.get("two_captcha_key", ""),
            "omocaptcha_key": self.omocaptcha_key_input.text().strip() if hasattr(self, 'omocaptcha_key_input') else self.settings.get("omocaptcha_key", ""),
            "captcha_provider": self.combo_captcha_provider.currentText() if hasattr(self, 'combo_captcha_provider') else self.settings.get("captcha_provider", "2captcha"),
            "captcha_timeout": self.spin_captcha_timeout.value() if hasattr(self, 'spin_captcha_timeout') else self.settings.get("captcha_timeout", 120),
            "captcha_retries": self.spin_captcha_retries.value() if hasattr(self, 'spin_captcha_retries') else self.settings.get("captcha_retries", 2),
        }

        save_settings(new_settings)
        self.settings = new_settings
        self.settings_changed.emit(new_settings)
        QMessageBox.information(self, "Cài đặt", "Đã lưu cài đặt thành công!")
