import json
import os
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, 
    QLabel, QCheckBox, QScrollArea, QWidget, QDialogButtonBox, QGridLayout, QComboBox, QMessageBox, QLineEdit, QSpinBox, QTabWidget
)
from PyQt6.QtCore import Qt
from core.i18n import tr, set_language
from core.updater import check_for_update, download_and_install, apply_update
from core.browser_manager import install_chromium

SETTINGS_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "settings.json")

# All available columns: (key, display_label, default_visible)
ALL_COLUMNS = [
    ("stt",            "STT",              True),
    ("name",           "Tên Hồ Sơ",        True),
    ("fb_uid",         "UID",              True),
    ("fb_pass",        "Password",         True),
    ("fb_2fa",         "2FA Key",          True),
    ("fb_level",       "Level",            True),
    ("fb_pass_email",  "Pass Email",       True),
    ("fb_email",       "Email",            True),
    ("fb_email_recovery", "Email Recovery",True),
    ("fb_gender",      "Giới tính",        True),
    ("fb_friends",     "Friends",          True),
    ("fb_live",        "Live",             True),
    ("status",         "Trạng thái",       True),
    ("fb_note",        "Ghi Chú",          True),
    ("fb_spend",       "Chi Phí",          False),
    ("fb_old_pass",    "Password Old",     False),
    ("fb_name",        "Tên FB",           True),
    ("fb_location",    "Location",         False),
    ("fb_proxy",       "Proxy",            False),
    ("fb_cookie",      "Cookie",           False),
    ("fb_pass_lim",    "PassLim",          False),
    ("fb_uid_target",  "UID Target",       False),
    ("fb_useragent",   "UserAgent",        False),
    ("fb_useragent_android", "UserAgent Android", False),
    ("fb_token",       "Token",            False),
    ("fb_dob",         "Ngày sinh",        True),
    ("fb_created",     "Ngày tạo",         True),
    ("fb_token_hotmail","Token Hotmail",   False),
    ("fb_backup",      "Backup",           False),
]

def load_settings():
    os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
    if not os.path.exists(SETTINGS_FILE):
        return {
            "columns": {col[0]: col[2] for col in ALL_COLUMNS},
            "language": "vi",
            "browser_width": 640,
            "browser_height": 480,
            "omocaptcha_key": "",
            "two_captcha_key": ""
        }
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            stored = json.load(f)
        
        # Migrating old settings format if necessary
        if "columns" not in stored:
            stored = {"columns": stored, "language": "vi", "browser_width": 640, "browser_height": 480, "omocaptcha_key": "", "two_captcha_path": r"C:\Users\Xeon\Desktop\2captcha-python-master", "categories": ["Default"]}
            
        # Fill in any new columns with defaults
        current_cols = {col[0]: col[2] for col in ALL_COLUMNS}
        current_cols.update(stored.get("columns", {}))
        stored["columns"] = current_cols
        
        if "browser_width" not in stored: stored["browser_width"] = 640
        if "browser_height" not in stored: stored["browser_height"] = 480
        if "omocaptcha_key" not in stored: stored["omocaptcha_key"] = ""
        if "two_captcha_key" not in stored: stored["two_captcha_key"] = ""
        if "two_captcha_path" not in stored: stored["two_captcha_path"] = r"C:\Users\Xeon\Desktop\2captcha-python-master"
        if "captcha_provider" not in stored: stored["captcha_provider"] = "2captcha"
        if "captcha_timeout" not in stored: stored["captcha_timeout"] = 120
        if "captcha_retries" not in stored: stored["captcha_retries"] = 2
        if "categories" not in stored: stored["categories"] = ["Default"]
        
        # New Settings from grid layout mockup
        if "chrome_scale" not in stored: stored["chrome_scale"] = "0.9"
        if "network_timeout" not in stored: stored["network_timeout"] = "120"
        if "startup_urls" not in stored: stored["startup_urls"] = "https://www.facebook.com"
        if "chrome_profile_base_path" not in stored: stored["chrome_profile_base_path"] = ""
        
        # Load language into i18n
        set_language(stored.get("language", "vi"))
        
        return stored
    except Exception:
        return {
            "columns": {col[0]: col[2] for col in ALL_COLUMNS}, 
            "language": "vi",
            "browser_width": 640,
            "browser_height": 480,
            "omocaptcha_key": "",
            "categories": ["Default"]
        }

def save_settings(settings: dict):
    os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)
    # Apply language change globally
    set_language(settings.get("language", "vi"))

def get_visible_columns():
    """Return list of (key, label) for all currently visible columns."""
    settings = load_settings()
    col_settings = settings.get("columns", {})
    return [(key, label) for key, label, default in ALL_COLUMNS if col_settings.get(key, default)]


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("settings_title"))
        self.resize(560, 650)
        
        self.settings = load_settings()
        self.column_settings = self.settings.get("columns", {})
        self.checkboxes = {}
        
        main_layout = QVBoxLayout(self)
        
        self.tabs = QTabWidget()
        
        self.tab_chung = QWidget()
        self.tab_browser = QWidget()
        self.tab_browser_type = QWidget()
        self.tab_columns = QWidget()
        
        self.tabs.addTab(self.tab_chung, "Setting Chung")
        self.tabs.addTab(self.tab_browser, "Setting Trình Duyệt")
        self.tabs.addTab(self.tab_browser_type, "Setting Loại Trình Duyệt")
        self.tabs.addTab(self.tab_columns, "Setting Cột")
        
        self.apply_theme()
        
        self.init_tab_chung()
        self.init_tab_browser()
        self.init_tab_browser_type()
        self.init_tab_columns()
        
        main_layout.addWidget(self.tabs)
        
        # Action Buttons Bottom
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self._on_ok)
        btns.rejected.connect(self.reject)
        
        btn_layout = QHBoxLayout()
        btn_layout.addWidget(btns)
        main_layout.addLayout(btn_layout)

    def apply_theme(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #f0f0f0;
                color: #000000;
            }
            QLabel {
                color: #000000;
                font-family: 'Segoe UI', Arial;
            }
            QGroupBox {
                border: 1px solid #99ccff;
                border-radius: 4px;
                margin-top: 1ex;
                background-color: #f0f8ff;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px 0 3px;
                color: #333333;
                font-weight: bold;
            }
            QCheckBox {
                color: #000000;
                spacing: 6px;
            }
            QScrollArea {
                border: 1px solid #adadad;
                background-color: #ffffff;
            }
            QWidget#container {
                background-color: #ffffff;
            }
            QLineEdit, QSpinBox, QComboBox {
                background-color: #ffffff;
                border: 1px solid #99ccff;
                border-radius: 2px;
                padding: 4px 8px;
                color: #000000;
            }
            QLineEdit:focus, QSpinBox:focus, QComboBox:focus {
                border-color: #0078d7;
            }
            QPushButton {
                background: #e1e1e1;
                border: 1px solid #adadad;
                border-radius: 2px;
                padding: 6px 12px;
                color: #000000;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #e5f1fb;
                border-color: #0078d7;
            }
        """)

    def init_tab_chung(self):
        from PyQt6.QtWidgets import QGroupBox
        layout = QVBoxLayout(self.tab_chung)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Group 1: Scale and Timeout
        row1 = QHBoxLayout()
        
        group_scale = QGroupBox()
        scale_lay = QVBoxLayout(group_scale)
        scale_lay.addWidget(QLabel("Kích thước browser (tỷ lệ màn hình)"))
        
        from PyQt6.QtWidgets import QDoubleSpinBox
        scale_row = QHBoxLayout()
        self.spin_scale = QDoubleSpinBox()
        self.spin_scale.setRange(0.1, 1.0)
        self.spin_scale.setSingleStep(0.1)
        self.spin_scale.setDecimals(1)
        try:
            val = float(self.settings.get("chrome_scale", "0.25"))
        except (ValueError, TypeError):
            val = 0.5
        self.spin_scale.setValue(max(0.1, min(1.0, val)))
        self.spin_scale.setFixedWidth(80)
        self.spin_scale.valueChanged.connect(self._update_scale_preview)
        scale_row.addWidget(self.spin_scale)
        
        self.lbl_scale_preview = QLabel()
        self.lbl_scale_preview.setStyleSheet("color: #0078d7; font-size: 11px;")
        scale_row.addWidget(self.lbl_scale_preview)
        scale_row.addStretch()
        scale_lay.addLayout(scale_row)
        self._update_scale_preview(self.spin_scale.value())
        
        group_timeout = QGroupBox()
        timeout_lay = QVBoxLayout(group_timeout)
        timeout_lay.addWidget(QLabel("Timeout Network"))
        self.input_timeout = QLineEdit()
        self.input_timeout.setText(self.settings.get("network_timeout", "120"))
        timeout_lay.addWidget(self.input_timeout)
        
        row1.addWidget(group_scale)
        row1.addWidget(group_timeout)
        row1.addStretch()
        layout.addLayout(row1)
        
        # Group 2: Startup URLs
        group_url = QGroupBox()
        url_lay = QVBoxLayout(group_url)
        url_lay.addWidget(QLabel("Danh sách Link khi mở trình duyệt"))
        self.input_urls = QLineEdit()
        self.input_urls.setText(self.settings.get("startup_urls", "https://www.facebook.com"))
        url_lay.addWidget(self.input_urls)
        layout.addWidget(group_url)
        
        # Group 3: Chrome profile path
        group_path = QGroupBox()
        path_lay = QVBoxLayout(group_path)
        path_lay.addWidget(QLabel("Đường dẫn thư mục Chrome Profile (có thể bỏ trống)"))
        self.input_profile_path = QLineEdit()
        self.input_profile_path.setText(self.settings.get("chrome_profile_base_path", ""))
        path_lay.addWidget(self.input_profile_path)
        layout.addWidget(group_path)
        
        # Save All Buttons
        self.btn_save_all = QPushButton("Save All Settings")
        self.btn_save_all.setObjectName("SaveAllBtn")
        self.btn_save_all.setMinimumHeight(40)
        self.btn_save_all.setMinimumWidth(150)
        self.btn_save_all.setStyleSheet("""
            QPushButton#SaveAllBtn {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #33bbf6, stop:1 #0f7bf8);
                color: white;
                font-weight: bold;
                font-size: 14px;
                border: 1px solid #0056b3;
                border-radius: 4px;
            }
            QPushButton#SaveAllBtn:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #4dc6fb, stop:1 #218cff);
            }
            QPushButton#SaveAllBtn:pressed {
                background: #0f7bf8;
            }
        """)
        self.btn_save_all.clicked.connect(self._on_ok)
        
        bottom_row = QHBoxLayout()
        bottom_row.addWidget(self.btn_save_all, alignment=Qt.AlignmentFlag.AlignLeft)
        layout.addLayout(bottom_row)
        layout.addStretch()

    def _update_scale_preview(self, scale):
        """Show estimated grid layout preview based on scale value."""
        import ctypes
        import ctypes.wintypes
        try:
            rect = ctypes.wintypes.RECT()
            ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0)
            sw = rect.right - rect.left
            sh = rect.bottom - rect.top
        except Exception:
            sw, sh = 1920, 1040
        
        scale = max(0.1, min(1.0, scale))
        win_w = max(200, int(sw * scale))
        win_h = min(win_w, sh)
        if win_w > sw:
            win_w = sw
        cols = max(1, sw // win_w)
        rows = max(1, sh // win_h)
        total = cols * rows
        zoom = int(min(100, max(40, win_w / 800.0 * 100)))
        self.lbl_scale_preview.setText(
            f"→ {cols}×{rows} = {total} browser | {win_w}×{win_h}px | Zoom {zoom}%"
        )

    def init_tab_browser(self):
        from PyQt6.QtWidgets import QGroupBox

        outer_layout = QVBoxLayout(self.tab_browser)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; }")
        inner = QWidget()
        layout = QVBoxLayout(inner)
        layout.setSpacing(6)
        
        # Row 1: Language
        lang_layout = QHBoxLayout()
        lang_label = QLabel(tr("settings_language"))
        lang_label.setStyleSheet("font-weight: bold;")
        self.lang_combo = QComboBox()
        self.lang_combo.addItem("Tiếng Việt", "vi")
        self.lang_combo.addItem("English", "en")
        self.lang_combo.addItem("中文", "zh")
        
        current_lang = self.settings.get("language", "vi")
        index = self.lang_combo.findData(current_lang)
        if index >= 0:
            self.lang_combo.setCurrentIndex(index)
            
        lang_layout.addWidget(lang_label)
        lang_layout.addWidget(self.lang_combo)
        lang_layout.addStretch()
        layout.addLayout(lang_layout)
        
        # Browser scale info label
        scale_info = QLabel("💡 Kích thước browser được điều chỉnh tại tab 'Setting Chung' → Tỷ lệ 0.1–1.0")
        scale_info.setStyleSheet("font-style: italic; color: #666;")
        scale_info.setWordWrap(True)
        layout.addWidget(scale_info)
        
        # ═══════════════════════════════════════════
        # CAPTCHA Settings Group (prominent)
        # ═══════════════════════════════════════════
        captcha_group = QGroupBox("🤖 Cài đặt giải CAPTCHA tự động")
        captcha_group.setStyleSheet("""
            QGroupBox {
                border: 2px solid #3b82f6;
                border-radius: 6px;
                margin-top: 1.5ex;
                padding-top: 10px;
                background-color: #f0f8ff;
                font-weight: bold;
                font-size: 13px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 6px;
                color: #1e40af;
            }
        """)
        captcha_lay = QVBoxLayout(captcha_group)
        captcha_lay.setSpacing(6)

        # API Key
        captcha_key_layout = QHBoxLayout()
        captcha_key_label = QLabel("API Key:")
        captcha_key_label.setStyleSheet("font-weight: bold; min-width: 65px;")
        self.captcha_key_input = QLineEdit()
        self.captcha_key_input.setText(self.settings.get("two_captcha_key", ""))
        self.captcha_key_input.setPlaceholderText("Nhập API Key từ 2captcha.com / anti-captcha.com / capsolver.com")
        captcha_key_layout.addWidget(captcha_key_label)
        captcha_key_layout.addWidget(self.captcha_key_input)
        captcha_lay.addLayout(captcha_key_layout)

        # Provider + Timeout + Retries
        captcha_opts = QHBoxLayout()
        captcha_opts.addWidget(QLabel("Provider:"))
        self.combo_captcha_provider = QComboBox()
        self.combo_captcha_provider.addItems(["2captcha", "anti-captcha", "capsolver"])
        self.combo_captcha_provider.setCurrentText(self.settings.get("captcha_provider", "2captcha"))
        self.combo_captcha_provider.setFixedWidth(120)
        captcha_opts.addWidget(self.combo_captcha_provider)
        captcha_opts.addSpacing(10)
        captcha_opts.addWidget(QLabel("Timeout (s):"))
        self.spin_captcha_timeout = QSpinBox()
        self.spin_captcha_timeout.setRange(30, 300)
        self.spin_captcha_timeout.setValue(int(self.settings.get("captcha_timeout", 120)))
        self.spin_captcha_timeout.setFixedWidth(70)
        captcha_opts.addWidget(self.spin_captcha_timeout)
        captcha_opts.addSpacing(10)
        captcha_opts.addWidget(QLabel("Retries:"))
        self.spin_captcha_retries = QSpinBox()
        self.spin_captcha_retries.setRange(1, 5)
        self.spin_captcha_retries.setValue(int(self.settings.get("captcha_retries", 2)))
        self.spin_captcha_retries.setFixedWidth(50)
        captcha_opts.addWidget(self.spin_captcha_retries)
        captcha_opts.addStretch()
        captcha_lay.addLayout(captcha_opts)

        layout.addWidget(captcha_group)

        # OmoCaptcha (legacy)
        api_layout = QHBoxLayout()
        api_label = QLabel("OmoCaptcha API Key:")
        api_label.setStyleSheet("font-weight: bold;")
        self.api_input = QLineEdit()
        self.api_input.setText(self.settings.get("omocaptcha_key", ""))
        self.api_input.setPlaceholderText("Nhập API Key OmoCaptcha...")
        api_layout.addWidget(api_label)
        api_layout.addWidget(self.api_input)
        layout.addLayout(api_layout)
        
        # 2Captcha Extension Path (legacy)
        captcha_layout = QHBoxLayout()
        captcha_label = QLabel("2Captcha Path:")
        captcha_label.setStyleSheet("font-weight: bold;")
        self.captcha_input = QLineEdit()
        self.captcha_input.setText(self.settings.get("two_captcha_path", r"C:\Users\Xeon\Desktop\2captcha-python-master"))
        self.captcha_input.setPlaceholderText("Đường dẫn giải nén 2Captcha Extension...")
        captcha_layout.addWidget(captcha_label)
        captcha_layout.addWidget(self.captcha_input)
        layout.addLayout(captcha_layout)
        
        layout.addSpacing(10)
        
        # Row 1: Layout type + Mute Chrome
        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Bố cục khi đăng ảnh"))
        self.combo_layout = QComboBox()
        self.combo_layout.addItems(["COLUMNS", "GRID", "LIST"])
        row1.addWidget(self.combo_layout)
        row1.addSpacing(20)
        self.chk_mute_chrome = QCheckBox("Tắt tiếng chrome")
        self.chk_mute_chrome.setChecked(self.settings.get("mute_chrome", True))
        row1.addWidget(self.chk_mute_chrome)
        row1.addStretch()
        layout.addLayout(row1)
        
        # List of right-aligned checkboxes
        self.chk_close_chrome = QCheckBox("Tắt chrome sau khi Login/SetCookie")
        self.chk_close_chrome.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.chk_close_chrome.setChecked(self.settings.get("close_chrome_after_login", True))
        layout.addWidget(self.chk_close_chrome, alignment=Qt.AlignmentFlag.AlignRight)
        
        self.chk_disable_notif = QCheckBox("Tắt thông báo Hoàn thành")
        self.chk_disable_notif.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.chk_disable_notif.setChecked(self.settings.get("disable_done_notification", True))
        layout.addWidget(self.chk_disable_notif, alignment=Qt.AlignmentFlag.AlignRight)
        
        self.chk_check_cp = QCheckBox("Check dạng Checkpoint khi Kiểm tra cookie")
        self.chk_check_cp.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.chk_check_cp.setChecked(self.settings.get("check_cp_when_checking_cookie", True))
        layout.addWidget(self.chk_check_cp, alignment=Qt.AlignmentFlag.AlignRight)
        
        self.chk_del_chrome = QCheckBox("Xóa folder Chrome sau khi Login")
        self.chk_del_chrome.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.chk_del_chrome.setChecked(self.settings.get("delete_chrome_folder_after_login", False))
        layout.addWidget(self.chk_del_chrome, alignment=Qt.AlignmentFlag.AlignRight)
        
        self.chk_incognito = QCheckBox("Bật option trình duyệt ẩn danh")
        self.chk_incognito.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.chk_incognito.setChecked(self.settings.get("incognito_mode", False))
        layout.addWidget(self.chk_incognito, alignment=Qt.AlignmentFlag.AlignRight)
        
        self.chk_check_info_api = QCheckBox("Check info Nick sau khi Login API Android")
        self.chk_check_info_api.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.chk_check_info_api.setChecked(self.settings.get("check_info_after_api_login", False))
        layout.addWidget(self.chk_check_info_api, alignment=Qt.AlignmentFlag.AlignRight)
        
        self.chk_del_profile = QCheckBox("Xóa Profile Chrome khi xóa nick trên tool")
        self.chk_del_profile.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.chk_del_profile.setChecked(self.settings.get("delete_chrome_profile_on_delete_acc", True))
        layout.addWidget(self.chk_del_profile, alignment=Qt.AlignmentFlag.AlignRight)
        
        self.chk_use_captcha = QCheckBox("Sử dụng tút vượt captcha khi login www")
        self.chk_use_captcha.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.chk_use_captcha.setChecked(self.settings.get("use_captcha_bypass_www", True))
        layout.addWidget(self.chk_use_captcha, alignment=Qt.AlignmentFlag.AlignRight)
        
        layout.addSpacing(20)
        
        # Cookie mapping bottom combobox
        cookie_row = QHBoxLayout()
        cookie_row.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.chk_use_cookie = QCheckBox()
        self.chk_use_cookie.setChecked(self.settings.get("use_cookie_login_method", True))
        self.combo_cookie_method = QComboBox()
        self.combo_cookie_method.addItems(["Sử dụng Cookie Mới khi Login Fl", "Sử dụng Cookie Cũ khi Login Fl"])
        self.combo_cookie_method.setCurrentText(self.settings.get("cookie_login_method", "Sử dụng Cookie Mới khi Login Fl"))
        cookie_row.addWidget(self.chk_use_cookie)
        cookie_row.addWidget(self.combo_cookie_method)
        layout.addLayout(cookie_row)
        
        layout.addStretch()
        scroll.setWidget(inner)
        outer_layout.addWidget(scroll)

    def init_tab_browser_type(self):
        layout = QVBoxLayout(self.tab_browser_type)
        layout.setSpacing(10)
        
        title = QLabel("Chọn loại trình duyệt mặc định cho Tool")
        title.setStyleSheet("font-weight: bold; font-size: 13px;")
        layout.addWidget(title)
        
        # Radio button group for browser selection
        from PyQt6.QtWidgets import QButtonGroup, QRadioButton, QProgressBar
        self.browser_group = QButtonGroup(self)
        
        browsers = ["Chromium", "Firefox", "Cốc Cốc", "Tor Browser", "Orbita Browser"]
        stored_browser = self.settings.get("selected_browser", "Chromium")
        
        self.radio_buttons = {}
        for btn_name in browsers:
            rb = QRadioButton(btn_name)
            if btn_name == stored_browser:
                rb.setChecked(True)
            self.radio_buttons[btn_name] = rb
            self.browser_group.addButton(rb)
            layout.addWidget(rb)
            
        layout.addSpacing(20)
        
        # Installer Panel
        self.installer_panel = QWidget()
        inst_layout = QVBoxLayout(self.installer_panel)
        inst_layout.setContentsMargins(0, 0, 0, 0)
        
        status_row = QHBoxLayout()
        self.lbl_install_status = QLabel("Trình duyệt này đã có sẵn trên máy (hoặc là mặc định của Playwright).")
        self.lbl_install_status.setWordWrap(True)
        
        self.btn_rescan = QPushButton("Quét Lại")
        self.btn_rescan.setFixedWidth(80)
        self.btn_rescan.clicked.connect(self._on_browser_selection_changed)
        
        status_row.addWidget(self.lbl_install_status, stretch=1)
        status_row.addWidget(self.btn_rescan)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        
        inst_layout.addLayout(status_row)
        inst_layout.addWidget(self.progress_bar)
        
        layout.addWidget(self.installer_panel)
        layout.addStretch()
        
        self.browser_group.buttonClicked.connect(self._on_browser_selection_changed)
        self._on_browser_selection_changed() # Trigger initial check
        
    def _on_browser_selection_changed(self):
        sel = self.browser_group.checkedButton().text()
        self.progress_bar.setVisible(False)
        
        if sel in ["Chromium", "Firefox"]:
            self.lbl_install_status.setText("Trình duyệt đã được tích hợp sẵn cùng bộ lõi mạng!")
            self.lbl_install_status.setStyleSheet("color: green; font-weight: bold;")
            return
            
        # Check external browsers smartly
        from core.browser_manager import SmartBrowserDetector
        found_path = SmartBrowserDetector.find_browser(sel)
            
        if found_path:
            self.lbl_install_status.setText(f"✓ Đã tìm thấy: {found_path}")
            self.lbl_install_status.setStyleSheet("color: green; font-weight: normal; font-size: 11px;")
        else:
            self.lbl_install_status.setText(f"⚠ Đang tự động tải và cài đặt {sel} (Chạy Ngầm)...")
            self.lbl_install_status.setStyleSheet("color: red; font-weight: bold;")
            self._trigger_auto_install(sel)

    def _trigger_auto_install(self, sel):
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.lbl_install_status.setText(f"Đang chuẩn bị cài đặt {sel}...")
        self.lbl_install_status.setStyleSheet("color: blue;")
        
        from core.browser_installer import BrowserInstallerWorker
        self.installer_worker = BrowserInstallerWorker(sel)
        self.installer_worker.progress.connect(self._on_install_progress)
        self.installer_worker.finished.connect(self._on_install_finished)
        self.installer_worker.start()

    def _on_install_progress(self, val, msg):
        self.progress_bar.setValue(val)
        self.lbl_install_status.setText(msg)

    def _on_install_finished(self, success, msg):
        self.progress_bar.setValue(100)
        if success:
            self.lbl_install_status.setText(f"✓ {msg}. Đang quét lại...")
            self.lbl_install_status.setStyleSheet("color: green; font-weight: bold;")
            # Auto-rescan after successful install
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(2000, self._on_browser_selection_changed)
        else:
            self.lbl_install_status.setText(f"✕ Lỗi cài ngầm: {msg}")
            self.lbl_install_status.setStyleSheet("color: red; font-weight: bold;")

    def init_tab_columns(self):
        layout = QVBoxLayout(self.tab_columns)
        
        title = QLabel(tr("settings_columns"))
        title.setStyleSheet("font-weight: bold; font-size: 13px; padding-bottom: 6px;")
        layout.addWidget(title)
        
        # Scrollable checkbox area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        container = QWidget()
        container.setObjectName("container")
        grid = QGridLayout(container)
        grid.setSpacing(6)
        
        for i, (key, label, default) in enumerate(ALL_COLUMNS):
            if key == "stt":
                continue  # Always visible, skip
            chk = QCheckBox(label)
            chk.setChecked(self.column_settings.get(key, default))
            self.checkboxes[key] = chk
            grid.addWidget(chk, i // 2, i % 2)
        
        scroll.setWidget(container)
        layout.addWidget(scroll)
        
        # Select All / Deselect All buttons
        btn_row = QHBoxLayout()
        btn_all = QPushButton("Select All")
        btn_all.clicked.connect(self._select_all)
        btn_none = QPushButton("Deselect All")
        btn_none.clicked.connect(self._deselect_all)
        btn_update = QPushButton(tr("update_btn_check"))
        btn_update.clicked.connect(self._check_update)
        
        btn_fix = QPushButton(tr("settings_btn_fix_browser"))
        btn_fix.clicked.connect(self._fix_browser)
        
        btn_row.addWidget(btn_all)
        btn_row.addWidget(btn_none)
        btn_row.addStretch()
        btn_row.addWidget(btn_fix)
        btn_row.addWidget(btn_update)
        layout.addLayout(btn_row)
        layout.addStretch()
        
        # Save All Button (Big blue button mimicking image)
        self.btn_save_all_browser = QPushButton("Save All Settings")
        self.btn_save_all_browser.setObjectName("SaveAllBtn")
        self.btn_save_all_browser.setMinimumHeight(40)
        self.btn_save_all_browser.setMinimumWidth(150)
        self.btn_save_all_browser.setStyleSheet("""
            QPushButton#SaveAllBtn {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #33bbf6, stop:1 #0f7bf8);
                color: white;
                font-weight: bold;
                font-size: 14px;
                border: 1px solid #0056b3;
                border-radius: 4px;
            }
            QPushButton#SaveAllBtn:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #4dc6fb, stop:1 #218cff);
            }
            QPushButton#SaveAllBtn:pressed {
                background: #0f7bf8;
            }
        """)
        self.btn_save_all_browser.clicked.connect(self._on_ok)
        
        btn_layout = QHBoxLayout()
        btn_layout.addWidget(self.btn_save_all_browser, alignment=Qt.AlignmentFlag.AlignLeft)
        layout.addLayout(btn_layout)
        layout.addStretch()

    def _select_all(self):
        for chk in self.checkboxes.values():
            chk.setChecked(True)
            
    def _deselect_all(self):
        for chk in self.checkboxes.values():
            chk.setChecked(False)
            
    def _check_update(self):
        found, version, changelog = check_for_update()
        if not found:
            QMessageBox.information(self, tr("app_title"), tr("update_msg_latest"))
            return
            
        msg = tr("update_msg_found", version)
        if changelog:
            msg += f"\n\n{changelog}"
            
        reply = QMessageBox.information(
            self, 
            tr("update_btn_now"), 
            msg,
            QMessageBox.StandardButton.Apply | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Apply
        )
        
        if reply == QMessageBox.StandardButton.Apply:
            if download_and_install(""): # URL handled in updater
                QMessageBox.information(self, tr("app_title"), tr("update_msg_restarting"))
                apply_update()

    def _fix_browser(self):
        QMessageBox.information(self, tr("app_title"), tr("msg_fixing_browser"))
        if install_chromium():
            QMessageBox.information(self, tr("app_title"), tr("msg_fix_success"))
        else:
            QMessageBox.warning(self, tr("app_title"), tr("msg_fix_failed"))
    
    def _on_ok(self):
        new_columns = {key: chk.isChecked() for key, chk in self.checkboxes.items()}
        new_columns["stt"] = True  # always on
        
        new_settings = {
            "columns": new_columns,
            "language": "vi",  # Removed dropdown, kept default
            "omocaptcha_key": "",
            "categories": self.settings.get("categories", ["Default"]),
            
            # Browser Grid Layout specific
            "chrome_scale": str(self.spin_scale.value()),
            "network_timeout": self.input_timeout.text().strip(),
            "startup_urls": self.input_urls.text().strip(),
            "chrome_profile_base_path": self.input_profile_path.text().strip(),
            
            # New Keys mapped to logic
            "mute_chrome": self.chk_mute_chrome.isChecked(),
            "close_chrome_after_login": self.chk_close_chrome.isChecked(),
            "disable_done_notification": self.chk_disable_notif.isChecked(),
            "check_cp_when_checking_cookie": self.chk_check_cp.isChecked(),
            "delete_chrome_folder_after_login": self.chk_del_chrome.isChecked(),
            "incognito_mode": self.chk_incognito.isChecked(),
            "check_info_after_api_login": self.chk_check_info_api.isChecked(),
            "delete_chrome_profile_on_delete_acc": self.chk_del_profile.isChecked(),
            "use_captcha_bypass_www": self.chk_use_captcha.isChecked(),
            "cookie_login_method": self.combo_cookie_method.currentText(),
            "selected_browser": self.browser_group.checkedButton().text() if hasattr(self, 'browser_group') else self.settings.get("selected_browser", "Chromium"),
            "two_captcha_key": self.captcha_key_input.text().strip() if hasattr(self, 'captcha_key_input') else self.settings.get("two_captcha_key", ""),
            "captcha_provider": self.combo_captcha_provider.currentText() if hasattr(self, 'combo_captcha_provider') else self.settings.get("captcha_provider", "2captcha"),
            "captcha_timeout": self.spin_captcha_timeout.value() if hasattr(self, 'spin_captcha_timeout') else self.settings.get("captcha_timeout", 120),
            "captcha_retries": self.spin_captcha_retries.value() if hasattr(self, 'spin_captcha_retries') else self.settings.get("captcha_retries", 2),
        }
        
        # Check if browser changed and notify main window logic
        old_browser = self.settings.get("selected_browser", "Chromium")
        new_browser = new_settings.get("selected_browser")
        if getattr(self, "parent", None) and hasattr(self.parent(), "on_browser_setting_changed"):
             if old_browser != new_browser:
                 self.parent().on_browser_setting_changed(new_browser)
                 
        save_settings(new_settings)
        self.accept()

