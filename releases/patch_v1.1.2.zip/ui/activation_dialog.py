from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
    QLineEdit, QPushButton, QMessageBox
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon, QPixmap
from core.i18n import tr
from core.licensing import get_hwid, verify_license, save_license
import os


class ActivationDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Kích hoạt tool — Facebook THE TIHA DEALER")
        self.setFixedSize(480, 340)
        self.setWindowFlags(
            self.windowFlags()
            & ~Qt.WindowType.WindowContextHelpButtonHint
            | Qt.WindowType.WindowStaysOnTopHint
        )

        # Set Window Icon
        logo_path = os.path.join(os.path.dirname(__file__), "..", "assets", "logo.png")
        if os.path.exists(logo_path):
            self.setWindowIcon(QIcon(logo_path))

        self._apply_dark_theme()

        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(24, 20, 24, 20)

        # ─── Logo + Title ───
        header = QHBoxLayout()
        if os.path.exists(logo_path):
            logo_lbl = QLabel()
            pix = QPixmap(logo_path).scaled(
                42, 42, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            logo_lbl.setPixmap(pix)
            logo_lbl.setStyleSheet("background: transparent; border: none;")
            header.addWidget(logo_lbl)
            header.addSpacing(10)

        title = QLabel(
            '<span style="color:#a78bfa;font-size:16px;font-weight:800;">Facebook</span>'
            '<span style="color:#f1f5f9;font-size:16px;font-weight:700;"> THE TIHA DEALER</span>'
        )
        title.setStyleSheet("background: transparent; border: none;")
        header.addWidget(title)
        header.addStretch()
        layout.addLayout(header)
        layout.addSpacing(6)

        # ─── HWID Section ───
        hwid_label = QLabel("HWID máy của bạn (gửi cho admin để nhận key):")
        hwid_label.setStyleSheet("color: #93c5fd; font-weight: 700; font-size: 11px; border: none;")
        layout.addWidget(hwid_label)

        self.hwid_display = QLineEdit(get_hwid())
        self.hwid_display.setReadOnly(True)
        self.hwid_display.setStyleSheet("""
            QLineEdit {
                background: #0d1117; border: 1px solid #334155; border-radius: 6px;
                padding: 8px 10px; color: #fbbf24; font-family: 'Consolas', monospace;
                font-size: 13px; font-weight: bold; letter-spacing: 1px;
            }
        """)
        layout.addWidget(self.hwid_display)

        # Copy HWID button
        btn_copy = QPushButton("📋 Copy HWID")
        btn_copy.setFixedHeight(26)
        btn_copy.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_copy.setStyleSheet("""
            QPushButton { background: #1e293b; border: 1px solid #334155; border-radius: 4px;
                          color: #94a3b8; font-size: 10px; font-weight: 600; padding: 0 10px; }
            QPushButton:hover { background: #334155; color: #e2e8f0; }
        """)
        btn_copy.clicked.connect(lambda: (
            QApplication.clipboard().setText(get_hwid()),
            btn_copy.setText("✓ Đã copy!")
        ))
        from PyQt6.QtWidgets import QApplication
        layout.addWidget(btn_copy, alignment=Qt.AlignmentFlag.AlignLeft)

        layout.addSpacing(8)

        # ─── Key Entry Section ───
        key_label = QLabel("Nhập Key kích hoạt:")
        key_label.setStyleSheet("color: #93c5fd; font-weight: 700; font-size: 11px; border: none;")
        layout.addWidget(key_label)

        self.key_input = QLineEdit()
        self.key_input.setPlaceholderText("XXXXXXXX-YYYYMMDD")
        self.key_input.setStyleSheet("""
            QLineEdit {
                background: #1a1f2e; border: 1px solid #334155; border-radius: 6px;
                padding: 10px 12px; color: #e2e8f0; font-family: 'Consolas', monospace;
                font-size: 14px; letter-spacing: 1px;
            }
            QLineEdit:focus { border-color: #3b82f6; }
        """)
        layout.addWidget(self.key_input)

        layout.addSpacing(8)

        # ─── Activate Button ───
        self.btn_activate = QPushButton("🔑  Kích hoạt")
        self.btn_activate.setFixedHeight(40)
        self.btn_activate.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_activate.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #2563eb, stop:1 #1d4ed8);
                border: 1px solid #3b82f6;
                border-radius: 8px;
                color: #ffffff;
                font-weight: 800;
                font-size: 14px;
                letter-spacing: 0.5px;
            }
            QPushButton:hover {
                background: #3b82f6;
            }
        """)
        self.btn_activate.clicked.connect(self.on_activate)
        layout.addWidget(self.btn_activate)

    def _apply_dark_theme(self):
        self.setStyleSheet("""
            QDialog {
                background: #0f1219;
                color: #e2e8f0;
                border: 2px solid #1e293b;
                border-radius: 12px;
            }
        """)

    def on_activate(self):
        key = self.key_input.text().strip().upper()
        if not key:
            QMessageBox.warning(self, "Kích hoạt", "Vui lòng nhập key!")
            return

        if verify_license(key):
            save_license(key)
            QMessageBox.information(
                self, "Kích hoạt thành công ✅",
                "Key hợp lệ! Tool đã được kích hoạt.\nChúc bạn sử dụng vui vẻ!"
            )
            self.accept()
        else:
            QMessageBox.warning(
                self, "Kích hoạt thất bại ❌",
                "Key không hợp lệ hoặc đã hết hạn!\n"
                "Liên hệ admin để nhận key mới.\n\n"
                f"HWID của bạn: {get_hwid()}"
            )
