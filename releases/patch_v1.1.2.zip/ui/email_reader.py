"""
Email Reader Module — Dual IMAP + Graph API support with auto-detection.
Supports Microsoft Refresh Token format: REFRESH_TOKEN|CLIENT_ID

Two reading methods:
1. Graph API — scope: https://graph.microsoft.com/Mail.Read (faster, REST-based)
2. IMAP XOAUTH2 — scope: https://outlook.office.com/mail.read (protocol-based)

Auto-detection: tries Graph API first, falls back to IMAP, then password.
"""
import imaplib
import json
import re
import urllib.request
import urllib.parse
import urllib.error
import email as email_lib
from email.header import decode_header

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QScrollArea, QWidget, QApplication, QMessageBox
)
from PyQt6.QtCore import QThread, pyqtSignal


# ═══════════════════════════════
#  Microsoft OAuth2 Constants
# ═══════════════════════════════

MS_TOKEN_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token"
GRAPH_SCOPE = "https://graph.microsoft.com/Mail.Read offline_access"
IMAP_SCOPE = "https://outlook.office.com/mail.read offline_access"
GRAPH_MESSAGES_URL = "https://graph.microsoft.com/v1.0/me/messages"


# ═══════════════════════════════
#  Helper Functions
# ═══════════════════════════════

def parse_hotmail_token(raw_token: str):
    """Parse 'REFRESH_TOKEN|CLIENT_ID' format.
    Returns (refresh_token, client_id) or (raw_token, None)."""
    if not raw_token or "|" not in raw_token:
        return raw_token, None
    parts = raw_token.rsplit("|", 1)
    if len(parts) == 2 and len(parts[1]) > 10:
        return parts[0], parts[1]
    return raw_token, None


def exchange_refresh_token(refresh_token: str, client_id: str, scope: str) -> dict:
    """Exchange Microsoft refresh token for access token with specific scope."""
    data = urllib.parse.urlencode({
        "client_id": client_id,
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "scope": scope,
    }).encode()

    req = urllib.request.Request(
        MS_TOKEN_URL, data=data,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            if "access_token" in result:
                return result
            raise Exception(result.get("error_description", "Unknown error"))
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        try:
            err = json.loads(body)
            raise Exception(err.get("error_description", body[:200]))
        except json.JSONDecodeError:
            raise Exception(body[:200])


def detect_token_type(refresh_token: str, client_id: str) -> str:
    """Detect which scope works: 'graph', 'imap', or 'none'.
    Tries Graph API first (faster REST), then falls back to IMAP."""
    for scope, label in [(GRAPH_SCOPE, "graph"), (IMAP_SCOPE, "imap")]:
        try:
            exchange_refresh_token(refresh_token, client_id, scope)
            return label
        except:
            continue
    return "none"


def read_inbox_graph(access_token: str, max_messages: int = 20) -> list:
    """Read inbox via Microsoft Graph API. Returns list of mail dicts."""
    params = urllib.parse.urlencode({
        "$top": str(max_messages),
        "$orderby": "receivedDateTime desc",
        "$select": "subject,from,receivedDateTime,bodyPreview,body",
    })
    url = f"{GRAPH_MESSAGES_URL}?{params}"
    req = urllib.request.Request(url, headers={
        "Authorization": f"Bearer {access_token}",
    })

    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode())

    results = []
    for m in data.get("value", []):
        subject = m.get("subject", "") or ""
        sender = m.get("from", {}).get("emailAddress", {}).get("address", "")
        date_str = m.get("receivedDateTime", "")

        # Get body text (strip HTML)
        body_html = m.get("body", {}).get("content", "")
        body = re.sub(r'<[^>]+>', ' ', body_html)
        body = re.sub(r'\s+', ' ', body).strip()

        # Extract verification codes
        codes = _extract_codes(subject, body)

        results.append({
            "subject": subject[:200],
            "sender": sender[:100],
            "date": date_str[:50],
            "body_preview": body[:500],
            "codes": codes,
        })
    return results


def read_inbox_imap(email_addr: str, access_token: str, max_messages: int = 20) -> list:
    """Read inbox via IMAP XOAUTH2. Returns list of mail dicts."""
    imap_server = _detect_imap_server(email_addr)
    mail = imaplib.IMAP4_SSL(imap_server, 993, timeout=30)
    auth_string = f"user={email_addr}\x01auth=Bearer {access_token}\x01\x01"
    mail.authenticate("XOAUTH2", lambda x: auth_string.encode())
    mail.select("INBOX")

    status, messages = mail.search(None, "ALL")
    if status != "OK":
        mail.logout()
        return []

    msg_ids = messages[0].split()
    latest_ids = msg_ids[-max_messages:] if len(msg_ids) > max_messages else msg_ids
    latest_ids.reverse()

    results = []
    for msg_id in latest_ids:
        try:
            st, msg_data = mail.fetch(msg_id, "(RFC822)")
            if st != "OK":
                continue
            raw = msg_data[0][1]
            msg = email_lib.message_from_bytes(raw)
            parsed = _parse_imap_message(msg)
            if parsed:
                results.append(parsed)
        except:
            continue

    mail.logout()
    return results


def read_inbox_password(email_addr: str, password: str, max_messages: int = 20) -> list:
    """Read inbox via IMAP password login."""
    imap_server = _detect_imap_server(email_addr)
    mail = imaplib.IMAP4_SSL(imap_server, 993, timeout=30)
    mail.login(email_addr, password)
    mail.select("INBOX")

    status, messages = mail.search(None, "ALL")
    if status != "OK":
        mail.logout()
        return []

    msg_ids = messages[0].split()
    latest_ids = msg_ids[-max_messages:] if len(msg_ids) > max_messages else msg_ids
    latest_ids.reverse()

    results = []
    for msg_id in latest_ids:
        try:
            st, msg_data = mail.fetch(msg_id, "(RFC822)")
            if st != "OK":
                continue
            raw = msg_data[0][1]
            msg = email_lib.message_from_bytes(raw)
            parsed = _parse_imap_message(msg)
            if parsed:
                results.append(parsed)
        except:
            continue

    mail.logout()
    return results


def _extract_codes(subject: str, body: str) -> list:
    """Extract verification codes (4-8 digits) if email has code-related keywords."""
    codes = re.findall(r'\b(\d{4,8})\b', body)
    code_kw = ["code", "verify", "confirmation", "otp", "pin", "security",
               "reset", "password"]
    combined = (subject + " " + body).lower()
    if not any(kw in combined for kw in code_kw):
        codes = []
    return codes[:5]


def _detect_imap_server(email_addr: str) -> str:
    domain = email_addr.split("@")[-1].lower() if "@" in email_addr else ""
    if any(x in domain for x in ["hotmail", "outlook", "live"]):
        return "imap-mail.outlook.com"
    elif any(x in domain for x in ["gmail", "google"]):
        return "imap.gmail.com"
    elif "yahoo" in domain:
        return "imap.mail.yahoo.com"
    return f"imap.{domain}"


def _is_hotmail(email_addr: str) -> bool:
    domain = email_addr.split("@")[-1].lower() if "@" in email_addr else ""
    return any(x in domain for x in ["hotmail", "outlook", "live"])


def _parse_imap_message(msg) -> dict:
    """Parse a stdlib email.message.Message into our dict format."""
    subject = ""
    raw_subj = msg.get("Subject", "")
    if raw_subj:
        for part, enc in decode_header(raw_subj):
            if isinstance(part, bytes):
                subject += part.decode(enc or "utf-8", errors="replace")
            else:
                subject += str(part)

    sender = msg.get("From", "")
    date_str = msg.get("Date", "")

    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            if ct == "text/plain":
                try:
                    cs = part.get_content_charset() or "utf-8"
                    body = part.get_payload(decode=True).decode(cs, errors="replace")
                except:
                    body = str(part.get_payload(decode=True))
                break
            elif ct == "text/html" and not body:
                try:
                    cs = part.get_content_charset() or "utf-8"
                    html = part.get_payload(decode=True).decode(cs, errors="replace")
                    body = re.sub(r'<[^>]+>', ' ', html)
                    body = re.sub(r'\s+', ' ', body).strip()
                except:
                    pass
    else:
        try:
            cs = msg.get_content_charset() or "utf-8"
            body = msg.get_payload(decode=True).decode(cs, errors="replace")
        except:
            body = str(msg.get_payload(decode=True))

    codes = _extract_codes(subject, body)

    return {
        "subject": subject[:200],
        "sender": sender[:100],
        "date": date_str[:50],
        "body_preview": body[:500],
        "codes": codes,
    }


# ═══════════════════════════════
#  Email Reader Thread
# ═══════════════════════════════

class EmailReaderThread(QThread):
    """Background thread: reads inbox with auto-detection.
    Priority: Graph API > IMAP OAuth2 > IMAP Password."""
    mail_loaded = pyqtSignal(list)       # list of mail dicts
    error = pyqtSignal(str)
    status_msg = pyqtSignal(str)
    new_token = pyqtSignal(str)          # new refresh token if rotated
    method_detected = pyqtSignal(str)    # 'Graph API' or 'IMAP' or 'Password'

    def __init__(self, email_addr, password="", token="", max_messages=20):
        super().__init__()
        self.email_addr = email_addr
        self.password = password
        self.token = token
        self.max_messages = max_messages

    def run(self):
        try:
            # Try token-based methods first for Hotmail/Outlook
            if self.token and _is_hotmail(self.email_addr):
                refresh_token, client_id = parse_hotmail_token(self.token)

                if client_id:
                    # Try Graph API first
                    self.status_msg.emit("Thu doc qua Graph API...")
                    try:
                        resp = exchange_refresh_token(refresh_token, client_id, GRAPH_SCOPE)
                        access_token = resp["access_token"]
                        self._save_new_token(resp, refresh_token, client_id)
                        
                        results = read_inbox_graph(access_token, self.max_messages)
                        self.method_detected.emit("Graph API")
                        self.mail_loaded.emit(results)
                        return
                    except Exception as e1:
                        graph_err = str(e1)[:80]

                    # Fallback: IMAP OAuth2
                    self.status_msg.emit("Graph API loi, thu IMAP OAuth2...")
                    try:
                        resp = exchange_refresh_token(refresh_token, client_id, IMAP_SCOPE)
                        access_token = resp["access_token"]
                        self._save_new_token(resp, refresh_token, client_id)

                        results = read_inbox_imap(self.email_addr, access_token, self.max_messages)
                        self.method_detected.emit("IMAP OAuth2")
                        self.mail_loaded.emit(results)
                        return
                    except Exception as e2:
                        imap_err = str(e2)[:80]

                    # Fallback: Password
                    if self.password:
                        self.status_msg.emit("Token loi, thu dang nhap bang password...")
                        try:
                            results = read_inbox_password(self.email_addr, self.password, self.max_messages)
                            self.method_detected.emit("IMAP Password")
                            self.mail_loaded.emit(results)
                            return
                        except Exception as e3:
                            pass

                    self.error.emit(f"Tat ca phuong thuc deu loi. Graph: {graph_err}")
                    return

            # No token or not Hotmail — use IMAP password
            if self.password:
                self.status_msg.emit("Dang nhap IMAP bang password...")
                results = read_inbox_password(self.email_addr, self.password, self.max_messages)
                self.method_detected.emit("IMAP Password")
                self.mail_loaded.emit(results)
            else:
                self.error.emit("Khong co password hoac token.")

        except Exception as e:
            self.error.emit(f"Loi: {str(e)[:150]}")

    def _save_new_token(self, resp, old_rt, client_id):
        new_rt = resp.get("refresh_token")
        if new_rt and new_rt != old_rt:
            self.new_token.emit(f"{new_rt}|{client_id}")


# ═══════════════════════════════
#  Token Check Thread (Bulk)
# ═══════════════════════════════

class TokenCheckThread(QThread):
    """Check refresh tokens in bulk with auto-detection.
    Tries Graph API scope first, then IMAP scope.
    Emits (email_id, status_msg, live_value, method)."""
    status_update = pyqtSignal(str, str, str, str)  # id, status, live, method
    finished_all = pyqtSignal()

    def __init__(self, emails_to_check: list):
        super().__init__()
        self.emails = emails_to_check
        self._running = True

    def run(self):
        for rec in self.emails:
            if not self._running:
                break

            eid = rec.get("id", "")
            email_addr = rec.get("email", "")
            token = rec.get("token_hotmail", "")

            if not email_addr:
                self.status_update.emit(eid, "Thieu email", "", "")
                continue
            if not token:
                self.status_update.emit(eid, "Khong co token", "No Token", "")
                continue

            if _is_hotmail(email_addr):
                refresh_token, client_id = parse_hotmail_token(token)
                if not client_id:
                    self.status_update.emit(eid, "Token sai dinh dang (thieu client_id)", "Token Out", "")
                    continue

                # Try Graph API scope
                try:
                    exchange_refresh_token(refresh_token, client_id, GRAPH_SCOPE)
                    self.status_update.emit(eid, "Token Live (Graph API)", "Live", "Graph API")
                    continue
                except:
                    pass

                # Try IMAP scope
                try:
                    exchange_refresh_token(refresh_token, client_id, IMAP_SCOPE)
                    self.status_update.emit(eid, "Token Live (IMAP)", "Live", "IMAP")
                    continue
                except:
                    pass

                self.status_update.emit(eid, "Token Out", "Token Out", "")
            else:
                # Non-Hotmail: test password IMAP login
                password = rec.get("pass_email", "")
                if password:
                    try:
                        imap_server = _detect_imap_server(email_addr)
                        mail = imaplib.IMAP4_SSL(imap_server, 993, timeout=15)
                        mail.login(email_addr, password)
                        mail.logout()
                        self.status_update.emit(eid, "Login OK (Password)", "Live", "Password")
                    except Exception as e:
                        self.status_update.emit(eid, f"Login loi - {str(e)[:60]}", "Out", "")
                else:
                    self.status_update.emit(eid, "Khong co password", "", "")

        self.finished_all.emit()

    def stop(self):
        self._running = False


# ═══════════════════════════════
#  Read Mail Dialog
# ═══════════════════════════════

class ReadMailDialog(QDialog):
    """Dark-themed popup showing 20 recent emails with auto-detection and code extraction."""
    def __init__(self, parent=None, email_addr="", password="", token="", email_id="", em=None):
        super().__init__(parent)
        self.email_addr = email_addr
        self.password = password
        self.token = token
        self.email_id = email_id
        self.em = em
        self.setWindowTitle(f"Hop thu - {email_addr}")
        self.resize(720, 580)
        self.setStyleSheet("""
            QDialog { background-color: #1a1d23; }
            QLabel { color: #e0e0e0; font-family: 'Segoe UI', Arial; }
            QScrollArea { border: none; background: #1a1d23; }
            QPushButton { background: #2d3748; border: 1px solid #4a5568; border-radius: 4px;
                          padding: 5px 10px; color: #e0e0e0; font-weight: bold; }
            QPushButton:hover { background: #4a5568; }
        """)
        layout = QVBoxLayout(self)

        header = QLabel(f"📧 {email_addr}")
        header.setStyleSheet("font-size: 16px; font-weight: bold; color: #a78bfa; padding: 5px;")
        layout.addWidget(header)

        self.method_lbl = QLabel("")
        self.method_lbl.setStyleSheet("color: #b794f4; font-size: 11px; padding: 0 5px;")
        layout.addWidget(self.method_lbl)

        self.status_lbl = QLabel("⏳ Dang tai hop thu...")
        self.status_lbl.setStyleSheet("color: #fbd38d; font-size: 12px; padding: 2px 5px;")
        layout.addWidget(self.status_lbl)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.mail_container = QWidget()
        self.mail_container.setStyleSheet("background: #1a1d23;")
        self.mail_layout = QVBoxLayout(self.mail_container)
        self.mail_layout.setSpacing(6)
        self.mail_layout.setContentsMargins(4, 4, 4, 4)
        self.mail_layout.addStretch()
        scroll.setWidget(self.mail_container)
        layout.addWidget(scroll, 1)

        btn_row = QHBoxLayout()
        btn_refresh = QPushButton("🔄 Lam moi")
        btn_refresh.clicked.connect(self._start_loading)
        btn_close = QPushButton("Dong")
        btn_close.clicked.connect(self.close)
        btn_row.addWidget(btn_refresh)
        btn_row.addStretch()
        btn_row.addWidget(btn_close)
        layout.addLayout(btn_row)

        self._start_loading()

    def _start_loading(self):
        self.status_lbl.setText("⏳ Dang ket noi...")
        self.status_lbl.setStyleSheet("color: #fbd38d; font-size: 12px;")
        self.method_lbl.setText("")
        while self.mail_layout.count() > 1:
            item = self.mail_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        self.reader_thread = EmailReaderThread(self.email_addr, self.password, self.token, 20)
        self.reader_thread.mail_loaded.connect(self._on_mail_loaded)
        self.reader_thread.error.connect(self._on_error)
        self.reader_thread.status_msg.connect(self._on_status)
        self.reader_thread.new_token.connect(self._on_new_token)
        self.reader_thread.method_detected.connect(self._on_method)
        self.reader_thread.start()

    def _on_status(self, msg):
        self.status_lbl.setText(f"⏳ {msg}")

    def _on_method(self, method):
        self.method_lbl.setText(f"🔌 Phuong thuc: {method}")

    def _on_mail_loaded(self, mails):
        if not mails:
            self.status_lbl.setText("📭 Hop thu trong.")
            self.status_lbl.setStyleSheet("color: #a0aec0; font-size: 12px;")
            return
        self.status_lbl.setText(f"✅ Da tai {len(mails)} thu")
        self.status_lbl.setStyleSheet("color: #68d391; font-size: 12px;")
        for md in mails:
            card = self._create_mail_card(md)
            self.mail_layout.insertWidget(self.mail_layout.count() - 1, card)

    def _on_error(self, msg):
        self.status_lbl.setText(f"❌ {msg}")
        self.status_lbl.setStyleSheet("color: #fc8181; font-size: 12px;")

    def _on_new_token(self, new_token):
        if self.em and self.email_id:
            self.em.update_email(self.email_id, {"token_hotmail": new_token})
            self.token = new_token

    def _create_mail_card(self, md):
        card = QWidget()
        has_codes = bool(md.get("codes"))
        bg = "#2a4365" if has_codes else "#2d3748"
        border = "#a78bfa" if has_codes else "#4a5568"
        card.setStyleSheet(
            f"QWidget {{ background: {bg}; border: 1px solid {border}; "
            f"border-radius: 6px; padding: 8px; }} "
            f"QLabel {{ border: none; padding: 0; }}")
        cl = QVBoxLayout(card)
        cl.setSpacing(3)
        cl.setContentsMargins(8, 6, 8, 6)

        subj = md.get("subject", "(No subject)")
        lbl_s = QLabel(f"📌 {subj}")
        lbl_s.setStyleSheet("font-weight: bold; font-size: 13px; color: #e2e8f0;")
        lbl_s.setWordWrap(True)
        cl.addWidget(lbl_s)

        info = QHBoxLayout()
        lbl_from = QLabel(f"👤 {md.get('sender', '')}")
        lbl_from.setStyleSheet("font-size: 11px; color: #a0aec0;")
        lbl_date = QLabel(f"📅 {md.get('date', '')}")
        lbl_date.setStyleSheet("font-size: 11px; color: #a0aec0;")
        info.addWidget(lbl_from, 1)
        info.addWidget(lbl_date, 0)
        cl.addLayout(info)

        body = md.get("body_preview", "")[:300]
        if body:
            lbl_b = QLabel(body)
            lbl_b.setStyleSheet("font-size: 11px; color: #cbd5e0;")
            lbl_b.setWordWrap(True)
            lbl_b.setMaximumHeight(60)
            cl.addWidget(lbl_b)

        codes = md.get("codes", [])
        if codes:
            cr = QHBoxLayout()
            code_lbl = QLabel("🔑 Code:")
            code_lbl.setStyleSheet("color: #fbd38d; font-weight: bold;")
            cr.addWidget(code_lbl)
            for code in codes:
                btn = QPushButton(f"📋 {code}")
                btn.setStyleSheet(
                    "QPushButton { background: #48bb78; color: white; font-weight: bold; "
                    "font-size: 13px; border-radius: 4px; padding: 4px 12px; border: none; } "
                    "QPushButton:hover { background: #38a169; }")
                btn.setFixedHeight(28)
                btn.clicked.connect(lambda checked, c=code: self._copy_code(c))
                cr.addWidget(btn)
            cr.addStretch()
            cl.addLayout(cr)
        return card

    def _copy_code(self, code):
        QApplication.clipboard().setText(code)
        self.status_lbl.setText(f"✅ Copied: {code}")
        self.status_lbl.setStyleSheet("color: #68d391; font-size: 12px; font-weight: bold;")
