from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, 
    QComboBox, QApplication, QMessageBox, QFileDialog, QScrollArea, QWidget
)
from PyQt6.QtCore import Qt

class ExportDialog(QDialog):
    def __init__(self, parent=None, profiles=None):
        super().__init__(parent)
        self.setWindowTitle("Xuất dữ liệu")
        self.resize(1000, 200)
        
        # Guard passing empty or None
        self.profiles = profiles or []

        self.setStyleSheet("""
            QDialog {
                background-color: #1e293b;
                color: #e2e8f0;
            }
            QLabel {
                font-size: 13px;
                color: #e2e8f0;
            }
            QLabel#Separator {
                color: #94a3b8;
                font-weight: bold;
                font-size: 14px;
                margin: 0px 2px;
            }
            QComboBox {
                border: 1px solid #475569;
                border-radius: 3px;
                padding: 3px 6px;
                background: #334155;
                color: #e2e8f0;
                min-width: 70px;
                font-size: 12px;
            }
            QComboBox::drop-down {
                border-left: 1px solid #475569;
                width: 18px;
                background: #475569;
            }
            QComboBox::down-arrow {
                width: 10px; height: 10px;
            }
            QComboBox QAbstractItemView {
                background: #334155;
                color: #e2e8f0;
                border: 1px solid #475569;
                selection-background-color: #3b82f6;
            }
            QPushButton.action-btn {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #4bbdf5, stop:1 #1a8dfb);
                color: white;
                font-weight: bold;
                border: 1px solid #1a8dfb;
                border-radius: 4px;
                min-width: 130px;
                min-height: 35px;
                font-size: 13px;
            }
            QPushButton.action-btn:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #5ecafb, stop:1 #2b9dff);
            }
            QScrollArea {
                border: none;
                background-color: transparent;
            }
        """)

        self.mapping_options = [
            ("Bỏ qua", ""),
            ("UID", "fb_uid"),
            ("PASS", "fb_pass"),
            ("2FA", "fb_2fa"),
            ("Email", "fb_email"),
            ("Pass Email", "fb_pass_email"),
            ("Mail Reco", "fb_email_recovery"),
            ("Proxy", "fb_proxy"),
            ("Cookie", "fb_cookie"),
            ("UserAgent", "fb_useragent"),
            ("Token", "fb_token"),
            ("Birthday", "fb_dob"),
            ("UID Target", "fb_uid_target"),
            ("Note", "fb_note"),
            ("Friend", "fb_friends"),
            ("Ngày tạo", "fb_created"),
            ("Email Old", "fb_old_pass"),
            ("Gender", "fb_gender")
        ]

        self.init_ui()
        self.preset_all() # Default to preset all like image shows

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # ── Top Row: Scrollable Mappings ──
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        
        scroll_content = QWidget()
        scroll_layout = QHBoxLayout(scroll_content)
        scroll_layout.setContentsMargins(0, 5, 0, 5)
        scroll_layout.setSpacing(2)

        lbl_fmt = QLabel("Định dạng nhập")
        lbl_fmt.setFixedWidth(100)
        scroll_layout.addWidget(lbl_fmt)
        scroll_layout.addSpacing(10)

        self.mapping_combos = []
        
        # 18 comboboxes as requested
        for i in range(18):
            cb = QComboBox()
            for text, data_key in self.mapping_options:
                cb.addItem(text, data_key)
            self.mapping_combos.append(cb)
            
            scroll_layout.addWidget(cb)
            if i < 17:
                sep = QLabel("|")
                sep.setObjectName("Separator")
                scroll_layout.addWidget(sep)

        scroll_layout.addStretch()
        scroll.setWidget(scroll_content)
        
        layout.addWidget(scroll)

        # ── Bottom Row: Action Buttons ──
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(20)

        btn_copy = QPushButton("Copy to Clipboard")
        btn_save = QPushButton("Lưu ra File")
        btn_clear = QPushButton("Bỏ Chọn Tất cả")
        btn_select_all = QPushButton("Chọn Tất cả")
        btn_ok = QPushButton("OK")

        # Apply CSS Class
        for btn in [btn_copy, btn_save, btn_clear, btn_select_all, btn_ok]:
            btn.setProperty("class", "action-btn")

        btn_copy.clicked.connect(self.do_copy)
        btn_save.clicked.connect(self.do_save)
        btn_clear.clicked.connect(self.clear_all)
        btn_select_all.clicked.connect(self.preset_all)
        btn_ok.clicked.connect(self.accept)

        btn_layout.addWidget(btn_copy)
        btn_layout.addWidget(btn_save)
        btn_layout.addStretch() # Push center actions slightly apart
        btn_layout.addWidget(btn_clear)
        btn_layout.addWidget(btn_select_all)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_ok)

        layout.addLayout(btn_layout)

    def clear_all(self):
        for cb in self.mapping_combos:
            cb.setCurrentIndex(0) # "Bỏ qua"

    def preset_all(self):
        # Preset the primary options in sequence
        # UID | PASS | 2FA | Email | Pass Email | Mail Reco | Proxy | Cookie | UserAgent | Token | Birthday | UID Target | Note | Friend | Ngày tạo | Email Old | Gender
        preset_sequence = [
            "fb_uid", "fb_pass", "fb_2fa", "fb_email", "fb_pass_email",
            "fb_email_recovery", "fb_proxy", "fb_cookie", "fb_useragent", "fb_token",
            "fb_dob", "fb_uid_target", "fb_note", "fb_friends", "fb_created", 
            "fb_old_pass", "fb_gender"
        ]
        
        for i, cb in enumerate(self.mapping_combos):
            if i < len(preset_sequence):
                idx = cb.findData(preset_sequence[i])
                cb.setCurrentIndex(idx if idx >= 0 else 0)
            else:
                cb.setCurrentIndex(0) # Pad rest with Bỏ qua

    def build_export_string(self):
        if not self.profiles:
            return ""

        mappings = [cb.currentData() for cb in self.mapping_combos]
        if not any(mappings): # All empty
            return ""

        lines = []
        for p in self.profiles:
            parts = []
            for key in mappings:
                if key: # Has mapping
                    parts.append(str(p.get(key, "")).strip())
                else: # Allow spacing alignment for untouched combos
                    parts.append("")
            
            # Remove trailing empty pipes 
            while parts and not parts[-1]:
                parts.pop()
                
            lines.append("|".join(parts))
            
        return "\n".join(lines)

    def do_copy(self):
        text = self.build_export_string()
        if not text:
            QMessageBox.information(self, "Thông báo", "Không có dữ liệu hợp lệ để xuất (hoặc chưa chọn định dạng)!")
            return
            
        QApplication.clipboard().setText(text)
        QMessageBox.information(self, "Thành công", f"Đã copy {len(self.profiles)} dòng vào bộ nhớ tạm.")

    def do_save(self):
        text = self.build_export_string()
        if not text:
            QMessageBox.information(self, "Thông báo", "Không có dữ liệu hợp lệ để xuất!")
            return
            
        path, _ = QFileDialog.getSaveFileName(self, "Lưu file", "", "Text Files (*.txt);;All Files (*)")
        if path:
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(text)
                QMessageBox.information(self, "Thành công", f"Đã lưu thành công ra file:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Lỗi", f"Lỗi khi lưu file: {str(e)}")
