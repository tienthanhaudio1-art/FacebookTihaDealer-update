from ui.copyable_table import CopyableTable
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QPushButton, QTableWidget, QTableWidgetItem, 
    QHeaderView, QMessageBox, QInputDialog, QDialog, QFormLayout, QLineEdit, QDialogButtonBox, QMenu, QTextEdit, QLabel, QTabWidget, QSpinBox, QComboBox, QCheckBox, QScrollArea,
    QGraphicsOpacityEffect
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QPropertyAnimation, QEasingCurve, QRectF
from PyQt6.QtGui import (
    QIcon, QColor, QClipboard, QPixmap, QKeySequence,
    QPainter, QPen, QBrush, QLinearGradient, QPainterPath, QRadialGradient
)
from PyQt6.QtWidgets import QApplication
import os
from core.updater import check_for_update, apply_update, CURRENT_VERSION, DownloadUpdateThread, get_local_version
from core.licensing import get_stored_license, verify_license, get_expiry_date_str

class AddProfileDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("btn_add"))
        self.resize(300, 200)
        
        layout = QVBoxLayout(self)
        form_layout = QFormLayout()
        
        self.name_input = QLineEdit()
        self.uid_input = QLineEdit()
        self.email_input = QLineEdit()
        self.pass_input = QLineEdit()
        self.pass_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.tfa_input = QLineEdit()
        
        form_layout.addRow(tr("lbl_profile_name"), self.name_input)
        form_layout.addRow(tr("lbl_fb_uid"), self.uid_input)
        form_layout.addRow(tr("lbl_fb_email"), self.email_input)
        form_layout.addRow(tr("lbl_fb_pass"), self.pass_input)
        form_layout.addRow(tr("lbl_fb_2fa"), self.tfa_input)
        
        layout.addLayout(form_layout)
        
        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)
        
    def get_data(self):
        return (
            self.name_input.text(),
            self.uid_input.text(),
            self.email_input.text(),
            self.pass_input.text(),
            self.tfa_input.text()
        )

class SetProxyDialog(QDialog):
    """Dialog to set proxy for selected profiles. One proxy per line.
    Auto-detects format: ip:port, ip:port:user:pass, user:pass@ip:port,
    socks5://ip:port, http://user:pass@ip:port"""
    def __init__(self, parent=None, profile_count=1):
        super().__init__(parent)
        self.setWindowTitle("Set Proxy cho Profile")
        self.resize(500, 400)
        self.setStyleSheet("""
            QDialog { background-color: #f0f0f0; }
            QLabel { color: #000000; font-family: 'Segoe UI', Arial; }
            QTextEdit { background: #fff; border: 1px solid #99ccff; border-radius: 3px; padding: 4px; font-family: Consolas, monospace; font-size: 12px; }
            QPushButton { background: #e1e1e1; border: 1px solid #adadad; border-radius: 2px; padding: 6px 12px; color: #000; font-weight: bold; }
            QPushButton:hover { background: #e5f1fb; border-color: #0078d7; }
        """)
        
        layout = QVBoxLayout(self)
        
        info_lbl = QLabel(f"Nhập proxy cho {profile_count} profile (mỗi proxy 1 dòng).")
        info_lbl.setStyleSheet("font-weight: bold; font-size: 13px;")
        layout.addWidget(info_lbl)
        
        fmt_lbl = QLabel("Định dạng hỗ trợ: ip:port | ip:port:user:pass | user:pass@ip:port | socks5://ip:port")
        fmt_lbl.setStyleSheet("color: #666; font-size: 11px;")
        fmt_lbl.setWordWrap(True)
        layout.addWidget(fmt_lbl)
        
        self.text_input = QTextEdit()
        self.text_input.setPlaceholderText("192.168.1.1:8080\nuser:pass@proxy.com:3128\nsocks5://10.0.0.1:1080\n...")
        self.text_input.textChanged.connect(self._on_text_changed)
        layout.addWidget(self.text_input)
        
        self.preview_lbl = QLabel("")
        self.preview_lbl.setStyleSheet("color: #0078d7; font-size: 11px;")
        self.preview_lbl.setWordWrap(True)
        layout.addWidget(self.preview_lbl)
        
        # Mode: assign sequentially or same proxy for all
        mode_layout = QHBoxLayout()
        self.chk_same = QCheckBox("Dùng chung 1 proxy cho tất cả profile đã chọn")
        self.chk_same.setChecked(profile_count <= 1)
        mode_layout.addWidget(self.chk_same)
        mode_layout.addStretch()
        layout.addLayout(mode_layout)
        
        btn_row = QHBoxLayout()
        btn_ok = QPushButton("Áp dụng Proxy")
        btn_ok.setStyleSheet("background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #33bbf6,stop:1 #0f7bf8); color: white; font-weight: bold;")
        btn_ok.clicked.connect(self.accept)
        btn_cancel = QPushButton("Hủy")
        btn_cancel.clicked.connect(self.reject)
        btn_clear = QPushButton("Xóa Proxy")
        btn_clear.setStyleSheet("background: #ff6b6b; color: white;")
        btn_clear.clicked.connect(self._clear_proxy)
        btn_row.addWidget(btn_clear)
        btn_row.addStretch()
        btn_row.addWidget(btn_cancel)
        btn_row.addWidget(btn_ok)
        layout.addLayout(btn_row)
        
        self._clear_mode = False
    
    def _clear_proxy(self):
        self._clear_mode = True
        self.accept()
    
    def _on_text_changed(self):
        lines = [l.strip() for l in self.text_input.toPlainText().strip().split('\n') if l.strip()]
        if not lines:
            self.preview_lbl.setText("")
            return
        
        # Auto-detect format of first line
        first = lines[0]
        import re
        if re.match(r'^(https?|socks[45])://', first, re.IGNORECASE):
            fmt = "Giao thức + địa chỉ (vd: socks5://ip:port)"
        elif '@' in first:
            fmt = "user:pass@host:port"
        elif first.count(':') == 3:
            fmt = "host:port:user:pass"
        elif first.count(':') == 1:
            fmt = "host:port"
        else:
            fmt = "Không nhận dạng được"
        
        self.preview_lbl.setText(f"📡 Đã nhận {len(lines)} proxy | Định dạng: {fmt}")
    
    def get_proxies(self):
        if self._clear_mode:
            return []  # Empty list = clear proxy
        lines = [l.strip() for l in self.text_input.toPlainText().strip().split('\n') if l.strip()]
        return lines
    
    def is_same_for_all(self):
        return self.chk_same.isChecked()
    
    def is_clear_mode(self):
        return self._clear_mode

class BulkAddDialog(QDialog):
    def __init__(self, parent=None, current_category="Default", all_categories=None):
        super().__init__(parent)
        self.setWindowTitle(tr("btn_add"))
        self.resize(800, 500)
        
        self.all_categories = all_categories or ["Default"]
        self.current_category = current_category
        
        layout = QVBoxLayout(self)
        
        # 1. Category Selection
        cat_layout = QHBoxLayout()
        cat_lbl = QLabel("Chọn danh mục:")
        cat_lbl.setFixedWidth(100)
        self.combo_cat = QComboBox()
        self.combo_cat.addItems(self.all_categories)
        idx = self.combo_cat.findText(current_category)
        if idx >= 0:
            self.combo_cat.setCurrentIndex(idx)
        cat_layout.addWidget(cat_lbl)
        cat_layout.addWidget(self.combo_cat)
        cat_layout.addStretch()
        layout.addLayout(cat_layout)
        
        # 2. Format Selection (Predefined templates)
        fmt_layout = QHBoxLayout()
        fmt_lbl = QLabel("Định dạng nhập:")
        fmt_lbl.setFixedWidth(100)
        self.combo_fmt = QComboBox()
        self.combo_fmt.addItem("Tùy chỉnh", [])
        self.combo_fmt.addItem("UID|PASS", ["fb_uid", "fb_pass"])
        self.combo_fmt.addItem("UID|PASS|2FA", ["fb_uid", "fb_pass", "fb_2fa"])
        self.combo_fmt.addItem("UID|PASS|2FA|Email", ["fb_uid", "fb_pass", "fb_2fa", "fb_email"])
        self.combo_fmt.addItem("UID|PASS|2FA|Email|Pass Email", ["fb_uid", "fb_pass", "fb_2fa", "fb_email", "fb_pass_email"])
        self.combo_fmt.addItem("UID|PASS|2FA|Cookie", ["fb_uid", "fb_pass", "fb_2fa", "fb_cookie"])
        self.combo_fmt.currentIndexChanged.connect(self.on_format_changed)
        
        fmt_layout.addWidget(fmt_lbl)
        fmt_layout.addWidget(self.combo_fmt)
        fmt_layout.addStretch()
        layout.addLayout(fmt_layout)
        
        # 3. Dynamic Column Mapping Comboboxes
        from ui.settings_dialog import ALL_COLUMNS
        self.available_fields = [("Bỏ qua", "")] + [(lbl, key) for key, lbl, _ in ALL_COLUMNS if key not in ["stt", "status", "chk"]]
        
        self.mapping_combos = []
        map_layout = QHBoxLayout()
        map_layout.setSpacing(2)
        
        # Create 15 comboboxes for mapping up to 15 columns separated by |
        for i in range(15):
            cb = QComboBox()
            for lbl, key in self.available_fields:
                cb.addItem(lbl, key)
            cb.setFixedWidth(100)
            self.mapping_combos.append(cb)
            map_layout.addWidget(cb)
            
            if i < 14:
                sep_lbl = QLabel("|")
                sep_lbl.setFixedWidth(10)
                sep_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
                map_layout.addWidget(sep_lbl)
                
        map_layout.addStretch()
        
        # Put mapping combos inside a scroll area since it's wide
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFixedHeight(60)
        scroll_area.setStyleSheet("QScrollArea { border: none; }")
        
        map_container = QWidget()
        map_container.setLayout(map_layout)
        scroll_area.setWidget(map_container)
        
        layout.addWidget(scroll_area)
        
        # 4. Text Edit Area
        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText("Dán thông tin tài khoản vào đây, chia cách bởi dấu '|'...")
        layout.addWidget(self.text_edit)
        
        # 5. Bottom Options
        bottom_layout = QHBoxLayout()
        
        self.btn_ok = QPushButton("OK")
        self.btn_ok.setMinimumWidth(120)
        self.btn_ok.setStyleSheet("background-color: #409eff; color: white; font-weight: bold; border-radius: 4px; padding: 8px;")
        self.btn_ok.clicked.connect(self.accept)
        
        self.chk_no_useragent = QCheckBox("Không lấy UserAgent từ cookie")
        self.chk_no_useragent.setChecked(True)
        
        self.combo_random_ua = QComboBox()
        self.combo_random_ua.addItems(["Random UserAgent Chrome Android", "Random UserAgent Chrome Windows", "Random UserAgent Safari iOS"])
        
        bottom_layout.addWidget(self.btn_ok)
        bottom_layout.addSpacing(20)
        bottom_layout.addWidget(self.chk_no_useragent)
        bottom_layout.addWidget(self.combo_random_ua)
        bottom_layout.addStretch()
        
        # Cancel Button
        self.btn_cancel = QPushButton("Hủy")
        self.btn_cancel.clicked.connect(self.reject)
        bottom_layout.addWidget(self.btn_cancel)
        
        layout.addLayout(bottom_layout)
        
        # Init default "Tùy chỉnh" layout
        self.on_format_changed(0)
        
    def on_format_changed(self, index):
        keys = self.combo_fmt.currentData()
        # Reset all
        for cb in self.mapping_combos:
            cb.setCurrentIndex(0) # Bỏ qua
            
        if keys:
            for i, key in enumerate(keys):
                if i < len(self.mapping_combos):
                    # Find index of key
                    idx = self.mapping_combos[i].findData(key)
                    if idx >= 0:
                        self.mapping_combos[i].setCurrentIndex(idx)
        
    def get_parsed_data(self):
        text = self.text_edit.toPlainText().strip()
        if not text:
            return None, []
            
        category = self.combo_cat.currentText()
        if category == "All Categories": category = "Default"
        
        mappings = [cb.currentData() for cb in self.mapping_combos]
        
        results = []
        for line in text.split('\n'):
            line = line.strip()
            if not line: continue
            
            parts = line.split('|')
            profile_data = {"category": category}
            
            for i, part in enumerate(parts):
                if i < len(mappings):
                    key = mappings[i]
                    if key: # Ignore if "Bỏ qua" (empty string)
                        profile_data[key] = part.strip()
            
            # Default name if empty
            if not profile_data.get("name"):
                profile_data["name"] = profile_data.get("fb_uid", profile_data.get("fb_email", "New Profile"))
                
            results.append(profile_data)
            
        return category, results

from core.profile_manager import ProfileManager
from core.browser_manager import BrowserManager
from ui.email_manager import EmailManagerWidget
from ui.settings_dialog import SettingsDialog, get_visible_columns, load_settings
from core.i18n import tr, set_language

class UpdateThread(QThread):
    """Background thread: check GitHub for new version."""
    finished = pyqtSignal(bool, str, str)  # (found, version, changelog)

    def run(self):
        try:
            found, version, changelog = check_for_update()
            self.finished.emit(
                bool(found),
                str(version or ""),
                str(changelog or "")
            )
        except Exception as e:
            self.finished.emit(False, "", f"Lỗi kiểm tra: {str(e)[:80]}")


class FilterProfileDialog(QDialog):
    """Dark-themed filter/search dialog for profiles."""

    FILTER_MODES = [
        "Lọc theo UID",
        "Lọc theo Name",
        "Lọc theo Ghi chú",
        "Lọc nhiều danh mục",
        "Lọc theo Email",
        "Lọc theo Email Old",
        "Lọc theo Token",
        "Lọc theo domain Email",
        "Lọc theo domain Email Old",
        "Lọc theo Proxy",
        "Lọc theo Password",
        "Lọc theo Live",
    ]

    def __init__(self, parent=None, categories=None):
        super().__init__(parent)
        self.setWindowTitle("Lọc Profile --- Điền UID hoặc text để lọc (có thể nhập nhiều dòng)")
        self.resize(650, 560)
        self.setMinimumSize(500, 400)
        self._categories = categories or ["Default"]
        self._setup_ui()
        self._apply_dark_theme()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(10)

        # ─── Search input ───
        lbl_input = QLabel("Nhập nội dung tìm kiếm hoặc UID")
        lbl_input.setStyleSheet("color: #93c5fd; font-weight: 700; font-size: 12px;")
        layout.addWidget(lbl_input)

        self.text_input = QTextEdit()
        self.text_input.setPlaceholderText("Nhập UID, tên, email... mỗi dòng một giá trị")
        self.text_input.setMinimumHeight(120)
        layout.addWidget(self.text_input)

        # ─── Category table ───
        lbl_cat = QLabel("Chọn danh mục")
        lbl_cat.setStyleSheet("color: #93c5fd; font-weight: 700; font-size: 12px;")
        layout.addWidget(lbl_cat)

        self.cat_table = QTableWidget()
        self.cat_table.setColumnCount(3)
        self.cat_table.setHorizontalHeaderLabels(["", "ID", "Category"])
        self.cat_table.verticalHeader().setVisible(False)
        self.cat_table.setMinimumHeight(160)
        self.cat_table.setAlternatingRowColors(False)

        # Select-all checkbox in header
        self._chk_all = QCheckBox()
        self._chk_all.setChecked(True)
        self._chk_all.stateChanged.connect(self._toggle_all_cats)

        header = self.cat_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.cat_table.setColumnWidth(0, 34)
        self.cat_table.setColumnWidth(1, 50)

        # Populate categories
        self.cat_table.setRowCount(len(self._categories))
        self._cat_checkboxes = []
        for i, cat in enumerate(self._categories):
            chk = QCheckBox()
            chk.setChecked(True)
            self._cat_checkboxes.append(chk)

            chk_widget = QWidget()
            chk_layout = QHBoxLayout(chk_widget)
            chk_layout.addWidget(chk)
            chk_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            chk_layout.setContentsMargins(0, 0, 0, 0)
            self.cat_table.setCellWidget(i, 0, chk_widget)

            id_item = QTableWidgetItem(str(i + 1))
            id_item.setFlags(id_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            id_item.setForeground(QColor("#a78bfa"))
            self.cat_table.setItem(i, 1, id_item)

            cat_item = QTableWidgetItem(cat)
            cat_item.setFlags(cat_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            cat_item.setForeground(QColor("#f7fafc"))
            self.cat_table.setItem(i, 2, cat_item)

        layout.addWidget(self.cat_table)

        # ─── Filter mode ───
        mode_layout = QHBoxLayout()
        self.combo_mode = QComboBox()
        self.combo_mode.addItems(self.FILTER_MODES)
        self.combo_mode.setMinimumHeight(30)
        mode_layout.addWidget(self.combo_mode, 1)
        layout.addLayout(mode_layout)

        # ─── Buttons ───
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()

        self.btn_show_all = QPushButton("Hiện tất cả")
        self.btn_show_all.setMinimumWidth(110)
        self.btn_show_all.setFixedHeight(34)
        self.btn_show_all.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #4a5568, stop:1 #3a4a5c);
                border: 1px solid #718096;
                border-radius: 6px;
                color: #f7fafc;
                font-weight: 700;
                padding: 0 16px;
            }
            QPushButton:hover { background: #718096; }
        """)
        self.btn_show_all.clicked.connect(self._on_show_all)

        self.btn_ok = QPushButton("OK — Lọc")
        self.btn_ok.setMinimumWidth(130)
        self.btn_ok.setFixedHeight(34)
        self.btn_ok.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #2563eb, stop:1 #1d4ed8);
                border: 1px solid #3b82f6;
                border-radius: 6px;
                color: #ffffff;
                font-weight: 700;
                font-size: 13px;
                padding: 0 20px;
            }
            QPushButton:hover { background: #3b82f6; }
        """)
        self.btn_ok.clicked.connect(self.accept)

        btn_layout.addWidget(self.btn_show_all)
        btn_layout.addSpacing(10)
        btn_layout.addWidget(self.btn_ok)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

    def _apply_dark_theme(self):
        self.setStyleSheet("""
            QDialog {
                background: #1a202c;
                color: #f7fafc;
                border: 1px solid #4a5568;
                border-radius: 10px;
            }
            QTextEdit {
                background: #2d3748;
                border: 1px solid #4a5568;
                border-radius: 6px;
                color: #f7fafc;
                padding: 8px;
                font-size: 12px;
            }
            QTextEdit:focus {
                border-color: #a78bfa;
            }
            QTableWidget {
                background: #1e2533;
                gridline-color: #334155;
                border: 1px solid #4a5568;
                border-radius: 6px;
                color: #f7fafc;
            }
            QTableWidget::item {
                padding: 4px;
                border-bottom: 1px solid #334155;
            }
            QHeaderView::section {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #2d3748, stop:1 #252f3f);
                color: #c4b5fd;
                padding: 5px;
                border: none;
                border-bottom: 2px solid #7c3aed;
                border-right: 1px solid #334155;
                font-weight: 700;
            }
            QComboBox {
                background: #2d3748;
                border: 1px solid #4a5568;
                border-radius: 6px;
                color: #f7fafc;
                padding: 6px 10px;
                font-size: 12px;
            }
            QComboBox:focus { border-color: #a78bfa; }
            QComboBox::drop-down {
                border-left: 1px solid #4a5568;
                width: 22px;
                background: #3a4a5c;
            }
            QComboBox QAbstractItemView {
                background: #2d3748;
                border: 1px solid #4a5568;
                selection-background-color: #8b5cf6;
                color: #f7fafc;
            }
            QCheckBox { color: #f7fafc; }
            QCheckBox::indicator {
                width: 16px; height: 16px;
                border: 1px solid #718096;
                border-radius: 3px;
                background: #2d3748;
            }
            QCheckBox::indicator:checked {
                background: #8b5cf6;
                border-color: #a78bfa;
            }
        """)

    def _toggle_all_cats(self, state):
        checked = state == 2
        for chk in self._cat_checkboxes:
            chk.setChecked(checked)

    def _on_show_all(self):
        """Signal parent to show all profiles and close."""
        parent = self.parent()
        if hasattr(parent, 'show_all_profiles'):
            parent.show_all_profiles()
        self.reject()

    def get_query_lines(self):
        text = self.text_input.toPlainText().strip()
        if not text:
            return []
        return [l.strip() for l in text.split('\n') if l.strip()]

    def get_filter_mode(self):
        return self.combo_mode.currentText()

    def get_selected_categories(self):
        selected = []
        for i, chk in enumerate(self._cat_checkboxes):
            if chk.isChecked() and i < len(self._categories):
                selected.append(self._categories[i])
        return selected

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # Frameless window with custom title bar
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)

        # For dragging
        self._drag_pos = None

        # Load settings and apply language
        self.settings = load_settings()
        set_language(self.settings.get("language", "vi"))
        
        # Get Expiry
        license_key = get_stored_license()
        self._expiry_info = get_expiry_date_str(license_key)
        
        self.setWindowTitle(tr("app_title") + f" v{CURRENT_VERSION}")
        self.resize(1200, 720)
        self.setMinimumSize(1050, 530)
        
        # Set window icon
        icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "logo.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        
        self.apply_theme()
        
        self.profile_manager = ProfileManager()
        self.browser_manager = BrowserManager()
        
        self.profiles = []
        self.init_ui()
        self.load_categories_to_ui()
        self.load_data()
        
        # Start background update check
        self.update_thread = UpdateThread()
        self.update_thread.finished.connect(self.on_update_check_finished)
        self.update_thread.start()

        # ─── Animated Border ───
        self._border_hue = 0.0
        self._border_timer = QTimer(self)
        self._border_timer.setInterval(30)  # ~33fps
        self._border_timer.timeout.connect(self._animate_border)
        self._border_timer.start()

        # For edge resize
        self._resize_edge = None
        self._resize_start = None
        self._EDGE = 8  # Wider grab zone
        self.setMouseTracking(True)
        
        # Enable native Windows resize border on frameless window
        self._enable_native_resize()

    def _enable_native_resize(self):
        """Add native Windows resize border to frameless window via WinAPI."""
        try:
            import ctypes
            hwnd = int(self.winId())
            # GWL_STYLE = -16, WS_THICKFRAME = 0x00040000, WS_MAXIMIZEBOX = 0x00010000
            style = ctypes.windll.user32.GetWindowLongPtrW(hwnd, -16)
            style |= 0x00040000 | 0x00010000  # WS_THICKFRAME | WS_MAXIMIZEBOX
            ctypes.windll.user32.SetWindowLongPtrW(hwnd, -16, style)
            # Force Windows to recompute frame
            ctypes.windll.user32.SetWindowPos(
                hwnd, 0, 0, 0, 0, 0,
                0x0001 | 0x0002 | 0x0004 | 0x0020  # NOMOVE|NOSIZE|NOZORDER|FRAMECHANGED
            )
        except Exception:
            pass

    def _animate_border(self):
        self._border_hue = (self._border_hue + 0.7) % 360
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w, h = self.width(), self.height()
        R = 14  # corner radius

        # ─── Clip to rounded rect ───
        clip = QPainterPath()
        clip.addRoundedRect(QRectF(0, 0, w, h), R, R)
        p.setClipPath(clip)
        p.fillRect(0, 0, w, h, QColor(13, 16, 23))

        p.setClipping(False)
        hue = self._border_hue

        # ─── Outer glow layer (wide, faded) ───
        for i in range(3):
            alpha = 0.12 - i * 0.03
            gc = QColor.fromHsvF(hue / 360, 0.8, 1.0, max(alpha, 0.02))
            p.setPen(QPen(gc, 6 - i * 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            off = 1 + i
            p.drawRoundedRect(QRectF(off, off, w - off * 2, h - off * 2), R, R)

        # ─── Main animated border (bright, 2px) ───
        c1 = QColor.fromHsvF(hue / 360, 0.85, 1.0, 0.9)
        c2 = QColor.fromHsvF(((hue + 90) % 360) / 360, 0.7, 1.0, 0.7)
        c3 = QColor.fromHsvF(((hue + 180) % 360) / 360, 0.85, 1.0, 0.9)
        c4 = QColor.fromHsvF(((hue + 270) % 360) / 360, 0.7, 1.0, 0.7)

        grad = QLinearGradient(0, 0, w, h)
        grad.setColorAt(0.0, c1)
        grad.setColorAt(0.25, c2)
        grad.setColorAt(0.5, c3)
        grad.setColorAt(0.75, c4)
        grad.setColorAt(1.0, c1)

        p.setPen(QPen(QBrush(grad), 2.0))
        p.drawRoundedRect(QRectF(1, 1, w - 2, h - 2), R, R)

        # ─── Corner glow accents ───
        for cx, cy in [(0, 0), (w, 0), (0, h), (w, h)]:
            g = QRadialGradient(cx, cy, 90)
            g.setColorAt(0.0, QColor.fromHsvF(hue / 360, 0.6, 1.0, 0.12))
            g.setColorAt(0.5, QColor.fromHsvF(((hue + 60) % 360) / 360, 0.4, 1.0, 0.04))
            g.setColorAt(1.0, QColor(0, 0, 0, 0))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(g))
            p.drawEllipse(cx - 90, cy - 90, 180, 180)

        # ─── Top edge highlight ───
        top_g = QLinearGradient(0, 0, w, 0)
        top_g.setColorAt(0.0, QColor(0, 0, 0, 0))
        top_g.setColorAt(0.3, QColor.fromHsvF(hue / 360, 0.5, 1.0, 0.15))
        top_g.setColorAt(0.7, QColor.fromHsvF(((hue + 180) % 360) / 360, 0.5, 1.0, 0.15))
        top_g.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setPen(QPen(QBrush(top_g), 1))
        p.drawLine(R, 2, w - R, 2)

        p.end()

    # ─── Edge resize for frameless window ───
    def _edge_zone(self, pos):
        e = self._EDGE
        x, y, w, h = pos.x(), pos.y(), self.width(), self.height()
        if x < e and y < e: return "tl"
        if x > w - e and y < e: return "tr"
        if x < e and y > h - e: return "bl"
        if x > w - e and y > h - e: return "br"
        if x < e: return "l"
        if x > w - e: return "r"
        if y < e: return "t"
        if y > h - e: return "b"
        return None

    def _set_resize_cursor(self, edge):
        cursors = {
            "l": Qt.CursorShape.SizeHorCursor,
            "r": Qt.CursorShape.SizeHorCursor,
            "t": Qt.CursorShape.SizeVerCursor,
            "b": Qt.CursorShape.SizeVerCursor,
            "tl": Qt.CursorShape.SizeFDiagCursor,
            "br": Qt.CursorShape.SizeFDiagCursor,
            "tr": Qt.CursorShape.SizeBDiagCursor,
            "bl": Qt.CursorShape.SizeBDiagCursor,
        }
        if edge and edge in cursors:
            self.setCursor(cursors[edge])
        else:
            self.unsetCursor()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            edge = self._edge_zone(event.pos())
            if edge:
                self._resize_edge = edge
                self._resize_start = event.globalPosition().toPoint()
                self._resize_geo = self.geometry()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._resize_edge and self._resize_start:
            delta = event.globalPosition().toPoint() - self._resize_start
            geo = self._resize_geo
            e = self._resize_edge
            new_geo = geo.adjusted(
                delta.x() if 'l' in e else 0,
                delta.y() if 't' in e else 0,
                delta.x() if 'r' in e else 0,
                delta.y() if 'b' in e else 0,
            )
            if new_geo.width() >= self.minimumWidth() and new_geo.height() >= self.minimumHeight():
                self.setGeometry(new_geo)
            event.accept()
            return
        # Update cursor based on edge zone
        edge = self._edge_zone(event.pos())
        self._set_resize_cursor(edge)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._resize_edge = None
        self._resize_start = None
        self.unsetCursor()
        super().mouseReleaseEvent(event)

    # ─── Custom Title Bar ─────────────────────
    def _build_title_bar(self):
        """Create premium custom title bar widget."""
        bar = QWidget()
        bar.setObjectName("CustomTitleBar")
        bar.setFixedHeight(42)
        bar.setStyleSheet("""
            #CustomTitleBar {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #141926, stop:1 #0d1017);
                border-bottom: 1px solid #1e293b;
            }
        """)

        ly = QHBoxLayout(bar)
        ly.setContentsMargins(12, 0, 6, 0)
        ly.setSpacing(0)

        # ─── Logo with styled glow container ───
        logo_container = QLabel()
        logo_container.setFixedSize(32, 32)
        logo_container.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_container.setStyleSheet("""
            background: qradialgradient(cx:0.5,cy:0.5,radius:0.6,
                fx:0.5,fy:0.5, stop:0 #1e3a5f, stop:1 #0d1017);
            border: 1px solid #2563eb;
            border-radius: 16px;
        """)
        logo_path = os.path.join(os.path.dirname(__file__), "..", "assets", "logo.png")
        if os.path.exists(logo_path):
            pix = QPixmap(logo_path).scaled(
                22, 22,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            logo_container.setPixmap(pix)

        # Smooth pulsing glow
        self._logo_effect = QGraphicsOpacityEffect(logo_container)
        logo_container.setGraphicsEffect(self._logo_effect)
        self._logo_anim = QPropertyAnimation(self._logo_effect, b"opacity")
        self._logo_anim.setDuration(3000)  # Slower = smoother
        self._logo_anim.setStartValue(0.7)
        self._logo_anim.setEndValue(1.0)
        self._logo_anim.setEasingCurve(QEasingCurve.Type.InOutSine)
        self._logo_anim.setLoopCount(-1)
        self._logo_anim.start()

        ly.addWidget(logo_container)
        ly.addSpacing(10)

        # ─── Title text ───
        title_lbl = QLabel(
            f'<span style="color:#a78bfa;font-weight:800;font-size:13px;letter-spacing:0.5px;">Facebook</span>'
            f'<span style="color:#f1f5f9;font-weight:700;font-size:13px;"> THE TIHA DEALER</span>'
            f'<span style="color:#475569;font-size:10px;">  v{CURRENT_VERSION}</span>'
            f'<span style="color:#334155;font-size:10px;">  •  Hạn: {self._expiry_info}</span>'
        )
        title_lbl.setStyleSheet("background: transparent;")
        ly.addWidget(title_lbl)

        ly.addStretch()

        # ─── Animated Contact Banner ───
        contact_widget = QWidget()
        contact_widget.setFixedHeight(34)
        contact_widget.setObjectName("ContactBanner")
        contact_layout = QHBoxLayout(contact_widget)
        contact_layout.setContentsMargins(0, 0, 0, 0)
        contact_layout.setSpacing(6)

        # Telegram button with animated glow
        tg_btn = QPushButton("  ✈  Liên hệ Telegram  ")
        tg_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        tg_btn.setObjectName("TelegramBtn")
        tg_btn.clicked.connect(lambda: __import__('webbrowser').open("https://t.me/ingredientthetiha"))

        # Zalo button
        zalo_btn = QPushButton("  📱  Zalo  ")
        zalo_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        zalo_btn.setObjectName("ZaloBtn")
        zalo_btn.clicked.connect(lambda: __import__('webbrowser').open("https://zalo.me/ingredientthetiha"))

        contact_layout.addWidget(tg_btn)
        contact_layout.addWidget(zalo_btn)

        # Animated gradient cycling for contact banner
        self._contact_hue = 0
        self._contact_widget = contact_widget
        self._tg_btn = tg_btn
        self._zalo_btn = zalo_btn

        def _update_contact_glow():
            self._contact_hue = (self._contact_hue + 1) % 360
            h = self._contact_hue
            # Gradient between two hues for smooth cycling
            h2 = (h + 40) % 360
            h3 = (h + 80) % 360
            self._tg_btn.setStyleSheet(f"""
                QPushButton#TelegramBtn {{
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                        stop:0 hsl({h},80%,30%), stop:0.5 hsl({h2},85%,35%), stop:1 hsl({h3},80%,30%));
                    border: 1px solid hsl({h2},90%,50%);
                    border-radius: 14px;
                    color: #ffffff;
                    font-size: 12px;
                    font-weight: 800;
                    padding: 5px 18px;
                    letter-spacing: 0.8px;
                }}
                QPushButton#TelegramBtn:hover {{
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                        stop:0 hsl({h},85%,40%), stop:1 hsl({h3},85%,45%));
                    border: 2px solid hsl({h2},95%,60%);
                }}
            """)
            self._zalo_btn.setStyleSheet(f"""
                QPushButton#ZaloBtn {{
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                        stop:0 hsl({h3},75%,28%), stop:1 hsl({h},75%,28%));
                    border: 1px solid hsl({h},85%,45%);
                    border-radius: 14px;
                    color: #ffffff;
                    font-size: 12px;
                    font-weight: 800;
                    padding: 5px 18px;
                    letter-spacing: 0.8px;
                }}
                QPushButton#ZaloBtn:hover {{
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                        stop:0 hsl({h3},80%,38%), stop:1 hsl({h},80%,38%));
                    border: 2px solid hsl({h},90%,55%);
                }}
            """)

        self._contact_timer = QTimer(self)
        self._contact_timer.timeout.connect(_update_contact_glow)
        self._contact_timer.start(50)  # 20 FPS smooth animation
        _update_contact_glow()  # Initial style

        ly.addWidget(contact_widget)
        ly.addSpacing(12)


        # ─── Window Control Buttons ───
        btn_style = """
            QPushButton {{
                background: transparent;
                border: 1px solid transparent;
                color: {color};
                font-size: 13px;
                font-weight: bold;
                min-width: 34px; max-width: 34px;
                min-height: 26px; max-height: 26px;
                border-radius: 5px;
            }}
            QPushButton:hover {{
                background: {hover_bg};
                border-color: {border};
            }}
        """

        btn_min = QPushButton("─")
        btn_min.setStyleSheet(btn_style.format(color="#a0aec0", hover_bg="#2d3748", border="#4a5568"))
        btn_min.clicked.connect(self.showMinimized)

        btn_max = QPushButton("□")
        btn_max.setStyleSheet(btn_style.format(color="#a0aec0", hover_bg="#2d3748", border="#4a5568"))
        btn_max.clicked.connect(self._toggle_maximize)

        btn_close = QPushButton("✕")
        btn_close.setStyleSheet(btn_style.format(color="#f87171", hover_bg="#450a0a", border="#991b1b"))
        btn_close.clicked.connect(self.close)

        ly.addWidget(btn_min)
        ly.addSpacing(2)
        ly.addWidget(btn_max)
        ly.addSpacing(2)
        ly.addWidget(btn_close)

        # Drag support
        bar.mousePressEvent = self._title_mouse_press
        bar.mouseMoveEvent = self._title_mouse_move
        bar.mouseDoubleClickEvent = lambda e: self._toggle_maximize()

        return bar

    def _toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def _title_mouse_press(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def _title_mouse_move(self, event):
        if self._drag_pos and event.buttons() == Qt.MouseButton.LeftButton:
            if self.isMaximized():
                self.showNormal()
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()


    def apply_theme(self):
        stylesheet = """
        /* ─── Global & Typography ─── */
        QMainWindow, QDialog {
            background-color: #0c1220;
            color: #e2e8f0;
            font-family: 'Segoe UI', Arial;
            font-size: 12px;
        }
        QWidget {
            font-family: 'Segoe UI', Arial;
            font-size: 12px;
            color: #e2e8f0;
        }

        /* ─── Tab Bar — Muted Blue Zone ─── */
        QTabWidget::pane {
            border: 1px solid #1e3a5f;
            background: #0c1220;
            top: -1px;
            border-radius: 0 0 6px 6px;
        }
        QTabBar::tab {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #162d4a, stop:1 #112240);
            color: #7db8e8;
            padding: 10px 22px;
            margin-right: 3px;
            border: 1px solid #1e3a5f;
            border-bottom: none;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            font-weight: 700;
            font-size: 12px;
        }
        QTabBar::tab:selected {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 #1a4a7a, stop:0.5 #1e5590, stop:1 #2266a8);
            color: #ffffff;
            border: 1px solid #3b82f6;
            border-bottom: 2px solid #0c1220;
            border-top: 2px solid #60a5fa;
            font-weight: 800;
        }
        QTabBar::tab:hover:!selected {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #1a3d65, stop:1 #162d4a);
            color: #bfdbfe;
            border-color: #2563eb;
        }
        QTabBar::tab:first {
            margin-left: 4px;
        }

        /* ─── Buttons — Distinct Toolbar Zone ─── */
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #1e3d6b, stop:1 #162d50);
            border: 1px solid #2a5080;
            border-radius: 5px;
            padding: 6px 14px;
            color: #dbeafe;
            font-weight: 600;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #2a5080, stop:1 #1e3d6b);
            border-color: #3b82f6;
            color: #ffffff;
        }
        QPushButton:pressed {
            background: #153262;
        }

        QPushButton#PrimaryBtn {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #7c3aed, stop:1 #6d28d9);
            border: 1px solid #5b21b6;
            color: white;
        }
        QPushButton#PrimaryBtn:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #8b5cf6, stop:1 #7c3aed);
        }
        QPushButton#PrimaryBtn:pressed {
            background: #5b21b6;
        }

        QPushButton#DeleteBtn {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #ef4444, stop:1 #dc2626);
            border: 1px solid #b91c1c;
            color: white;
        }
        QPushButton#DeleteBtn:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #f87171, stop:1 #ef4444);
        }
        QPushButton#DeleteBtn:pressed {
            background: #b91c1c;
        }

        /* ─── Table — NO CSS background (programmatic coloring) ─── */
        QTableWidget {
            gridline-color: #cbd5e1;
            border: 1px solid #1e3a5f;
            selection-background-color: #93c5fd;
            selection-color: #0f172a;
            outline: none;
            color: #0f172a;
            border-radius: 6px;
        }
        QTableWidget::item {
            padding: 4px 6px;
            border-bottom: 1px solid #cbd5e1;
        }
        QTableWidget::item:selected {
            background-color: #93c5fd;
            color: #0f172a;
        }

        /* ─── Table Header — Light Zone ─── */
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #f8fafc, stop:1 #f1f5f9);
            color: #1e293b;
            padding: 6px 6px;
            border: none;
            border-bottom: 2px solid #94a3b8;
            border-right: 1px solid #cbd5e1;
            font-weight: 700;
            font-size: 11px;
            text-transform: uppercase;
        }

        /* ─── Inputs — Subtle Dark Zone ─── */
        QLineEdit, QTextEdit, QSpinBox, QComboBox {
            background-color: #152a45;
            border: 1px solid #1e3a5f;
            padding: 4px 8px;
            color: #e2e8f0;
            border-radius: 4px;
        }
        QLineEdit:focus, QTextEdit:focus, QSpinBox:focus, QComboBox:focus {
            border-color: #3b82f6;
        }
        QComboBox::drop-down {
            border-left: 1px solid #1e3a5f;
            width: 20px;
            background: #1a3d65;
        }
        QComboBox QAbstractItemView {
            background: #152a45;
            border: 1px solid #1e3a5f;
            selection-background-color: #2563eb;
            color: #e2e8f0;
        }

        /* ─── Labels ─── */
        QLabel {
            color: #e2e8f0;
            font-weight: 500;
        }

        /* ─── CheckBox ─── */
        QCheckBox {
            color: #e2e8f0;
            spacing: 5px;
        }
        QCheckBox::indicator {
            width: 14px;
            height: 14px;
            border: 1px solid #3b82f6;
            border-radius: 3px;
            background: #152a45;
        }
        QCheckBox::indicator:checked {
            background: #2563eb;
            border-color: #3b82f6;
        }

        /* ─── Scrollbar ─── */
        QScrollBar:vertical {
            background: #0c1220;
            width: 10px;
            margin: 0px;
        }
        QScrollBar::handle:vertical {
            background: #1e3a5f;
            min-height: 20px;
            border-radius: 4px;
        }
        QScrollBar::handle:vertical:hover {
            background: #2563eb;
        }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
            height: 0px;
        }
        QScrollBar:horizontal {
            background: #0c1220;
            height: 10px;
        }
        QScrollBar::handle:horizontal {
            background: #1e3a5f;
            border-radius: 4px;
        }
        QScrollBar::handle:horizontal:hover {
            background: #2563eb;
        }
        QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
            width: 0px;
        }

        /* ─── SpinBox Arrows ─── */
        QSpinBox::up-button, QSpinBox::down-button {
            background: #1a3d65;
            border: none;
            width: 16px;
        }
        QSpinBox::up-arrow { image: none; border: none; }
        QSpinBox::down-arrow { image: none; border: none; }

        /* ─── Status Bar — Bottom Zone ─── */
        #StatusBar {
            background: #0a0f1a;
            border-top: 1px solid #1e3a5f;
            padding: 4px 10px;
            color: #7db8e8;
        }

        /* ─── Menu ─── */
        QMenu {
            background: #152a45;
            border: 1px solid #1e3a5f;
            color: #e2e8f0;
        }
        QMenu::item:selected {
            background: #2563eb;
            color: white;
        }
        QMenu::separator {
            height: 1px;
            background: #1e3a5f;
        }

        /* ─── ToolTip ─── */
        QToolTip {
            background: #152a45;
            border: 1px solid #2563eb;
            color: #e2e8f0;
            padding: 6px;
        }

        QDialog { background-color: #0c1220; color: #e2e8f0; }
        """
        self.setStyleSheet(stylesheet)
    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Custom Title Bar ──
        self.title_bar = self._build_title_bar()
        main_layout.addWidget(self.title_bar)
        
        # Top-level tabs (Ribbon style)
        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget, 1)
        
        # ── Tab 1: Facebook Profiles ──
        fb_tab = QWidget()
        layout = QVBoxLayout(fb_tab)
        layout.setContentsMargins(6, 6, 6, 0)
        layout.setSpacing(4)
        
        # ====== ROW 1: Primary Action Buttons ======
        row1 = QHBoxLayout()
        row1.setSpacing(4)
        row1.setContentsMargins(0, 0, 0, 0)
        
        BTN_H = 30  # unified button height

        def make_btn(label, obj_name=None, min_w=90, h=BTN_H):
            b = QPushButton(label)
            if obj_name:
                b.setObjectName(obj_name)
            b.setMinimumWidth(min_w)
            b.setFixedHeight(h)
            return b
        
        self.btn_load_profile  = make_btn("Load Profile", "PrimaryBtn", 100)
        self.btn_open_profile  = make_btn("Open Profile", "PrimaryBtn", 100)
        self.btn_delete_profile= make_btn("Delete Profile", "DeleteBtn", 100)
        self.btn_find_uid      = make_btn("Find UID", "PrimaryBtn", 80)
        self.btn_refresh       = make_btn("Refresh Profile", None, 110)
        self.btn_stop          = make_btn("Stop", "DeleteBtn", 60)
        self.btn_check_update  = make_btn("Check Update", None, 100)
        
        self.btn_load_profile.clicked.connect(self.start_background_profile_check)
        self.btn_open_profile.clicked.connect(lambda: self.launch_selected(auto_login=False, headless=False))
        self.btn_delete_profile.clicked.connect(self.delete_selected)
        self.btn_find_uid.clicked.connect(self.find_uid_selected)
        self.btn_refresh.clicked.connect(self.show_all_profiles)
        self.btn_stop.clicked.connect(self.stop_all_threads)
        self.btn_check_update.clicked.connect(self.check_for_updates)
        
        # Style Refresh button (green accent)
        self.btn_refresh.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #166534, stop:1 #14532d);
                border: 1px solid #22c55e;
                border-radius: 5px;
                color: #bbf7d0;
                font-weight: 700;
                font-size: 11px;
            }
            QPushButton:hover {
                background: #22c55e;
                color: #052e16;
            }
        """)
        
        row1.addWidget(self.btn_load_profile)
        row1.addWidget(self.btn_open_profile)
        row1.addWidget(self.btn_delete_profile)
        row1.addWidget(self.btn_find_uid)
        row1.addWidget(self.btn_refresh)
        row1.addWidget(self.btn_stop)
        row1.addWidget(self.btn_check_update)
        row1.addStretch()
        
        # ====== ROW 2: Category + Settings ======
        row2 = QHBoxLayout()
        row2.setSpacing(4)
        row2.setContentsMargins(0, 0, 0, 0)
        
        lbl_cat = QLabel("Thư mục:")
        lbl_cat.setStyleSheet("font-weight:bold; font-size:12px;")
        lbl_cat.setFixedHeight(BTN_H)
        self.combo_category = QComboBox()
        self.combo_category.setMinimumWidth(160)
        self.combo_category.setFixedHeight(BTN_H)
        self.combo_category.currentTextChanged.connect(self.on_category_changed)
        
        self.btn_add_category   = make_btn("Add",    "PrimaryBtn", 50)
        self.btn_edit_category  = make_btn("Edit",   None,         48)
        self.btn_delete_category= make_btn("Delete", "DeleteBtn",  55)
        self.btn_add_category.clicked.connect(self.add_category)
        self.btn_edit_category.clicked.connect(self.rename_category)
        self.btn_delete_category.clicked.connect(self.delete_category)
        
        lbl_threads = QLabel("Số luồng:")
        lbl_threads.setFixedHeight(BTN_H)
        self.spin_threads = QSpinBox()
        self.spin_threads.setRange(1, 100)
        self.spin_threads.setValue(3)
        self.spin_threads.setFixedWidth(60)
        self.spin_threads.setFixedHeight(BTN_H)
        

        
        row2.addWidget(lbl_cat)
        row2.addWidget(self.combo_category)
        row2.addWidget(self.btn_add_category)
        row2.addWidget(self.btn_edit_category)
        row2.addWidget(self.btn_delete_category)
        row2.addSpacing(15)
        row2.addWidget(lbl_threads)
        row2.addWidget(self.spin_threads)
        row2.addStretch()
        
        layout.addLayout(row1)
        layout.addLayout(row2)
        
        # Table
        self.table = CopyableTable()
        self.table.setAlternatingRowColors(False)  # We manage row coloring manually
        # Force item backgrounds to render despite CSS (Qt stylesheet override fix)
        from ui.copyable_table import BackgroundDelegate
        self.table.setItemDelegate(BackgroundDelegate(self.table))
        self.setup_table_columns()
        
        self.table.setEditTriggers(QTableWidget.EditTrigger.DoubleClicked)
        self.table.verticalHeader().setVisible(False) # Hide leftmost vertical header (STT numbers)
        self.table.cellChanged.connect(self.on_cell_changed)
        self.table.itemSelectionChanged.connect(self.update_status_bar)
        
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        # Override keyPressEvent to allow spacebar toggling of checkboxes
        self.table.keyPressEvent = self.table_key_press_event
        
        layout.addWidget(self.table)
        
        self.tab_widget.addTab(fb_tab, "Quản lý Profile")
        
        # ── Tab 2: Email Manager ──
        self.email_manager = EmailManagerWidget()
        self.tab_widget.addTab(self.email_manager, "Quản lý Email")
        
        # ── Tab 3: Gmail Manager ──
        from ui.gmail_manager import GmailManagerWidget
        self.gmail_manager = GmailManagerWidget()
        self.tab_widget.addTab(self.gmail_manager, "Quản lý Gmail")
        
        # ── Tab 4: Change Via ──
        from ui.change_via_widget import ChangeViaWidget
        self.change_via_widget = ChangeViaWidget()
        self.change_via_widget.set_profile_manager(self.profile_manager)
        self.tab_widget.addTab(self.change_via_widget, "Change Via")
        
        # ── Tab 4: Edit Profile ──
        from ui.edit_profile_widget import EditProfileWidget
        self.edit_profile_widget = EditProfileWidget()
        self.edit_profile_widget.profile_saved.connect(self.load_data)
        self.tab_widget.addTab(self.edit_profile_widget, "Edit Profile")
        
        # ── Tab 5: Settings ──
        from ui.settings_widget import SettingsWidget
        self.settings_widget = SettingsWidget()
        self.settings_widget.settings_changed.connect(self.reload_settings)
        self.tab_widget.addTab(self.settings_widget, "Cài đặt")
        
        # ── Status Bar ──
        self.status_bar_widget = QWidget()
        self.status_bar_widget.setObjectName("StatusBar")
        status_layout = QHBoxLayout(self.status_bar_widget)
        status_layout.setContentsMargins(10, 2, 10, 2)
        
        self.lbl_status_total = QLabel("Tổng số nick: 0")
        self.lbl_status_selected = QLabel("Tích chọn: 0")
        self.lbl_status_active = QLabel("Trạng thái: Sẵn sàng")
        
        status_layout.addWidget(self.lbl_status_total)
        status_layout.addSpacing(20)
        status_layout.addWidget(self.lbl_status_selected)
        status_layout.addSpacing(20)
        status_layout.addWidget(self.lbl_status_active)
        status_layout.addStretch()
        
        main_layout.addWidget(self.status_bar_widget, 0)
        
        self.ui_timer = QTimer(self)
        self.ui_timer.timeout.connect(self.update_status_bar)
        self.ui_timer.start(1000)

    def setup_table_columns(self):
        visible_cols = get_visible_columns()
        self.current_columns = [("chk", "")] + visible_cols
        
        self.table.setColumnCount(len(self.current_columns))
        
        # We will set header labels in load_data dynamically to include sorting arrows
        # but initialize them here first:
        headers = [col[1] for col in self.current_columns]
        self.table.setHorizontalHeaderLabels(headers)
        
        # ── Select All checkbox: parent it to the header widget, position manually ──
        if not hasattr(self, '_select_all_chk'):
            self._select_all_chk = QCheckBox(self.table.horizontalHeader())
            self._select_all_chk.setToolTip("Chọn tất cả / Bỏ chọn tất cả")
            self._select_all_chk.setTristate(False)
            self._select_all_chk.stateChanged.connect(self.toggle_select_all)
            self._select_all_chk.setStyleSheet(
                "QCheckBox::indicator { width: 14px; height: 14px; }"
            )
        
        # Column resize and reorder modes
        header = self.table.horizontalHeader()
        header.setMinimumSectionSize(24)
        header.setSectionsMovable(True)  # Allow drag and drop columns
        header.setSectionsClickable(True) # Allow sorting clicks
        
        # Track 3-step sort states: dict of col_idx -> int (0=None, 1=Asc, 2=Desc)
        self.sort_states = {}
        self.current_sort_col = -1
        header.sectionClicked.connect(self.on_header_clicked)
        
        self.table.setColumnWidth(0, 30)  # chk column
        for i, (key, label) in enumerate(self.current_columns):
            if key == "chk":
                header.setSectionResizeMode(i, QHeaderView.ResizeMode.Fixed)
            elif key == "stt":
                self.table.setColumnWidth(i, 45)
                header.setSectionResizeMode(i, QHeaderView.ResizeMode.Fixed)
            else:
                header.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
                if key in ["fb_uid", "fb_pass", "fb_email", "name", "fb_name"]:
                    self.table.setColumnWidth(i, 120)
                elif key == "status":
                    self.table.setColumnWidth(i, 100)
                elif key == "fb_note":
                    self.table.setColumnWidth(i, 150)
                else:
                    self.table.setColumnWidth(i, 100)
        
        # Position the checkbox after sizes are set
        self._reposition_select_all_checkbox()


    def _reposition_select_all_checkbox(self):
        """Position the Select All QCheckBox inside the first header section."""
        header = self.table.horizontalHeader()
        # Get position of section 0
        x = header.sectionPosition(0)
        w = header.sectionSize(0)
        h = header.height()
        chk = self._select_all_chk
        chk_w, chk_h = 16, 16
        chk.setGeometry(x + (w - chk_w) // 2, (h - chk_h) // 2, chk_w, chk_h)
        chk.raise_()
        chk.show()

    def toggle_select_all(self, state):
        """Check or uncheck all profile checkboxes."""
        checked = state == 2  # Qt.CheckState.Checked == 2
        self.table.blockSignals(True)
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item:
                item.setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
        self.table.blockSignals(False)
        self.update_status_bar()

    def table_key_press_event(self, event):
        """Handle spacebar to toggle checkboxes + Ctrl+C to copy."""
        # Ctrl+C → copy selected cells
        if event.matches(QKeySequence.StandardKey.Copy):
            self.table._copy_selection()
            return
        if event.key() == Qt.Key.Key_Space:
            selected_items = self.table.selectedItems()
            if not selected_items:
                return # Standard behavior if nothing is selected
            
            # Find unique rows that are currently highlighted
            selected_rows = set(item.row() for item in selected_items)
            
            self.table.blockSignals(True)
            for row in selected_rows:
                chk_item = self.table.item(row, 0)
                if chk_item:
                    # Toggle state
                    current = chk_item.checkState()
                    new_state = Qt.CheckState.Unchecked if current == Qt.CheckState.Checked else Qt.CheckState.Checked
                    chk_item.setCheckState(new_state)
            self.table.blockSignals(False)
            self.update_status_bar()
            event.accept()
        else:
            # Fallback to default QTableWidget handling for other keys
            QTableWidget.keyPressEvent(self.table, event)

    def on_header_clicked(self, logicalIndex):
        """Handle 3-state column sorting: 1=Asc, 2=Desc, 0=None"""
        if logicalIndex == 0: # Can't sort checkbox column easily
            return
            
        # Reset other columns
        for idx in list(self.sort_states.keys()):
            if idx != logicalIndex:
                self.sort_states[idx] = 0
                
        current_state = self.sort_states.get(logicalIndex, 0)
        
        # 0 -> 1 -> 2 -> 0
        new_state = (current_state + 1) % 3
        self.sort_states[logicalIndex] = new_state
        self.current_sort_col = logicalIndex if new_state != 0 else -1
        
        self.load_data()

    def parse_numeric_for_sort(self, val_str):
        """Helper to extract continuous numbers so they sort mathematically instead of lexicographically. (e.g., '1.2K Friends' -> 1200)"""
        val_str = str(val_str).lower().strip()
        if not val_str:
            return -999999999 # Empty values push to bottom generally
            
        import re
        
        # Parse K / M suffixes
        multiplier = 1
        if 'k' in val_str: multiplier = 1000
        elif 'm' in val_str: multiplier = 1000000
        
        # Extract digits and decimals/commas
        num_match = re.search(r'([\d,.]+)', val_str)
        if num_match:
            try:
                num_str = num_match.group(1).replace(',', '.') # normalize comma
                # if there are multiple dots, just take first part or strip others
                parts = num_str.split('.')
                if len(parts) > 2: num_str = parts[0] + "." + "".join(parts[1:])
                return float(num_str) * multiplier
            except:
                pass
                
        return val_str # Fallback to alphabetical if no number detected

    def reload_settings(self, new_settings=None):
        """Reload settings after they've been changed from the Settings tab."""
        from ui.settings_dialog import load_settings
        self.settings = new_settings or load_settings()
        self.setup_table_columns()
        self.load_data()

    def load_data(self):
        try:
            self._load_data_inner()
        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.warning(self, "Lỗi", f"Lỗi load dữ liệu: {str(e)[:200]}")

    def _load_data_inner(self):
        self.table.blockSignals(True)
        self.table.setRowCount(0)
        
        current_cat = self.combo_category.currentText()
        profiles = self.profile_manager.get_all_profiles(category=current_cat)
        
        # -- Intercept and Sort Profiles --
        
        # Prepare header names with arrows
        header_labels = []
        for i, (key, label) in enumerate(self.current_columns):
            sort_state = self.sort_states.get(i, 0)
            if sort_state == 1:
                header_labels.append(f"{label} ▲")
            elif sort_state == 2:
                header_labels.append(f"{label} ▼")
            else:
                header_labels.append(label)
        self.table.setHorizontalHeaderLabels(header_labels)
        
        if self.current_sort_col > 0:
            sort_key, _ = self.current_columns[self.current_sort_col]
            sort_state = self.sort_states.get(self.current_sort_col, 0)
            
            if sort_state != 0:
                is_reverse = (sort_state == 2)
                
                # Check if column is generally numeric
                numeric_cols = ["stt", "fb_friends", "id", "fb_uid"]
                use_numeric_sort = (sort_key in numeric_cols)
                
                def sort_func(prof):
                    val = prof.get(sort_key, "")
                    if sort_key == "stt":
                        # stt isn't in db natively, use original index for tie breaking or stable mapping
                        # We just sort by internal order string or if it's purely STT we can skip it.
                        return 0 
                        
                    if use_numeric_sort:
                        return self.parse_numeric_for_sort(val)
                    else:
                        # Case insensitive ABC sort
                        return str(val).lower()
                        
                profiles.sort(key=sort_func, reverse=is_reverse)
        
        for row_idx, profile in enumerate(profiles):
            self.table.insertRow(row_idx)
            
            # ──── Row Color — ONLY based on Live column ────
            status = str(profile.get("status", "Stopped"))
            live_val = str(profile.get("fb_live", "")).lower()

            row_fg = QColor("#0f172a")  # Black text (always)
            row_bg = QColor("#e0f2fe") if (row_idx % 2 == 0) else QColor("#ffffff")

            if any(x in live_val for x in ["dead", "die", "disabled", "locked", "banned", "khóa", "cp282", "cp956", "checkpoint", "xác minh"]):
                row_bg = QColor("#ff6b6b")  # 🔴 RED — Dead/Die/Locked/CP
            elif "out" in live_val:
                row_bg = QColor("#ffec8b")  # 🟡 YELLOW — Out
            elif "live" in live_val:
                row_bg = QColor("#81c784")  # 🟢 GREEN — Live

            for col_idx, (key, label) in enumerate(self.current_columns):
                item = None
                if key == "chk":
                    item = QTableWidgetItem()
                    item.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                    item.setCheckState(Qt.CheckState.Unchecked)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                elif key == "stt":
                    item = QTableWidgetItem(str(row_idx + 1))
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                elif key == "status":
                    disp_status = tr(f"status_{status.lower()}") if status.lower() in ["running", "stopped", "error"] else status
                    item = QTableWidgetItem(disp_status)
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                else:
                    val = str(profile.get(key, ""))
                    item = QTableWidgetItem(val)
                    if key == "id":
                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                
                if item:
                    # ALWAYS apply background + foreground (no CSS fallback)
                    item.setBackground(row_bg)
                    item.setForeground(row_fg)
                    self.table.setItem(row_idx, col_idx, item)
                    
        self.table.blockSignals(False)
        # Reposition select-all checkbox after header might have changed
        if hasattr(self, '_select_all_chk'):
            self._reposition_select_all_checkbox()
            # Reset select-all state
            self._select_all_chk.blockSignals(True)
            self._select_all_chk.setCheckState(Qt.CheckState.Unchecked)
            self._select_all_chk.blockSignals(False)
        self.update_status_bar()

    # Store currently visible profiles so get_id_at_row is always sync'd with the table
    def _get_visible_profiles(self):
        current_cat = self.combo_category.currentText()
        return self.profile_manager.get_all_profiles(category=current_cat)

    def update_status_bar(self):
        total = self.table.rowCount()
        selected = len(self.get_checked_profile_ids())
        if selected == 0 and self.table.selectedItems():
            # If checkboxes aren't strictly used, count selected rows
            selected_rows = set(item.row() for item in self.table.selectedItems())
            selected = len(selected_rows)
            
        self.lbl_status_total.setText(f"Tổng số nick: {total}")
        self.lbl_status_selected.setText(f"Tích chọn: {selected}")
        
        running_threads = len(self.browser_manager.running_threads)
        if running_threads > 0:
            self.lbl_status_active.setText(f"Trạng thái: Đang chạy {running_threads} luồng")
        else:
            self.lbl_status_active.setText("Trạng thái: Sẵn sàng")

    def load_categories_to_ui(self):
        self.combo_category.blockSignals(True)
        self.combo_category.clear()
        self.combo_category.addItem("All Categories")
        
        # Load custom categories
        categories = self.settings.get("categories", ["Default"])
        if "Default" not in categories:
            categories.insert(0, "Default")
            
        for cat in categories:
            self.combo_category.addItem(cat)
            
        self.combo_category.blockSignals(False)

    def on_category_changed(self, text):
        self.load_data()

    def add_category(self):
        text, ok = QInputDialog.getText(self, "Thêm Danh Mục", "Tên danh mục mới:")
        if ok and text:
            text = text.strip()
            cats = self.settings.get("categories", ["Default"])
            if text not in cats and text != "All Categories":
                cats.append(text)
                self.settings["categories"] = cats
                from ui.settings_dialog import save_settings
                save_settings(self.settings)
                self.load_categories_to_ui()
                index = self.combo_category.findText(text)
                if index >= 0:
                    self.combo_category.setCurrentIndex(index)

    def delete_category(self):
        current = self.combo_category.currentText()
        if current in ["All Categories", "Default"]:
            QMessageBox.warning(self, "Lỗi", "Không thể xóa danh mục mặc định!")
            return
            
        reply = QMessageBox.question(self, "Xóa Danh Mục", f"Bạn có chắc chắn muốn xóa danh mục '{current}'?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            cats = self.settings.get("categories", ["Default"])
            if current in cats:
                cats.remove(current)
                self.settings["categories"] = cats
                from ui.settings_dialog import save_settings
                save_settings(self.settings)
                
                # Move profiles in this category to Default
                profiles = self.profile_manager.get_all_profiles(category=current)
                for p in profiles:
                    self.profile_manager.update_profile(p["id"], {"category": "Default"})
                    
                self.load_categories_to_ui()
                self.combo_category.setCurrentIndex(0) # Switch to All

    def add_profile(self):
        dialog = AddProfileDialog(self)
        if dialog.exec():
            name, uid, email, pwd, tfa = dialog.get_data()
            if uid or email or name:
                display_name = name if name else (uid if uid else email) # Fallback name
                
                cat = self.combo_category.currentText()
                if cat == "All Categories": cat = "Default"
                
                self.profile_manager.add_profile(display_name, fb_uid=uid, fb_email=email, fb_pass=pwd, fb_2fa=tfa, category=cat)
                self.load_data()

    def bulk_add_profiles(self):
        cats = self.settings.get("categories", ["Default"])
        current = self.combo_category.currentText()
        if current == "All Categories": current = "Default"
        
        dialog = BulkAddDialog(self, current_category=current, all_categories=cats)
        if dialog.exec():
            category, parsed_profiles = dialog.get_parsed_data()
            if not parsed_profiles: return
            
            for data in parsed_profiles:
                # Basic validation
                uid = data.get("fb_uid", "")
                email = data.get("fb_email", "")
                if not uid and not email:
                    continue # Skip empty login rows
                    
                # The ProfileManager.add_profile expects keyword arguments for typical fields, 
                # but we can pass them in or update after creation.
                name = data.pop("name", uid if uid else email)
                cat = data.pop("category", category)
                
                new_prof = self.profile_manager.add_profile(
                    name=name, 
                    fb_uid=uid, 
                    fb_email=email, 
                    fb_pass=data.get("fb_pass", ""), 
                    fb_2fa=data.get("fb_2fa", ""), 
                    category=cat
                )
                
                # Assign the rest of the dynamic fields
                self.profile_manager.update_profile(new_prof["id"], data)
                
            self.load_data()

    def show_context_menu(self, position):
        row = self.table.rowAt(position.y())
        selected_ids = self.get_checked_profile_ids()
        
        # If right clicked on a row that isn't checked, and nothing else is checked, select it
        row_id = self.get_id_at_row(row) if row >= 0 else None
        if row_id and row_id not in selected_ids and not selected_ids:
            selected_ids = [row_id]
            
        profile_data = self.profile_manager.get_profile(row_id) if row_id else None
            
        menu = QMenu()
        menu.setStyleSheet("""
            QMenu { background-color: white; border: 2px solid #1e5fa0; border-radius: 4px; padding: 4px; }
            QMenu::item { padding: 6px 20px; font-size: 13px; color: #333333; }
            QMenu::item:selected { background-color: #e6f7ff; color: #1890ff; }
            QMenu::separator { height: 1px; background: #abbed1; margin: 4px 0px; }
        """)
        
        # ── Launch Actions ──
        login_auto = menu.addAction("Đăng nhập Tự động (Chrome)")
        login_headless = menu.addAction("Đăng nhập Chạy ẩn (API)")
        launch_normal = menu.addAction("Mở Chrome bình thường")
        menu.addSeparator()

        # ── Check Actions ──
        check_menu = menu.addMenu("Kiểm tra (Check)")
        check_uid = check_menu.addAction("Check UID")
        check_token = check_menu.addAction("Check Token")
        check_cookie = check_menu.addAction("Check Cookie")
        check_info = check_menu.addAction("Check Thông tin (Full)")
        
        # ── Account Actions ──
        acc_menu = menu.addMenu("Hành động Tài khoản")
        change_pass = acc_menu.addAction("Đổi Mật khẩu")
        log_out = acc_menu.addAction("Đăng xuất thiết bị khác")
        toggle_2fa = acc_menu.addAction("Bật/Tắt 2FA")
        
        # ── Browser Functions ──
        browser_menu = menu.addMenu("Chức năng Trình duyệt")
        bw_open_cookie = browser_menu.addAction("Open Chrome With Cookie")
        bw_close = browser_menu.addAction("Đóng trình duyệt")
        bw_set_cookie = browser_menu.addAction("Set Cookie vào Chrome")
        bw_get_cookie = browser_menu.addAction("Get Cookie từ Chrome")
        bw_clear_cache = browser_menu.addAction("Clear Cache Profile")
        bw_delete_profile = browser_menu.addAction("Delete Chrome Profile")
        bw_set_proxy = browser_menu.addAction("🌐 Set Proxy")
        bw_read_email = browser_menu.addAction("📧 Read Email")
        
        # ── Login Email Functions ──
        email_login_menu = menu.addMenu("📧 Login Email")
        el_login_pass = email_login_menu.addAction("Login Email (sử dụng password)")
        el_login_recover = email_login_menu.addAction("Login Email (sử dụng email khôi phục)")
        el_login_add_recovery = email_login_menu.addAction("Login Hotmail (Add Mail khôi phục)")
        el_login_chrome = email_login_menu.addAction("Login Email with Chrome")
        el_close_browser_email = email_login_menu.addAction("Đóng trình duyệt email")
        
        # ── Data Actions ──
        data_menu = menu.addMenu("Xuất/Nhập dữ liệu")
        import_action = data_menu.addAction("Import Via (Nhập dữ liệu)")
        export_action = data_menu.addAction("Export Via (Xuất dữ liệu)")
        import_no_dup_action = data_menu.addAction("Import Via 2 (Bỏ qua không import UID trùng lặp)")
        add_email_action = data_menu.addAction("Thêm Email vào Quản lý Email")
        
        menu.addSeparator()
        send_to_change_via_action = menu.addAction("👉 Gởi sang Change Via")
        menu.addSeparator()

        # ── Copy Submenu ──
        copy_actions = {}
        if selected_ids:
            copy_menu = menu.addMenu("Copy")
            
            def build_copy_string(format_keys):
                lines = []
                for pid in selected_ids:
                    p = self.profile_manager.get_profile(pid)
                    if p:
                        # For single keys like UID, we don't want a trailing | but join implicitly handles 1-length lists
                        parts = [p.get(k, "") for k in format_keys]
                        lines.append("|".join(parts))
                return "\n".join(lines)

            copy_options = [
                ("UID", ["fb_uid"]),
                ("PASS", ["fb_pass"]),
                ("2FA Code", ["fb_2fa"]),
                ("Cookie", ["fb_cookie"]),
                ("Token", ["fb_token"]),
                ("UID|PASS|2FA", ["fb_uid", "fb_pass", "fb_2fa"]),
                ("UID|PASS|2FA|Cookie", ["fb_uid", "fb_pass", "fb_2fa", "fb_cookie"]),
                ("UID|Cookie", ["fb_uid", "fb_cookie"]),
                ("UID|PASS|Email", ["fb_uid", "fb_pass", "fb_email"]),
                ("UID|PASS|2FA|Email|Pass Email", ["fb_uid", "fb_pass", "fb_2fa", "fb_email", "fb_pass_email"]),
            ]
            
            for fmt_name, fmt_keys in copy_options:
                act = copy_menu.addAction(fmt_name)
                copy_actions[id(act)] = build_copy_string(fmt_keys)
                    
        menu.addSeparator()
        delete_action = menu.addAction("Xóa Profile")
            
        action = menu.exec(self.table.viewport().mapToGlobal(position))
        
        if not action:
            return
            
        # ── Handle actions that DON'T require selected profiles ──
        if action == import_action:
            self.show_import_dialog(skip_duplicates=False)
            return
        elif action == import_no_dup_action:
            self.show_import_dialog(skip_duplicates=True)
            return
        elif action == export_action:
            self.show_export_dialog()
            return

        # ── Actions that REQUIRE selected profiles ──
        # Target IDs for action
        ids_to_act = selected_ids if selected_ids else ([row_id] if row_id else [])
        if not ids_to_act: return

        if id(action) in copy_actions:
            QApplication.clipboard().setText(copy_actions[id(action)])
        elif action == login_auto:
            self.launch_selected(auto_login=True, headless=False, override_ids=ids_to_act)
        elif action == login_headless:
            self.launch_selected(auto_login=True, headless=True, override_ids=ids_to_act)
        elif action == launch_normal:
            self.launch_selected(auto_login=False, headless=False, override_ids=ids_to_act)
        elif action == delete_action:
            self.delete_selected()
        elif action == check_cookie:
            self.launch_selected(action="check_cookie", headless=True)
        elif action == check_info:
            self.launch_selected(action="check_info_full", headless=True)
        elif action in [check_uid, check_token]:
            QMessageBox.information(self, "Check", f"Tính năng checking đang được cập nhật...")
        elif action in [change_pass, log_out, toggle_2fa]:
            QMessageBox.information(self, "Hành động", f"Đang thực hiện hành động cho {len(ids_to_act)} profile...")
        elif action == add_email_action:
            self.add_emails_from_selected()
        elif action == send_to_change_via_action:
            self.send_to_change_via(ids_to_act)
        elif action in [bw_open_cookie, bw_close, bw_set_cookie, bw_get_cookie, bw_clear_cache, bw_delete_profile]:
            self.handle_browser_action(action, ids_to_act)
        elif action == bw_set_proxy:
            self.set_proxy_for_profiles(ids_to_act)
        elif action == bw_read_email:
            self.read_email_for_profiles(ids_to_act)
        elif action == el_login_pass:
            self._profile_login_email(ids_to_act, "password")
        elif action == el_login_recover:
            self._profile_login_email(ids_to_act, "recovery")
        elif action == el_login_add_recovery:
            self._profile_login_add_recovery(ids_to_act)
        elif action == el_login_chrome:
            self._profile_login_email(ids_to_act, "chrome")
        elif action == el_close_browser_email:
            self._profile_close_email_browser(ids_to_act)

    def send_to_change_via(self, ids):
        profiles = [self.profile_manager.get_profile(pid) for pid in ids if self.profile_manager.get_profile(pid)]
        if profiles:
            self.change_via_widget.load_profiles(profiles)
            self.tab_widget.setCurrentWidget(self.change_via_widget)

    def _profile_login_email(self, profile_ids, login_type):
        """Login email for selected profiles."""
        if not profile_ids:
            return
        from ui.email_login_worker import HotmailLoginThread, EmailBrowserManager
        if not hasattr(self, '_profile_email_mgr'):
            self._profile_email_mgr = EmailBrowserManager()
        headless = login_type != "chrome"
        for pid in profile_ids:
            p = self.profile_manager.get_profile(pid)
            if not p:
                continue
            rec = {
                "id": pid,
                "email": p.get("fb_email", ""),
                "pass_email": p.get("fb_pass_email", ""),
                "token_hotmail": p.get("fb_token", ""),
            }
            thread = self._profile_email_mgr.start_login(rec, login_type, headless)
            thread.status_update.connect(self._on_profile_email_status)
            thread.login_done.connect(self._on_profile_email_done)
            thread.error_signal.connect(self._on_profile_email_error)
            thread.start()

    def _profile_login_add_recovery(self, profile_ids):
        """Login email with add recovery for selected profiles."""
        if not profile_ids:
            return
        from ui.email_login_worker import RecoveryDomainDialog, EmailBrowserManager, build_recovery_email
        dlg = RecoveryDomainDialog(self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        provider, domain, suffix = dlg.get_result()
        if not hasattr(self, '_profile_email_mgr'):
            self._profile_email_mgr = EmailBrowserManager()
        for pid in profile_ids:
            p = self.profile_manager.get_profile(pid)
            if not p:
                continue
            rec = {
                "id": pid,
                "email": p.get("fb_email", ""),
                "pass_email": p.get("fb_pass_email", ""),
                "token_hotmail": p.get("fb_token", ""),
            }
            thread = self._profile_email_mgr.start_login(
                rec, "token_recovery", headless=True,
                recovery_domain=domain, recovery_provider=provider,
                recovery_suffix=suffix
            )
            thread.status_update.connect(self._on_profile_email_status)
            thread.login_done.connect(self._on_profile_email_done)
            thread.error_signal.connect(self._on_profile_email_error)
            thread.start()

    def _profile_close_email_browser(self, profile_ids):
        if hasattr(self, '_profile_email_mgr'):
            for pid in profile_ids:
                self._profile_email_mgr.stop_session(pid)

    def _on_profile_email_status(self, email_id, status):
        self.profile_manager.update_profile(email_id, {"status": status})
        self.load_data()

    def _on_profile_email_done(self, email_id, result):
        status = result.get("status", "Done")
        updates = {"status": status}
        if "OK" in status:
            updates["live"] = "Live"
        self.profile_manager.update_profile(email_id, updates)
        self.load_data()

    def _on_profile_email_error(self, email_id, msg):
        self.profile_manager.update_profile(email_id, {"status": msg})
        self.load_data()

    def handle_browser_action(self, action, target_ids):
        action_text = action.text()
        for pid in target_ids:
            if action_text == "Open Chrome With Cookie":
                self.launch_selected(auto_login=False, headless=False, override_ids=[pid], action="open_with_cookie")
            elif action_text == "Đóng trình duyệt":
                self.browser_manager.close_browser(pid)
            elif action_text == "Set Cookie vào Chrome":
                self.browser_manager.set_cookie_to_chrome(pid)
            elif action_text == "Get Cookie từ Chrome":
                self.browser_manager.get_cookie_from_chrome(pid)
            elif action_text == "Clear Cache Profile":
                self.browser_manager.clear_cache_profile(pid)
            elif action_text == "Delete Chrome Profile":
                self.browser_manager.delete_chrome_profile(pid)
        
        # Reload UI in case Get Cookie / Delete changed db state
        if action_text in ["Get Cookie từ Chrome", "Delete Chrome Profile"]:
              self.load_data()

    def set_proxy_for_profiles(self, profile_ids):
        """Open proxy dialog and assign proxies to selected profiles."""
        if not profile_ids:
            QMessageBox.information(self, tr("app_title"), "Vui lòng chọn profile cần set proxy.")
            return
        
        dialog = SetProxyDialog(self, profile_count=len(profile_ids))
        if dialog.exec():
            if dialog.is_clear_mode():
                # Clear proxy for all selected profiles
                for pid in profile_ids:
                    self.profile_manager.update_profile(pid, {"fb_proxy": ""})
                self.load_data()
                QMessageBox.information(self, tr("app_title"), f"Đã xóa proxy cho {len(profile_ids)} profile.")
                return
            
            proxies = dialog.get_proxies()
            if not proxies:
                return
            
            same_for_all = dialog.is_same_for_all()
            assigned = 0
            
            for i, pid in enumerate(profile_ids):
                if same_for_all:
                    proxy = proxies[0]
                else:
                    proxy = proxies[i] if i < len(proxies) else proxies[-1]  # Repeat last if not enough
                
                self.profile_manager.update_profile(pid, {"fb_proxy": proxy})
                assigned += 1
            
            self.load_data()
            QMessageBox.information(self, tr("app_title"), f"Đã set proxy cho {assigned} profile thành công!")

    def read_email_for_profiles(self, profile_ids):
        """Open Read Mail dialog for selected profile's email."""
        if not profile_ids:
            QMessageBox.information(self, tr("app_title"), "Vui lòng chọn profile.")
            return
        profile = self.profile_manager.get_profile(profile_ids[0])
        if not profile:
            return
        email_addr = profile.get("fb_email", "")
        password = profile.get("fb_pass_email", "")
        token = profile.get("fb_token", "")
        if not email_addr:
            QMessageBox.warning(self, tr("app_title"), "Profile chưa có email.")
            return
        from ui.email_reader import ReadMailDialog
        dlg = ReadMailDialog(self, email_addr=email_addr, password=password, token=token)
        dlg.exec()

    def show_import_dialog(self, skip_duplicates=False):
        try:
            from ui.import_dialog import ImportDialog
            cats = self.settings.get("categories", ["Default"])
            current = self.combo_category.currentText()
            if current == "All Categories": current = "Default"
            
            dialog = ImportDialog(self, current_category=current, all_categories=cats)
            if dialog.exec():
                category, parsed_profiles = dialog.get_parsed_data()
                if not parsed_profiles: return
                
                added_count = 0
                existing_uids = {p.get("fb_uid") for p in self.profile_manager.get_all_profiles() if p.get("fb_uid")}
                
                for data in parsed_profiles:
                    uid = data.get("fb_uid", "").strip()
                    email = data.get("fb_email", "").strip()
                    if not uid and not email:
                        continue # Skip empty login rows
                    
                    if skip_duplicates and uid and uid in existing_uids:
                        continue
                        
                    name = data.pop("name", uid if uid else email)
                    cat = data.pop("category", category)
                    
                    new_prof = self.profile_manager.add_profile(
                        name=name, 
                        fb_uid=uid, 
                        fb_email=email, 
                        fb_pass=data.get("fb_pass", ""), 
                        fb_2fa=data.get("fb_2fa", ""), 
                        category=cat
                    )
                    
                    # Assign the rest of the dynamic fields
                    self.profile_manager.update_profile(new_prof["id"], data)
                    added_count += 1
                    
                self.load_data()
                QMessageBox.information(self, tr("app_title"), f"Đã nhập thành công {added_count} profiles.")
        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Import Error", f"Lỗi khi nhập dữ liệu:\n{str(e)}")

    def show_export_dialog(self):
        try:
            checked_ids = self.get_checked_profile_ids()
            if not checked_ids:
                 QMessageBox.information(self, tr("app_title"), "Vui lòng chọn hoặc tích profile cần xuất dữ liệu.")
                 return
                 
            from ui.export_dialog import ExportDialog
            
            # Pull full profiles to export
            profiles_to_export = [self.profile_manager.get_profile(pid) for pid in checked_ids if self.profile_manager.get_profile(pid)]
            
            dialog = ExportDialog(self, profiles=profiles_to_export)
            dialog.exec()
        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Export Error", f"Lỗi khi xuất dữ liệu:\n{str(e)}")

    def add_emails_from_selected(self):
        checked_ids = self.get_checked_profile_ids()
        if not checked_ids:
             QMessageBox.information(self, tr("app_title"), "Vui lòng chọn profile cần thêm email.")
             return
             
        # Optional: Ask user for confirmation
        added = 0
        from core.email_manager import GlobalEmailManager
        em_manager = GlobalEmailManager()
        for pid in checked_ids:
             prof = self.profile_manager.get_profile(pid)
             if prof and prof.get("fb_email"):
                 # Check if exists
                 existing = [e for e in em_manager.get_all_emails() if e.get("email") == prof["fb_email"]]
                 if not existing:
                     em_manager.add_email(
                         email=prof["fb_email"],
                         password=prof.get("fb_pass_email", ""),
                         recovery="",
                         imap="imap-mail.outlook.com" if "hotmail" in prof["fb_email"] else "imap.gmail.com"
                     )
                     added += 1
                     
        if added > 0:
             # Refresh Email tab
             self.email_manager.load_data()
             QMessageBox.information(self, tr("app_title"), f"Đã thêm {added} email vào Quản lý Email.")
        else:
             QMessageBox.information(self, tr("app_title"), "Không có email mới nào được thêm (trống hoặc đã tồn tại).")

    def get_id_at_row(self, row):
        """Get the profile ID for the given table row."""
        if row < 0: return None
        # We need to map current row to the actual profile list
        # Since we block signals during load_data, indices should match
        current_cat = self.combo_category.currentText()
        profiles = self.profile_manager.get_all_profiles(category=current_cat)
        if 0 <= row < len(profiles):
            return profiles[row]["id"]
        return None

    def on_cell_changed(self, row, col):
        if row < 0 or col < 0: return
        key = self.current_columns[col][0]
        if key in ["chk", "stt", "status", "id"]: return
        
        new_val = self.table.item(row, col).text()
        profile_id = self.get_id_at_row(row)
        if profile_id:
            self.profile_manager.update_profile(profile_id, {key: new_val})

    def show_settings(self):
        dialog = SettingsDialog(self)
        if dialog.exec():
            self.setup_table_columns()
            self.load_data()

    def delete_selected(self):
        checked_ids = self.get_checked_profile_ids()
        if not checked_ids:
            # Fallback to selected rows if no checkbox
            selected = self.table.selectedItems()
            if not selected:
                QMessageBox.information(self, tr("app_title"), tr("msg_select_profile"))
                return
            row = selected[0].row()
            checked_ids = [self.get_id_at_row(row)]
            
        confirm = QMessageBox.question(
            self, tr("app_title"), 
            tr("msg_confirm_delete", len(checked_ids)),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm == QMessageBox.StandardButton.Yes:
            for pid in checked_ids:
                self.profile_manager.delete_profile(pid)
            self.load_data()

    def get_checked_profile_ids(self):
        checked_ids = []
        for row in range(self.table.rowCount()):
            chk_item = self.table.item(row, 0)
            if chk_item and chk_item.checkState() == Qt.CheckState.Checked:
                pid = self.get_id_at_row(row)
                if pid:
                    checked_ids.append(pid)
        return checked_ids

    def launch_selected(self, auto_login=False, override_ids=None, headless=False, action="launch"):
        target_ids = []
        
        # If right clicked on an array of specific rows, launch them
        if override_ids:
            target_ids.extend(override_ids)
        else:
            # Check checkboxes first
            target_ids = self.get_checked_profile_ids()
            
            # If no checkmarks, try ALL selected highlighted rows
            if not target_ids:
                selected = self.table.selectedItems()
                if selected:
                    # QTableWidget.selectedItems() returns an item for every cell highlighted. Let's get unique rows.
                    unique_rows = list(set([item.row() for item in selected]))
                    for row in unique_rows:
                        pid = self.get_id_at_row(row)
                        if pid:
                            target_ids.append(pid)

        if not target_ids:
            QMessageBox.information(self, tr("app_title"), tr("msg_select_profile"))
            return

        self.pending_tasks = getattr(self, 'pending_tasks', [])
        
        # Reset browser grid position counter for this batch operation
        from core.browser_manager import reset_browser_positions
        reset_browser_positions()
        
        for pid in target_ids:
            if pid and pid not in [t[0] for t in self.pending_tasks] and pid not in self.browser_manager.running_threads:
                self.pending_tasks.append((pid, auto_login, headless, action))
                
        self.process_pending_tasks()

    def process_pending_tasks(self):
        max_threads = getattr(self, 'spin_threads', None)
        max_concurrent = max_threads.value() if max_threads else 3
        
        while len(self.browser_manager.running_threads) < max_concurrent and self.pending_tasks:
            pid, auto_login, headless, action = self.pending_tasks.pop(0)
            self._start_profile_task(pid, auto_login, headless, action)

    def _start_profile_task(self, profile_id, auto_login, headless, action="launch"):
        profile = self.profile_manager.get_profile(profile_id)
        if profile:
            self.update_status(profile_id, "Running")
            started = self.browser_manager.launch_browser(
                profile, 
                self.on_browser_finished, 
                self.on_browser_error,
                auto_login=auto_login,
                headless=headless,
                action=action
            )
            if started:
                # Connect info ready signal (this happens per browser thread)
                # We need to find the thread for this profile
                thread = self.browser_manager.running_threads.get(profile_id)
                if thread:
                    thread.info_ready.connect(self.on_info_scraped)
                    thread.status_update.connect(self.update_status)
            else:
                self.update_status(profile_id, "Running")

    def on_info_scraped(self, profile_id, data):
        self.profile_manager.update_profile(profile_id, data)
        self.load_data()

    def on_browser_finished(self, profile_id):
        profile = self.profile_manager.get_profile(profile_id)
        # Preserve checkpoint/CP statuses — don't reset to Stopped
        if profile:
            current_status = profile.get("status", "")
            cp_keywords = ["cp282", "cp956", "cp ", "checkpoint", "disabled", "locked", "suspicious", "violated", "hacked", "wall live", "wall out", "dead"]
            if any(kw in current_status.lower() for kw in cp_keywords):
                pass  # Keep the existing detailed status
            else:
                self.update_status(profile_id, "Stopped")
        self.browser_manager.running_threads.pop(profile_id, None)
        self.process_pending_tasks()

    def on_browser_error(self, profile_id, error_msg):
        self.update_status(profile_id, "Error")
        self.browser_manager.running_threads.pop(profile_id, None)
        QMessageBox.critical(self, "Browser Error", f"Failed to launch browser:\n{error_msg}")
        self.process_pending_tasks()

    def update_status(self, profile_id, status):
        # ── Derive fb_live from status keywords ──
        s = (status or "").lower()
        fb_live_update = None
        if any(x in s for x in ["disabled", "vô hiệu", "locked", "khóa", "hacked", "hack", "banned", "chết"]):
            fb_live_update = "Dead"
        elif any(x in s for x in ["cp282", "cp956", "checkpoint", "xác minh"]):
            fb_live_update = s.upper() if "cp" in s else "Checkpoint"
        elif any(x in s for x in ["wall out", "sai pass", "wrong pass", "sai 2fa", "wrong 2fa",
                                    "sai mật khẩu", "die", "dead", "out"]) and "running" not in s:
            fb_live_update = "Out"
        elif any(x in s for x in ["wall live", "live"]) and "out" not in s:
            fb_live_update = "Live"

        # Update in memory and disk
        update_data = {"status": status}
        if fb_live_update:
            update_data["fb_live"] = fb_live_update
        self.profile_manager.update_profile(profile_id, update_data)
            
        # Update UI row safely (do NOT reload whole table)
        self.table.blockSignals(True)
        for row in range(self.table.rowCount()):
            pid = self.get_id_at_row(row)
            if pid == profile_id:
                # ── Color ONLY based on Live column ──
                live_val = (self.profile_manager.get_profile(profile_id) or {}).get("fb_live", "").lower()
                
                row_bg = QColor("#e0f2fe") if (row % 2 == 0) else QColor("#ffffff")
                row_fg = QColor("#0f172a")
                if any(x in live_val for x in ["dead", "die", "disabled", "locked", "banned", "khóa", "cp282", "cp956", "checkpoint", "xác minh"]):
                    row_bg = QColor("#ff6b6b")
                elif "out" in live_val:
                    row_bg = QColor("#ffec8b")
                elif "live" in live_val:
                    row_bg = QColor("#81c784")
                
                # Find and update status column
                status_col = next((i for i, (k, _) in enumerate(self.current_columns) if k == "status"), -1)
                if status_col != -1:
                    disp_status = tr(f"status_{status.lower()}") if status.lower() in ["running", "stopped", "error"] else status
                    status_item = QTableWidgetItem(disp_status)
                    status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    status_item.setFlags(status_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    if row_fg:
                        status_item.setForeground(row_fg)
                    self.table.setItem(row, status_col, status_item)

                # Also update the Live column cell if fb_live changed
                if fb_live_update:
                    live_col = next((i for i, (k, _) in enumerate(self.current_columns) if k == "fb_live"), -1)
                    if live_col != -1:
                        live_item = self.table.item(row, live_col)
                        if live_item:
                            live_item.setText(fb_live_update)
                        else:
                            self.table.setItem(row, live_col, QTableWidgetItem(fb_live_update))
                
                # Repaint the whole row's background (ALWAYS)
                for c in range(self.table.columnCount()):
                    it = self.table.item(row, c)
                    if it:
                        it.setBackground(row_bg)
                        it.setForeground(row_fg)
                    else:
                        new_it = QTableWidgetItem("")
                        new_it.setBackground(row_bg)
                        new_it.setForeground(row_fg)
                        self.table.setItem(row, c, new_it)
                break
        self.table.blockSignals(False)

    def on_update_check_finished(self, found, version, changelog):
        if found:
            self.show_update_notification(version, changelog)

    def show_update_notification(self, version, changelog):
        """Show update available dialog with version info and changelog."""
        local_ver = get_local_version()
        dlg = QMessageBox(self)
        dlg.setWindowTitle("🔄 Cập nhật Facebook THE TIHA DEALER")
        dlg.setIcon(QMessageBox.Icon.Information)
        dlg.setText(
            f"<b style='font-size:14px;'>Có phiên bản mới!</b><br><br>"
            f"📌 Phiên bản hiện tại: <b>v{local_ver}</b><br>"
            f"🆕 Phiên bản mới: <b style='color:#22c55e;'>v{version}</b>"
        )
        if changelog:
            dlg.setInformativeText(f"📋 Thay đổi:\n{changelog}")
        dlg.setStyleSheet("""
            QMessageBox { background: #1e293b; }
            QLabel { color: #f1f5f9; font-size: 13px; }
            QPushButton {
                background: #3b82f6; color: white; font-weight: bold;
                padding: 8px 20px; border-radius: 6px; border: none; min-width: 100px;
            }
            QPushButton:hover { background: #2563eb; }
        """)
        btn_update = dlg.addButton("🚀 Cập nhật ngay", QMessageBox.ButtonRole.AcceptRole)
        dlg.addButton("Để sau", QMessageBox.ButtonRole.RejectRole)

        dlg.exec()
        if dlg.clickedButton() == btn_update:
            self._start_background_update()

    def _start_background_update(self):
        """Download and apply update in background with styled progress dialog."""
        from PyQt6.QtWidgets import QProgressDialog

        self._update_progress = QProgressDialog(
            "Đang kết nối server cập nhật...", None, 0, 100, self
        )
        self._update_progress.setWindowTitle("🔄 Cập nhật Facebook THE TIHA DEALER")
        self._update_progress.setMinimumWidth(500)
        self._update_progress.setMinimumDuration(0)
        self._update_progress.setAutoClose(False)
        self._update_progress.setAutoReset(False)
        self._update_progress.setCancelButton(None)
        self._update_progress.setStyleSheet("""
            QProgressDialog { background: #1e293b; color: #f7fafc; }
            QLabel { color: #f1f5f9; font-size: 13px; font-weight: bold; }
            QProgressBar {
                border: 1px solid #475569; border-radius: 6px;
                background: #0f172a; text-align: center; color: white;
                min-height: 22px; font-size: 12px;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 #8b5cf6, stop:0.5 #a78bfa, stop:1 #3b82f6);
                border-radius: 5px;
            }
        """)
        self._update_progress.show()

        self._download_thread = DownloadUpdateThread()
        self._download_thread.progress.connect(self._on_update_progress)
        self._download_thread.finished.connect(self._on_update_finished)
        self._download_thread.start()

    def _on_update_progress(self, percent, message):
        if hasattr(self, '_update_progress') and self._update_progress:
            self._update_progress.setValue(percent)
            self._update_progress.setLabelText(message)

    def _on_update_finished(self, success, message):
        if hasattr(self, '_update_progress') and self._update_progress:
            self._update_progress.close()
            self._update_progress = None

        if success:
            dlg = QMessageBox(self)
            dlg.setWindowTitle("✅ Cập nhật hoàn tất")
            dlg.setIcon(QMessageBox.Icon.Information)
            dlg.setText(
                "<b style='font-size:14px; color:#22c55e;'>✅ Cập nhật thành công!</b><br><br>"
                "Tool cần khởi động lại để áp dụng thay đổi."
            )
            dlg.setStyleSheet("""
                QMessageBox { background: #1e293b; }
                QLabel { color: #f1f5f9; font-size: 13px; }
                QPushButton {
                    background: #22c55e; color: white; font-weight: bold;
                    padding: 8px 20px; border-radius: 6px; border: none; min-width: 100px;
                }
                QPushButton:hover { background: #16a34a; }
            """)
            btn_restart = dlg.addButton("🔄 Khởi động lại ngay", QMessageBox.ButtonRole.AcceptRole)
            dlg.addButton("Để sau", QMessageBox.ButtonRole.RejectRole)
            dlg.exec()
            if dlg.clickedButton() == btn_restart:
                apply_update()
        else:
            QMessageBox.warning(self, "❌ Lỗi cập nhật", f"Không thể cập nhật:\n{message}")

    def on_browser_setting_changed(self, new_browser_name):
        """Called by SettingsDialog when the global browser selection is changed and saved."""
        running = list(self.browser_manager.running_threads.keys())
        if not running:
            return
            
        if self.is_browser_installing(new_browser_name):
            QMessageBox.information(
                self, "Chờ Cài Đặt", 
                f"Đang cài đặt ngầm {new_browser_name}. Khi hoàn tất 100%, hệ thống sẽ hỏi để khởi động lại máy ảo."
            )
            return
            
        reply = QMessageBox.question(
            self, 
            "Thay Đổi Trình Duyệt", 
            f"Bạn đã đổi sang {new_browser_name}. Có {len(running)} profiles đang mở. Bạn có muốn khởi động lại chúng ngay lập tức không?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self._do_browser_hot_swap(running)
            
    def _do_browser_hot_swap(self, running_pids):
        profiles_to_relaunch = []
        for pid in running_pids:
            p = self.profile_manager.get_profile(pid)
            if p: profiles_to_relaunch.append(p)
            self.browser_manager.close_browser(pid)
            
        self.browser_manager.running_threads.clear()
        self.update_status_bar()
        
        for p in profiles_to_relaunch:
            # We add them to pending tasks as a tuple: (pid, auto_login, headless, action)
            self.pending_tasks.append((p["id"], False, False, "launch"))
            
        self.process_pending_tasks()

    def start_background_browser_install(self, browser_name):
        if hasattr(self, "browser_installer_worker") and self.browser_installer_worker.isRunning():
            return
            
        from core.browser_installer import BrowserInstallerWorker
        self.browser_installer_worker = BrowserInstallerWorker(browser_name)
        self.browser_installer_worker.progress.connect(self._on_global_install_progress)
        self.browser_installer_worker.finished.connect(self._on_global_install_finished)
        self.browser_installer_worker.start()
        
    def _on_global_install_progress(self, val, msg):
        self.statusBar().showMessage(msg)
        
    def _on_global_install_finished(self, success, msg):
        self.statusBar().showMessage(f"Cài đặt trình duyệt: {msg}", 10000)
        from ui.settings_dialog import load_settings
        settings = load_settings()
        curr = settings.get("selected_browser", "Chromium")
        if success and hasattr(self, "browser_installer_worker"):
             if curr == self.browser_installer_worker.browser_name:
                 running = list(self.browser_manager.running_threads.keys())
                 if running:
                     reply = QMessageBox.question(
                         self, "Cài đặt hoàn tất",
                         f"Đã cài ngầm xong {curr}. Khởi động lại {len(running)} profiles ngay bây giờ để áp dụng trình duyệt mới nhé?",
                         QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                         QMessageBox.StandardButton.Yes
                     )
                     if reply == QMessageBox.StandardButton.Yes:
                         self._do_browser_hot_swap(running)

    def is_browser_installing(self, name):
        if hasattr(self, "browser_installer_worker") and self.browser_installer_worker.isRunning():
             return self.browser_installer_worker.browser_name == name
        return False

    # ── New: Load Profile Background Checker ──
    def start_background_profile_check(self):
        try:
            profiles = self._get_visible_profiles()
            if not profiles:
                QMessageBox.information(self, "Load Profile", "Không có profile nào để kiểm tra!")
                return

            self.btn_load_profile.setEnabled(False)
            self.btn_load_profile.setStyleSheet("""
                QPushButton {
                    background: #000000;
                    color: white; 
                    font-weight: bold; 
                    border-radius: 4px;
                }
            """)

            max_threads = self.spin_threads.value() if hasattr(self, 'spin_threads') else 5
            
            from modules.background_checker import ProfileCheckWorkerManager
            self.background_checker = ProfileCheckWorkerManager(profiles, max_threads=max_threads)
            self.background_checker.profile_checked.connect(self.on_background_profile_checked)
            self.background_checker.finished_all.connect(self.on_background_check_finished)
            self.background_checker.start()
            
            self.update_status_bar()
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.btn_load_profile.setEnabled(True)
            QMessageBox.warning(self, "Lỗi", f"Lỗi Load Profile: {str(e)[:200]}")

    def on_background_profile_checked(self, profile_id, data):
        self.profile_manager.update_profile(profile_id, data)
        # Update row if it's visible to avoid full reload freeze
        if "status" in data:
            self.update_status(profile_id, data["status"])
        else:
            # Just do a silent UI reload or targeted cell update for the info.
            # To be simple and robust:
            self.load_data()

    def on_background_check_finished(self):
        self.background_checker = None
        self.btn_load_profile.setEnabled(True)
        # Restore primary style — clear inline style to use global stylesheet
        self.btn_load_profile.setStyleSheet("")  # Reset to inherit from global stylesheet
        self.btn_load_profile.setObjectName("PrimaryBtn")  # Ensure PrimaryBtn style applies
        self.load_data() # Final refresh
        QMessageBox.information(self, "Load Profile", "Đã chạy ngầm kiểm tra xong tất cả profile!")

    # ── New: Stop all running threads ──
    def stop_all_threads(self):
        running = self.browser_manager.running_threads
        if not running:
            QMessageBox.information(self, "Stop", "Không có tiến trình nào đang chạy!")
            return
        count = len(running)
        for pid in list(running.keys()):
            self.browser_manager.close_browser(pid)
        if hasattr(self, 'background_checker') and self.background_checker:
            self.background_checker.stop()
            self.background_checker = None
            count += 1
            
        self.browser_manager.running_threads.clear()
        self.pending_tasks = []
        QMessageBox.information(self, "Stop", f"Đã dừng tiến trình!")
        self.update_status_bar()

    # ── Find / Filter UID ──
    def find_uid_selected(self):
        """Open the Filter Profile dialog."""
        # Gather current categories
        categories = []
        settings = load_settings()
        cats = settings.get("categories", ["Default"])
        for c in cats:
            categories.append(c)

        dlg = FilterProfileDialog(self, categories=categories)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            query_lines = dlg.get_query_lines()
            filter_mode = dlg.get_filter_mode()
            selected_cats = dlg.get_selected_categories()

            if not query_lines and not selected_cats:
                return  # Nothing to filter

            self._apply_profile_filter(query_lines, filter_mode, selected_cats)

    def _apply_profile_filter(self, query_lines, filter_mode, selected_cats):
        """Filter the profile table based on search criteria."""
        # Map filter mode to column key
        mode_key_map = {
            "Lọc theo UID": "fb_uid",
            "Lọc theo Name": "name",
            "Lọc theo Ghi chú": "fb_note",
            "Lọc nhiều danh mục": "_category",
            "Lọc theo Email": "fb_email",
            "Lọc theo Email Old": "fb_email_recovery",
            "Lọc theo Token": "fb_token",
            "Lọc theo domain Email": "fb_email",
            "Lọc theo domain Email Old": "fb_email_recovery",
            "Lọc theo Proxy": "fb_proxy",
            "Lọc theo Password": "fb_pass",
            "Lọc theo Live": "fb_live",
        }

        data_key = mode_key_map.get(filter_mode, "fb_uid")
        is_domain = "domain" in filter_mode
        is_category = filter_mode == "Lọc nhiều danh mục"

        # Find the column index for the target key
        target_col = -1
        for col_idx, (key, label) in enumerate(self.current_columns):
            if key == data_key:
                target_col = col_idx
                break

        # For category filter, look up from self.profiles
        for row in range(self.table.rowCount()):
            show = False  # Default: hide all, only show matches

            if is_category:
                # Match category from profile data
                stt_col = -1
                uid_col = -1
                for ci, (k, _) in enumerate(self.current_columns):
                    if k == "stt": stt_col = ci
                    if k == "fb_uid": uid_col = ci

                # Find profile for this row
                row_uid = ""
                if uid_col >= 0:
                    item = self.table.item(row, uid_col)
                    if item:
                        row_uid = item.text().strip()

                for p in self.profiles:
                    if str(p.get("fb_uid", "")) == row_uid:
                        p_cat = p.get("category", "Default")
                        if not selected_cats or p_cat in selected_cats:
                            show = True
                        break
            elif target_col >= 0 and query_lines:
                # Match text from table cell
                item = self.table.item(row, target_col)
                if item:
                    value = item.text().strip().lower()
                    if is_domain and "@" in value:
                        value = value.split("@")[1]

                    for q in query_lines:
                        if q.strip().lower() in value:
                            show = True
                            break
            elif not query_lines and selected_cats:
                # Only category filter (no text query)
                uid_col = -1
                for ci, (k, _) in enumerate(self.current_columns):
                    if k == "fb_uid": uid_col = ci

                row_uid = ""
                if uid_col >= 0:
                    item = self.table.item(row, uid_col)
                    if item:
                        row_uid = item.text().strip()

                for p in self.profiles:
                    if str(p.get("fb_uid", "")) == row_uid:
                        p_cat = p.get("category", "Default")
                        if p_cat in selected_cats:
                            show = True
                        break
            else:
                show = True  # No filter criteria

            self.table.setRowHidden(row, not show)

        # Count visible
        visible = sum(1 for r in range(self.table.rowCount()) if not self.table.isRowHidden(r))
        total = self.table.rowCount()
        self.lbl_status_active.setText(f"Lọc: {visible}/{total} profile")

    def show_all_profiles(self):
        """Reset filter — show all rows (Refresh Profile)."""
        for row in range(self.table.rowCount()):
            self.table.setRowHidden(row, False)
        self.update_status_bar()
        self.lbl_status_active.setText("Trạng thái: Sẵn sàng")

    # ── New: Rename category ──
    def rename_category(self):
        current = self.combo_category.currentText()
        if current in ["All Categories", "Default"]:
            QMessageBox.warning(self, "Edit", "Không thể đổi tên danh mục mặc định!")
            return
        new_name, ok = QInputDialog.getText(self, "Sửa Danh Mục", "Tên mới:", text=current)
        if ok and new_name and new_name.strip() != current:
            new_name = new_name.strip()
            cats = self.settings.get("categories", ["Default"])
            if new_name not in cats:
                idx = cats.index(current)
                cats[idx] = new_name
                self.settings["categories"] = cats
                from ui.settings_dialog import save_settings
                save_settings(self.settings)
                for p in self.profile_manager.get_all_profiles(category=current):
                    self.profile_manager.update_profile(p["id"], {"category": new_name})
                self.load_categories_to_ui()
                self.load_data()

    # ── Manual update check (rewritten from scratch) ──
    def check_for_updates(self):
        """Check for updates from GitHub and show result."""
        self.btn_check_update.setEnabled(False)
        self.btn_check_update.setText("⏳ Đang kiểm tra...")

        t = UpdateThread()

        def on_done(found, version, changelog):
            self.btn_check_update.setEnabled(True)
            self.btn_check_update.setText("Check Update")
            if found and version:
                self.show_update_notification(version, changelog)
            else:
                local_ver = get_local_version()
                msg = QMessageBox(self)
                msg.setWindowTitle("✅ Kiểm tra cập nhật")
                msg.setIcon(QMessageBox.Icon.Information)
                msg.setText(
                    f"<b>Đang dùng phiên bản mới nhất!</b><br><br>"
                    f"📌 Phiên bản hiện tại: <b>v{local_ver}</b>"
                )
                if changelog:
                    msg.setInformativeText(changelog)
                msg.setStyleSheet("""
                    QMessageBox { background: #1e293b; }
                    QLabel { color: #f1f5f9; font-size: 13px; }
                    QPushButton {
                        background: #3b82f6; color: white; font-weight: bold;
                        padding: 6px 16px; border-radius: 4px; border: none;
                    }
                    QPushButton:hover { background: #2563eb; }
                """)
                msg.exec()

        t.finished.connect(on_done)
        t.start()
        self._last_update_thread = t

    # ── Override: on_info_scraped to also refresh name + all fields live ──
    def on_info_scraped(self, profile_id, data):
        self.profile_manager.update_profile(profile_id, data)
        # Reload the corresponding row live without reloading entire table
        self.table.blockSignals(True)
        profiles = self._get_visible_profiles()
        for row_idx, profile in enumerate(profiles):
            if profile["id"] == profile_id:
                # Re-read the updated profile from manager
                updated = self.profile_manager.get_profile(profile_id) or {}
                for col_idx, (key, label) in enumerate(self.current_columns):
                    if key not in ["chk", "stt", "status"]:
                        val = str(updated.get(key, ""))
                        it = self.table.item(row_idx, col_idx)
                        if it:
                            it.setText(val)
                        else:
                            self.table.setItem(row_idx, col_idx, QTableWidgetItem(val))
                # Trigger color update via status
                new_status = data.get("status", updated.get("status", "Stopped"))
                self.update_status(profile_id, new_status)
                break
        self.table.blockSignals(False)
