Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

' Try py launcher first, then python, then pythonw
Dim cmd
If FileExists("main.py") Then
    cmd = "pythonw main.py"
End If

WshShell.Run cmd, 0, False

Function FileExists(path)
    FileExists = CreateObject("Scripting.FileSystemObject").FileExists(path)
End Function
