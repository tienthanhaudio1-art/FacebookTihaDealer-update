import sys
import os

# Add the current directory to sys.path so we can import core and ui
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Clear ALL __pycache__ recursively to prevent stale bytecode
import shutil
import importlib
_base = os.path.dirname(os.path.abspath(__file__))
for _root, _dirs, _files in os.walk(_base):
    for _d in _dirs:
        if _d == "__pycache__":
            shutil.rmtree(os.path.join(_root, _d), ignore_errors=True)
importlib.invalidate_caches()  # Force Python to re-read all .py files

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QTimer


def _create_desktop_shortcut():
    """Auto-create Desktop shortcut on first run (Windows only)."""
    if sys.platform != "win32":
        return
    try:
        import subprocess
        # Determine paths
        app_dir = os.path.dirname(os.path.abspath(__file__))
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        shortcut_name = "Facebook THE TIHA DEALER.lnk"
        shortcut_path = os.path.join(desktop, shortcut_name)

        # Skip if shortcut already exists
        if os.path.exists(shortcut_path):
            return

        # Find icon
        icon_path = os.path.join(app_dir, "assets", "logo.ico")
        if not os.path.exists(icon_path):
            icon_path = ""

        # Find target: Run Tool.vbs (hidden console) > Run Tool.bat > main.py
        vbs_path = os.path.join(app_dir, "Run Tool.vbs")
        bat_path = os.path.join(app_dir, "Run Tool.bat")
        if os.path.exists(vbs_path):
            target = vbs_path
        elif os.path.exists(bat_path):
            target = bat_path
        else:
            target = os.path.join(app_dir, "main.py")

        # Create shortcut using PowerShell (no extra dependencies needed)
        icon_line = ""
        if icon_path:
            icon_line = f"$s.IconLocation = '{icon_path}'"

        ps_script = f"""
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut('{shortcut_path}')
$s.TargetPath = '{target}'
$s.WorkingDirectory = '{app_dir}'
$s.Description = 'Facebook THE TIHA DEALER Tool'
{icon_line}
$s.Save()
"""
        subprocess.run(
            ["powershell", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
            capture_output=True, timeout=10
        )
        print(f"[Shortcut] Created: {shortcut_path}")
    except Exception as e:
        print(f"[Shortcut] Warning: {e}")


def main():
    # Set AppUserModelID to show custom icon on taskbar in Windows
    if sys.platform == "win32":
        import ctypes
        myappid = u'thetiha.facebookdealer.tool.1.0'
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)

    app = QApplication(sys.argv)

    # ─── Show Splash Screen ───
    from ui.splash_screen import SplashScreen
    splash = SplashScreen()
    splash.show()
    app.processEvents()

    # Check License while splash is showing
    from core.licensing import get_stored_license, verify_license
    stored_key = get_stored_license()
    if not verify_license(stored_key):
        from ui.activation_dialog import ActivationDialog
        splash.close()
        activation = ActivationDialog()
        if not activation.exec():
            sys.exit(0)  # User cancelled activation

    # Global exception hook — show error dialog instead of crashing
    def global_exception_handler(exc_type, exc_value, exc_traceback):
        import traceback
        tb = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        print(f"UNHANDLED EXCEPTION:\n{tb}")
        try:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.critical(None, "Lỗi Tool",
                f"Đã xảy ra lỗi:\n{str(exc_value)[:300]}\n\nTool sẽ không tắt.")
        except:
            pass
    sys.excepthook = global_exception_handler

    # Wait for splash to finish before showing main window
    def _show_main():
        if splash.is_done():
            splash.close()
            from ui.main_window import MainWindow
            window = MainWindow()
            window.show()
            # Store reference to prevent garbage collection
            app._main_window = window
            # Auto-create desktop shortcut (non-blocking)
            QTimer.singleShot(500, _create_desktop_shortcut)
        else:
            QTimer.singleShot(100, _show_main)

    QTimer.singleShot(100, _show_main)

    sys.exit(app.exec())

if __name__ == "__main__":
    main()

