"""
Post Cleaner Worker v7 — Activity Log, locator-only (no DOM traversal).

Uses Playwright locator bounding boxes to associate checkboxes with date headers
by Y-coordinate proximity (bypasses virtual DOM hierarchy issue).

SCAN:  Find date headers + checkboxes → associate by Y position → count by date.
DELETE: Click checkboxes → click "Bỏ đi" → confirm.
"""
import re
import time
import os
from datetime import datetime, date, timedelta
from PyQt6.QtCore import QThread, pyqtSignal


class PostCleanerWorker(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    post_found = pyqtSignal(dict)
    scan_complete = pyqtSignal(int)
    delete_complete = pyqtSignal(int, int)
    error_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()

    ACTIVITY_URL = (
        "https://www.facebook.com/{uid}/allactivity"
        "?activity_history=false"
        "&category_key=MANAGEPOSTSPHOTOSANDVIDEOS"
        "&manage_mode=false"
        "&should_load_landing_page=false"
    )

    def __init__(self, cookie_str, uid, start_date, end_date, mode="scan",
                 posts_to_delete=None):
        super().__init__()
        self.cookie_str = cookie_str
        self.uid = uid
        self.start_date = start_date
        self.end_date = end_date
        self.mode = mode
        self.posts_to_delete = posts_to_delete or []
        self._running = True
        self.found_posts = []

    def stop(self):
        self._running = False

    def run(self):
        try:
            from playwright.sync_api import sync_playwright
            from core.browser_manager import setup_playwright
            setup_playwright()

            with sync_playwright() as p:
                temp = os.path.join(
                    os.environ.get("TEMP", "C:\\temp"),
                    "PostCleaner", str(self.uid)
                )
                os.makedirs(temp, exist_ok=True)

                from core.browser_manager import get_browser_window_params
                wp = get_browser_window_params(0)

                ctx = p.chromium.launch_persistent_context(
                    user_data_dir=temp, headless=True,
                    args=["--disable-blink-features=AutomationControlled",
                          "--no-sandbox"],
                    viewport={"width": wp["win_w"], "height": wp["win_h"]},
                    locale="vi-VN"
                )
                page = ctx.pages[0] if ctx.pages else ctx.new_page()

                self.log_signal.emit("🔑 Đăng nhập...")
                cks = []
                for part in self.cookie_str.split(';'):
                    if '=' in part:
                        k, v = part.strip().split('=', 1)
                        cks.append({"name": k, "value": v,
                                    "domain": ".facebook.com", "path": "/"})
                if cks:
                    ctx.add_cookies(cks)

                url = self.ACTIVITY_URL.format(uid=self.uid)
                self.log_signal.emit("🌐 Mở Nhật ký hoạt động...")
                page.goto(url, wait_until="domcontentloaded", timeout=30000)
                time.sleep(4)

                if "login" in page.url.lower() or "checkpoint" in page.url.lower():
                    self.error_signal.emit("Cookie hết hạn hoặc checkpoint!")
                    ctx.close()
                    return

                self.log_signal.emit("✅ Đã mở Nhật ký hoạt động!")

                if self.mode == "scan":
                    self._scan(page)
                elif self.mode == "delete":
                    self._delete(page)

                ctx.close()

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.error_signal.emit(f"Lỗi: {str(e)[:200]}")
        finally:
            self.finished_signal.emit()

    # ═══════════════════════════════════════════
    #  SCAN — date headers + checkbox bounding boxes
    # ═══════════════════════════════════════════
    def _scan(self, page):
        self.log_signal.emit(f"🔍 Quét UID {self.uid}")
        self.log_signal.emit(
            f"📅 {self.start_date.strftime('%d/%m/%Y')} → "
            f"{self.end_date.strftime('%d/%m/%Y')}"
        )

        # Track how many posts we've counted per date header
        date_post_counts = {}
        scroll_count = 0
        no_new = 0
        past_range = False

        while self._running and scroll_count < 150 and not past_range:
            scroll_count += 1
            self.progress_signal.emit(min(scroll_count * 2, 95))

            # 1. Find date headers with Y positions
            date_entries = self._get_date_header_positions(page)
            
            if not date_entries:
                no_new += 1
                if no_new >= 4:
                    if not self._click_show_more(page):
                        break
                    no_new = 0
                page.evaluate("window.scrollBy(0, 600)")
                time.sleep(0.8)
                continue

            # 2. Find checkboxes with Y positions (excluding select-all)
            cb_positions = self._get_checkbox_positions(page)

            # 3. Count checkboxes per date header
            header_cb_counts = {}
            for cb_y in cb_positions:
                best_header = None
                best_y = -999999
                for header_text, header_date, header_y in date_entries:
                    if header_y <= cb_y and header_y > best_y:
                        best_header = header_text
                        best_y = header_y
                if best_header:
                    header_cb_counts[best_header] = header_cb_counts.get(best_header, 0) + 1

            # 4. For each header, add NEW posts (if count increased)
            new_found = 0
            for header_text, header_date, _ in date_entries:
                if not self._running:
                    break
                
                current_count = header_cb_counts.get(header_text, 0)
                previous_count = date_post_counts.get(header_text, 0)
                
                if current_count <= previous_count:
                    continue  # No new posts under this header
                
                date_post_counts[header_text] = current_count
                new_posts = current_count - previous_count
                new_found += new_posts

                if header_date < self.start_date:
                    past_range = True
                    self.log_signal.emit("📌 Qua mốc thời gian.")
                    break

                if self.start_date <= header_date <= self.end_date:
                    for j in range(previous_count, current_count):
                        post_data = {
                            "id": f"{header_text}_{j}",
                            "date": header_date,
                            "text": header_text,
                        }
                        self.found_posts.append(post_data)
                        self.post_found.emit(post_data)
                    
                    self.log_signal.emit(
                        f"  ✅ [{header_date.strftime('%d/%m/%Y')}] "
                        f"+{new_posts} bài (tổng: {current_count})"
                    )

            if new_found > 0:
                no_new = 0
            else:
                no_new += 1
                if no_new >= 4:
                    if not self._click_show_more(page):
                        self.log_signal.emit("📌 Hết bài.")
                        break
                    no_new = 0

            page.evaluate("window.scrollBy(0, 600)")
            time.sleep(0.8)

            if scroll_count % 5 == 0:
                self.log_signal.emit(
                    f"📄 Cuộn {scroll_count}x → {len(self.found_posts)} bài"
                )

        total = len(self.found_posts)
        self.log_signal.emit(f"\n{'='*40}")
        self.log_signal.emit(f"📊 KẾT QUẢ: {total} bài viết")
        self.log_signal.emit(f"{'='*40}")
        self.scan_complete.emit(total)

    def _get_date_header_positions(self, page):
        """Get date headers with their Y positions."""
        entries = []
        try:
            headers = page.get_by_text(
                re.compile(r'^\d{1,2}\s+[Tt]háng\s+\d{1,2},?\s+\d{4}$')
            )
            for i in range(headers.count()):
                el = headers.nth(i)
                try:
                    txt = el.text_content()
                    box = el.bounding_box()
                    if txt and box:
                        d = self._parse_date_header(txt.strip())
                        if d:
                            entries.append((txt.strip(), d, box['y']))
                except:
                    continue
        except:
            pass
        return entries

    def _get_checkbox_positions(self, page):
        """Get Y positions of all checkboxes (excluding the select-all one)."""
        positions = []
        try:
            cbs = page.locator('input[type="checkbox"]')
            count = cbs.count()
            select_all_y = None
            
            for i in range(count):
                try:
                    box = cbs.nth(i).bounding_box()
                    if box:
                        if select_all_y is None:
                            # First checkbox is usually "Tất cả"
                            select_all_y = box['y']
                            continue  # Skip select-all
                        positions.append(box['y'])
                except:
                    continue
        except:
            pass
        return positions

    def _click_show_more(self, page):
        try:
            btn = page.get_by_text("Xem thêm", exact=True)
            if btn.count() > 0 and btn.first.is_visible():
                btn.first.click()
                time.sleep(1.5)
                return True
        except:
            pass
        return False

    def _parse_date_header(self, text):
        m = re.match(
            r'(\d{1,2})\s+[Tt]háng\s+(\d{1,2}),?\s+(\d{4})', text
        )
        if m:
            try:
                return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            except ValueError:
                pass
        return None

    # ═══════════════════════════════════════════
    #  DELETE — Click checkboxes by Y-position → "Bỏ đi"
    # ═══════════════════════════════════════════
    def _delete(self, page):
        total = len(self.posts_to_delete)
        if total == 0:
            self.delete_complete.emit(0, 0)
            return

        self.log_signal.emit(f"🗑️ Xóa {total} bài...")

        # Collect target dates
        target_dates = set()
        for p in self.posts_to_delete:
            d = p.get("date")
            if d:
                target_dates.add(d)

        checked = 0
        scroll_count = 0
        seen_y = set()

        while self._running and scroll_count < 100:
            scroll_count += 1
            self.progress_signal.emit(min(scroll_count, 70))

            # Get date headers
            date_entries = self._get_date_header_positions(page)
            
            # Get checkboxes
            cbs = page.locator('input[type="checkbox"]')
            cb_count = cbs.count()
            
            for i in range(cb_count):
                if not self._running:
                    break
                try:
                    cb = cbs.nth(i)
                    box = cb.bounding_box()
                    if not box:
                        continue
                    
                    rounded_y = round(box['y'])
                    if rounded_y in seen_y:
                        continue
                    
                    # Skip select-all (first checkbox, typically at y < first date header)
                    if date_entries and box['y'] < date_entries[0][2]:
                        continue
                    
                    # Find date for this checkbox
                    best_date = None
                    best_y = -999999
                    for _, hd, hy in date_entries:
                        if hy <= box['y'] and hy > best_y:
                            best_date = hd
                            best_y = hy
                    
                    if best_date and best_date in target_dates:
                        seen_y.add(rounded_y)
                        cb.click()
                        checked += 1
                        time.sleep(0.2)
                except:
                    continue

            if checked >= total:
                break

            page.evaluate("window.scrollBy(0, 600)")
            time.sleep(0.8)

            if scroll_count % 5 == 0:
                self._click_show_more(page)
                self.log_signal.emit(f"  ☑ Đã chọn {checked}/{total}")

        self.log_signal.emit(f"📋 Chọn xong: {checked} bài")
        self.progress_signal.emit(80)

        if checked == 0:
            self.log_signal.emit("⚠️ Không chọn được bài!")
            self.delete_complete.emit(0, total)
            return

        # Click "Bỏ đi"
        deleted = self._click_trash_action(page, checked)
        errors = total - deleted

        self.log_signal.emit(f"\n{'='*40}")
        self.log_signal.emit(f"📊 XÓA: {deleted}/{total}, lỗi: {errors}")
        self.log_signal.emit(f"{'='*40}")
        self.delete_complete.emit(deleted, errors)

    def _click_trash_action(self, page, expected):
        """Click trash/archive action button."""
        page.evaluate("window.scrollTo(0, 0)")
        time.sleep(0.5)

        for label in ["Bỏ đi", "Thùng rác", "Trash", "Delete"]:
            try:
                btn = page.get_by_text(label, exact=True)
                if btn.count() > 0 and btn.first.is_visible():
                    btn.first.click()
                    time.sleep(1.5)
                    self.log_signal.emit(f"🗑️ Nhấn '{label}'!")
                    self._confirm_dialog(page)
                    return expected
            except:
                continue

        for label in ["Lưu trữ", "Archive"]:
            try:
                btn = page.get_by_text(label, exact=True)
                if btn.count() > 0 and btn.first.is_visible():
                    btn.first.click()
                    time.sleep(1.5)
                    self.log_signal.emit(f"📦 Nhấn '{label}'!")
                    self._confirm_dialog(page)
                    return expected
            except:
                continue

        self.log_signal.emit("❌ Không tìm thấy nút xóa!")
        return 0

    def _confirm_dialog(self, page):
        time.sleep(1)
        try:
            dialog = page.locator('div[role="dialog"]')
            if dialog.count() > 0 and dialog.first.is_visible():
                for ct in ['Bỏ đi', 'Trash', 'Delete', 'Xóa',
                           'Lưu trữ', 'Archive', 'OK', 'Xác nhận',
                           'Confirm', 'Chuyển', 'Move']:
                    try:
                        cb = dialog.first.locator('button').filter(
                            has_text=re.compile(ct, re.IGNORECASE)
                        ).first
                        if cb.is_visible():
                            cb.click()
                            time.sleep(1)
                            self.log_signal.emit(f"✅ Xác nhận: '{ct}'")
                            return
                    except:
                        continue
        except:
            pass
