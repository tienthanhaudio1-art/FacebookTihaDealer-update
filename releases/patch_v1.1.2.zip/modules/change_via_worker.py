"""
Change Via Worker — Background executor for Change Via tab actions.
Supports: Change Password via Playwright headless + email IMAP verification.
All operations run headlessly using cookie/API token from Profile Manager.
"""
import re
import time
import os
from datetime import datetime
from PyQt6.QtCore import QThread, pyqtSignal


class ChangeViaWorker(QThread):
    """Worker thread for Change Via operations."""
    log_signal = pyqtSignal(str, str, str)   # uid, column_name, message
    finished_one = pyqtSignal(str)
    finished_all = pyqtSignal()

    def __init__(self, profiles: list, action: str, settings: dict):
        super().__init__()
        self.profiles = profiles
        self.action = action
        self.settings = settings
        self._running = True

    def stop(self):
        self._running = False

    def run(self):
        for p in self.profiles:
            if not self._running:
                break

            uid = p.get("fb_uid", "")
            if not uid:
                continue

            self.log_signal.emit(uid, "Trạng thái", "Đang xử lý...")
            self.log_signal.emit(uid, "Kết quả", "")
            self.log_signal.emit(uid, "Lỗi", "")

            # Check auth
            cookie_mode = self.settings.get("cookie_mode", True)
            api_mode = self.settings.get("api_android_mode", False)
            cookie_str = p.get("fb_cookie", "")
            token = p.get("fb_token", "")

            if cookie_mode and not cookie_str:
                self.log_signal.emit(uid, "Lỗi", "Cookie Out")
                self.log_signal.emit(uid, "Trạng thái", "Dừng — Thiếu Cookie")
                self.finished_one.emit(uid)
                continue
            if api_mode and not token:
                self.log_signal.emit(uid, "Lỗi", "Token Out")
                self.log_signal.emit(uid, "Trạng thái", "Dừng — Thiếu Token")
                self.finished_one.emit(uid)
                continue
            if not cookie_str and not token:
                self.log_signal.emit(uid, "Lỗi", "Cookie Out / Token Out")
                self.log_signal.emit(uid, "Trạng thái", "Dừng")
                self.finished_one.emit(uid)
                continue

            # Delay
            delay = self.settings.get("delay", 0)
            if delay > 0:
                time.sleep(delay)

            try:
                if self.action == "Change Password":
                    self._change_password(p)
                else:
                    self.log_signal.emit(uid, "Trạng thái", f"[{self.action}] Chưa implement")
            except Exception as e:
                import traceback
                traceback.print_exc()
                self.log_signal.emit(uid, "Lỗi", str(e)[:100])
                self.log_signal.emit(uid, "Trạng thái", "Lỗi hệ thống")

            self.finished_one.emit(uid)

        self.finished_all.emit()

    # ═══════════════════════════════════════════
    #  CHANGE PASSWORD
    # ═══════════════════════════════════════════
    def _change_password(self, profile):
        uid = profile.get("fb_uid", "")
        old_pass = profile.get("fb_pass", "")
        new_pass = self.settings.get("new_pass", "")
        cookie_str = profile.get("fb_cookie", "")
        email = profile.get("fb_email", "")
        email_pass = profile.get("fb_pass_email", "")

        if not old_pass:
            self.log_signal.emit(uid, "Lỗi", "Thiếu mật khẩu cũ")
            self.log_signal.emit(uid, "Trạng thái", "Dừng — Không có pass cũ")
            return

        if not new_pass:
            self.log_signal.emit(uid, "Lỗi", "Thiếu mật khẩu mới")
            self.log_signal.emit(uid, "Trạng thái", "Dừng — Không có pass mới")
            return

        self.log_signal.emit(uid, "Trạng thái", "Đang mở trình duyệt...")

        try:
            from playwright.sync_api import sync_playwright
            from core.browser_manager import setup_playwright
            setup_playwright()
        except Exception as e:
            self.log_signal.emit(uid, "Lỗi", f"Playwright: {str(e)[:60]}")
            self.log_signal.emit(uid, "Trạng thái", "Lỗi Playwright")
            return

        with sync_playwright() as pw:
            temp_dir = os.path.join(
                os.environ.get("TEMP", "C:\\temp"),
                "ChangeVia", str(uid)
            )
            os.makedirs(temp_dir, exist_ok=True)

            from core.browser_manager import get_browser_window_params
            wp = get_browser_window_params(0)

            ctx = pw.chromium.launch_persistent_context(
                user_data_dir=temp_dir, headless=True,
                args=["--disable-blink-features=AutomationControlled", "--no-sandbox"],
                viewport={"width": wp["win_w"], "height": wp["win_h"]},
                locale="vi-VN"
            )
            page = ctx.pages[0] if ctx.pages else ctx.new_page()

            # Inject cookies
            cks = []
            for part in cookie_str.split(';'):
                if '=' in part:
                    k, v = part.strip().split('=', 1)
                    cks.append({"name": k, "value": v,
                                "domain": ".facebook.com", "path": "/"})
            if cks:
                ctx.add_cookies(cks)

            self.log_signal.emit(uid, "Trạng thái", "Truy cập đổi mật khẩu...")

            # Navigate to password change page
            change_url = "https://accountscenter.facebook.com/password_and_security/password/change"
            page.goto(change_url, wait_until="domcontentloaded", timeout=30000)
            time.sleep(5)

            # Check if logged in
            if "login" in page.url.lower():
                self.log_signal.emit(uid, "Lỗi", "Cookie Die — Bắt đăng nhập")
                self.log_signal.emit(uid, "Trạng thái", "Cookie Out")
                ctx.close()
                return

            if "checkpoint" in page.url.lower():
                self.log_signal.emit(uid, "Lỗi", "Checkpoint")
                self.log_signal.emit(uid, "Trạng thái", "Checkpoint")
                ctx.close()
                return

            # Take screenshot for debugging
            page.screenshot(path=os.path.join(temp_dir, "change_pass_1.png"))

            # Look for profile selector (Facebook might ask which account)
            self.log_signal.emit(uid, "Trạng thái", "Chọn tài khoản chính...")
            time.sleep(2)

            # Try to find and click the main FB profile
            try:
                # Facebook accounts center shows profile selector
                fb_profile = page.get_by_text("Facebook", exact=False)
                if fb_profile.count() > 0:
                    # Look for the clickable profile item
                    profile_items = page.locator('[role="radio"], [role="listitem"], [role="button"]').filter(
                        has_text=re.compile(r'facebook', re.IGNORECASE)
                    )
                    if profile_items.count() > 0:
                        profile_items.first.click()
                        time.sleep(2)
            except:
                pass

            # Look for "Continue" / "Tiếp tục" button after profile selection
            for btn_text in ["Tiếp tục", "Continue", "Tiếp"]:
                try:
                    btn = page.get_by_text(btn_text, exact=True)
                    if btn.count() > 0 and btn.first.is_visible():
                        btn.first.click()
                        time.sleep(3)
                        break
                except:
                    continue

            page.screenshot(path=os.path.join(temp_dir, "change_pass_2.png"))

            # Now we should be on the password change form
            self.log_signal.emit(uid, "Trạng thái", "Nhập mật khẩu...")

            # Find password fields
            # Old password field
            old_pw_filled = False
            new_pw_filled = False

            pw_inputs = page.locator('input[type="password"]')
            pw_count = pw_inputs.count()

            if pw_count >= 2:
                # First = old password, second = new password
                pw_inputs.nth(0).fill(old_pass)
                time.sleep(0.5)
                pw_inputs.nth(1).fill(new_pass)
                old_pw_filled = True
                new_pw_filled = True
            elif pw_count == 1:
                # Might be asking for current password first
                pw_inputs.nth(0).fill(old_pass)
                old_pw_filled = True
                time.sleep(1)

                # Click continue/next
                for btn_text in ["Tiếp tục", "Continue", "Tiếp", "Next"]:
                    try:
                        btn = page.get_by_text(btn_text, exact=True)
                        if btn.count() > 0 and btn.first.is_visible():
                            btn.first.click()
                            time.sleep(3)
                            break
                    except:
                        continue

                # Now look for new password field
                new_pw_inputs = page.locator('input[type="password"]')
                if new_pw_inputs.count() > 0:
                    new_pw_inputs.first.fill(new_pass)
                    new_pw_filled = True
                    time.sleep(0.5)

            if not old_pw_filled or not new_pw_filled:
                # Try labeled inputs
                try:
                    old_input = page.get_by_label(re.compile(r'mật khẩu hiện tại|current password|mật khẩu cũ', re.IGNORECASE))
                    if old_input.count() > 0:
                        old_input.first.fill(old_pass)
                        old_pw_filled = True
                except:
                    pass
                try:
                    new_input = page.get_by_label(re.compile(r'mật khẩu mới|new password', re.IGNORECASE))
                    if new_input.count() > 0:
                        new_input.first.fill(new_pass)
                        new_pw_filled = True
                except:
                    pass

            if not old_pw_filled:
                self.log_signal.emit(uid, "Lỗi", "Không tìm thấy ô nhập pass cũ")
                self.log_signal.emit(uid, "Trạng thái", "Lỗi form")
                ctx.close()
                return

            page.screenshot(path=os.path.join(temp_dir, "change_pass_3.png"))

            # Submit — click "Đổi mật khẩu" / "Change Password"
            self.log_signal.emit(uid, "Trạng thái", "Gửi đổi mật khẩu...")

            submitted = False
            for btn_text in ["Đổi mật khẩu", "Change password", "Đổi", "Change",
                             "Lưu thay đổi", "Save Changes", "Submit"]:
                try:
                    btn = page.get_by_text(btn_text, exact=False)
                    if btn.count() > 0:
                        for i in range(btn.count()):
                            el = btn.nth(i)
                            if el.is_visible():
                                el.click()
                                submitted = True
                                break
                    if submitted:
                        break
                except:
                    continue

            if not submitted:
                # Try generic submit button
                try:
                    submit_btns = page.locator('button[type="submit"], [role="button"]').filter(
                        has_text=re.compile(r'đổi|change|save|lưu|submit', re.IGNORECASE)
                    )
                    if submit_btns.count() > 0:
                        submit_btns.first.click()
                        submitted = True
                except:
                    pass

            if not submitted:
                self.log_signal.emit(uid, "Lỗi", "Không tìm thấy nút submit")
                self.log_signal.emit(uid, "Trạng thái", "Lỗi form")
                ctx.close()
                return

            time.sleep(5)
            page.screenshot(path=os.path.join(temp_dir, "change_pass_4.png"))

            # Check result
            page_text = ""
            try:
                page_text = page.locator('body').text_content() or ""
            except:
                pass

            # Check for security code request
            security_patterns = [
                r'mã bảo mật|security code|verification code|mã xác minh',
                r'xác nhận danh tính|confirm your identity|verify',
            ]
            needs_code = False
            for pat in security_patterns:
                if re.search(pat, page_text, re.IGNORECASE):
                    needs_code = True
                    break

            if needs_code:
                # Check if it's phone/WhatsApp based
                phone_patterns = [
                    r'số điện thoại|phone number|whatsapp|sms|tin nhắn',
                ]
                is_phone = False
                for pat in phone_patterns:
                    if re.search(pat, page_text, re.IGNORECASE):
                        is_phone = True
                        break

                if is_phone:
                    self.log_signal.emit(uid, "Lỗi",
                        "FB yêu cầu mã từ SĐT/WhatsApp")
                    self.log_signal.emit(uid, "Trạng thái",
                        "Dừng — Yêu cầu mã SĐT/WhatsApp")
                    ctx.close()
                    return

                # Email-based verification
                self.log_signal.emit(uid, "Trạng thái",
                    "FB yêu cầu mã email — Đang tìm...")

                if not email:
                    self.log_signal.emit(uid, "Lỗi",
                        "FB đòi mã email nhưng profile không có email")
                    self.log_signal.emit(uid, "Trạng thái", "Dừng — Thiếu email")
                    ctx.close()
                    return

                # Try to select email verification method
                try:
                    email_option = page.get_by_text(
                        re.compile(r'email|thư điện tử', re.IGNORECASE)
                    )
                    if email_option.count() > 0:
                        email_option.first.click()
                        time.sleep(2)
                        # Click continue
                        for t in ["Tiếp tục", "Continue", "Gửi mã", "Send Code"]:
                            try:
                                b = page.get_by_text(t, exact=True)
                                if b.count() > 0 and b.first.is_visible():
                                    b.first.click()
                                    time.sleep(3)
                                    break
                            except:
                                continue
                except:
                    pass

                # Get code from email via IMAP
                code = self._get_email_code(email, email_pass, profile)

                if code:
                    self.log_signal.emit(uid, "Trạng thái",
                        f"Tìm thấy mã: {code} — Nhập...")

                    # Enter code
                    code_inputs = page.locator(
                        'input[type="text"], input[type="number"], input[type="tel"]'
                    )
                    if code_inputs.count() > 0:
                        code_inputs.first.fill(code)
                        time.sleep(1)

                        # Submit code
                        for t in ["Tiếp tục", "Continue", "Xác nhận",
                                  "Confirm", "Submit", "Gửi"]:
                            try:
                                b = page.get_by_text(t, exact=True)
                                if b.count() > 0 and b.first.is_visible():
                                    b.first.click()
                                    time.sleep(4)
                                    break
                            except:
                                continue
                    else:
                        self.log_signal.emit(uid, "Lỗi",
                            "Không tìm thấy ô nhập mã")
                        ctx.close()
                        return

                    time.sleep(3)
                    page.screenshot(path=os.path.join(temp_dir, "change_pass_5.png"))
                else:
                    self.log_signal.emit(uid, "Lỗi",
                        "Không tìm thấy mã từ email (5 lần)")
                    self.log_signal.emit(uid, "Trạng thái",
                        "Dừng — Không nhận được mã email")
                    ctx.close()
                    return

            # Final check — success indicators
            final_text = ""
            try:
                final_text = page.locator('body').text_content() or ""
            except:
                pass

            success_patterns = [
                r'mật khẩu đã được thay đổi|password.*changed|password.*updated',
                r'thay đổi thành công|successfully|đã cập nhật',
            ]
            is_success = any(
                re.search(pat, final_text, re.IGNORECASE)
                for pat in success_patterns
            )

            if is_success or "password_and_security" in page.url:
                self.log_signal.emit(uid, "Kết quả",
                    f"✅ Đổi pass: {new_pass}")
                self.log_signal.emit(uid, "Trạng thái",
                    "Thành công ✅")
                # Update profile password
                self._update_profile_pass(uid, new_pass, old_pass)
            else:
                # Check for error messages
                error_patterns = [
                    r'sai mật khẩu|wrong password|incorrect password',
                    r'không đúng|doesn\'t match',
                    r'thử lại|try again',
                ]
                error_found = ""
                for pat in error_patterns:
                    m = re.search(pat, final_text, re.IGNORECASE)
                    if m:
                        error_found = m.group(0)
                        break

                if error_found:
                    self.log_signal.emit(uid, "Lỗi", f"FB: {error_found}")
                    self.log_signal.emit(uid, "Trạng thái", "❌ Sai mật khẩu cũ")
                else:
                    self.log_signal.emit(uid, "Kết quả",
                        f"Đã gửi — Pass mới: {new_pass}")
                    self.log_signal.emit(uid, "Trạng thái",
                        "Đã gửi (kiểm tra lại)")

            ctx.close()

    def _get_email_code(self, email_addr, email_pass, profile):
        """Search email inbox for Facebook security code.
        Retries 5 times with 5 second intervals."""
        self.log_signal.emit(profile["fb_uid"], "Trạng thái",
            f"Đăng nhập email {email_addr}...")

        for attempt in range(5):
            if not self._running:
                return None

            try:
                # Try reading email with available methods
                code = self._read_fb_code_from_email(
                    email_addr, email_pass, profile
                )
                if code:
                    return code

                self.log_signal.emit(profile["fb_uid"], "Trạng thái",
                    f"Tìm mã email... ({attempt+1}/5)")
                time.sleep(5)

            except Exception as e:
                self.log_signal.emit(profile["fb_uid"], "Trạng thái",
                    f"Lỗi email: {str(e)[:40]} ({attempt+1}/5)")
                time.sleep(5)

        return None

    def _read_fb_code_from_email(self, email_addr, email_pass, profile):
        """Read latest emails and find Facebook security code."""
        import imaplib
        import email as email_lib
        from email.header import decode_header

        # Detect IMAP server
        domain = email_addr.split('@')[-1].lower()
        if 'hotmail' in domain or 'outlook' in domain or 'live' in domain:
            imap_server = "imap-mail.outlook.com"
        elif 'gmail' in domain:
            imap_server = "imap.gmail.com"
        elif 'yahoo' in domain:
            imap_server = "imap.mail.yahoo.com"
        else:
            imap_server = f"imap.{domain}"

        # Try OAuth token first (if available)
        token = profile.get("fb_token_hotmail", "")
        mail = None

        if token and ('hotmail' in domain or 'outlook' in domain or 'live' in domain):
            try:
                from ui.email_reader import exchange_refresh_token, GRAPH_SCOPE
                # Try Graph API
                resp = exchange_refresh_token(token, "", GRAPH_SCOPE)
                access_token = resp.get("access_token", "")
                if access_token:
                    from ui.email_reader import read_inbox_graph
                    messages = read_inbox_graph(access_token, max_messages=5)
                    code = self._extract_fb_code(messages)
                    if code:
                        return code
            except:
                pass

        # Fallback: IMAP password login
        if email_pass:
            try:
                mail = imaplib.IMAP4_SSL(imap_server, 993, timeout=15)
                mail.login(email_addr, email_pass)
                mail.select("INBOX")

                # Search recent emails from Facebook
                _, msg_nums = mail.search(None, '(FROM "security@facebookmail.com")')
                if not msg_nums[0]:
                    _, msg_nums = mail.search(None, '(FROM "facebook")')

                if msg_nums[0]:
                    nums = msg_nums[0].split()[-5:]  # Last 5
                    for num in reversed(nums):
                        _, data = mail.fetch(num, "(RFC822)")
                        msg = email_lib.message_from_bytes(data[0][1])
                        body = self._get_email_body(msg)
                        code = self._extract_code_from_text(body)
                        if code:
                            mail.logout()
                            return code

                mail.logout()
            except:
                if mail:
                    try:
                        mail.logout()
                    except:
                        pass

        return None

    def _get_email_body(self, msg):
        """Extract text body from email message."""
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                ct = part.get_content_type()
                if ct == "text/plain":
                    try:
                        body += part.get_payload(decode=True).decode(errors='ignore')
                    except:
                        pass
                elif ct == "text/html":
                    try:
                        html = part.get_payload(decode=True).decode(errors='ignore')
                        # Simple HTML to text
                        body += re.sub(r'<[^>]+>', ' ', html)
                    except:
                        pass
        else:
            try:
                body = msg.get_payload(decode=True).decode(errors='ignore')
            except:
                pass
        return body

    def _extract_code_from_text(self, text):
        """Extract 6-8 digit code from email text."""
        # Look for patterns like "123456" or "Your code is 12345678"
        patterns = [
            r'(?:code|mã|ma)[\s:]*(\d{6,8})',
            r'(\d{6,8})[\s]*(?:is your|là mã)',
            r'(?:enter|nhập)[\s]*(\d{6,8})',
            r'\b(\d{6})\b',  # generic 6-digit
        ]
        for pat in patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                return m.group(1)
        return None

    def _extract_fb_code(self, messages):
        """Extract FB code from a list of email dicts."""
        for msg in messages:
            sender = msg.get("from", "").lower()
            if "facebook" in sender or "facebookmail" in sender:
                body = msg.get("body", "") + " " + msg.get("snippet", "")
                code = self._extract_code_from_text(body)
                if code:
                    return code
        return None

    def _update_profile_pass(self, uid, new_pass, old_pass):
        """Update profile password in ProfileManager."""
        try:
            from core.profile_manager import ProfileManager
            pm = ProfileManager()
            for p in pm.profiles:
                if str(p.get("fb_uid", "")) == str(uid):
                    p["fb_old_pass"] = old_pass
                    p["fb_pass"] = new_pass
                    pm._save_profiles()
                    break
        except:
            pass
