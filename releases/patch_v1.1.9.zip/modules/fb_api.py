"""
Facebook API Helper — Cookie-based HTTP API for Change Via operations.

Provides fb_dtsg extraction, GraphQL client, and Account Center helpers.
All operations use cookie auth (no browser needed).
"""
import re
import json
import time
import hashlib

try:
    import requests as _requests
except ImportError:
    _requests = None


# ════════════════════════════════════════
#  Cookie Helpers
# ════════════════════════════════════════

def parse_cookie_string(cookie_str):
    """Parse cookie string 'k1=v1;k2=v2' into dict."""
    cookies = {}
    if not cookie_str:
        return cookies
    for part in cookie_str.split(';'):
        part = part.strip()
        if '=' in part:
            k, v = part.split('=', 1)
            cookies[k.strip()] = v.strip()
    return cookies


def cookie_header(cookie_str):
    """Return cookie string suitable for Cookie header."""
    if not cookie_str:
        return ""
    parts = []
    for part in cookie_str.split(';'):
        part = part.strip()
        if '=' in part:
            parts.append(part)
    return "; ".join(parts)


def get_uid_from_cookie(cookie_str):
    """Extract c_user (UID) from cookie string."""
    cookies = parse_cookie_string(cookie_str)
    return cookies.get("c_user", "")


# ════════════════════════════════════════
#  HTTP Request Helper (uses requests lib)
# ════════════════════════════════════════

_session_cache = {}


def _get_session(cookie_str):
    """Get or create a requests.Session for this cookie."""
    key = cookie_str[:60] if cookie_str else ""
    if key in _session_cache:
        return _session_cache[key]

    s = _requests.Session()
    s.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "Accept-Encoding": "gzip, deflate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "navigate",
    })

    # Parse cookies into session
    for part in cookie_str.split(';'):
        part = part.strip()
        if '=' in part:
            k, v = part.split('=', 1)
            s.cookies.set(k.strip(), v.strip(), domain=".facebook.com")

    _session_cache[key] = s
    return s


def _make_request(url, cookie_str, data=None, method="GET",
                  extra_headers=None, timeout=30, user_agent=None):
    """Make HTTP request with cookie auth. Returns (status_code, response_text)."""
    if not _requests:
        return 0, "requests library not installed"

    session = _get_session(cookie_str)

    headers = {}
    if extra_headers:
        headers.update(extra_headers)
    if user_agent:
        headers["User-Agent"] = user_agent

    try:
        if data is not None:
            headers["Content-Type"] = "application/x-www-form-urlencoded"
            headers.setdefault("Origin", "https://www.facebook.com")
            headers.setdefault("Referer", "https://www.facebook.com/")
            resp = session.post(url, data=data, headers=headers,
                                timeout=timeout, allow_redirects=True)
        else:
            resp = session.get(url, headers=headers,
                               timeout=timeout, allow_redirects=True)
        return resp.status_code, resp.text
    except Exception as e:
        return 0, str(e)


# ════════════════════════════════════════
#  fb_dtsg Token Extraction
# ════════════════════════════════════════

def get_fb_dtsg(cookie_str):
    """Extract fb_dtsg CSRF token from Facebook home page.
    Returns (fb_dtsg, jazoest) tuple or ('', '') on failure."""
    status, html = _make_request("https://www.facebook.com/", cookie_str)
    if status != 200:
        # Try mbasic
        status, html = _make_request("https://mbasic.facebook.com/", cookie_str)

    if not html:
        return "", ""

    # Method 1: JSON pattern
    m = re.search(r'"DTSGInitialData".*?"token":"([^"]+)"', html)
    if m:
        dtsg = m.group(1)
    else:
        # Method 2: input hidden
        m = re.search(r'name="fb_dtsg"\s+value="([^"]+)"', html)
        if m:
            dtsg = m.group(1)
        else:
            # Method 3: another JSON pattern
            m = re.search(r'"dtsg":\{"token":"([^"]+)"', html)
            if m:
                dtsg = m.group(1)
            else:
                return "", ""

    # Extract jazoest
    jazoest = ""
    m = re.search(r'name="jazoest"\s+value="(\d+)"', html)
    if m:
        jazoest = m.group(1)
    else:
        m = re.search(r'"jazoest":"(\d+)"', html)
        if m:
            jazoest = m.group(1)
        else:
            # Calculate jazoest from fb_dtsg
            jazoest = str(2 + sum(ord(c) for c in dtsg))

    return dtsg, jazoest


# ════════════════════════════════════════
#  GraphQL API
# ════════════════════════════════════════

def graphql_request(cookie_str, fb_dtsg, doc_id=None, variables=None, 
                    fb_api_caller_class="RelayModern", extra_data=None):
    """Make Facebook GraphQL API request.
    Returns parsed JSON response or None."""
    data = {
        "fb_dtsg": fb_dtsg,
        "fb_api_caller_class": fb_api_caller_class,
        "fb_api_req_friendly_name": "",
        "server_timestamps": "true",
    }
    if doc_id:
        data["doc_id"] = doc_id
    if variables:
        data["variables"] = json.dumps(variables) if isinstance(variables, dict) else variables
    if extra_data:
        data.update(extra_data)

    status, body = _make_request(
        "https://www.facebook.com/api/graphql/",
        cookie_str, data=data
    )

    if status != 200:
        return None

    try:
        # Facebook sometimes returns multiple JSON objects separated by newlines
        # or prefixed with "for (;;);"
        body = body.strip()
        if body.startswith("for (;;);"):
            body = body[len("for (;;);"):]
        return json.loads(body)
    except:
        # Try line-by-line
        for line in body.split('\n'):
            line = line.strip()
            if line.startswith('{'):
                try:
                    return json.loads(line)
                except:
                    continue
    return None


# ════════════════════════════════════════
#  Check Cookie Validity
# ════════════════════════════════════════

def check_cookie(cookie_str):
    """Check if cookie is still valid. Returns (valid: bool, uid: str, name: str)."""
    status, html = _make_request("https://www.facebook.com/me", cookie_str)

    if status != 200:
        return False, "", ""

    # Check if redirected to login
    if "login" in html[:500].lower():
        return False, "", ""

    uid = get_uid_from_cookie(cookie_str)

    # Try to extract name
    name = ""
    m = re.search(r'"USER_ID":"(\d+)"', html)
    if m:
        uid = uid or m.group(1)

    # Extract name from title or meta
    m = re.search(r'<title[^>]*>([^<]+)</title>', html)
    if m:
        title = m.group(1).strip()
        # Title is usually "Name | Facebook" or "Name - Facebook"
        for sep in [' | ', ' - ', ' – ']:
            if sep in title:
                name = title.split(sep)[0].strip()
                break

    return True, uid, name


# ════════════════════════════════════════
#  Language Operations
# ════════════════════════════════════════

def get_language(cookie_str):
    """Get current Facebook language setting.
    Returns locale string like 'vi_VN' or ''."""
    cookies = parse_cookie_string(cookie_str)
    locale = cookies.get("locale", "")
    if locale:
        return locale

    # Fallback: check from settings page
    status, html = _make_request(
        "https://www.facebook.com/settings/language/",
        cookie_str
    )
    if status == 200:
        m = re.search(r'"locale":"([a-z]{2}_[A-Z]{2})"', html)
        if m:
            return m.group(1)
    return ""


def change_language(cookie_str, fb_dtsg, target_locale="vi_VN"):
    """Change Facebook language. Returns (success: bool, msg: str)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "new_language": target_locale,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/language/primary.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )
    if status == 200:
        return True, f"Đổi ngôn ngữ → {target_locale}"
    return False, f"Lỗi đổi ngôn ngữ (HTTP {status})"


# ════════════════════════════════════════
#  Contact Points (Phone/Email)
# ════════════════════════════════════════

def get_contact_points(cookie_str, fb_dtsg):
    """Get phone numbers and emails linked to account.
    Returns dict with 'emails', 'phones' lists."""
    result = {"emails": [], "phones": []}

    # Method 1: mbasic settings (cleaner HTML, better for parsing)
    status, html = _make_request(
        "https://mbasic.facebook.com/settings/contactpoint/",
        cookie_str
    )
    if status == 200 and html:
        # Extract emails from mbasic page
        for m in re.finditer(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', html):
            email = m.group(1)
            if (email not in result["emails"] 
                and "facebook" not in email.lower()
                and "fbcdn" not in email.lower()
                and not email.endswith(".js")
                and not email.endswith(".css")):
                result["emails"].append(email)

        # Extract phones - look for phone patterns in structured content
        # mbasic shows phones like "+84 123456789" or "+1234567890"  
        for m in re.finditer(r'(\+\d{1,3}[\s\-]?\d{6,12})', html):
            phone = m.group(1).strip()
            if phone not in result["phones"]:
                result["phones"].append(phone)

    # Method 2: Account settings primary email
    if not result["emails"]:
        status2, html2 = _make_request(
            "https://mbasic.facebook.com/settings/email/",
            cookie_str
        )
        if status2 == 200 and html2:
            for m in re.finditer(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', html2):
                email = m.group(1)
                if (email not in result["emails"]
                    and "facebook" not in email.lower()
                    and "fbcdn" not in email.lower()):
                    result["emails"].append(email)

    return result


# ════════════════════════════════════════
#  Password Change (API)
# ════════════════════════════════════════

def change_password_api(cookie_str, fb_dtsg, old_pass, new_pass):
    """Change password via Facebook API.
    Returns (success: bool, msg: str)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "password_old": old_pass,
        "password_new": new_pass,
        "password_confirm": new_pass,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/password/password.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )

    if status == 200:
        if "error" in body.lower() or "errorSummary" in body:
            try:
                j = json.loads(body.replace("for (;;);", ""))
                err = j.get("errorSummary", "") or j.get("error", {}).get("message", "")
                return False, f"FB: {err}" if err else "Lỗi không xác định"
            except:
                return False, "Lỗi response"
        return True, f"Đổi pass → {new_pass}"

    if status == 400:
        return False, "Sai mật khẩu cũ"

    return False, f"Lỗi HTTP {status}"


# ════════════════════════════════════════
#  2FA Operations
# ════════════════════════════════════════

def get_2fa_status(cookie_str, fb_dtsg):
    """Check if 2FA is enabled. Returns (enabled: bool, method: str)."""
    status, html = _make_request(
        "https://www.facebook.com/security/2fac/settings/",
        cookie_str
    )
    if status == 200:
        if "totp" in html.lower() or "authenticator" in html.lower():
            if "enabled" in html.lower() or "đã bật" in html.lower() or "active" in html.lower():
                return True, "TOTP"
        return False, ""
    return False, ""


def enable_2fa_totp(cookie_str, fb_dtsg):
    """Enable 2FA TOTP (Authenticator App).
    Returns (success: bool, secret_key: str, msg: str)."""
    # Step 1: Request TOTP setup
    data = {
        "fb_dtsg": fb_dtsg,
    }
    status, body = _make_request(
        "https://www.facebook.com/security/2fac/setup/start/?flow=totp",
        cookie_str
    )

    if status != 200:
        return False, "", f"Lỗi mở trang 2FA (HTTP {status})"

    # Extract TOTP secret from page
    secret = ""
    m = re.search(r'([A-Z2-7]{16,32})', body)
    if m:
        secret = m.group(1)

    if not secret:
        # Try GraphQL approach
        m = re.search(r'"shared_secret":"([^"]+)"', body)
        if m:
            secret = m.group(1)

    if not secret:
        m = re.search(r'"otpauth://totp/[^?]+\?secret=([A-Z2-7]+)', body)
        if m:
            secret = m.group(1)

    if not secret:
        return False, "", "Không tìm thấy TOTP secret key"

    # Step 2: Generate code from secret and confirm
    try:
        code = _generate_totp(secret)
    except:
        return False, secret, f"Secret: {secret} — cần nhập code thủ công"

    # Step 3: Confirm with code
    confirm_data = {
        "fb_dtsg": fb_dtsg,
        "code": code,
    }
    status2, body2 = _make_request(
        "https://www.facebook.com/security/2fac/setup/confirm/",
        cookie_str, data=confirm_data
    )

    if status2 == 200 and "error" not in body2.lower():
        return True, secret, f"2FA bật OK — Secret: {secret}"

    return False, secret, f"Secret: {secret} — confirm failed"


def disable_2fa(cookie_str, fb_dtsg, tfa_code=""):
    """Disable 2FA. Returns (success: bool, msg: str)."""
    data = {
        "fb_dtsg": fb_dtsg,
    }
    if tfa_code:
        data["code"] = tfa_code

    status, body = _make_request(
        "https://www.facebook.com/security/2fac/disable/",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )

    if status == 200:
        return True, "Tắt 2FA OK"
    return False, f"Lỗi tắt 2FA (HTTP {status})"


def _generate_totp(secret, time_step=30):
    """Generate TOTP code from secret (BASE32)."""
    import hmac
    import struct
    import base64

    # Decode base32 secret
    secret_bytes = base64.b32decode(secret.upper() + '=' * (-len(secret) % 8))

    # Get time counter
    counter = int(time.time()) // time_step
    counter_bytes = struct.pack('>Q', counter)

    # HMAC-SHA1
    hmac_hash = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

    # Dynamic truncation
    offset = hmac_hash[-1] & 0x0F
    code = struct.unpack('>I', hmac_hash[offset:offset+4])[0] & 0x7FFFFFFF
    code = code % 1000000

    return str(code).zfill(6)


# ════════════════════════════════════════
#  Email Operations
# ════════════════════════════════════════

def add_email(cookie_str, fb_dtsg, new_email, password):
    """Add email to Facebook account.
    Returns (success: bool, msg: str, needs_verification: bool)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "new_contact_point": new_email,
        "password": password,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/contactpoint/add_contactpoint.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )

    if status == 200:
        if "error" in body.lower():
            try:
                j = json.loads(body.replace("for (;;);", ""))
                err = j.get("errorSummary", "")
                return False, f"FB: {err}", False
            except:
                pass
            return False, "Lỗi add email", False

        if "confirm" in body.lower() or "verify" in body.lower() or "xác minh" in body.lower():
            return True, f"Đã thêm {new_email} — cần xác minh", True
        return True, f"Đã thêm {new_email}", False

    return False, f"Lỗi HTTP {status}", False


def remove_email(cookie_str, fb_dtsg, email_to_remove):
    """Remove email from Facebook account.
    Returns (success: bool, msg: str)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "contact_point": email_to_remove,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/contactpoint/remove_contactpoint.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )
    if status == 200 and "error" not in body.lower():
        return True, f"Đã xóa {email_to_remove}"
    return False, f"Lỗi xóa email (HTTP {status})"


# ════════════════════════════════════════
#  Instagram/Meta Link Operations
# ════════════════════════════════════════

def get_linked_accounts(cookie_str, fb_dtsg):
    """Get linked accounts from Accounts Center.
    Returns list of dict with 'type', 'name', 'id'."""
    accounts = []
    status, html = _make_request(
        "https://accountscenter.facebook.com/accounts",
        cookie_str
    )
    if status == 200:
        # Parse linked accounts from page
        # Look for Instagram references
        if "instagram" in html.lower():
            m = re.search(r'"instagram_user(?:name)?":"([^"]+)"', html)
            ig_name = m.group(1) if m else "unknown"
            accounts.append({"type": "instagram", "name": ig_name})

        # Look for Meta/FB accounts
        for m in re.finditer(r'"name":"([^"]+)".*?"type":"([^"]+)"', html[:5000]):
            accounts.append({"type": m.group(2), "name": m.group(1)})

    return accounts


def remove_instagram_link(cookie_str, fb_dtsg):
    """Remove Instagram link from Accounts Center.
    Returns (success: bool, msg: str)."""
    # This typically requires Account Center's remove endpoint
    data = {
        "fb_dtsg": fb_dtsg,
    }
    status, body = _make_request(
        "https://accountscenter.facebook.com/api/remove_account/",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )
    if status == 200:
        return True, "Đã xóa liên kết Instagram"
    return False, f"Lỗi xóa liên kết IG (HTTP {status})"


# ════════════════════════════════════════
#  Name Change
# ════════════════════════════════════════

def change_name(cookie_str, fb_dtsg, first_name, last_name, password=""):
    """Change Facebook display name.
    Returns (success: bool, msg: str)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "first_name": first_name,
        "last_name": last_name,
        "password": password,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/account/name.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )
    if status == 200 and "error" not in body.lower():
        return True, f"Đổi tên → {first_name} {last_name}"
    return False, f"Lỗi đổi tên (HTTP {status})"
