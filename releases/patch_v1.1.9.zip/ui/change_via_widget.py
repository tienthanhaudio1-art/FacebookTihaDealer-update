"""
Change Via Widget — Professional dark-themed UI for Facebook account operations.
Integrated with ProfileManager for auto-fill cookie/token/pass/email by UID.
"""
import os
from ui.copyable_table import CopyableTable
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget, QTableWidgetItem,
    QHeaderView, QLabel, QComboBox, QSpinBox, QCheckBox, QTextEdit, QTabWidget,
    QFrame, QGridLayout, QLineEdit, QSplitter
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QColor, QFont


class ChangeViaWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.workers = []
        self.profile_manager = None
        self._init_ui()

    def set_profile_manager(self, pm):
        """Set ProfileManager reference for UID lookup."""
        self.profile_manager = pm

    def _init_ui(self):
        self.setObjectName("ChangeViaMain")
        self.setStyleSheet(self._build_stylesheet())

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # ═══════════════════════════════════════════
        #  1. ACTION BUTTONS ROW
        # ═══════════════════════════════════════════
        btn_row = QHBoxLayout()
        btn_row.setSpacing(6)

        actions = [
            ("Change Password", "change_pass", "#3b82f6", "#2563eb"),
            ("Bật 2FA",         "enable_2fa",  "#6366f1", "#4f46e5"),
            ("Check Ngôn Ngữ",  "check_lang",  "#0ea5e9", "#0284c7"),
            ("Check Phone/Email","check_contact","#06b6d4","#0891b2"),
            ("Add Email",       "add_email",   "#8b5cf6", "#7c3aed"),
            ("Xác thực Email",  "verify_email","#10b981", "#059669"),
            ("Xóa LK Insta/Meta","remove_ig", "#f59e0b", "#d97706"),
            ("Add Insta",       "add_ig",      "#ec4899", "#db2777"),
            ("Change All",      "change_all",  "#14b8a6", "#0d9488"),
            ("Reg Meta",        "reg_meta",    "#a855f7", "#9333ea"),
        ]

        self.buttons = {}
        for label, key, c1, c2 in actions:
            btn = QPushButton(label)
            btn.setFixedHeight(34)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                        stop:0 {c1}, stop:1 {c2});
                    color: white; font-weight: 600; border-radius: 6px;
                    padding: 0 14px; border: none; font-size: 12px;
                    letter-spacing: 0.3px;
                }}
                QPushButton:hover {{
                    background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                        stop:0 {c1}dd, stop:1 {c1});
                    border: 1px solid rgba(255,255,255,0.2);
                }}
                QPushButton:pressed {{ background: {c2}; }}
            """)
            btn.clicked.connect(
                lambda checked, k=key, l=label: self.start_action(k, l)
            )
            btn_row.addWidget(btn)
            self.buttons[key] = btn

        # Stop button
        self.btn_stop = QPushButton("⏹ Stop")
        self.btn_stop.setFixedHeight(34)
        self.btn_stop.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_stop.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #ef4444, stop:1 #dc2626);
                color: white; font-weight: 700; border-radius: 6px;
                padding: 0 16px; border: none; font-size: 12px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #f87171, stop:1 #ef4444);
            }
            QPushButton:pressed { background: #b91c1c; }
        """)
        self.btn_stop.clicked.connect(self.stop_all)
        btn_row.addWidget(self.btn_stop)
        btn_row.addStretch()

        main_layout.addLayout(btn_row)

        # ═══════════════════════════════════════════
        #  2. SETTINGS CARD
        # ═══════════════════════════════════════════
        settings_card = QFrame()
        settings_card.setObjectName("SettingsCard")
        sc_layout = QVBoxLayout(settings_card)
        sc_layout.setContentsMargins(16, 12, 16, 12)
        sc_layout.setSpacing(10)

        # Row 1: Delay, Threads, Mode, Language
        row1 = QHBoxLayout()
        row1.setSpacing(16)

        # Delay
        row1.addWidget(self._make_label("⏱ Delay"))
        self.spin_delay = QSpinBox()
        self.spin_delay.setFixedWidth(55)
        self.spin_delay.setValue(0)
        self.spin_delay.setSuffix("s")
        row1.addWidget(self.spin_delay)

        self._add_divider(row1)

        # Threads
        row1.addWidget(self._make_label("🔀 Số luồng"))
        self.spin_threads = QSpinBox()
        self.spin_threads.setFixedWidth(55)
        self.spin_threads.setValue(8)
        self.spin_threads.setMinimum(1)
        self.spin_threads.setMaximum(50)
        row1.addWidget(self.spin_threads)

        self._add_divider(row1)

        # Mode checkboxes
        self.chk_api_android = QCheckBox("API Android")
        self.chk_run_cookie = QCheckBox("Cookie")
        self.chk_run_cookie.setChecked(True)

        # Mutual exclusive
        self.chk_api_android.toggled.connect(
            lambda c: self.chk_run_cookie.setChecked(not c) if c else None
        )
        self.chk_run_cookie.toggled.connect(
            lambda c: self.chk_api_android.setChecked(not c) if c else None
        )

        row1.addWidget(self.chk_api_android)
        row1.addWidget(self.chk_run_cookie)

        self._add_divider(row1)

        # Language
        self.chk_change_lang = QCheckBox("Đổi Ngôn Ngữ")
        self.combo_lang = QComboBox()
        self.combo_lang.addItems(["vi_VN", "en_US", "ja_JP", "ko_KR", "zh_CN"])
        self.combo_lang.setFixedWidth(80)
        row1.addWidget(self.chk_change_lang)
        row1.addWidget(self.combo_lang)

        self._add_divider(row1)

        # Use accountscenter
        self.chk_use_accountscenter = QCheckBox("Accountscenter")
        self.chk_use_accountscenter.setChecked(True)
        row1.addWidget(self.chk_use_accountscenter)

        row1.addStretch()
        sc_layout.addLayout(row1)

        # Row 2: Password, options
        row2 = QHBoxLayout()
        row2.setSpacing(16)

        row2.addWidget(self._make_label("🔑 Pass mới"))
        self.txt_new_pass = QLineEdit("2026Key1@#@#")
        self.txt_new_pass.setPlaceholderText("Cấu trúc Mậtkhẩu***")
        self.txt_new_pass.setMinimumWidth(180)
        row2.addWidget(self.txt_new_pass)

        self._add_divider(row2)

        self.chk_use_tempmail = QCheckBox("Temp Mail")
        self.combo_tempmail = QComboBox()
        self.combo_tempmail.addItems(["dongnai.com", "smvmail.com"])
        self.combo_tempmail.setFixedWidth(110)
        row2.addWidget(self.chk_use_tempmail)
        row2.addWidget(self.combo_tempmail)

        self._add_divider(row2)

        self.chk_no_remove_oldmail = QCheckBox("Giữ mail cũ")
        self.chk_no_remove_oldmail.setChecked(True)
        row2.addWidget(self.chk_no_remove_oldmail)

        self._add_divider(row2)

        self.chk_login_new = QCheckBox("Login New trước")
        row2.addWidget(self.chk_login_new)

        row2.addStretch()
        sc_layout.addLayout(row2)

        main_layout.addWidget(settings_card)

        # ═══════════════════════════════════════════
        #  3. DATA INPUT — Profile list + Password + Email + Names
        # ═══════════════════════════════════════════
        self.tabs = QTabWidget()
        self.tabs.setObjectName("DataTabs")

        # Tab: Account Info
        tab_info = QWidget()
        tab_info.setObjectName("TabContent")
        tl = QHBoxLayout(tab_info)
        tl.setContentsMargins(8, 8, 8, 8)
        tl.setSpacing(8)

        self.txt_profiles = self._make_textarea("Danh sách UID", "0", True)
        self.txt_passwords = self._make_textarea(
            "Mật khẩu mới (Cấu trúc Pass***)", "2026Key1@#@#", False
        )
        self.txt_emails = self._make_textarea("List Add Email", "0", True)
        self.txt_names = self._make_textarea("Danh sách Tên", "0", True)

        tl.addWidget(self.txt_profiles, stretch=3)
        tl.addWidget(self.txt_passwords, stretch=3)
        tl.addWidget(self.txt_emails, stretch=3)
        tl.addWidget(self.txt_names, stretch=2)

        # Tab: Change All Settings
        self._init_tab_change_all()

        self.tabs.addTab(tab_info, "📋 Thông tin tài khoản")
        self.tabs.addTab(self.tab_change_all, "⚙️ Setting Change All")

        # Tab 3: Phone Settings (shared module)
        from ui.phone_settings_widget import PhoneSettingsWidget
        self.phone_settings_tab = PhoneSettingsWidget(self)
        self.tabs.addTab(self.phone_settings_tab, "📱 Setting Phone")

        main_layout.addWidget(self.tabs)

        # ═══════════════════════════════════════════
        #  4. RESULTS TABLE
        # ═══════════════════════════════════════════
        self.table = CopyableTable()
        self.table.setObjectName("ResultsTable")
        self.cols = [
            ("stt", "STT"),
            ("uid", "UID"),
            ("info", "Info"),
            ("err", "Lỗi"),
            ("result", "Kết quả"),
            ("info_2fa", "2FA"),
            ("status", "Trạng thái"),
            ("change_all", "Change All"),
            ("verify", "Xác minh Email"),
        ]
        self.table.setColumnCount(len(self.cols))
        self.table.setHorizontalHeaderLabels([c[1] for c in self.cols])
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(False)

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        widths = [40, 140, 100, 120, 180, 80, 160, 140]
        for i, w in enumerate(widths):
            self.table.setColumnWidth(i, w)

        main_layout.addWidget(self.table)

        self.profiles_data = []

    # ─── Helper Methods ───────────────────────
    def _build_stylesheet(self):
        return """
            #ChangeViaMain {
                background: #0f1219;
            }

            #SettingsCard {
                background: #1a1f2e;
                border: 1px solid #2a3348;
                border-radius: 8px;
                padding: 4px;
            }
            #SettingsCard QLabel {
                color: #f1f5f9; font-weight: 700; font-size: 12px;
                background: transparent;
            }
            #SettingsCard QCheckBox {
                color: #f1f5f9; font-weight: 600; font-size: 12px;
            }
            #SettingsCard QCheckBox::indicator {
                width: 16px; height: 16px;
                border: 2px solid #64748b; border-radius: 3px;
                background: #0f172a;
            }
            #SettingsCard QCheckBox::indicator:checked {
                background: #3b82f6; border-color: #a78bfa;
            }
            #SettingsCard QComboBox, #SettingsCard QSpinBox, #SettingsCard QLineEdit {
                background: #0f172a; border: 1px solid #475569;
                border-radius: 5px; padding: 5px 10px;
                color: #f8fafc; min-height: 24px; font-weight: 500;
            }

            #DataTabs::pane {
                background: #131824; border: 1px solid #2a3348;
                border-radius: 8px; border-top-left-radius: 0;
            }
            #DataTabs > QTabBar::tab {
                background: #151a27; border: 1px solid #2a3348;
                border-bottom: none; padding: 8px 16px;
                margin-right: 2px; font-weight: 600;
                color: #94a3b8; border-top-left-radius: 6px;
                border-top-right-radius: 6px;
            }
            #DataTabs > QTabBar::tab:selected {
                background: #131824; color: #93c5fd;
                border-top: 2px solid #3b82f6;
            }
            #DataTabs > QTabBar::tab:hover:!selected {
                background: #1a2035; color: #e2e8f0;
            }

            #ResultsTable {
                background: #0f1219; gridline-color: #1e293b;
                border: 1px solid #2a3348; border-radius: 6px;
                font-size: 12px; color: #f1f5f9;
            }
            #ResultsTable QHeaderView::section {
                background: #1a1f2e; padding: 7px 4px;
                border: none; border-bottom: 2px solid #2a3348;
                border-right: 1px solid #1e293b;
                font-weight: 700; color: #cbd5e1;
                font-size: 11px; text-transform: uppercase;
            }
            #ResultsTable::item { padding: 4px; }
            #ResultsTable::item:selected {
                background: #1e3a5f; color: #93c5fd;
            }
        """

    def _make_label(self, text):
        lbl = QLabel(text)
        # No inline color — let #SettingsCard QLabel rule apply (#ffffff)
        return lbl

    def _add_divider(self, layout):
        div = QFrame()
        div.setFixedWidth(1)
        div.setFixedHeight(20)
        div.setStyleSheet("background: #334155;")
        layout.addWidget(div)

    def _make_textarea(self, title, initial="", show_count=True):
        w = QWidget()
        w.setStyleSheet("background: transparent;")
        l = QVBoxLayout(w)
        l.setContentsMargins(0, 0, 0, 0)
        l.setSpacing(0)

        # Header
        hdr = QWidget()
        hdr.setFixedHeight(28)
        hdr.setStyleSheet("""
            background: #1a2035;
            border: 1px solid #2a3348;
            border-bottom: none;
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
        """)
        hl = QHBoxLayout(hdr)
        hl.setContentsMargins(10, 0, 10, 0)

        lbl = QLabel(title)
        lbl.setStyleSheet(
            "color: #cbd5e1; font-size: 11px; font-weight: 700; "
            "border: none; background: transparent;"
        )
        hl.addWidget(lbl)
        hl.addStretch()

        count_lbl = QLabel("0")
        count_lbl.setStyleSheet(
            "color: #f87171; font-size: 11px; font-weight: 700; "
            "border: none; background: transparent;"
        )
        if show_count:
            hl.addWidget(count_lbl)

        l.addWidget(hdr)

        txt = QTextEdit()
        txt.setStyleSheet("""
            QTextEdit {
                background: #0f1219; border: 1px solid #2a3348;
                border-top: 1px solid #1e2538;
                font-family: 'Cascadia Code', Consolas, monospace;
                font-size: 12px; color: #e2e8f0;
                border-bottom-left-radius: 6px;
                border-bottom-right-radius: 6px;
            }
            QTextEdit:focus { border: 1px solid #3b82f6; }
        """)
        if initial and initial != "0":
            txt.setPlainText(initial)

        if show_count:
            def update_count():
                cnt = len([x for x in txt.toPlainText().split('\n') if x.strip()])
                count_lbl.setText(str(cnt))
            txt.textChanged.connect(update_count)
            update_count()

        l.addWidget(txt)
        w.text_edit = txt
        return w

    def _init_tab_change_all(self):
        self.tab_change_all = QWidget()
        self.tab_change_all.setObjectName("TabContent")
        layout = QVBoxLayout(self.tab_change_all)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)

        lbl = QLabel("Các bước chạy Change All")
        lbl.setStyleSheet("font-weight: 700; color: #a78bfa; font-size: 13px;")
        layout.addWidget(lbl)

        step_options = [
            "", "Add Email", "Tắt 2FA", "Bật 2FA", "Change Name",
            "Change Password", "Xóa thiết bị", "Check Phone/Email",
            "Change Ngôn ngữ", "Add Phone"
        ]
        row = QHBoxLayout()
        row.setSpacing(6)
        self.combo_steps = []
        for i in range(7):
            cb = QComboBox()
            cb.addItems(step_options)
            cb.setMinimumWidth(100)
            self.combo_steps.append(cb)
            row.addWidget(cb)
        self.combo_steps[0].setCurrentText("Tắt 2FA")
        self.combo_steps[1].setCurrentText("Bật 2FA")
        self.combo_steps[2].setCurrentText("Xóa thiết bị")
        row.addStretch()
        layout.addLayout(row)

        # Options row
        row2 = QHBoxLayout()
        row2.setSpacing(12)
        self.chk_relogin_all = QCheckBox("Relogin FB trước khi chạy")
        self.chk_log_out = QCheckBox("Log out tất cả thiết bị")
        self.chk_log_out.setChecked(True)
        self.chk_retry_api = QCheckBox("Retry lỗi API")
        self.chk_retry_api.setChecked(True)
        self.spin_retry = QSpinBox()
        self.spin_retry.setValue(5)
        self.spin_retry.setFixedWidth(45)
        row2.addWidget(self.chk_relogin_all)
        row2.addWidget(self.chk_log_out)
        row2.addWidget(self.chk_retry_api)
        row2.addWidget(self.spin_retry)
        row2.addWidget(QLabel("lần"))
        row2.addStretch()
        layout.addLayout(row2)

        # SIM config
        lbl2 = QLabel("Cấu hình SIM Add Phone")
        lbl2.setStyleSheet("font-weight: 700; color: #a78bfa; font-size: 13px;")
        layout.addWidget(lbl2)

        row3 = QHBoxLayout()
        row3.setSpacing(10)
        self.combo_sim_site = QComboBox()
        self.combo_sim_site.addItems(["thuesim.app", "chothuesimcode.com", "viotp.com"])
        row3.addWidget(self.combo_sim_site)
        row3.addWidget(QLabel("Mã QG"))
        self.txt_country_code = QLineEdit("+1")
        self.txt_country_code.setFixedWidth(50)
        row3.addWidget(self.txt_country_code)
        row3.addWidget(QLabel("API Key"))
        self.txt_sim_api_key = QLineEdit()
        self.txt_sim_api_key.setMinimumWidth(300)
        row3.addWidget(self.txt_sim_api_key)
        row3.addStretch()
        layout.addLayout(row3)
        layout.addStretch()

    # ─── Profile Parsing ──────────────────────
    def _parse_profiles_input(self):
        """Parse UID list and lookup full profile data from ProfileManager."""
        text = self.txt_profiles.text_edit.toPlainText().strip()
        lines = [x.strip() for x in text.split('\n') if x.strip()]
        self.profiles_data = []

        # Build UID lookup from ProfileManager
        pm_lookup = {}
        if self.profile_manager:
            for p in self.profile_manager.get_all_profiles():
                uid = str(p.get("fb_uid", ""))
                if uid:
                    pm_lookup[uid] = p

        for line in lines:
            parts = line.split('|')
            uid = parts[0].strip()
            if not uid:
                continue

            # Lookup from Profile Manager
            pm_profile = pm_lookup.get(uid, {})

            profile = {
                "fb_uid": uid,
                "fb_pass": pm_profile.get("fb_pass", parts[1].strip() if len(parts) > 1 else ""),
                "fb_2fa": pm_profile.get("fb_2fa", parts[2].strip() if len(parts) > 2 else ""),
                "fb_cookie": pm_profile.get("fb_cookie", parts[3].strip() if len(parts) > 3 else ""),
                "fb_token": pm_profile.get("fb_token", parts[4].strip() if len(parts) > 4 else ""),
                "fb_email": pm_profile.get("fb_email", ""),
                "fb_pass_email": pm_profile.get("fb_pass_email", ""),
                "fb_token_hotmail": pm_profile.get("fb_token_hotmail", ""),
                "fb_name": pm_profile.get("fb_name", ""),
                "raw": line,
            }
            self.profiles_data.append(profile)

        # Populate table
        self.table.setRowCount(0)
        for i, p in enumerate(self.profiles_data):
            self.table.insertRow(i)
            stt = QTableWidgetItem(str(i + 1))
            stt.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(i, 0, stt)

            uid_item = QTableWidgetItem(p["fb_uid"])
            uid_item.setForeground(QColor("#a78bfa"))
            self.table.setItem(i, 1, uid_item)

            # Show name if available
            if p["fb_name"]:
                info = QTableWidgetItem(p["fb_name"])
                info.setForeground(QColor("#94a3b8"))
                self.table.setItem(i, 2, info)

            # Show auth status
            auth = "🔒" if p["fb_cookie"] else "❌"
            if p["fb_token"]:
                auth += " 🔑"
            status = QTableWidgetItem(f"{auth} Sẵn sàng")
            status.setForeground(QColor("#4ade80") if p["fb_cookie"] else QColor("#f87171"))
            self.table.setItem(i, 6, status)

    def load_profiles(self, profiles_list: list):
        """Called from main window to populate tab with UIDs."""
        lines = []
        for p in profiles_list:
            uid = p.get("fb_uid", "")
            if uid:
                lines.append(uid)

        current = self.txt_profiles.text_edit.toPlainText()
        if current.strip():
            self.txt_profiles.text_edit.setPlainText(
                current + "\n" + "\n".join(lines)
            )
        else:
            self.txt_profiles.text_edit.setPlainText("\n".join(lines))
        self._parse_profiles_input()

    def start_action(self, action_key, action_label):
        """Start a Change Via action on all parsed profiles."""
        self._parse_profiles_input()
        if not self.profiles_data:
            return

        settings = {
            "delay": self.spin_delay.value(),
            "threads": self.spin_threads.value(),
            "new_pass": self.txt_new_pass.text().strip() or "2026Key1@#@#",
            "cookie_mode": self.chk_run_cookie.isChecked(),
            "api_android_mode": self.chk_api_android.isChecked(),
            "target_lang": (
                self.combo_lang.currentText()
                if self.chk_change_lang.isChecked() else ""
            ),
            # Extra settings for new actions
            "emails_list": [
                x.strip() for x in
                self.txt_emails.text_edit.toPlainText().split('\n')
                if x.strip()
            ],
            "names_list": [
                x.strip() for x in
                self.txt_names.text_edit.toPlainText().split('\n')
                if x.strip()
            ],
            "change_all_steps": [
                cb.currentText() for cb in self.combo_steps
                if cb.currentText()
            ],
        }

        from modules.change_via_worker import ChangeViaWorker
        worker = ChangeViaWorker(self.profiles_data, action_label, settings)
        worker.log_signal.connect(self.update_log)
        worker.finished_all.connect(lambda: self._on_finished(worker))
        worker.start()
        self.workers.append(worker)

    def update_log(self, uid, col_name, msg):
        """Update a cell in the results table."""
        col_idx = -1
        for i, (k, l) in enumerate(self.cols):
            if l == col_name:
                col_idx = i
                break
        if col_idx == -1:
            return

        for r in range(self.table.rowCount()):
            item = self.table.item(r, 1)
            if item and item.text() == uid:
                target = self.table.item(r, col_idx)
                if not target:
                    target = QTableWidgetItem()
                    target.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    self.table.setItem(r, col_idx, target)
                target.setText(msg)

                # Colorize
                if "Thành công" in msg or "✅" in msg:
                    target.setForeground(QColor("#4ade80"))
                elif "Thất bại" in msg or "❌" in msg or "Lỗi" in msg:
                    target.setForeground(QColor("#f87171"))
                elif "Dừng" in msg or "Out" in msg:
                    target.setForeground(QColor("#fbbf24"))
                elif "Đang" in msg:
                    target.setForeground(QColor("#a78bfa"))
                break

    def _on_finished(self, worker):
        if worker in self.workers:
            self.workers.remove(worker)

    def stop_all(self):
        for w in self.workers:
            w.stop()
        self.workers.clear()
