"""
Phone Service Module — Global phone rental/OTP service for the entire tool.

This module provides a unified API for renting phone numbers and receiving OTP codes
from various SMS rental services. Any tab (Gmail, Change Via, etc.) can use this module.

Supported flow:
1. rent_number(service, country) → phone_number, order_id
2. get_sms(order_id) → OTP code or None  (poll until code arrives)
3. cancel_order(order_id) → bool
4. check_balance() → float
5. is_available() → bool  (check if site API is reachable)
"""

import re
import time
import requests
from abc import ABC, abstractmethod
from typing import Optional, Tuple, Dict


class PhoneService(ABC):
    """Abstract base class for phone rental services."""

    name: str = "Unknown"
    base_url: str = ""
    requires_api_key: bool = True

    def __init__(self, api_key: str = ""):
        self.api_key = api_key
        self.timeout = 20  # HTTP request timeout

    @abstractmethod
    def check_balance(self) -> float:
        """Get account balance. Returns -1 on error."""
        pass

    @abstractmethod
    def rent_number(self, service: str = "google", country: str = "vn") -> Tuple[Optional[str], Optional[str]]:
        """
        Rent a phone number for the given service/country.
        Returns (phone_number, order_id) or (None, None) on failure.
        """
        pass

    @abstractmethod
    def get_sms(self, order_id: str) -> Optional[str]:
        """
        Poll for SMS/OTP code for the given order.
        Returns the OTP code string, or None if not yet received.
        """
        pass

    @abstractmethod
    def cancel_order(self, order_id: str) -> bool:
        """Cancel/refund an active order."""
        pass

    def is_available(self) -> bool:
        """Check if the service API is reachable and the API key is valid."""
        try:
            balance = self.check_balance()
            return balance >= 0
        except Exception:
            return False

    def wait_for_sms(self, order_id: str, timeout_seconds: int = 120, poll_interval: int = 5) -> Optional[str]:
        """
        Wait for SMS code with polling.
        Returns OTP code or None if timeout.
        """
        start = time.time()
        while time.time() - start < timeout_seconds:
            code = self.get_sms(order_id)
            if code:
                return code
            time.sleep(poll_interval)
        return None

    @staticmethod
    def _extract_code(text: str) -> str:
        """Extract numeric OTP code (4-8 digits) from SMS text."""
        if not text:
            return ""
        match = re.search(r'\b(\d{4,8})\b', str(text))
        return match.group(1) if match else str(text).strip()

    def _get(self, url: str, params: dict = None, headers: dict = None) -> dict:
        """Helper: GET request returning JSON."""
        try:
            resp = requests.get(url, params=params, headers=headers, timeout=self.timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.JSONDecodeError:
            return {"error": f"Invalid JSON response", "raw": resp.text[:200]}
        except requests.exceptions.HTTPError as e:
            return {"error": f"HTTP {resp.status_code}: {resp.text[:100]}"}
        except Exception as e:
            return {"error": str(e)}

    def _post(self, url: str, data: dict = None, headers: dict = None, json_body: dict = None) -> dict:
        """Helper: POST request returning JSON."""
        try:
            if json_body:
                resp = requests.post(url, json=json_body, headers=headers, timeout=self.timeout)
            else:
                resp = requests.post(url, data=data, headers=headers, timeout=self.timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.JSONDecodeError:
            return {"error": f"Invalid JSON response", "raw": resp.text[:200]}
        except requests.exceptions.HTTPError as e:
            return {"error": f"HTTP {resp.status_code}: {resp.text[:100]}"}
        except Exception as e:
            return {"error": str(e)}


# ═══════════════════════════════════════════════════════
# SMSPool.net — Well-documented REST API
# Docs: https://www.smspool.net/article/how-to-use-the-smspool-api
# Auth: API key passed as POST/GET parameter "key"
# ═══════════════════════════════════════════════════════

class SMSPoolService(PhoneService):
    name = "smspool.net"
    base_url = "https://api.smspool.net"

    # Country ID mapping — from SMSPool docs
    COUNTRY_MAP = {
        "vn": "1",    # Vietnam
        "us": "2",    # United States
        "uk": "10",   # United Kingdom
        "ru": "3",    # Russia
        "in": "22",   # India
        "id": "6",    # Indonesia
        "ph": "15",   # Philippines
    }

    def check_balance(self) -> float:
        """POST /request/balance with key parameter."""
        data = self._post(f"{self.base_url}/request/balance", data={"key": self.api_key})
        if "error" in data:
            return -1
        if "balance" in data:
            try:
                return float(data["balance"])
            except (ValueError, TypeError):
                pass
        return -1

    def rent_number(self, service: str = "google", country: str = "vn") -> Tuple[Optional[str], Optional[str]]:
        """POST /purchase/sms — service 395 = Google/Gmail."""
        country_id = self.COUNTRY_MAP.get(country, "1")
        data = self._post(f"{self.base_url}/purchase/sms", data={
            "key": self.api_key,
            "country": country_id,
            "service": "395",  # Google/Gmail service ID
        })
        if "error" in data and "number" not in data:
            return None, None
        if data.get("number") and data.get("order_id"):
            return str(data["number"]), str(data["order_id"])
        return None, None

    def get_sms(self, order_id: str) -> Optional[str]:
        """POST /sms/check — returns sms field when code arrives."""
        data = self._post(f"{self.base_url}/sms/check", data={
            "key": self.api_key,
            "orderid": order_id,
        })
        sms = data.get("sms")
        if sms:
            return self._extract_code(str(sms))
        return None

    def cancel_order(self, order_id: str) -> bool:
        """POST /sms/cancel — cancel an active order."""
        data = self._post(f"{self.base_url}/sms/cancel", data={
            "key": self.api_key,
            "orderid": order_id,
        })
        return data.get("success", 0) == 1


# ═══════════════════════════════════════════════════════
# 5sim.net — JWT Bearer token API
# Docs: https://5sim.net/docs
# Auth: Authorization: Bearer <api_key> in request headers
# ═══════════════════════════════════════════════════════

class FiveSimService(PhoneService):
    name = "5sim.net"
    base_url = "https://5sim.net/v1"

    # Country name mapping — 5sim uses full lowercase names
    COUNTRY_MAP = {
        "vn": "vietnam",
        "us": "usa",
        "uk": "england",
        "ru": "russia",
        "in": "india",
        "id": "indonesia",
        "ph": "philippines",
    }

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
        }

    def check_balance(self) -> float:
        """GET /v1/user/profile — returns balance field."""
        data = self._get(f"{self.base_url}/user/profile", headers=self._headers())
        if "error" in data:
            return -1
        balance = data.get("balance")
        if balance is not None:
            try:
                return float(balance)
            except (ValueError, TypeError):
                pass
        return -1

    def rent_number(self, service: str = "google", country: str = "vn") -> Tuple[Optional[str], Optional[str]]:
        """GET /v1/user/buy/activation/{country}/{operator}/{product}"""
        country_name = self.COUNTRY_MAP.get(country, "vietnam")
        data = self._get(
            f"{self.base_url}/user/buy/activation/{country_name}/any/google",
            headers=self._headers()
        )
        if "error" in data and "phone" not in data:
            return None, None
        phone = data.get("phone")
        order_id = data.get("id")
        if phone and order_id:
            return str(phone), str(order_id)
        return None, None

    def get_sms(self, order_id: str) -> Optional[str]:
        """GET /v1/user/check/{order_id} — returns sms array."""
        data = self._get(
            f"{self.base_url}/user/check/{order_id}",
            headers=self._headers()
        )
        sms_list = data.get("sms")
        if sms_list and isinstance(sms_list, list) and len(sms_list) > 0:
            sms_text = sms_list[0].get("text", "") if isinstance(sms_list[0], dict) else str(sms_list[0])
            return self._extract_code(sms_text) if sms_text else None
        return None

    def cancel_order(self, order_id: str) -> bool:
        """GET /v1/user/cancel/{order_id}"""
        data = self._get(
            f"{self.base_url}/user/cancel/{order_id}",
            headers=self._headers()
        )
        # 5sim returns the order object with status "CANCELED" on success
        return data.get("status") == "CANCELED" or "error" not in data


# ═══════════════════════════════════════════════════════
# ThueSimApp / ChoThueSimCode (chothuesim.org)
# Docs: https://openapi.chothuesim.org (Redocly, behind login)
# Auth: Authorization: Bearer <api_key> (JWT token in header)
# ═══════════════════════════════════════════════════════

class ThueSimAppService(PhoneService):
    name = "thuesim.app"
    base_url = "https://openapi.chothuesim.org"

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def check_balance(self) -> float:
        """GET balance endpoint with Bearer token."""
        # Try multiple known endpoint patterns
        for path in ["/api/Balance/GetBalance", "/api/wallet/balance", "/api/balance"]:
            data = self._get(f"{self.base_url}{path}", headers=self._headers())
            if "error" not in data:
                # Parse balance from various response formats
                balance = (
                    data.get("balance") or
                    data.get("Balance") or
                    data.get("data", {}).get("balance") if isinstance(data.get("data"), dict) else
                    data.get("data")
                )
                if balance is not None:
                    try:
                        return float(balance)
                    except (ValueError, TypeError):
                        pass
        return -1

    def rent_number(self, service: str = "google", country: str = "vn") -> Tuple[Optional[str], Optional[str]]:
        """Buy activation number for Google."""
        # Try known endpoint patterns for buying numbers
        for path in [
            "/api/Order/CreateOrder",
            "/api/order/buy",
            "/api/number/get",
        ]:
            data = self._post(
                f"{self.base_url}{path}",
                json_body={"service": "google", "serviceId": 1},
                headers=self._headers()
            )
            if "error" not in data:
                phone = (
                    data.get("phone") or data.get("Phone") or
                    data.get("number") or data.get("Number") or
                    data.get("data", {}).get("phone") if isinstance(data.get("data"), dict) else None
                )
                order_id = (
                    data.get("order_id") or data.get("orderId") or
                    data.get("id") or data.get("Id") or
                    data.get("data", {}).get("id") if isinstance(data.get("data"), dict) else None
                )
                if phone and order_id:
                    return str(phone), str(order_id)
        return None, None

    def get_sms(self, order_id: str) -> Optional[str]:
        """Check order for SMS code."""
        for path in [
            f"/api/Order/GetSms?orderId={order_id}",
            f"/api/order/check?id={order_id}",
            f"/api/sms/get?orderId={order_id}",
        ]:
            data = self._get(f"{self.base_url}{path}", headers=self._headers())
            if "error" not in data:
                sms = (
                    data.get("sms") or data.get("Sms") or data.get("code") or
                    data.get("Code") or data.get("message") or
                    data.get("data", {}).get("sms") if isinstance(data.get("data"), dict) else None
                )
                if sms:
                    return self._extract_code(str(sms))
        return None

    def cancel_order(self, order_id: str) -> bool:
        """Cancel active order."""
        for path in [
            f"/api/Order/CancelOrder?orderId={order_id}",
            f"/api/order/cancel?id={order_id}",
        ]:
            data = self._get(f"{self.base_url}{path}", headers=self._headers())
            if "error" not in data:
                return True
        return False


# ═══════════════════════════════════════════════════════
# VioTP.com — Vietnamese phone rental
# Docs: https://viotp.com/Account/ApiDocument
# Auth: token passed as GET query parameter "token"
# Base URL: https://api.viotp.com
# Response format: {"status_code": 200, "success": true, "data": {...}}
# ═══════════════════════════════════════════════════════

class VioTPService(PhoneService):
    name = "viotp.com"
    base_url = "https://api.viotp.com"

    # Service ID mapping — from /service/getv2 response
    # Google/Gmail = 3 (price ~1600đ)
    SERVICE_MAP = {
        "google": 3,
        "gmail": 3,
        "facebook": 7,
        "momo": 1,
        "shopee": 2,
    }

    def _params(self, **extra) -> dict:
        """Build params dict with token."""
        p = {"token": self.api_key}
        p.update(extra)
        return p

    def check_balance(self) -> float:
        """
        VioTP has no explicit balance endpoint.
        Use /networks/get to verify token validity.
        Balance is returned when renting a number (data.balance).
        Returns 0 if token valid (auth OK), -1 if invalid.
        """
        data = self._get(f"{self.base_url}/networks/get", params=self._params())
        if data.get("status_code") == 200 and data.get("success"):
            # Token is valid, but we don't know exact balance
            # Return 0 to indicate "available" (balance unknown until rent)
            return 0.0
        return -1

    def get_services(self, country: str = "vn") -> list:
        """GET /service/getv2 — list available services."""
        data = self._get(
            f"{self.base_url}/service/getv2",
            params=self._params(country=country)
        )
        if data.get("status_code") == 200:
            return data.get("data", [])
        return []

    def rent_number(self, service: str = "google", country: str = "vn") -> Tuple[Optional[str], Optional[str]]:
        """
        GET /request/getv2?token=TOKEN&serviceId=ID
        Google/Gmail serviceId = 3
        Returns (phone_number, request_id) from response data.
        """
        service_id = self.SERVICE_MAP.get(service.lower(), 3)  # Default to Google

        params = self._params(serviceId=service_id)
        if country and country != "vn":
            params["country"] = country

        data = self._get(f"{self.base_url}/request/getv2", params=params)

        if data.get("status_code") == 200 and data.get("success"):
            info = data.get("data", {})
            phone = info.get("phone_number")
            request_id = info.get("request_id")
            if phone and request_id:
                return str(phone), str(request_id)
        return None, None

    def get_sms(self, order_id: str) -> Optional[str]:
        """
        GET /session/getv2?requestId=ID&token=TOKEN
        Returns Code field from data when Status=1 (completed).
        Status: 0=waiting, 1=completed, 2=expired.
        """
        data = self._get(
            f"{self.base_url}/session/getv2",
            params=self._params(requestId=order_id)
        )
        if data.get("status_code") == 200 and data.get("success"):
            info = data.get("data", {})
            status = info.get("Status")
            if status == 1:  # Completed
                code = info.get("Code")
                if code:
                    return self._extract_code(str(code))
            # Status 0 = still waiting, return None
            # Status 2 = expired, return None
        return None

    def cancel_order(self, order_id: str) -> bool:
        """VioTP doesn't have explicit cancel in the docs provided.
        Orders auto-expire after timeout."""
        return True  # Auto-handled by VioTP


# ═══════════════════════════════════════════════════════
# CodeSim.net — Vietnamese phone rental
# Docs: https://codesim.net/ (API Tích hợp page)
# Auth: api_key passed as GET query parameter (JWT token)
# Base URL: https://apisim.codesim.net
# Response format: {"timestamp":..., "status":200, "message":"Thành công", "data":{...}}
# ⚠️ IMPORTANT: Poll interval for get_sms must be >= 4 seconds!
#    Calling faster WILL permanently ban the account!
# ═══════════════════════════════════════════════════════

class CodeSimService(PhoneService):
    name = "codesim.net"
    base_url = "https://apisim.codesim.net"

    # Service ID mapping — from /service/get_service_by_api_key response
    # Gmail = 2
    SERVICE_MAP = {
        "google": 2,
        "gmail": 2,
        "facebook": 1,
    }

    def _params(self, **extra) -> dict:
        """Build params dict with api_key."""
        p = {"api_key": self.api_key}
        p.update(extra)
        return p

    def check_balance(self) -> float:
        """
        GET /yourself/information-by-api-key?api_key=KEY
        Returns data.balance (actual balance in VNĐ).
        """
        data = self._get(
            f"{self.base_url}/yourself/information-by-api-key",
            params=self._params()
        )
        if data.get("status") == 200:
            info = data.get("data", {})
            balance = info.get("balance")
            if balance is not None:
                try:
                    return float(balance)
                except (ValueError, TypeError):
                    pass
        return -1

    def get_services(self) -> list:
        """GET /service/get_service_by_api_key — list available services."""
        data = self._get(
            f"{self.base_url}/service/get_service_by_api_key",
            params=self._params()
        )
        if data.get("status") == 200:
            return data.get("data", [])
        return []

    def rent_number(self, service: str = "google", country: str = "vn") -> Tuple[Optional[str], Optional[str]]:
        """
        GET /sim/get_sim?service_id=ID&api_key=KEY
        Gmail service_id = 2
        Returns (phone, "otpId:simId") — compound ID for later use.
        otpId is used for get_sms, simId is used for cancel_order.
        """
        service_id = self.SERVICE_MAP.get(service.lower(), 2)  # Default to Gmail

        data = self._get(
            f"{self.base_url}/sim/get_sim",
            params=self._params(service_id=service_id)
        )

        if data.get("status") == 200:
            info = data.get("data", {})
            phone = info.get("phone")
            otp_id = info.get("otpId")
            sim_id = info.get("simId")
            if phone and otp_id:
                # Encode both IDs: "otpId:simId" for later retrieval
                compound_id = f"{otp_id}:{sim_id}" if sim_id else str(otp_id)
                return str(phone), compound_id
        return None, None

    def get_sms(self, order_id: str) -> Optional[str]:
        """
        GET /otp/get_otp_by_phone_api_key?otp_id=OTP_ID&api_key=KEY
        Returns data.code when SMS is received.
        ⚠️ MUST wait >= 4 seconds between calls or account gets banned!
        order_id format: "otpId:simId" (from rent_number).
        """
        # Extract otpId from compound ID
        otp_id = order_id.split(":")[0] if ":" in order_id else order_id

        data = self._get(
            f"{self.base_url}/otp/get_otp_by_phone_api_key",
            params=self._params(otp_id=otp_id)
        )

        if data.get("status") == 200:
            info = data.get("data", {})
            code = info.get("code")
            if code:
                return self._extract_code(str(code))
        return None

    def cancel_order(self, order_id: str) -> bool:
        """
        GET /sim/cancel_api_key/{sim_id}?api_key=KEY
        order_id format: "otpId:simId" (from rent_number).
        """
        # Extract simId from compound ID
        parts = order_id.split(":")
        sim_id = parts[1] if len(parts) > 1 else parts[0]

        data = self._get(
            f"{self.base_url}/sim/cancel_api_key/{sim_id}",
            params=self._params()
        )
        return data.get("status") == 200

    def wait_for_sms(self, order_id: str, timeout_seconds: int = 120, poll_interval: int = 5) -> Optional[str]:
        """Override: enforce minimum 5s poll interval (API requires >= 4s)."""
        poll_interval = max(5, poll_interval)  # NEVER less than 5 seconds!
        return super().wait_for_sms(order_id, timeout_seconds, poll_interval)


# ═══════════════════════════════════════════════════════
# OtpCodeSms.site — Vietnamese OTP service (V1 = FB, V2 = Google)
# Docs: https://www.otpcodesms.site/ApiDocs/Index (login required)
# Auth: key passed as GET query parameter "key"
# Base URL: https://otpcodesms.site/api
# All actions via single endpoint with ?key=KEY&action=ACTION&id=ID
# ═══════════════════════════════════════════════════════

class OtpCodeSmsService(PhoneService):
    name = "otpcodesms.site"
    base_url = "https://otpcodesms.site/api"

    # Cache for service list to avoid repeated calls
    _cached_services = None

    def _api(self, action: str, **extra) -> dict:
        """Call the single API endpoint with action parameter."""
        params = {"key": self.api_key, "action": action}
        params.update(extra)
        return self._get(self.base_url, params=params)

    def _get_google_service_id(self) -> Optional[int]:
        """Find cheapest Google/Gmail V2 service."""
        if self._cached_services is None:
            data = self._api("get_all_services_v2")
            if isinstance(data, list):
                self._cached_services = data
            else:
                return None

        google = [
            s for s in self._cached_services
            if 'google' in s.get('name', '').lower() or 'gmail' in s.get('name', '').lower()
        ]
        if google:
            # Sort by price, pick cheapest
            google.sort(key=lambda s: s.get('price', 999999))
            return google[0]['id']
        return None

    def check_balance(self) -> float:
        """
        OtpCodeSms has no explicit balance endpoint.
        Verify API key by calling get_all_services_v2.
        Returns 0 if valid, -1 if invalid.
        """
        data = self._api("get_all_services_v2")
        if isinstance(data, list) and len(data) > 0:
            self._cached_services = data
            return 0.0  # Token valid, balance unknown
        if isinstance(data, dict) and data.get("message") == "Invalid api key!":
            return -1
        return -1

    def rent_number(self, service: str = "google", country: str = "vn") -> Tuple[Optional[str], Optional[str]]:
        """
        GET /api?key=KEY&action=get_number_v2&id=SERVICE_ID
        Google services are in V2 (V1 has Facebook).
        Returns (phone_number, request_id).
        """
        svc_id = self._get_google_service_id()
        if not svc_id:
            return None, None

        data = self._api("get_number_v2", id=svc_id)
        if isinstance(data, dict):
            number = data.get("number")
            request_id = data.get("request_id")
            if number and request_id:
                return str(number), str(request_id)
        return None, None

    def get_sms(self, order_id: str) -> Optional[str]:
        """
        GET /api?key=KEY&action=get_code_v2&id=REQUEST_ID
        Returns OTP code or None if still waiting.
        Responses: {"otp_code":"123456"} | {"otp_code":"is_coming"} | {"otp_code":"timeout"}
        """
        data = self._api("get_code_v2", id=order_id)
        if isinstance(data, dict):
            code = data.get("otp_code")
            if code and code not in ("is_coming", "timeout"):
                return self._extract_code(str(code))
        return None

    def cancel_order(self, order_id: str) -> bool:
        """
        GET /api?key=KEY&action=cancel_phone_v2&id=REQUEST_ID
        Must wait >120s after renting before canceling.
        """
        data = self._api("cancel_phone_v2", id=order_id)
        if isinstance(data, dict):
            return data.get("success", False)
        return False


# ═══════════════════════════════════════════════════════
# Registry — All available services
# ═══════════════════════════════════════════════════════

PHONE_SERVICES: Dict[str, type] = {
    "smspool.net": SMSPoolService,
    "5sim.net": FiveSimService,
    "thuesim.app": ThueSimAppService,
    "viotp.com": VioTPService,
    "codesim.net": CodeSimService,
    "otpcodesms.site": OtpCodeSmsService,
}

# Country codes for UI
COUNTRY_CODES = [
    ("vn", "🇻🇳 Việt Nam (+84)"),
    ("us", "🇺🇸 United States (+1)"),
    ("uk", "🇬🇧 United Kingdom (+44)"),
    ("ru", "🇷🇺 Russia (+7)"),
    ("in", "🇮🇳 India (+91)"),
    ("id", "🇮🇩 Indonesia (+62)"),
    ("ph", "🇵🇭 Philippines (+63)"),
]


def get_service(name: str, api_key: str) -> Optional[PhoneService]:
    """Factory: create a PhoneService instance by name."""
    cls = PHONE_SERVICES.get(name)
    if cls:
        return cls(api_key)
    return None


def check_all_services(api_keys: Dict[str, str]) -> Dict[str, bool]:
    """
    Check which services are available with the given API keys.
    Returns {service_name: is_available}.
    """
    results = {}
    for name, cls in PHONE_SERVICES.items():
        key = api_keys.get(name, "")
        if key:
            try:
                svc = cls(key)
                results[name] = svc.is_available()
            except Exception:
                results[name] = False
        else:
            results[name] = False
    return results

