"""
Global CAPTCHA Solver Module — reCAPTCHA v2 / Enterprise auto-solving.

Providers: 2Captcha (v2 JSON API), OmoCaptcha, Anti-Captcha, CapSolver, CapMonster
Settings:  data/settings.json -> two_captcha_key, omocaptcha_key,
           captcha_provider, captcha_timeout, captcha_retries

Speed optimizations:
  - Parallel racing: sends to ALL configured providers, returns first result
  - Skip checkbox click on Google pages (always fails)
  - Cached settings to avoid re-reading JSON every call
  - 2s polling interval for maximum speed

Usage from ANY login thread:
    from core.captcha_solver import handle_captcha_on_page
    solved = handle_captcha_on_page(page, status_callback=lambda msg: ...)
"""
import time
import urllib.request
import urllib.parse
import json
import re
import os
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed


# ════════════════════════════════════════
#  Universal JSON API helper
# ════════════════════════════════════════

def _post_json(url, data, timeout=30):
    """POST JSON request and return parsed response dict."""
    payload = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type": "application/json", "Accept": "application/json"}
    )
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode("utf-8"))


# ════════════════════════════════════════
#  CaptchaSolver — Multi-Provider with Racing
# ════════════════════════════════════════

class CaptchaSolver:
    """Solve reCAPTCHA v2/Enterprise via paid API services."""

    def __init__(self, api_key="", provider="2captcha",
                 timeout=60, retries=2, omocaptcha_key=""):
        self.api_key = api_key.strip()
        self.provider = provider.lower().strip()
        self.timeout = min(timeout, 90)  # Cap at 90s max
        self.retries = retries
        self.omocaptcha_key = omocaptcha_key.strip()

    def is_configured(self):
        if self.provider == "omocaptcha":
            return bool(self.omocaptcha_key)
        return bool(self.api_key)

    def has_any_key(self):
        """Check if ANY provider key is available."""
        return bool(self.api_key) or bool(self.omocaptcha_key)

    def solve_recaptcha_v2(self, sitekey, page_url, is_enterprise=False, log=None):
        """Solve reCAPTCHA v2/Enterprise. Returns token string or ''.
        Uses parallel racing if multiple providers are configured."""
        if not self.has_any_key():
            return ""

        for attempt in range(self.retries):
            if attempt > 0 and log:
                log(f"[CAPTCHA] Retry {attempt + 1}/{self.retries}...")
                time.sleep(1)
            try:
                token = self._solve_racing(sitekey, page_url, is_enterprise, log)
                if token:
                    return token
            except Exception as e:
                if log:
                    log(f"[CAPTCHA] Error: {str(e)[:80]}")
        return ""

    def _solve_racing(self, sitekey, page_url, is_enterprise, log):
        """Send to ALL configured providers simultaneously, return first result."""
        providers = []

        # Build list of available providers
        if self.api_key:
            if self.provider in ("2captcha", ""):
                providers.append(("2Captcha", lambda: self._solve_2captcha_v2(sitekey, page_url, is_enterprise, log)))
            elif self.provider == "anti-captcha":
                providers.append(("Anti-Captcha", lambda: self._solve_generic_json(
                    "https://api.anti-captcha.com/createTask",
                    "https://api.anti-captcha.com/getTaskResult",
                    self.api_key, sitekey, page_url, is_enterprise, log,
                    enterprise_type="RecaptchaV2EnterpriseTaskProxyless",
                    standard_type="RecaptchaV2TaskProxyless"
                )))
            elif self.provider == "capsolver":
                providers.append(("CapSolver", lambda: self._solve_generic_json(
                    "https://api.capsolver.com/createTask",
                    "https://api.capsolver.com/getTaskResult",
                    self.api_key, sitekey, page_url, is_enterprise, log,
                    enterprise_type="ReCaptchaV2EnterpriseTaskProxyLess",
                    standard_type="ReCaptchaV2TaskProxyLess"
                )))
            elif self.provider == "capmonster":
                providers.append(("CapMonster", lambda: self._solve_generic_json(
                    "https://api.capmonster.cloud/createTask",
                    "https://api.capmonster.cloud/getTaskResult",
                    self.api_key, sitekey, page_url, is_enterprise, log,
                    enterprise_type="RecaptchaV2EnterpriseTaskProxyless",
                    standard_type="RecaptchaV2TaskProxyless"
                )))
            else:
                # Default to 2captcha format
                providers.append(("2Captcha", lambda: self._solve_2captcha_v2(sitekey, page_url, is_enterprise, log)))

        # Always add OmoCaptcha if key exists AND it's not the only provider
        if self.omocaptcha_key:
            providers.append(("OmoCaptcha", lambda: self._solve_omocaptcha(sitekey, page_url, log)))

        if not providers:
            return ""

        # Single provider — no threading overhead
        if len(providers) == 1:
            name, solver_fn = providers[0]
            if log:
                log(f"[CAPTCHA] Sending to {name}...")
            return solver_fn() or ""

        # Multiple providers — RACE them!
        if log:
            names = " + ".join(p[0] for p in providers)
            log(f"[CAPTCHA] 🏎️ Racing: {names}")

        result_token = ""
        stop_event = threading.Event()

        def _run_provider(name, fn):
            nonlocal result_token
            try:
                token = fn()
                if token and not stop_event.is_set():
                    result_token = token
                    stop_event.set()
                    if log:
                        log(f"[CAPTCHA] ✅ {name} won the race!")
            except Exception:
                pass

        threads = []
        for name, fn in providers:
            t = threading.Thread(target=_run_provider, args=(name, fn), daemon=True)
            threads.append(t)
            t.start()

        # Wait for first result or all threads to finish
        for t in threads:
            t.join(timeout=self.timeout + 5)
            if stop_event.is_set():
                break

        return result_token

    # ─────────────────────────────────────
    #  2Captcha — New v2 JSON API
    #  Docs: https://2captcha.com/api-docs
    # ─────────────────────────────────────
    def _solve_2captcha_v2(self, sitekey, page_url, is_enterprise, log):
        """Use 2Captcha v2 JSON API (api.2captcha.com)."""
        task_type = "RecaptchaV2EnterpriseTaskProxyless" if is_enterprise else "RecaptchaV2TaskProxyless"

        if log:
            log(f"[2Captcha] createTask ({task_type})...")

        # Step 1: createTask
        resp = _post_json("https://api.2captcha.com/createTask", {
            "clientKey": self.api_key,
            "task": {
                "type": task_type,
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        })

        if resp.get("errorId", 1) != 0:
            if log:
                log(f"[2Captcha] Error: {resp.get('errorCode', 'unknown')}")
            return ""

        task_id = resp.get("taskId")
        if not task_id:
            return ""

        if log:
            log(f"[2Captcha] taskId={task_id}, polling...")

        # Step 2: getTaskResult (poll every 2s)
        return self._poll_task_result(
            "https://api.2captcha.com/getTaskResult",
            self.api_key, task_id, log, label="2Captcha"
        )

    # ──────────────────────────────────────
    #  OmoCaptcha API
    #  Docs: https://docs.omocaptcha.com
    # ──────────────────────────────────────
    def _solve_omocaptcha(self, sitekey, page_url, log):
        """Use OmoCaptcha API (api.omocaptcha.com)."""
        if log:
            log("[OmoCaptcha] createTask...")

        # Step 1: createTask
        resp = _post_json("https://api.omocaptcha.com/v2/createTask", {
            "clientKey": self.omocaptcha_key,
            "task": {
                "type": "RecaptchaV2TokenTask",
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        })

        if resp.get("errorId", 1) != 0:
            if log:
                log(f"[OmoCaptcha] Error: {resp.get('errorCode', 'unknown')}")
            return ""

        task_id = resp.get("taskId")
        if not task_id:
            return ""

        if log:
            log(f"[OmoCaptcha] taskId={task_id}, polling...")

        # Step 2: getTaskResult (poll every 2s)
        return self._poll_task_result(
            "https://api.omocaptcha.com/v2/getTaskResult",
            self.omocaptcha_key, task_id, log, label="OmoCaptcha"
        )

    # ──────────────────────────────────────
    #  Generic JSON API (Anti-Captcha, CapSolver, CapMonster)
    # ──────────────────────────────────────
    def _solve_generic_json(self, create_url, result_url, api_key,
                            sitekey, page_url, is_enterprise, log,
                            enterprise_type, standard_type):
        task_type = enterprise_type if is_enterprise else standard_type
        label = create_url.split("//")[1].split(".")[1] if "//" in create_url else "API"
        if log:
            log(f"[{label}] createTask ({task_type})...")

        resp = _post_json(create_url, {
            "clientKey": api_key,
            "task": {
                "type": task_type,
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        })

        if resp.get("errorId", 1) != 0:
            if log:
                log(f"[{label}] Error: {resp.get('errorCode', 'unknown')}")
            return ""

        task_id = resp.get("taskId")
        if not task_id:
            return ""

        if log:
            log(f"[{label}] taskId={task_id}, polling...")

        return self._poll_task_result(result_url, api_key, task_id, log, label=label)

    # ──────────────────────────────────────
    #  Unified poll (works for all providers)
    # ──────────────────────────────────────
    def _poll_task_result(self, url, api_key, task_id, log, label="API"):
        """Poll getTaskResult endpoint. Returns token or ''."""
        start = time.time()
        while time.time() - start < self.timeout:
            time.sleep(2)  # 2s poll for maximum speed
            try:
                resp = _post_json(url, {
                    "clientKey": api_key,
                    "taskId": task_id
                })
            except Exception:
                continue

            status = resp.get("status", "")
            if status == "ready":
                token = resp.get("solution", {}).get("gRecaptchaResponse", "")
                if token and log:
                    elapsed = int(time.time() - start)
                    log(f"[{label}] ✅ Solved in {elapsed}s!")
                return token
            elif status == "fail" or resp.get("errorId", 0) != 0:
                if log:
                    log(f"[{label}] Error: {resp.get('errorCode', 'fail')}")
                return ""
            # else status == "processing" → continue polling

        if log:
            log(f"[{label}] Timeout ({self.timeout}s)")
        return ""


# ════════════════════════════════════════
#  Page Helpers — Extract / Detect / Inject
# ════════════════════════════════════════

def extract_recaptcha_sitekey(page):
    """Extract reCAPTCHA v2 sitekey from page."""
    try:
        for frame in page.frames:
            url = frame.url or ""
            m = re.search(r'[?&]k=([A-Za-z0-9_-]+)', url)
            if m:
                return m.group(1)
        try:
            el = page.locator('[data-sitekey]')
            if el.count() > 0:
                return el.first.get_attribute('data-sitekey') or ""
        except:
            pass
        html = page.content()
        m = re.search(r'data-sitekey=["\']([A-Za-z0-9_-]+)["\']', html)
        if m:
            return m.group(1)
        m = re.search(r'render=([A-Za-z0-9_-]{20,})', html)
        if m:
            return m.group(1)
    except:
        pass
    return ""


def is_enterprise_recaptcha(page):
    """Detect if page uses reCAPTCHA Enterprise."""
    try:
        for frame in page.frames:
            if "/recaptcha/enterprise/" in (frame.url or ""):
                return True
        if "/recaptcha/enterprise/" in page.content():
            return True
    except:
        pass
    return False


def inject_recaptcha_token(page, token):
    """Inject reCAPTCHA token — TrustedHTML-safe, multi-frame, callback search."""
    injected = False

    # TrustedHTML-safe JS — NO innerHTML, only .value and .textContent
    inject_js = """(token) => {
        var found = false;
        // 1. Set textarea values (NO innerHTML — blocked by TrustedHTML policy)
        var textareas = document.querySelectorAll('textarea[name="g-recaptcha-response"]');
        for (var i = 0; i < textareas.length; i++) {
            textareas[i].value = token;
            try { textareas[i].textContent = token; } catch(e) {}
            textareas[i].style.display = 'block';
            found = true;
        }
        var el = document.getElementById('g-recaptcha-response');
        if (el) { el.value = token; found = true; }
        // 2. Find and call the reCAPTCHA callback
        if (typeof ___grecaptcha_cfg !== 'undefined') {
            try {
                var clients = ___grecaptcha_cfg.clients;
                for (var ck in clients) {
                    var client = clients[ck];
                    function searchCb(obj, depth) {
                        if (depth > 4 || !obj || typeof obj !== 'object') return false;
                        if (obj instanceof HTMLElement || obj instanceof Node || obj instanceof Window) return false;
                        if (typeof obj.callback === 'function') {
                            try { obj.callback(token); return true; } catch(e) {}
                        }
                        for (var key in obj) {
                            if (key === 'window' || key === 'document') continue;
                            var val = obj[key];
                            if (!val || typeof val !== 'object') continue;
                            if (val instanceof HTMLElement || val instanceof Node || val instanceof Window) continue;
                            if (searchCb(val, depth + 1)) return true;
                        }
                        return false;
                    }
                    if (searchCb(client, 0)) { found = true; break; }
                }
            } catch(e) {}
        }
        // 3. Try grecaptcha.enterprise.execute()
        if (typeof grecaptcha !== 'undefined') {
            try {
                if (grecaptcha.enterprise && grecaptcha.enterprise.execute) {
                    grecaptcha.enterprise.execute();
                    found = true;
                }
            } catch(e) {}
        }
        return found;
    }"""

    # Run injection on main page
    try:
        if page.evaluate(inject_js, token):
            injected = True
    except:
        pass

    # Also try in reCAPTCHA frames
    try:
        for frame in page.frames:
            furl = frame.url or ""
            if "recaptcha" in furl and "bframe" not in furl:
                try:
                    frame.evaluate(inject_js, token)
                    injected = True
                except:
                    pass
    except:
        pass

    # Set anchor checkbox as checked
    try:
        for frame in page.frames:
            furl = frame.url or ""
            if "recaptcha" in furl and "anchor" in furl:
                try:
                    frame.evaluate("""() => {
                        var anchor = document.getElementById('recaptcha-anchor');
                        if (anchor) {
                            anchor.setAttribute('aria-checked', 'true');
                            anchor.classList.add('recaptcha-checkbox-checked');
                        }
                    }""")
                except:
                    pass
    except:
        pass

    return injected


def detect_recaptcha_page(page):
    """Check if current page has a reCAPTCHA challenge."""
    try:
        url = page.url or ""
        if "challenge/recaptcha" in url:
            return True
        try:
            body_text = page.inner_text("body", timeout=3000)[:2000].lower()
        except:
            body_text = ""
        keywords = [
            "i'm not a robot", "confirm you're not a robot",
            "verify it's you", "not a robot", "recaptcha",
            "xac minh", "robot",
        ]
        if any(kw in body_text for kw in keywords):
            return True
        for frame in page.frames:
            if "recaptcha" in (frame.url or ""):
                return True
    except:
        pass
    return False


# ════════════════════════════════════════
#  Settings Loader (with cache)
# ════════════════════════════════════════

_cached_solver = None
_cached_solver_mtime = 0

def get_captcha_solver_from_settings():
    """Create CaptchaSolver from data/settings.json.
    Caches the solver and only reloads when file changes."""
    global _cached_solver, _cached_solver_mtime
    try:
        settings_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "data", "settings.json"
        )
        mtime = os.path.getmtime(settings_path)
        if _cached_solver and mtime == _cached_solver_mtime:
            return _cached_solver

        with open(settings_path, "r", encoding="utf-8") as f:
            s = json.load(f)
        solver = CaptchaSolver(
            api_key=s.get("two_captcha_key", ""),
            provider=s.get("captcha_provider", "2captcha"),
            timeout=min(int(s.get("captcha_timeout", 60)), 90),
            retries=int(s.get("captcha_retries", 2)),
            omocaptcha_key=s.get("omocaptcha_key", ""),
        )
        _cached_solver = solver
        _cached_solver_mtime = mtime
        return solver
    except Exception:
        return CaptchaSolver("")


# ════════════════════════════════════════
#  Global Handler — Call from ANY Login Thread
# ════════════════════════════════════════

def handle_captcha_on_page(page, status_callback=None, max_attempts=2, skip_submit=False):
    """
    Universal CAPTCHA handler -- call from any login thread.
    Returns True if CAPTCHA was detected, False if none found.

    Speed optimizations:
    - Skips checkbox click on Google pages (always fails, wastes 3s)
    - Uses parallel provider racing
    - Minimal sleep delays
    """
    def emit(msg):
        if status_callback:
            try:
                status_callback(msg)
            except:
                pass

    if not detect_recaptcha_page(page):
        return False

    emit("[CAPTCHA] Phát hiện reCAPTCHA — đang xử lý...")

    # Check if this is a Google page (checkbox click never works on Google)
    is_google = False
    try:
        url_lower = (page.url or "").lower()
        is_google = "google.com" in url_lower or "gstatic.com" in url_lower
    except:
        pass

    for attempt in range(max_attempts):
        if attempt > 0:
            emit(f"[CAPTCHA] Thử lại lần {attempt + 1}...")
            time.sleep(1)

        # Step 1: Try clicking checkbox (SKIP on Google — always fails)
        if not is_google:
            try:
                for frame in page.frames:
                    furl = frame.url or ""
                    if "recaptcha" in furl and "anchor" in furl:
                        cb = frame.locator('#recaptcha-anchor')
                        if cb.count() > 0:
                            cb.first.click()
                            time.sleep(2)
                            try:
                                if cb.first.get_attribute("aria-checked") == "true":
                                    emit("[OK] reCAPTCHA vượt qua (click)")
                                    if not skip_submit:
                                        _click_form_submit(page)
                                        time.sleep(2)
                                    return True
                            except:
                                pass
            except:
                pass

        # Step 2: Solve via API (racing all providers)
        solver = get_captcha_solver_from_settings()
        if not solver.has_any_key():
            emit("[!] Cần CAPTCHA API Key (Cài đặt -> Trình duyệt -> API Key)")
            return True

        sitekey = extract_recaptcha_sitekey(page)
        if not sitekey:
            emit("[X] Không tìm thấy sitekey reCAPTCHA")
            continue

        enterprise = is_enterprise_recaptcha(page)

        token = solver.solve_recaptcha_v2(sitekey, page.url, is_enterprise=enterprise, log=emit)
        if token:
            emit("[OK] CAPTCHA solved! Injecting token...")
            inject_recaptcha_token(page, token)
            time.sleep(1)
            if not skip_submit:
                _click_form_submit(page)
                time.sleep(3)
            else:
                emit("[OK] Skip submit (2FA mode — caller will handle)")

            if not detect_recaptcha_page(page):
                emit("[OK] reCAPTCHA bypassed ✅")
                return True
            else:
                emit("[!] CAPTCHA still present after inject, retrying...")
        else:
            emit(f"[X] CAPTCHA solving failed (attempt {attempt + 1})")

    return True


def _click_form_submit(page):
    """Click Next/Verify/Submit button on current page."""
    for sel in [
        'button:has-text("Tiep theo")', 'button:has-text("Next")',
        'button:has-text("Verify")', 'button:has-text("Xac minh")',
        'button:has-text("Continue")', 'button:has-text("Sign in")',
        '#submit', 'button[type="submit"]', '#passwordNext',
        '#identifierNext', '#identifierNext button',
    ]:
        try:
            btn = page.locator(sel)
            if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                btn.first.click()
                return True
        except:
            continue
    return False

