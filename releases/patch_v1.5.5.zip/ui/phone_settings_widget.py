"""
Phone Settings Widget — Reusable UI for phone rental configuration.

Can be embedded as a sub-tab in any manager (Gmail, Change Via, etc.).
Uses PhoneSettings singleton for persistent storage.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QLineEdit,
    QPushButton, QSpinBox, QGroupBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QCheckBox, QFrame
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QColor

from core.phone_service import PHONE_SERVICES, COUNTRY_CODES
from core.phone_settings import PhoneSettings


class CheckServicesThread(QThread):
    """Background thread to check which phone services are available."""
    result_ready = pyqtSignal(dict)  # {site_name: (available, balance_or_error)}

    def __init__(self, api_keys: dict):
        super().__init__()
        self.api_keys = api_keys

    def run(self):
        results = {}
        for name, cls in PHONE_SERVICES.items():
            key = self.api_keys.get(name, "")
            if not key:
                results[name] = (False, "Chưa nhập API Key")
                continue
            try:
                svc = cls(key)
                balance = svc.check_balance()
                if balance >= 0:
                    if balance == 0:
                        results[name] = (True, "✅ Token hợp lệ")
                    else:
                        results[name] = (True, f"Số dư: {balance}")
                else:
                    results[name] = (False, "API Key không hợp lệ")
            except Exception as e:
                results[name] = (False, str(e)[:50])
        self.result_ready.emit(results)


class PhoneSettingsWidget(QWidget):
    """
    Reusable phone settings panel.
    Embed this widget as a tab in any manager.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.settings = PhoneSettings.instance()
        self._check_thread = None
        self._init_ui()
        self._load_settings()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        # ── Title ──
        title = QLabel("📱 Cài đặt Thuê Số — Phone Rental Settings")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #a78bfa; margin-bottom: 5px;")
        layout.addWidget(title)

        desc = QLabel(
            "Cấu hình dịch vụ thuê số điện thoại để xác minh tài khoản.\n"
            "Cài đặt này dùng chung cho toàn bộ tool (Gmail, Change Via, v.v.)."
        )
        desc.setStyleSheet("color: #a0aec0; font-size: 11px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # ── Site + Country Selection ──
        select_group = QGroupBox("🌐 Chọn dịch vụ & Mã vùng")
        select_group.setStyleSheet("""
            QGroupBox {
                color: #c4b5fd; font-weight: bold;
                border: 1px solid #4a5568; border-radius: 8px;
                margin-top: 8px; padding-top: 16px;
            }
            QGroupBox::title {
                subcontrol-origin: margin; left: 12px; padding: 0 6px;
            }
        """)
        sg_layout = QVBoxLayout(select_group)
        sg_layout.setSpacing(8)

        # Row 1: Site selection
        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Dịch vụ:"))
        self.combo_site = QComboBox()
        for name in PHONE_SERVICES.keys():
            self.combo_site.addItem(name)
        self.combo_site.setMinimumWidth(180)
        self.combo_site.currentTextChanged.connect(self._on_site_changed)
        row1.addWidget(self.combo_site)

        row1.addSpacing(15)
        row1.addWidget(QLabel("Mã vùng:"))
        self.combo_country = QComboBox()
        for code, label in COUNTRY_CODES:
            self.combo_country.addItem(label, code)
        self.combo_country.setMinimumWidth(200)
        self.combo_country.currentIndexChanged.connect(self._on_country_changed)
        row1.addWidget(self.combo_country)
        row1.addStretch()
        sg_layout.addLayout(row1)

        # Row 2: API Key
        row2 = QHBoxLayout()
        row2.addWidget(QLabel("API Key:"))
        self.input_api_key = QLineEdit()
        self.input_api_key.setPlaceholderText("Nhập API Key của dịch vụ đã chọn...")
        self.input_api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.input_api_key.setMinimumWidth(300)
        row2.addWidget(self.input_api_key)

        self.btn_toggle_key = QPushButton("👁")
        self.btn_toggle_key.setFixedSize(32, 28)
        self.btn_toggle_key.setToolTip("Hiện/Ẩn API Key")
        self.btn_toggle_key.clicked.connect(self._toggle_key_visibility)
        row2.addWidget(self.btn_toggle_key)

        self.btn_save_key = QPushButton("💾 Lưu Key")
        self.btn_save_key.setFixedHeight(28)
        self.btn_save_key.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #8b5cf6,stop:1 #7c3aed);
                border: 1px solid #6d28d9; border-radius: 4px; color: white;
                font-weight: 700; padding: 0 12px;
            }
            QPushButton:hover { background: #a78bfa; }
        """)
        self.btn_save_key.clicked.connect(self._save_api_key)
        row2.addWidget(self.btn_save_key)

        self.btn_test_key = QPushButton("🔗 Test API")
        self.btn_test_key.setFixedHeight(28)
        self.btn_test_key.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #10b981,stop:1 #059669);
                border: 1px solid #047857; border-radius: 4px; color: white;
                font-weight: 700; padding: 0 12px;
            }
            QPushButton:hover { background: #34d399; }
        """)
        self.btn_test_key.clicked.connect(self._test_api_key)
        row2.addWidget(self.btn_test_key)
        row2.addStretch()
        sg_layout.addLayout(row2)

        # Test result label
        self.lbl_test_result = QLabel("")
        self.lbl_test_result.setStyleSheet("color: #a0aec0; font-size: 11px; padding-left: 60px;")
        sg_layout.addWidget(self.lbl_test_result)

        layout.addWidget(select_group)

        # ── Parameters ──
        param_group = QGroupBox("⚙️ Tham số xác minh")
        param_group.setStyleSheet("""
            QGroupBox {
                color: #c4b5fd; font-weight: bold;
                border: 1px solid #4a5568; border-radius: 8px;
                margin-top: 8px; padding-top: 16px;
            }
            QGroupBox::title {
                subcontrol-origin: margin; left: 12px; padding: 0 6px;
            }
        """)
        pg_layout = QHBoxLayout(param_group)
        pg_layout.setSpacing(20)

        # Wait timeout
        pg_layout.addWidget(QLabel("⏱ Chờ code (giây):"))
        self.spin_timeout = QSpinBox()
        self.spin_timeout.setRange(30, 300)
        self.spin_timeout.setSingleStep(10)
        self.spin_timeout.setFixedWidth(70)
        self.spin_timeout.valueChanged.connect(self._on_timeout_changed)
        pg_layout.addWidget(self.spin_timeout)

        pg_layout.addSpacing(10)

        # Max retries
        pg_layout.addWidget(QLabel("🔄 Số lần thử:"))
        self.spin_retries = QSpinBox()
        self.spin_retries.setRange(1, 10)
        self.spin_retries.setFixedWidth(60)
        self.spin_retries.valueChanged.connect(self._on_retries_changed)
        pg_layout.addWidget(self.spin_retries)

        pg_layout.addSpacing(10)

        # Auto verify
        self.chk_auto_verify = QCheckBox("Tự động xác minh khi cần phone")
        self.chk_auto_verify.stateChanged.connect(self._on_auto_verify_changed)
        pg_layout.addWidget(self.chk_auto_verify)

        pg_layout.addStretch()
        layout.addWidget(param_group)

        # ── Service Status Table ──
        status_group = QGroupBox("📊 Trạng thái các dịch vụ")
        status_group.setStyleSheet("""
            QGroupBox {
                color: #c4b5fd; font-weight: bold;
                border: 1px solid #4a5568; border-radius: 8px;
                margin-top: 8px; padding-top: 16px;
            }
            QGroupBox::title {
                subcontrol-origin: margin; left: 12px; padding: 0 6px;
            }
        """)
        stg_layout = QVBoxLayout(status_group)

        self.btn_check_all = QPushButton("🔍 Kiểm tra tất cả dịch vụ")
        self.btn_check_all.setFixedHeight(32)
        self.btn_check_all.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #8b5cf6,stop:1 #7c3aed);
                border: 1px solid #6d28d9; border-radius: 6px; color: white;
                font-weight: 700; padding: 0 16px; font-size: 12px;
            }
            QPushButton:hover { background: #a78bfa; }
        """)
        self.btn_check_all.clicked.connect(self._check_all_services)
        stg_layout.addWidget(self.btn_check_all)

        self.status_table = QTableWidget()
        self.status_table.setColumnCount(4)
        self.status_table.setHorizontalHeaderLabels(["Dịch vụ", "API Key", "Trạng thái", "Thông tin"])
        self.status_table.verticalHeader().setVisible(False)
        self.status_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.status_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        header = self.status_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.status_table.setColumnWidth(0, 160)
        self.status_table.setColumnWidth(1, 130)
        self.status_table.setColumnWidth(2, 100)
        self.status_table.setMaximumHeight(200)
        stg_layout.addWidget(self.status_table)
        layout.addWidget(status_group)

        # ── Sites Reference ──
        ref_group = QGroupBox("📋 Danh sách các web thuê số")
        ref_group.setStyleSheet("""
            QGroupBox {
                color: #c4b5fd; font-weight: bold;
                border: 1px solid #4a5568; border-radius: 8px;
                margin-top: 8px; padding-top: 16px;
            }
            QGroupBox::title {
                subcontrol-origin: margin; left: 12px; padding: 0 6px;
            }
        """)
        rg_layout = QVBoxLayout(ref_group)
        sites_text = (
            "✅ Hỗ trợ API: smspool.net • 5sim.net • thuesim.app • viotp.com • codesim.net • otpcodesms.site\n"
            "🔜 Sắp hỗ trợ: funotp.com • otp282.com • smspva.com\n"
            "📝 Khác: winmail.shop • hcotp.com • smartotp.net • fastsim.online\n"
            "         ironsim.com • otptextnow.com/fun • bossotp.com • muasms.com • thueotp.site"
        )
        sites_lbl = QLabel(sites_text)
        sites_lbl.setStyleSheet("color: #a0aec0; font-size: 11px; line-height: 1.5;")
        sites_lbl.setWordWrap(True)
        rg_layout.addWidget(sites_lbl)
        layout.addWidget(ref_group)

        layout.addStretch()

    # ─── Load Settings ───

    def _load_settings(self):
        # Site
        idx = self.combo_site.findText(self.settings.selected_site)
        if idx >= 0:
            self.combo_site.setCurrentIndex(idx)

        # Country
        for i in range(self.combo_country.count()):
            if self.combo_country.itemData(i) == self.settings.country:
                self.combo_country.setCurrentIndex(i)
                break

        # API Key
        self.input_api_key.setText(self.settings.get_api_key())

        # Parameters
        self.spin_timeout.setValue(self.settings.wait_timeout)
        self.spin_retries.setValue(self.settings.max_retries)
        self.chk_auto_verify.setChecked(self.settings.auto_verify_phone)

        # Populate status table
        self._populate_status_table()

    def _populate_status_table(self):
        self.status_table.setRowCount(len(PHONE_SERVICES))
        for i, name in enumerate(PHONE_SERVICES.keys()):
            # Service name
            item = QTableWidgetItem(name)
            item.setForeground(QColor("#f7fafc"))
            self.status_table.setItem(i, 0, item)

            # API Key status
            key = self.settings.get_api_key(name)
            key_item = QTableWidgetItem("✅ Đã lưu" if key else "❌ Chưa có")
            key_item.setForeground(QColor("#10b981") if key else QColor("#ef4444"))
            self.status_table.setItem(i, 1, key_item)

            # Status
            status_item = QTableWidgetItem("⏳ Chưa kiểm tra")
            status_item.setForeground(QColor("#a0aec0"))
            self.status_table.setItem(i, 2, status_item)

            # Info
            info_item = QTableWidgetItem("Nhấn 'Kiểm tra tất cả' để kiểm tra")
            info_item.setForeground(QColor("#718096"))
            self.status_table.setItem(i, 3, info_item)

    # ─── Event Handlers ───

    def _on_site_changed(self, site_name):
        self.settings.selected_site = site_name
        self.input_api_key.setText(self.settings.get_api_key(site_name))
        self.lbl_test_result.setText("")

    def _on_country_changed(self, index):
        code = self.combo_country.itemData(index)
        if code:
            self.settings.country = code

    def _on_timeout_changed(self, value):
        self.settings.wait_timeout = value

    def _on_retries_changed(self, value):
        self.settings.max_retries = value

    def _on_auto_verify_changed(self, state):
        self.settings.auto_verify_phone = (state == 2)

    def _toggle_key_visibility(self):
        if self.input_api_key.echoMode() == QLineEdit.EchoMode.Password:
            self.input_api_key.setEchoMode(QLineEdit.EchoMode.Normal)
            self.btn_toggle_key.setText("🙈")
        else:
            self.input_api_key.setEchoMode(QLineEdit.EchoMode.Password)
            self.btn_toggle_key.setText("👁")

    def _save_api_key(self):
        site = self.combo_site.currentText()
        key = self.input_api_key.text().strip()
        if key:
            self.settings.set_api_key(site, key)
            self.lbl_test_result.setText(f"✅ Đã lưu API Key cho {site}")
            self.lbl_test_result.setStyleSheet("color: #10b981; font-size: 11px; padding-left: 60px;")
        else:
            self.lbl_test_result.setText("⚠️ Vui lòng nhập API Key")
            self.lbl_test_result.setStyleSheet("color: #fbbf24; font-size: 11px; padding-left: 60px;")
        self._populate_status_table()

    def _test_api_key(self):
        site = self.combo_site.currentText()
        key = self.input_api_key.text().strip()
        if not key:
            self.lbl_test_result.setText("⚠️ Vui lòng nhập API Key trước")
            self.lbl_test_result.setStyleSheet("color: #fbbf24; font-size: 11px; padding-left: 60px;")
            return

        self.lbl_test_result.setText("⏳ Đang kiểm tra...")
        self.lbl_test_result.setStyleSheet("color: #a78bfa; font-size: 11px; padding-left: 60px;")
        self.btn_test_key.setEnabled(False)

        from core.phone_service import get_service
        try:
            svc = get_service(site, key)
            if svc:
                balance = svc.check_balance()
                if balance >= 0:
                    if balance == 0:
                        msg = "✅ Kết nối thành công! Token hợp lệ"
                    else:
                        msg = f"✅ Kết nối thành công! Số dư: {balance}"
                    self.lbl_test_result.setText(msg)
                    self.lbl_test_result.setStyleSheet("color: #10b981; font-size: 11px; padding-left: 60px;")
                else:
                    self.lbl_test_result.setText("❌ API Key không hợp lệ hoặc hết số dư")
                    self.lbl_test_result.setStyleSheet("color: #ef4444; font-size: 11px; padding-left: 60px;")
            else:
                self.lbl_test_result.setText("❌ Dịch vụ không được hỗ trợ")
                self.lbl_test_result.setStyleSheet("color: #ef4444; font-size: 11px; padding-left: 60px;")
        except Exception as e:
            self.lbl_test_result.setText(f"❌ Lỗi: {str(e)[:60]}")
            self.lbl_test_result.setStyleSheet("color: #ef4444; font-size: 11px; padding-left: 60px;")
        finally:
            self.btn_test_key.setEnabled(True)

    def _check_all_services(self):
        self.btn_check_all.setEnabled(False)
        self.btn_check_all.setText("⏳ Đang kiểm tra...")

        self._check_thread = CheckServicesThread(self.settings.api_keys)
        self._check_thread.result_ready.connect(self._on_check_results)
        self._check_thread.finished.connect(lambda: self.btn_check_all.setEnabled(True))
        self._check_thread.finished.connect(lambda: self.btn_check_all.setText("🔍 Kiểm tra tất cả dịch vụ"))
        self._check_thread.start()

    def _on_check_results(self, results: dict):
        for i, name in enumerate(PHONE_SERVICES.keys()):
            if name in results:
                available, info = results[name]
                status_item = QTableWidgetItem("✅ OK" if available else "❌ Lỗi")
                status_item.setForeground(QColor("#10b981") if available else QColor("#ef4444"))
                self.status_table.setItem(i, 2, status_item)

                info_item = QTableWidgetItem(str(info))
                info_item.setForeground(QColor("#f7fafc") if available else QColor("#fc8181"))
                self.status_table.setItem(i, 3, info_item)
