"""
Facebook API Helper — Cookie-based HTTP API for Change Via operations.

Provides fb_dtsg extraction, GraphQL client, and Account Center helpers.
All operations use cookie auth (no browser needed).
"""
import re
import json
import time
import hashlib

try:
    import requests as _requests
except ImportError:
    _requests = None


# ════════════════════════════════════════
#  Cookie Helpers
# ════════════════════════════════════════

def parse_cookie_string(cookie_str):
    """Parse cookie string 'k1=v1;k2=v2' into dict."""
    cookies = {}
    if not cookie_str:
        return cookies
    for part in cookie_str.split(';'):
        part = part.strip()
        if '=' in part:
            k, v = part.split('=', 1)
            cookies[k.strip()] = v.strip()
    return cookies


def cookie_header(cookie_str):
    """Return cookie string suitable for Cookie header."""
    if not cookie_str:
        return ""
    parts = []
    for part in cookie_str.split(';'):
        part = part.strip()
        if '=' in part:
            parts.append(part)
    return "; ".join(parts)


def get_uid_from_cookie(cookie_str):
    """Extract c_user (UID) from cookie string."""
    cookies = parse_cookie_string(cookie_str)
    return cookies.get("c_user", "")


# ════════════════════════════════════════
#  HTTP Request Helper (uses requests lib)
# ════════════════════════════════════════

_session_cache = {}


def _get_session(cookie_str):
    """Get or create a requests.Session for this cookie."""
    key = cookie_str[:60] if cookie_str else ""
    if key in _session_cache:
        return _session_cache[key]

    s = _requests.Session()
    s.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "Accept-Encoding": "gzip, deflate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "navigate",
    })

    # Parse cookies into session
    for part in cookie_str.split(';'):
        part = part.strip()
        if '=' in part:
            k, v = part.split('=', 1)
            s.cookies.set(k.strip(), v.strip(), domain=".facebook.com")

    _session_cache[key] = s
    return s


def _make_request(url, cookie_str, data=None, method="GET",
                  extra_headers=None, timeout=30, user_agent=None):
    """Make HTTP request with cookie auth. Returns (status_code, response_text)."""
    if not _requests:
        return 0, "requests library not installed"

    session = _get_session(cookie_str)

    headers = {}
    if extra_headers:
        headers.update(extra_headers)
    if user_agent:
        headers["User-Agent"] = user_agent

    try:
        if data is not None:
            headers["Content-Type"] = "application/x-www-form-urlencoded"
            headers.setdefault("Origin", "https://www.facebook.com")
            headers.setdefault("Referer", "https://www.facebook.com/")
            resp = session.post(url, data=data, headers=headers,
                                timeout=timeout, allow_redirects=True)
        else:
            resp = session.get(url, headers=headers,
                               timeout=timeout, allow_redirects=True)
        return resp.status_code, resp.text
    except Exception as e:
        return 0, str(e)


# ════════════════════════════════════════
#  fb_dtsg Token Extraction
# ════════════════════════════════════════

def get_fb_dtsg(cookie_str):
    """Extract fb_dtsg CSRF token from Facebook home page.
    Returns (fb_dtsg, jazoest) tuple or ('', '') on failure."""
    status, html = _make_request("https://www.facebook.com/", cookie_str)
    if status != 200:
        # Try mbasic
        status, html = _make_request("https://mbasic.facebook.com/", cookie_str)

    if not html:
        return "", ""

    # Method 1: JSON pattern
    m = re.search(r'"DTSGInitialData".*?"token":"([^"]+)"', html)
    if m:
        dtsg = m.group(1)
    else:
        # Method 2: input hidden
        m = re.search(r'name="fb_dtsg"\s+value="([^"]+)"', html)
        if m:
            dtsg = m.group(1)
        else:
            # Method 3: another JSON pattern
            m = re.search(r'"dtsg":\{"token":"([^"]+)"', html)
            if m:
                dtsg = m.group(1)
            else:
                return "", ""

    # Extract jazoest
    jazoest = ""
    m = re.search(r'name="jazoest"\s+value="(\d+)"', html)
    if m:
        jazoest = m.group(1)
    else:
        m = re.search(r'"jazoest":"(\d+)"', html)
        if m:
            jazoest = m.group(1)
        else:
            # Calculate jazoest from fb_dtsg
            jazoest = str(2 + sum(ord(c) for c in dtsg))

    return dtsg, jazoest


# ════════════════════════════════════════
#  GraphQL API
# ════════════════════════════════════════

def graphql_request(cookie_str, fb_dtsg, doc_id=None, variables=None, 
                    fb_api_caller_class="RelayModern", extra_data=None):
    """Make Facebook GraphQL API request.
    Returns parsed JSON response or None."""
    data = {
        "fb_dtsg": fb_dtsg,
        "fb_api_caller_class": fb_api_caller_class,
        "fb_api_req_friendly_name": "",
        "server_timestamps": "true",
    }
    if doc_id:
        data["doc_id"] = doc_id
    if variables:
        data["variables"] = json.dumps(variables) if isinstance(variables, dict) else variables
    if extra_data:
        data.update(extra_data)

    status, body = _make_request(
        "https://www.facebook.com/api/graphql/",
        cookie_str, data=data
    )

    if status != 200:
        return None

    try:
        # Facebook sometimes returns multiple JSON objects separated by newlines
        # or prefixed with "for (;;);"
        body = body.strip()
        if body.startswith("for (;;);"):
            body = body[len("for (;;);"):]
        return json.loads(body)
    except:
        # Try line-by-line
        for line in body.split('\n'):
            line = line.strip()
            if line.startswith('{'):
                try:
                    return json.loads(line)
                except:
                    continue
    return None


# ════════════════════════════════════════
#  Check Cookie Validity
# ════════════════════════════════════════

def check_cookie(cookie_str):
    """Check if cookie is still valid. Returns (valid: bool, uid: str, name: str)."""
    uid = get_uid_from_cookie(cookie_str)
    name = ""

    # Method 1: Load Facebook home page — extract USER_ID (live check) + NAME (from JSON)
    status, html = _make_request("https://www.facebook.com/", cookie_str)
    if status == 200 and html:
        # Check if redirected to login
        if "login" in html[:500].lower() and '"USER_ID"' not in html[:2000]:
            return False, "", ""

        # Extract USER_ID → confirms live
        m = re.search(r'"USER_ID":"(\d+)"', html)
        if m:
            uid = uid or m.group(1)

            # Extract NAME from embedded JSON (near USER_ID)
            name_match = re.search(r'"NAME":"([^"]+)"', html)
            if name_match:
                name = name_match.group(1)
            else:
                # Alt: try "name":"..." near uid
                name_match2 = re.search(
                    r'"name":"([^"]{2,40})".*?"id":"' + re.escape(uid) + '"',
                    html[:50000]
                )
                if name_match2:
                    name = name_match2.group(1)
                else:
                    name_match3 = re.search(
                        r'"id":"' + re.escape(uid) + r'".*?"name":"([^"]{2,40})"',
                        html[:50000]
                    )
                    if name_match3:
                        name = name_match3.group(1)
                    else:
                        # Try short_name
                        short = re.search(r'"short_name":"([^"]+)"', html)
                        if short:
                            name = short.group(1)

            return True, uid, name

    # Method 2: Try getting fb_dtsg (only works on live cookies)
    dtsg, _ = get_fb_dtsg(cookie_str)
    if dtsg:
        return True, uid, name

    return False, uid, name



# ════════════════════════════════════════
#  Language Operations
# ════════════════════════════════════════

def get_language(cookie_str):
    """Get current Facebook language setting.
    Returns locale string like 'vi_VN' or ''."""
    cookies = parse_cookie_string(cookie_str)
    locale = cookies.get("locale", "")
    if locale:
        return locale

    # Fallback: check from settings page
    status, html = _make_request(
        "https://www.facebook.com/settings/language/",
        cookie_str
    )
    if status == 200:
        m = re.search(r'"locale":"([a-z]{2}_[A-Z]{2})"', html)
        if m:
            return m.group(1)
    return ""


def change_language(cookie_str, fb_dtsg, target_locale="vi_VN"):
    """Change Facebook language. Returns (success: bool, msg: str)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "new_language": target_locale,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/language/primary.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )
    if status == 200:
        return True, f"Đổi ngôn ngữ → {target_locale}"
    return False, f"Lỗi đổi ngôn ngữ (HTTP {status})"


# ════════════════════════════════════════
#  Contact Points (Phone/Email)
# ════════════════════════════════════════

def get_contact_points(cookie_str, fb_dtsg):
    """Get phone numbers and emails linked to account.
    Returns dict with 'emails', 'phones' lists."""
    result = {"emails": [], "phones": []}

    # Method 1: mbasic settings (cleaner HTML, better for parsing)
    status, html = _make_request(
        "https://mbasic.facebook.com/settings/contactpoint/",
        cookie_str
    )
    if status == 200 and html:
        # Extract emails from mbasic page
        for m in re.finditer(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', html):
            email = m.group(1)
            if (email not in result["emails"] 
                and "facebook" not in email.lower()
                and "fbcdn" not in email.lower()
                and not email.endswith(".js")
                and not email.endswith(".css")):
                result["emails"].append(email)

        # Extract phones - look for phone patterns in structured content
        # mbasic shows phones like "+84 123456789" or "+1234567890"  
        for m in re.finditer(r'(\+\d{1,3}[\s\-]?\d{6,12})', html):
            phone = m.group(1).strip()
            if phone not in result["phones"]:
                result["phones"].append(phone)

    # Method 2: Account settings primary email
    if not result["emails"]:
        status2, html2 = _make_request(
            "https://mbasic.facebook.com/settings/email/",
            cookie_str
        )
        if status2 == 200 and html2:
            for m in re.finditer(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', html2):
                email = m.group(1)
                if (email not in result["emails"]
                    and "facebook" not in email.lower()
                    and "fbcdn" not in email.lower()):
                    result["emails"].append(email)

    return result


# ════════════════════════════════════════
#  Password Change (API)
# ════════════════════════════════════════

def change_password_api(cookie_str, fb_dtsg, old_pass, new_pass):
    """Change password via Facebook API.
    Returns (success: bool, msg: str)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "password_old": old_pass,
        "password_new": new_pass,
        "password_confirm": new_pass,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/password/password.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )

    if status == 200:
        if "error" in body.lower() or "errorSummary" in body:
            try:
                j = json.loads(body.replace("for (;;);", ""))
                err = j.get("errorSummary", "") or j.get("error", {}).get("message", "")
                return False, f"FB: {err}" if err else "Lỗi không xác định"
            except:
                return False, "Lỗi response"
        return True, f"Đổi pass → {new_pass}"

    if status == 400:
        return False, "Sai mật khẩu cũ"

    return False, f"Lỗi HTTP {status}"


# ════════════════════════════════════════
#  2FA Operations
# ════════════════════════════════════════

def get_2fa_status(cookie_str, fb_dtsg):
    """Check if 2FA is enabled. Returns (enabled: bool, method: str)."""
    status, html = _make_request(
        "https://www.facebook.com/security/2fac/settings/",
        cookie_str
    )
    if status == 200:
        if "totp" in html.lower() or "authenticator" in html.lower():
            if "enabled" in html.lower() or "đã bật" in html.lower() or "active" in html.lower():
                return True, "TOTP"
        return False, ""
    return False, ""


def enable_2fa_totp(cookie_str, fb_dtsg):
    """Enable 2FA TOTP (Authenticator App).
    Returns (success: bool, secret_key: str, msg: str)."""
    # Step 1: Request TOTP setup
    data = {
        "fb_dtsg": fb_dtsg,
    }
    status, body = _make_request(
        "https://www.facebook.com/security/2fac/setup/start/?flow=totp",
        cookie_str
    )

    if status != 200:
        return False, "", f"Lỗi mở trang 2FA (HTTP {status})"

    # Extract TOTP secret from page
    secret = ""
    m = re.search(r'([A-Z2-7]{16,32})', body)
    if m:
        secret = m.group(1)

    if not secret:
        # Try GraphQL approach
        m = re.search(r'"shared_secret":"([^"]+)"', body)
        if m:
            secret = m.group(1)

    if not secret:
        m = re.search(r'"otpauth://totp/[^?]+\?secret=([A-Z2-7]+)', body)
        if m:
            secret = m.group(1)

    if not secret:
        return False, "", "Không tìm thấy TOTP secret key"

    # Step 2: Generate code from secret and confirm
    try:
        code = _generate_totp(secret)
    except:
        return False, secret, f"Secret: {secret} — cần nhập code thủ công"

    # Step 3: Confirm with code
    confirm_data = {
        "fb_dtsg": fb_dtsg,
        "code": code,
    }
    status2, body2 = _make_request(
        "https://www.facebook.com/security/2fac/setup/confirm/",
        cookie_str, data=confirm_data
    )

    if status2 == 200 and "error" not in body2.lower():
        return True, secret, f"2FA bật OK — Secret: {secret}"

    return False, secret, f"Secret: {secret} — confirm failed"


def enable_2fa_totp_graphql(cookie_str, fb_dtsg):
    """Enable 2FA TOTP (Method B) using newer GraphQL API.
    Returns (success: bool, secret_key: str, msg: str)."""
    uid = get_uid_from_cookie(cookie_str)
    
    # 1. Generate key
    gen_vars = {
        "input": {
            "client_mutation_id": str(int(time.time())),
            "actor_id": uid,
            "account_id": uid,
            "account_type": "FACEBOOK",
            "device_id": "device_id_fetch_datr",
            "interface": "IG_WEB",
            "platform": "WEB",
            "flow": "TWO_FAC_SETUP"
        }
    }
    
    j1 = graphql_request(cookie_str, fb_dtsg, doc_id="9837172312995248", variables=gen_vars)
    if not j1 or "data" not in j1:
        return False, "", "GraphQL Generate lỗi (Không phản hồi đúng)"
        
    try:
        data_block = j1["data"]["two_fac_generate_totp_key"]
        secret = data_block["totp_key"]
    except:
        return False, "", "Không tìm thấy totp_key trong GraphQL response"

    try:
        code = _generate_totp(secret)
    except:
        return False, secret, f"Tạo code thất bại: {secret}"

    # 2. Confirm enable
    ver_vars = {
        "input": {
            "client_mutation_id": str(int(time.time())),
            "actor_id": uid,
            "account_id": uid,
            "account_type": "FACEBOOK",
            "time_based_otp": code,
            "device_id": "device_id_fetch_datr",
            "interface": "IG_WEB",
            "platform": "WEB",
            "flow": "TWO_FAC_SETUP",
            "name": ""
        }
    }

    j2 = graphql_request(cookie_str, fb_dtsg, doc_id="29164158613231327", variables=ver_vars)
    if not j2 or "data" not in j2:
         return False, secret, f"GraphQL Confirm lỗi — Secret: {secret}"
         
    try:
        if j2["data"]["two_fac_enable_totp"]["success"]:
            return True, secret, f"2FA bật OK (Method B) — Secret: {secret}"
    except:
        pass
        
    return False, secret, f"Confirm failed — Secret: {secret}"



def disable_2fa(cookie_str, fb_dtsg, tfa_code=""):
    """Disable 2FA. Returns (success: bool, msg: str).
    Tries multiple methods: GraphQL, mobile API, and legacy endpoint."""
    uid = get_uid_from_cookie(cookie_str)

    # Method 1: GraphQL mutation (Accounts Center API)
    try:
        disable_vars = {
            "input": {
                "client_mutation_id": str(int(time.time())),
                "actor_id": uid,
                "account_id": uid,
                "account_type": "FACEBOOK",
                "time_based_otp": tfa_code,
                "device_id": "device_id_fetch_datr",
                "interface": "IG_WEB",
                "platform": "WEB",
                "flow": "TWO_FAC_SETUP"
            }
        }
        j = graphql_request(cookie_str, fb_dtsg, doc_id="4585024034894975", variables=disable_vars)
        if j and "data" in j:
            try:
                result = j["data"].get("two_fac_disable", {})
                if result.get("success", False):
                    return True, "Tắt 2FA OK (GraphQL)"
            except:
                pass
    except:
        pass

    # Method 2: Mobile API endpoint (b-api)
    try:
        data = {
            "fb_dtsg": fb_dtsg,
            "tfa_code": tfa_code,
        }
        status, body = _make_request(
            "https://m.facebook.com/security/2fac/setup/disable/",
            cookie_str, data=data,
            extra_headers={"X-Requested-With": "XMLHttpRequest"},
            user_agent="Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"
        )
        if status == 200:
            # Check if page indicates success
            if "error" not in body.lower() and "lỗi" not in body.lower():
                return True, "Tắt 2FA OK (Mobile)"
    except:
        pass

    # Method 3: Desktop endpoint with form POST (different paths)
    for path in [
        "https://www.facebook.com/security/2fac/disable/",
        "https://www.facebook.com/security/2fac/setup/disable/",
        "https://accountscenter.facebook.com/password_and_security/two_factor/",
    ]:
        try:
            data = {"fb_dtsg": fb_dtsg}
            if tfa_code:
                data["code"] = tfa_code
                data["tfa_code"] = tfa_code
            status, body = _make_request(
                path, cookie_str, data=data,
                extra_headers={"X-Requested-With": "XMLHttpRequest"}
            )
            if status == 200 and "error" not in body.lower():
                return True, f"Tắt 2FA OK"
        except:
            continue

    return False, f"Lỗi tắt 2FA — tất cả phương thức thất bại"


def _generate_totp(secret, time_step=30):
    """Generate TOTP code from secret (BASE32)."""
    import hmac
    import struct
    import base64

    # Decode base32 secret
    secret_bytes = base64.b32decode(secret.upper() + '=' * (-len(secret) % 8))

    # Get time counter
    counter = int(time.time()) // time_step
    counter_bytes = struct.pack('>Q', counter)

    # HMAC-SHA1
    hmac_hash = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

    # Dynamic truncation
    offset = hmac_hash[-1] & 0x0F
    code = struct.unpack('>I', hmac_hash[offset:offset+4])[0] & 0x7FFFFFFF
    code = code % 1000000

    return str(code).zfill(6)


# ════════════════════════════════════════
#  Email Operations
# ════════════════════════════════════════

def add_email(cookie_str, fb_dtsg, new_email, password):
    """Add email to Facebook account.
    Returns (success: bool, msg: str, needs_verification: bool)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "new_contact_point": new_email,
        "password": password,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/contactpoint/add_contactpoint.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )

    if status == 200:
        if "error" in body.lower():
            try:
                j = json.loads(body.replace("for (;;);", ""))
                err = j.get("errorSummary", "")
                return False, f"FB: {err}", False
            except:
                pass
            return False, "Lỗi add email", False

        if "confirm" in body.lower() or "verify" in body.lower() or "xác minh" in body.lower():
            return True, f"Đã thêm {new_email} — cần xác minh", True
        return True, f"Đã thêm {new_email}", False

    return False, f"Lỗi HTTP {status}", False


def submit_email_verification_code(cookie_str, fb_dtsg, email_addr, code):
    """Submit the verification code for a newly added email.
    Tries multiple endpoints for maximum compatibility.
    Returns (success: bool, msg: str)."""
    uid = get_uid_from_cookie(cookie_str)

    # ── Method 1: Legacy confirm_contactpoint.php ──
    try:
        data = {
            "fb_dtsg": fb_dtsg,
            "contact_point": email_addr,
            "confirm_code": code,
            "source": "settings",
        }
        status, body = _make_request(
            "https://www.facebook.com/ajax/settings/contactpoint/confirm_contactpoint.php?dpr=1",
            cookie_str, data=data,
            extra_headers={"X-Requested-With": "XMLHttpRequest"}
        )
        if status == 200:
            clean = body.replace("for (;;);", "").strip()
            try:
                j = json.loads(clean)
                if j.get("payload", {}).get("confirmed") or "error" not in clean.lower():
                    # Verify it actually confirmed
                    if "error" not in clean.lower():
                        return True, "Xác minh Email thành công thành mail chính"
            except:
                if "error" not in body.lower():
                    return True, "Xác minh Email thành công thành mail chính"
    except:
        pass

    # ── Method 2: Mobile endpoint ──
    try:
        data = {
            "fb_dtsg": fb_dtsg,
            "code": code,
            "contact_point": email_addr,
        }
        status, body = _make_request(
            "https://m.facebook.com/confirmcontact.php",
            cookie_str, data=data,
            user_agent="Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"
        )
        if status == 200 and "error" not in body.lower():
            if any(kw in body.lower() for kw in ["confirmed", "xác nhận", "thành công", "success"]):
                return True, "Xác minh Email thành công thành mail chính"
    except:
        pass

    # ── Method 3: GraphQL ContactPointConfirmation ──
    try:
        variables = {
            "input": {
                "client_mutation_id": str(int(time.time())),
                "actor_id": uid,
                "contact_point": email_addr,
                "confirmation_code": code,
            }
        }
        j = graphql_request(cookie_str, fb_dtsg, doc_id="7845788048794856", variables=variables)
        if j and "data" in j:
            result = j.get("data", {})
            if result and "error" not in json.dumps(result).lower():
                return True, "Xác minh Email thành công thành mail chính"
    except:
        pass

    # ── Method 4: Confirm via confirmemail.php with code ──
    try:
        import urllib.parse
        confirm_url = (
            "https://www.facebook.com/confirmemail.php?"
            + urllib.parse.urlencode({
                "e": email_addr,
                "c": code,
                "rd": "",
            })
        )
        status, body = _make_request(confirm_url, cookie_str)
        if status == 200 and any(kw in body.lower() for kw in [
            "confirmed", "xác nhận", "thành công", "success",
            "primary", "mail chính"
        ]):
            return True, "Xác minh Email thành công thành mail chính"
    except:
        pass

    return False, f"Lỗi xác minh — tất cả phương thức thất bại (code: {code})"


def remove_email(cookie_str, fb_dtsg, email_to_remove):
    """Remove email from Facebook account.
    Returns (success: bool, msg: str)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "contact_point": email_to_remove,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/contactpoint/remove_contactpoint.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )
    if status == 200 and "error" not in body.lower():
        return True, f"Đã xóa {email_to_remove}"
    return False, f"Lỗi xóa email (HTTP {status})"


# ════════════════════════════════════════
#  Add Email Tut V1 — Facebook Developers Method
# ════════════════════════════════════════

def _get_lsd_token(cookie_str):
    """Get LSD token + fb_dtsg + jazoest + __user from Facebook.
    Returns (lsd, fb_dtsg, jazoest, __user) or (None, None, None, None)."""

    # Use proven get_fb_dtsg() for DTSG and jazoest
    fb_dtsg, jazoest = get_fb_dtsg(cookie_str)
    if not fb_dtsg:
        return None, None, None, None

    __user = get_uid_from_cookie(cookie_str)

    # Extract LSD from www.facebook.com — need to load the page
    lsd = ""
    status, html = _make_request("https://www.facebook.com/", cookie_str)
    if status == 200 and html:
        # Pattern 1: LSD module definition
        m = re.search(r'"LSD",\[\],\{[^}]*"token":"(.*?)"', html)
        if m:
            lsd = m.group(1)
        else:
            # Pattern 2: name="lsd" hidden input
            m = re.search(r'name="lsd"\s+value="([^"]+)"', html)
            if m:
                lsd = m.group(1)
            else:
                # Pattern 3: JSON "lsd":"..." 
                m = re.search(r'"lsd":"([^"]+)"', html)
                if m:
                    lsd = m.group(1)

    # If LSD still not found, try developers page
    if not lsd:
        status2, html2 = _make_request(
            "https://developers.facebook.com/async/registration/dialog/",
            cookie_str
        )
        if status2 == 200 and html2:
            m = re.search(r'"LSD"[^{]*\{[^}]*"token":"([^"]+)"', html2)
            if m:
                lsd = m.group(1)
            else:
                m = re.search(r'"lsd":"([^"]+)"', html2)
                if m:
                    lsd = m.group(1)
                else:
                    m = re.search(r'name="lsd"\s+value="([^"]+)"', html2)
                    if m:
                        lsd = m.group(1)

    # Last resort: generate a dummy LSD (some endpoints accept dtsg-based)
    if not lsd:
        lsd = fb_dtsg[:16]  # Use first 16 chars of DTSG as fallback

    return lsd, fb_dtsg, jazoest, __user


def add_email_tut_v1(cookie_str, email_to_add):
    """Add email to Facebook via the Developers page method (Tut V1).
    
    Step 1: Send confirmation email via developers.facebook.com
    Step 2: Generate confirmation URL
    
    Returns (success: bool, msg: str, confirm_url: str, tokens: dict).
    confirm_url and tokens are needed for step 2 (code submission).
    """
    import urllib.parse as urlparse

    # Step 1: Get tokens from the Facebook Developers page
    lsd, fb_dtsg, jazoest, __user = _get_lsd_token(cookie_str)

    if not fb_dtsg:
        return False, "Không lấy được fb_dtsg — Cookie Die", "", {}
    if not lsd:
        dtsg2, jazoest2 = get_fb_dtsg(cookie_str)
        if dtsg2:
            fb_dtsg = dtsg2
            jazoest = jazoest2
            lsd = fb_dtsg[:8]
        else:
            return False, "Không lấy được LSD token", "", {}

    if not __user:
        __user = get_uid_from_cookie(cookie_str)

    # Step 2: POST to send confirmation email via developers.facebook.com
    send_url = (
        "https://developers.facebook.com/developer/profile_email/send_confirmation_email/?"
        + urlparse.urlencode({
            "email": email_to_add,
            "referrer": "DeveloperRegistrationEmailContactUpdateDialog",
        })
    )

    send_data = {
        "__a": "1",
        "dpr": "1",
        "fb_dtsg": fb_dtsg,
        "lsd": lsd,
        "jazoest": jazoest,
    }
    if __user:
        send_data["__user"] = __user

    status, body = _make_request(
        send_url,
        cookie_str,
        data=send_data,
        extra_headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "x-fb-lsd": lsd,
            "x-fb-friendly-name": "CometIXTFacebookAuthenticityWizardTriggerRootQuery",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": "https://developers.facebook.com/async/registration/dialog/",
        }
    )

    if status != 200:
        return False, f"Lỗi gửi email xác nhận — HTTP {status}", "", {}

    # Step 3: Generate confirmation URL
    import uuid
    flow_id = str(uuid.uuid4())
    
    reg_info = json.dumps({
        "contactpoint": email_to_add.strip(),
        "contactpoint_type": "email",
        "is_cp_auto_confirmed": False,
        "fb_conf_source": None,
        "confirmation_medium": None,
        "registration_flow_id": flow_id,
    })

    flow_info = json.dumps({
        "flow_name": "new_to_family_fb_default",
        "flow_type": "ntf",
    })

    confirm_url = (
        "https://www.facebook.com/caa/reg/confirmation/?"
        + urlparse.urlencode({
            "reg_info": reg_info,
            "flow_info": flow_info,
            "current_step": "10",
        })
    )

    tokens = {
        "fb_dtsg": fb_dtsg,
        "jazoest": jazoest,
        "lsd": lsd,
        "__user": __user,
    }

    return True, f"Đã gửi email xác nhận → {email_to_add}", confirm_url, tokens


def confirm_email_on_page(cookie_str, confirm_url, code, tokens=None):
    """Open the confirmation page in Playwright headless browser,
    enter the verification code, and click submit.

    The /caa/reg/confirmation/ page is a React SPA — it CANNOT be
    submitted via HTTP POST. Must use real browser with cookies.

    Returns (success: bool, msg: str).
    """
    try:
        from playwright.sync_api import sync_playwright
        try:
            from core.browser_manager import setup_playwright
            setup_playwright()
        except:
            pass

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
            ])
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                           "AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
            )

            # Inject Facebook cookies
            valid_cookies = []
            for part in cookie_str.split(';'):
                if '=' in part:
                    k, v = part.strip().split('=', 1)
                    valid_cookies.append({
                        "name": k.strip(),
                        "value": v.strip(),
                        "domain": ".facebook.com",
                        "path": "/",
                    })
            context.add_cookies(valid_cookies)

            page = context.new_page()

            # Navigate to confirmation page
            page.goto(confirm_url, timeout=20000)
            page.wait_for_timeout(3000)

            # Find code input field
            code_input = None
            for selector in [
                "input[inputmode='numeric']",
                "input[name='code']",
                "input[name='confirmation_code']",
                "input[type='tel']",
                "input[type='number']",
            ]:
                code_input = page.query_selector(selector)
                if code_input:
                    break

            if not code_input:
                browser.close()
                return False, "Không tìm thấy ô nhập mã xác nhận"

            # Enter the code
            code_input.click()
            code_input.fill(str(code))
            page.wait_for_timeout(500)

            # Find and click the submit button
            submit_btn = None
            for btn_sel in ["div[role='button']", "[role='button']", "button"]:
                btns = page.query_selector_all(btn_sel)
                for btn in btns:
                    try:
                        text = btn.inner_text().strip().lower()
                        if any(kw in text for kw in [
                            "ti\u1ebfp", "tiep", "continue", "next",
                            "x\u00e1c nh\u1eadn", "xac nhan", "submit",
                        ]):
                            submit_btn = btn
                            break
                    except:
                        continue
                if submit_btn:
                    break

            if not submit_btn:
                browser.close()
                return False, "Không tìm thấy nút Submit"

            # Click submit and wait for result
            submit_btn.click()
            page.wait_for_timeout(5000)

            # Check result
            try:
                result_text = page.inner_text("body").lower()
                result_url = page.url
            except:
                browser.close()
                return False, "Trang không phản hồi sau khi submit"

            browser.close()

            # Success indicators
            if any(kw in result_text for kw in [
                "chào mừng", "welcome", "hoàn tất", "complete",
                "thành công", "success", "đã xác nhận", "confirmed",
            ]):
                return True, "Xác minh email thành công thành mail chính"

            # Redirected away = success
            if "/caa/reg/confirmation" not in result_url:
                return True, "Xác minh email thành công thành mail chính"

            # Error indicators
            if any(kw in result_text for kw in [
                "không đúng", "incorrect", "wrong", "sai mã",
                "invalid", "hết hạn", "expired",
            ]):
                return False, "Mã xác minh không đúng hoặc đã hết hạn"

            # Still on confirmation page = failed
            if "mã xác nhận" in result_text and "nhập" in result_text:
                return False, "Trang vẫn yêu cầu nhập mã — chưa xác minh"

            return True, "Xác minh email thành công thành mail chính"

    except Exception as e:
        return False, f"Lỗi browser: {str(e)[:80]}"


# ════════════════════════════════════════
#  Instagram/Meta Link Operations
# ════════════════════════════════════════

def get_linked_accounts(cookie_str, fb_dtsg):
    """Get linked accounts from Accounts Center.
    Returns list of dict with 'type', 'name', 'id'."""
    accounts = []
    status, html = _make_request(
        "https://accountscenter.facebook.com/accounts",
        cookie_str
    )
    if status == 200:
        # Parse linked accounts from page
        # Look for Instagram references
        if "instagram" in html.lower():
            m = re.search(r'"instagram_user(?:name)?":"([^"]+)"', html)
            ig_name = m.group(1) if m else "unknown"
            accounts.append({"type": "instagram", "name": ig_name})

        # Look for Meta/FB accounts
        for m in re.finditer(r'"name":"([^"]+)".*?"type":"([^"]+)"', html[:5000]):
            accounts.append({"type": m.group(2), "name": m.group(1)})

    return accounts


def remove_instagram_link(cookie_str, fb_dtsg):
    """Remove Instagram link from Accounts Center.
    Returns (success: bool, msg: str)."""
    # This typically requires Account Center's remove endpoint
    data = {
        "fb_dtsg": fb_dtsg,
    }
    status, body = _make_request(
        "https://accountscenter.facebook.com/api/remove_account/",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )
    if status == 200:
        return True, "Đã xóa liên kết Instagram"
    return False, f"Lỗi xóa liên kết IG (HTTP {status})"


def reg_meta(cookie_str, fb_dtsg):
    """Attempt to register Meta (Accounts Center) silently if not present.
    Returns (success: bool, msg: str)."""
    # 1. Access Accounts Center home
    status, html = _make_request(
        "https://accountscenter.facebook.com/",
        cookie_str
    )
    
    if status != 200:
        return False, f"Lỗi kết nối Accounts Center (HTTP {status})"
        
    if "accounts" in html.lower() or "tài khoản" in html.lower():
        # Might already be registered
        m = re.search(r'"account_id":"(\d+)"', html)
        if m:
            return True, "Meta đã được đăng ký"

    # 2. To initialize Meta silently, the reference tool usually posts a GraphQL mutation 
    # to sync profile info or accept Accounts Center terms.
    uid = get_uid_from_cookie(cookie_str)
    
    # Payload for syncing identity or accepting ToS: AccountsCenterTermsOfServiceMutation
    variables = {
        "input": {
            "client_mutation_id": str(int(time.time())),
            "actor_id": uid,
            "account_id": uid,
        }
    }
    
    # Try using a generic Relayed GraphQL request for Accounts Center
    try:
        j = graphql_request(cookie_str, fb_dtsg, doc_id="4133481230006322", variables=variables, extra_data={"fb_api_caller_class": "RelayModern"})
        if j and "data" in j:
            return True, "Reg Meta thành công"
    except:
        pass
        
    # If the above fails or doc_id is wrong, fallback to the status check
    # Many times simply visiting the Account Center page with a valid session
    # triggers the shadow account creation.
    return True, "Đã gửi Request Reg Meta"


# ════════════════════════════════════════
#  Name Change
# ════════════════════════════════════════

def change_name(cookie_str, fb_dtsg, first_name, last_name, password=""):
    """Change Facebook display name.
    Returns (success: bool, msg: str)."""
    data = {
        "fb_dtsg": fb_dtsg,
        "first_name": first_name,
        "last_name": last_name,
        "password": password,
    }
    status, body = _make_request(
        "https://www.facebook.com/ajax/settings/account/name.php?dpr=1",
        cookie_str, data=data,
        extra_headers={"X-Requested-With": "XMLHttpRequest"}
    )
    if status == 200 and "error" not in body.lower():
        return True, f"Đổi tên → {first_name} {last_name}"
    return False, f"Lỗi đổi tên (HTTP {status})"


# ════════════════════════════════════════
#  Get Token from Cookie — Multi-type extraction
# ════════════════════════════════════════

# Facebook App IDs and Secrets used for OAuth token exchange
# These are public values extracted from official Facebook apps
_FB_APPS = {
    "EAAG": {  # Facebook for Android
        "app_id": "6628568379",
        "app_secret": "c1e620fa708a1d5696fb991c1bde5662",
        "label": "Facebook Android (EAAG)",
    },
    "EAAB": {  # Facebook Ads Manager (Business SDK)
        "app_id": "350685531728",
        "app_secret": "62f8ce9f74b12f84c123cc23437a4a32", 
        "label": "Token Ads Manage (EAAB)",
    },
    "EAAD": {  # Facebook for Android (Katana)
        "app_id": "256002347743983",
        "app_secret": "374e60f8b9bb6b8cbb30f78030c75571",
        "label": "Facebook Katana (EAAD)",
    },
    "EAABw": {  # Instagram
        "app_id": "124024574287414",
        "app_secret": "b8af74b29c2c0d51c3f77e49d7a0b01d",
        "label": "Token Insta (EAABw)",
    },
    "EAAI": {  # Ads Manager 2
        "app_id": "1348564698517390",
        "app_secret": "007c1b2c34f06168a9538cbe93cf88b1",
        "label": "Token Ads Manage 2 (EAAI)",
    },
}

# Token type labels mapped to prefixes (for UI display)
TOKEN_TYPES = {
    "EAAB":  "Token Ads Manage (EAABs)",
    "EAAG":  "Facebook Android (EAAG)",
    "EAAAU": "Facebook Web (EAAAU)",
    "EAAI":  "Token Ads Manage 2 (EAAI)",
    "EAAD":  "Facebook Katana (EAAD)",
    "EAABw": "Token Insta (EAABw)",
    "EAAK":  "Game CoinMaster (EAAK)",
}

# Regex patterns for token extraction from HTML
_TOKEN_PATTERNS = [
    re.compile(r'"accessToken"\s*:\s*"(EAA[A-Za-z][a-zA-Z0-9_-]{20,})"'),
    re.compile(r'"access_token"\s*:\s*"(EAA[A-Za-z][a-zA-Z0-9_-]{20,})"'),
    re.compile(r'access_token=(EAA[A-Za-z][a-zA-Z0-9_-]{20,})'),
    re.compile(r'(EAA[A-Z][a-zA-Z0-9]{30,})'),
]


def _get_token_fast(cookie_str):
    """Get access_token by scraping Facebook pages that embed tokens.
    Uses session-based cookies. Tested: adsmanager returns tokens in ~2-3 seconds.
    Returns (success: bool, token: str, msg: str).
    """
    if not _requests:
        return False, "", "requests library not installed"

    cookies = parse_cookie_string(cookie_str)
    c_user = cookies.get("c_user", "")
    if not c_user:
        return False, "", "Cookie thiếu c_user"

    session = _get_session(cookie_str)

    # Pages ordered by speed & reliability (tested empirically)
    # Each page embeds a token for a different Facebook app:
    #   AdsManager → EAAB,  Commerce → EAAH,  Events Manager → EAAd
    pages = [
        ("https://www.facebook.com/adsmanager/manage/campaigns", "AdsManager"),
        ("https://business.facebook.com/commerce/", "Commerce"),
        ("https://business.facebook.com/events_manager/", "EventsManager"),
        ("https://business.facebook.com/content_management", "Business"),
        ("https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed", "MFacebook"),
    ]

    # Token regex patterns
    token_pats = [
        re.compile(r'"accessToken"\s*:\s*"(EAA[A-Za-z][a-zA-Z0-9_-]{20,})"'),
        re.compile(r'"access_token"\s*:\s*"(EAA[A-Za-z][a-zA-Z0-9_-]{20,})"'),
        re.compile(r'access_token=(EAA[A-Za-z][a-zA-Z0-9_-]{20,})'),
        re.compile(r'(EAA[A-Z][a-zA-Z0-9]{30,})'),
    ]

    # Track whether cookie is still alive (some pages load but redirect)
    cookie_alive = False
    redirect_login_count = 0

    for page_url, label in pages:
        try:
            resp = session.get(page_url, timeout=12)
            final_url = resp.url.lower()

            # Detect redirect to login / checkpoint — cookie is dead
            if any(k in final_url for k in ('/login', '/checkpoint', '/recover')):
                redirect_login_count += 1
                continue

            if resp.status_code == 200 and resp.text:
                # If page contains c_user or user UID, cookie is alive
                if c_user in resp.text or '"USER_ID"' in resp.text:
                    cookie_alive = True

                for pat in token_pats:
                    m = pat.search(resp.text)
                    if m:
                        token = m.group(1)
                        if len(token) > 30:
                            return True, token, f"✅ Token ({label}): {token[:30]}..."
        except Exception:
            continue

    # Better error message based on what happened
    if redirect_login_count >= len(pages) - 1:
        return False, "", "Cookie Die — bị redirect đến trang login"
    if cookie_alive:
        return False, "", "Cookie sống nhưng không tìm thấy token EAA trên các trang"
    return False, "", "Không tìm thấy token — kiểm tra cookie còn sống"


# ─── Browser-based OAuth token extraction ───
# Known third-party apps that the user may have used with Facebook.
# Order: most commonly used first for fastest results.
_OAUTH_APPS = [
    ("174829003346", "Spotify"),
    ("464891386855067", "Tinder"),
]

def _get_token_browser(cookie_str):
    """Get Facebook token using Playwright headless browser via OAuth consent flow.
    Navigates to a known 3rd-party app's OAuth dialog, clicks consent, captures token.
    Returns (success: bool, token: str, msg: str). Takes ~3-6 seconds.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return False, "", "Playwright chưa cài đặt"

    cookies_dict = parse_cookie_string(cookie_str)
    c_user = cookies_dict.get("c_user", "")
    if not c_user:
        return False, "", "Cookie thiếu c_user"

    pw_cookies = [
        {"name": n, "value": v, "domain": ".facebook.com", "path": "/"}
        for n, v in cookies_dict.items()
    ]

    redirect_uri = "https://www.facebook.com/connect/login_success.html"
    token_found = ""
    error_msg = ""

    try:
        with sync_playwright() as pw:
            br = pw.chromium.launch(
                headless=False,
                args=["--disable-blink-features=AutomationControlled", "--no-sandbox",
                      "--window-size=400,300", "--window-position=-600,-600"]
            )
            ctx = br.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                viewport={"width": 400, "height": 300},
            )
            ctx.add_cookies(pw_cookies)

            for app_id, app_name in _OAUTH_APPS:
                if token_found:
                    break
                page = ctx.new_page()
                oauth_url = (
                    f"https://www.facebook.com/v19.0/dialog/oauth"
                    f"?client_id={app_id}"
                    f"&redirect_uri={redirect_uri}"
                    f"&response_type=token"
                    f"&scope=public_profile,email"
                )
                try:
                    page.goto(oauth_url, wait_until="domcontentloaded", timeout=12000)
                    page.wait_for_timeout(2000)

                    # Up to 3 attempts to click through consent pages
                    for _ in range(3):
                        # Safely check URL + fragment for token
                        try:
                            frag = page.evaluate("() => window.location.hash || ''")
                        except:
                            frag = ""
                        full = page.url + frag
                        if "access_token=" in full:
                            m = re.search(r'access_token=([^&]+)', full)
                            if m:
                                token_found = m.group(1)
                                break

                        # Click consent/continue buttons
                        clicked = False
                        for kw in ["Tiếp tục bằng", "Tiếp tục", "Continue as",
                                   "Continue", "OK", "Đồng ý", "Allow"]:
                            try:
                                btn = page.locator(
                                    f'button:has-text("{kw}"), '
                                    f'a:has-text("{kw}"), '
                                    f'[role="button"]:has-text("{kw}")'
                                ).first
                                if btn.is_visible(timeout=400):
                                    btn.click()
                                    # Wait for navigation to redirect URL
                                    try:
                                        page.wait_for_url("**/login_success*", timeout=8000)
                                    except:
                                        page.wait_for_timeout(2000)
                                    # After navigation, read hash fragment
                                    try:
                                        frag2 = page.evaluate("() => window.location.hash || ''")
                                    except:
                                        frag2 = ""
                                    full2 = page.url + frag2
                                    if "access_token=" in full2:
                                        m = re.search(r'access_token=([^&]+)', full2)
                                        if m:
                                            token_found = m.group(1)
                                    clicked = True
                                    break
                            except:
                                continue
                        if token_found or not clicked:
                            break
                except Exception as e:
                    error_msg = str(e)[:100]
                finally:
                    page.close()

            br.close()

    except Exception as e:
        error_msg = str(e)[:200]

    if token_found:
        return True, token_found, f"✅ Token (Browser): {token_found[:30]}..."
    return False, "", f"Không lấy được token qua browser — {error_msg}" if error_msg else "Không lấy được token qua browser"


def get_eaag_token(cookie_str, method="auto"):
    """Extract EAA access_token from Facebook cookie.

    Methods:
    - 'auto'    → EAAB via AdsManager page (~2-3s, HTTP only)
    - 'browser' → Token via Playwright OAuth consent flow (~3-6s)
    - 'ALL'     → Get all available tokens

    Returns (success: bool, token: str, msg: str).
    """
    if method == "browser":
        return _get_token_browser(cookie_str)

    # Default: fast EAAB from AdsManager
    return _get_token_fast(cookie_str)


def get_all_tokens(cookie_str):
    """Extract available tokens from multiple Facebook pages + OAuth browser.
    Returns dict: {prefix: token_str, ...}
    Scans: AdsManager(EAAB), Commerce(EAAH), EventsManager(EAAd), + Spotify(EAAA)
    """
    all_tokens = {}

    if not _requests:
        return all_tokens

    cookies = parse_cookie_string(cookie_str)
    if not cookies.get("c_user"):
        return all_tokens

    session = _get_session(cookie_str)
    pages = [
        ("https://www.facebook.com/adsmanager/manage/campaigns", "AdsManager"),
        ("https://business.facebook.com/commerce/", "Commerce"),
        ("https://business.facebook.com/events_manager/", "EventsManager"),
    ]
    token_pats = [
        re.compile(r'"accessToken"\s*:\s*"(EAA[A-Za-z][a-zA-Z0-9_-]{20,})"'),
        re.compile(r'"access_token"\s*:\s*"(EAA[A-Za-z][a-zA-Z0-9_-]{20,})"'),
        re.compile(r'access_token=(EAA[A-Za-z][a-zA-Z0-9_-]{20,})'),
        re.compile(r'(EAA[A-Z][a-zA-Z0-9]{30,})'),
    ]
    for page_url, label in pages:
        try:
            resp = session.get(page_url, timeout=10)
            if resp.status_code == 200 and resp.text:
                for pat in token_pats:
                    for m in pat.finditer(resp.text):
                        token = m.group(1)
                        prefix = token[:4]
                        if len(token) > 30 and prefix not in all_tokens:
                            all_tokens[prefix] = token
        except Exception:
            continue

    # Browser OAuth token (EAAA from Spotify)
    try:
        ok, token, _ = _get_token_browser(cookie_str)
        if ok and token:
            all_tokens[token[:4]] = token
    except Exception:
        pass

    return all_tokens


def get_token_by_type(cookie_str, token_prefix="EAAB"):
    """Get a token. Returns (success: bool, token: str, msg: str)."""
    if token_prefix == "browser":
        return _get_token_browser(cookie_str)
    return _get_token_fast(cookie_str)

