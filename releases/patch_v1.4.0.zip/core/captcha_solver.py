"""
Global CAPTCHA Solver Module — reCAPTCHA v2 / Enterprise auto-solving.

Providers: 2Captcha (v2 JSON API), OmoCaptcha, Anti-Captcha, CapSolver
Settings:  data/settings.json -> two_captcha_key, omocaptcha_key,
           captcha_provider, captcha_timeout, captcha_retries

Usage from ANY login thread:
    from core.captcha_solver import handle_captcha_on_page
    solved = handle_captcha_on_page(page, status_callback=lambda msg: ...)
"""
import time
import urllib.request
import urllib.parse
import json
import re
import os


# ════════════════════════════════════════
#  Universal JSON API helper
# ════════════════════════════════════════

def _post_json(url, data, timeout=30):
    """POST JSON request and return parsed response dict."""
    payload = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type": "application/json", "Accept": "application/json"}
    )
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode("utf-8"))


# ════════════════════════════════════════
#  CaptchaSolver — Multi-Provider
# ════════════════════════════════════════

class CaptchaSolver:
    """Solve reCAPTCHA v2/Enterprise via paid API services."""

    def __init__(self, api_key="", provider="2captcha",
                 timeout=120, retries=2, omocaptcha_key=""):
        self.api_key = api_key.strip()
        self.provider = provider.lower().strip()
        self.timeout = timeout
        self.retries = retries
        self.omocaptcha_key = omocaptcha_key.strip()

    def is_configured(self):
        if self.provider == "omocaptcha":
            return bool(self.omocaptcha_key)
        return bool(self.api_key)

    def solve_recaptcha_v2(self, sitekey, page_url, is_enterprise=False, log=None):
        """Solve reCAPTCHA v2/Enterprise. Returns token string or ''."""
        if not self.is_configured():
            return ""

        for attempt in range(self.retries):
            if attempt > 0 and log:
                log(f"[CAPTCHA] Retry {attempt + 1}/{self.retries}...")
                time.sleep(2)
            try:
                if self.provider == "2captcha":
                    token = self._solve_2captcha_v2(sitekey, page_url, is_enterprise, log)
                elif self.provider == "omocaptcha":
                    token = self._solve_omocaptcha(sitekey, page_url, log)
                elif self.provider == "anti-captcha":
                    token = self._solve_generic_json(
                        "https://api.anti-captcha.com/createTask",
                        "https://api.anti-captcha.com/getTaskResult",
                        self.api_key, sitekey, page_url, is_enterprise, log,
                        enterprise_type="RecaptchaV2EnterpriseTaskProxyless",
                        standard_type="RecaptchaV2TaskProxyless"
                    )
                elif self.provider == "capsolver":
                    token = self._solve_generic_json(
                        "https://api.capsolver.com/createTask",
                        "https://api.capsolver.com/getTaskResult",
                        self.api_key, sitekey, page_url, is_enterprise, log,
                        enterprise_type="ReCaptchaV2EnterpriseTaskProxyLess",
                        standard_type="ReCaptchaV2TaskProxyLess"
                    )
                else:
                    token = self._solve_2captcha_v2(sitekey, page_url, is_enterprise, log)

                if token:
                    return token
            except Exception as e:
                if log:
                    log(f"[CAPTCHA] Error: {str(e)[:80]}")
        return ""

    # ─────────────────────────────────────
    #  2Captcha — New v2 JSON API
    #  Docs: https://2captcha.com/api-docs
    # ─────────────────────────────────────
    def _solve_2captcha_v2(self, sitekey, page_url, is_enterprise, log):
        """Use 2Captcha v2 JSON API (api.2captcha.com)."""
        task_type = "RecaptchaV2EnterpriseTaskProxyless" if is_enterprise else "RecaptchaV2TaskProxyless"

        if log:
            log(f"[CAPTCHA] 2Captcha createTask ({task_type})...")

        # Step 1: createTask
        resp = _post_json("https://api.2captcha.com/createTask", {
            "clientKey": self.api_key,
            "task": {
                "type": task_type,
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        })

        if resp.get("errorId", 1) != 0:
            if log:
                log(f"[CAPTCHA] 2Captcha error: {resp.get('errorCode', 'unknown')}")
            return ""

        task_id = resp.get("taskId")
        if not task_id:
            return ""

        if log:
            log(f"[CAPTCHA] 2Captcha taskId={task_id}, polling...")

        # Step 2: getTaskResult (poll every 5s)
        return self._poll_task_result(
            "https://api.2captcha.com/getTaskResult",
            self.api_key, task_id, log
        )

    # ──────────────────────────────────────
    #  OmoCaptcha API
    #  Docs: https://docs.omocaptcha.com
    # ──────────────────────────────────────
    def _solve_omocaptcha(self, sitekey, page_url, log):
        """Use OmoCaptcha API (api.omocaptcha.com)."""
        if log:
            log("[CAPTCHA] OmoCaptcha createTask (RecaptchaV2TokenTask)...")

        # Step 1: createTask
        resp = _post_json("https://api.omocaptcha.com/v2/createTask", {
            "clientKey": self.omocaptcha_key,
            "task": {
                "type": "RecaptchaV2TokenTask",
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        })

        if resp.get("errorId", 1) != 0:
            if log:
                log(f"[CAPTCHA] OmoCaptcha error: {resp.get('errorCode', 'unknown')}")
            return ""

        task_id = resp.get("taskId")
        if not task_id:
            return ""

        if log:
            log(f"[CAPTCHA] OmoCaptcha taskId={task_id}, polling...")

        # Step 2: getTaskResult (poll every 3s — OmoCaptcha recommends 2s)
        return self._poll_task_result_omo(
            "https://api.omocaptcha.com/v2/getTaskResult",
            self.omocaptcha_key, task_id, log
        )

    # ──────────────────────────────────────
    #  Generic JSON API (Anti-Captcha, CapSolver)
    # ──────────────────────────────────────
    def _solve_generic_json(self, create_url, result_url, api_key,
                            sitekey, page_url, is_enterprise, log,
                            enterprise_type, standard_type):
        task_type = enterprise_type if is_enterprise else standard_type
        if log:
            log(f"[CAPTCHA] createTask ({task_type})...")

        resp = _post_json(create_url, {
            "clientKey": api_key,
            "task": {
                "type": task_type,
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        })

        if resp.get("errorId", 1) != 0:
            if log:
                log(f"[CAPTCHA] Error: {resp.get('errorCode', 'unknown')}")
            return ""

        task_id = resp.get("taskId")
        if not task_id:
            return ""

        if log:
            log(f"[CAPTCHA] taskId={task_id}, polling...")

        return self._poll_task_result(result_url, api_key, task_id, log)

    # ──────────────────────────────────────
    #  Poll for result (2Captcha / Anti-Captcha / CapSolver)
    # ──────────────────────────────────────
    def _poll_task_result(self, url, api_key, task_id, log):
        """Poll getTaskResult endpoint. Returns token or ''."""
        start = time.time()
        while time.time() - start < self.timeout:
            time.sleep(2)  # 2s poll for maximum speed
            try:
                resp = _post_json(url, {
                    "clientKey": api_key,
                    "taskId": task_id
                })
            except Exception:
                continue

            status = resp.get("status", "")
            if status == "ready":
                token = resp.get("solution", {}).get("gRecaptchaResponse", "")
                if token and log:
                    elapsed = int(time.time() - start)
                    log(f"[CAPTCHA] Solved in {elapsed}s!")
                return token
            elif resp.get("errorId", 0) != 0:
                if log:
                    log(f"[CAPTCHA] Error: {resp.get('errorCode', '')}")
                return ""
            # else status == "processing" → continue polling
            if log:
                elapsed = int(time.time() - start)
                log(f"[CAPTCHA] Waiting... ({elapsed}s)")

        if log:
            log(f"[CAPTCHA] Timeout ({self.timeout}s)")
        return ""

    # ──────────────────────────────────────
    #  Poll for result (OmoCaptcha specific)
    # ──────────────────────────────────────
    def _poll_task_result_omo(self, url, client_key, task_id, log):
        """Poll OmoCaptcha getTaskResult. Returns token or ''."""
        start = time.time()
        while time.time() - start < self.timeout:
            time.sleep(2)  # 2s poll (OmoCaptcha recommends 2-3s)
            try:
                resp = _post_json(url, {
                    "clientKey": client_key,
                    "taskId": task_id
                })
            except Exception:
                continue

            status = resp.get("status", "")
            if status == "ready":
                token = resp.get("solution", {}).get("gRecaptchaResponse", "")
                if token and log:
                    elapsed = int(time.time() - start)
                    log(f"[CAPTCHA] OmoCaptcha solved in {elapsed}s!")
                return token
            elif status == "fail" or resp.get("errorId", 0) != 0:
                if log:
                    log(f"[CAPTCHA] OmoCaptcha error: {resp.get('errorCode', 'fail')}")
                return ""
            # else status == "processing" → continue polling
            if log:
                elapsed = int(time.time() - start)
                log(f"[CAPTCHA] OmoCaptcha waiting... ({elapsed}s)")

        if log:
            log(f"[CAPTCHA] OmoCaptcha timeout ({self.timeout}s)")
        return ""


# ════════════════════════════════════════
#  Page Helpers — Extract / Detect / Inject
# ════════════════════════════════════════

def extract_recaptcha_sitekey(page):
    """Extract reCAPTCHA v2 sitekey from page."""
    try:
        for frame in page.frames:
            url = frame.url or ""
            m = re.search(r'[?&]k=([A-Za-z0-9_-]+)', url)
            if m:
                return m.group(1)
        try:
            el = page.locator('[data-sitekey]')
            if el.count() > 0:
                return el.first.get_attribute('data-sitekey') or ""
        except:
            pass
        html = page.content()
        m = re.search(r'data-sitekey=["\']([A-Za-z0-9_-]+)["\']', html)
        if m:
            return m.group(1)
        m = re.search(r'render=([A-Za-z0-9_-]{20,})', html)
        if m:
            return m.group(1)
    except:
        pass
    return ""


def is_enterprise_recaptcha(page):
    """Detect if page uses reCAPTCHA Enterprise."""
    try:
        for frame in page.frames:
            if "/recaptcha/enterprise/" in (frame.url or ""):
                return True
        if "/recaptcha/enterprise/" in page.content():
            return True
    except:
        pass
    return False


def inject_recaptcha_token(page, token):
    """Inject reCAPTCHA token — TrustedHTML-safe, multi-frame, callback search."""
    injected = False

    # TrustedHTML-safe JS — NO innerHTML, only .value and .textContent
    inject_js = """(token) => {
        var found = false;
        // 1. Set textarea values (NO innerHTML — blocked by TrustedHTML policy)
        var textareas = document.querySelectorAll('textarea[name="g-recaptcha-response"]');
        for (var i = 0; i < textareas.length; i++) {
            textareas[i].value = token;
            try { textareas[i].textContent = token; } catch(e) {}
            textareas[i].style.display = 'block';
            found = true;
        }
        var el = document.getElementById('g-recaptcha-response');
        if (el) { el.value = token; found = true; }
        // 2. Find and call the reCAPTCHA callback
        if (typeof ___grecaptcha_cfg !== 'undefined') {
            try {
                var clients = ___grecaptcha_cfg.clients;
                for (var ck in clients) {
                    var client = clients[ck];
                    function searchCb(obj, depth) {
                        if (depth > 4 || !obj || typeof obj !== 'object') return false;
                        if (obj instanceof HTMLElement || obj instanceof Node || obj instanceof Window) return false;
                        if (typeof obj.callback === 'function') {
                            try { obj.callback(token); return true; } catch(e) {}
                        }
                        for (var key in obj) {
                            if (key === 'window' || key === 'document') continue;
                            var val = obj[key];
                            if (!val || typeof val !== 'object') continue;
                            if (val instanceof HTMLElement || val instanceof Node || val instanceof Window) continue;
                            if (searchCb(val, depth + 1)) return true;
                        }
                        return false;
                    }
                    if (searchCb(client, 0)) { found = true; break; }
                }
            } catch(e) {}
        }
        // 3. Try grecaptcha.enterprise.execute()
        if (typeof grecaptcha !== 'undefined') {
            try {
                if (grecaptcha.enterprise && grecaptcha.enterprise.execute) {
                    grecaptcha.enterprise.execute();
                    found = true;
                }
            } catch(e) {}
        }
        return found;
    }"""

    # Run injection on main page
    try:
        if page.evaluate(inject_js, token):
            injected = True
    except:
        pass

    # Also try in reCAPTCHA frames
    try:
        for frame in page.frames:
            furl = frame.url or ""
            if "recaptcha" in furl and "bframe" not in furl:
                try:
                    frame.evaluate(inject_js, token)
                    injected = True
                except:
                    pass
    except:
        pass

    # Set anchor checkbox as checked
    try:
        for frame in page.frames:
            furl = frame.url or ""
            if "recaptcha" in furl and "anchor" in furl:
                try:
                    frame.evaluate("""() => {
                        var anchor = document.getElementById('recaptcha-anchor');
                        if (anchor) {
                            anchor.setAttribute('aria-checked', 'true');
                            anchor.classList.add('recaptcha-checkbox-checked');
                        }
                    }""")
                except:
                    pass
    except:
        pass

    return injected


def detect_recaptcha_page(page):
    """Check if current page has a reCAPTCHA challenge."""
    try:
        url = page.url or ""
        if "challenge/recaptcha" in url:
            return True
        try:
            body_text = page.inner_text("body", timeout=3000)[:2000].lower()
        except:
            body_text = ""
        keywords = [
            "i'm not a robot", "confirm you're not a robot",
            "verify it's you", "not a robot", "recaptcha",
            "xac minh", "robot",
        ]
        if any(kw in body_text for kw in keywords):
            return True
        for frame in page.frames:
            if "recaptcha" in (frame.url or ""):
                return True
    except:
        pass
    return False


# ════════════════════════════════════════
#  Settings Loader
# ════════════════════════════════════════

def get_captcha_solver_from_settings():
    """Create CaptchaSolver from data/settings.json."""
    try:
        settings_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "data", "settings.json"
        )
        with open(settings_path, "r", encoding="utf-8") as f:
            s = json.load(f)
        return CaptchaSolver(
            api_key=s.get("two_captcha_key", ""),
            provider=s.get("captcha_provider", "2captcha"),
            timeout=int(s.get("captcha_timeout", 120)),
            retries=int(s.get("captcha_retries", 2)),
            omocaptcha_key=s.get("omocaptcha_key", ""),
        )
    except Exception:
        return CaptchaSolver("")


# ════════════════════════════════════════
#  Global Handler — Call from ANY Login Thread
# ════════════════════════════════════════

def handle_captcha_on_page(page, status_callback=None, max_attempts=2, skip_submit=False):
    """
    Universal CAPTCHA handler -- call from any login thread.
    Returns True if CAPTCHA was detected, False if none found.
    """
    def emit(msg):
        if status_callback:
            try:
                status_callback(msg)
            except:
                pass

    if not detect_recaptcha_page(page):
        return False

    emit("[CAPTCHA] Phat hien reCAPTCHA -- dang xu ly...")

    for attempt in range(max_attempts):
        if attempt > 0:
            emit(f"[CAPTCHA] Thu lai lan {attempt + 1}...")
            time.sleep(2)

        # Step 1: Try clicking checkbox (free method)
        try:
            for frame in page.frames:
                furl = frame.url or ""
                if "recaptcha" in furl and "anchor" in furl:
                    cb = frame.locator('#recaptcha-anchor')
                    if cb.count() > 0:
                        cb.first.click()
                        time.sleep(3)
                        try:
                            if cb.first.get_attribute("aria-checked") == "true":
                                emit("[OK] reCAPTCHA vuot qua (click)")
                                if not skip_submit:
                                    _click_form_submit(page)
                                    time.sleep(3)
                                else:
                                    emit("[OK] Skip submit (2FA mode)")
                                return True
                        except:
                            pass
        except:
            pass

        # Step 2: Solve via API
        solver = get_captcha_solver_from_settings()
        if not solver.is_configured():
            emit("[!] Can CAPTCHA API Key (Cai dat -> Trinh duyet -> API Key)")
            return True

        sitekey = extract_recaptcha_sitekey(page)
        if not sitekey:
            emit("[X] Khong tim thay sitekey reCAPTCHA")
            continue

        enterprise = is_enterprise_recaptcha(page)
        provider_name = solver.provider.upper()
        if enterprise:
            emit(f"[CAPTCHA] reCAPTCHA Enterprise detected, sending to {provider_name}...")
        else:
            emit(f"[CAPTCHA] Sending to {provider_name}...")

        token = solver.solve_recaptcha_v2(sitekey, page.url, is_enterprise=enterprise, log=emit)
        if token:
            emit(f"[OK] {provider_name} solved! Injecting token...")
            inject_recaptcha_token(page, token)
            time.sleep(2)
            if not skip_submit:
                _click_form_submit(page)
                time.sleep(5)
            else:
                emit("[OK] Skip submit (2FA mode — caller will handle)")
                time.sleep(1)

            if not detect_recaptcha_page(page):
                emit(f"[OK] reCAPTCHA bypassed ({provider_name})")
                return True
            else:
                emit("[!] CAPTCHA still present after inject, retrying...")
        else:
            emit(f"[X] {provider_name} failed (attempt {attempt + 1})")

    return True


def _click_form_submit(page):
    """Click Next/Verify/Submit button on current page."""
    for sel in [
        'button:has-text("Tiep theo")', 'button:has-text("Next")',
        'button:has-text("Verify")', 'button:has-text("Xac minh")',
        'button:has-text("Continue")', 'button:has-text("Sign in")',
        '#submit', 'button[type="submit"]', '#passwordNext',
        '#identifierNext', '#identifierNext button',
    ]:
        try:
            btn = page.locator(sel)
            if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                btn.first.click()
                return True
        except:
            continue
    return False
