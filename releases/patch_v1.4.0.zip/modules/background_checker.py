import threading
import time
import requests
import re
from PyQt6.QtCore import QObject, QRunnable, QThreadPool, pyqtSignal, pyqtSlot

class WorkerSignals(QObject):
    profile_checked = pyqtSignal(str, dict)
    finished_all = pyqtSignal()
    
class SingleProfileCheck(QRunnable):
    def __init__(self, profile, worker_ref, signals):
        super().__init__()
        self.profile = profile
        self.worker_ref = worker_ref # Reference to check if still running
        self.signals = signals

    @pyqtSlot()
    def run(self):
        if not self.worker_ref._running:
            return
            
        try:
            result = self.worker_ref.check_single_profile(self.profile)
            if result and self.worker_ref._running:
                self.signals.profile_checked.emit(self.profile["id"], result)
        except Exception as e:
            print(f"Error checking profile {self.profile.get('fb_uid', '')}: {e}")
            
class ProfileCheckWorkerManager(QObject):
    # This acts as the manager/controller that main_window talks to
    profile_checked = pyqtSignal(str, dict)
    finished_all = pyqtSignal()
    
    def __init__(self, profiles: list, max_threads: int = 5):
        super().__init__()
        self.profiles = profiles
        self.max_threads = max_threads
        self._running = True
        self.active_tasks = 0
        self.tasks_lock = threading.Lock()
        
    def start(self):
        self._running = True
        self.active_tasks = len(self.profiles)
        if self.active_tasks == 0:
            self.finished_all.emit()
            return
            
        pool = QThreadPool.globalInstance()
        pool.setMaxThreadCount(self.max_threads)
        
        # We need intermediate signals since QRunnable doesn't support them natively without QObject
        self.signals = WorkerSignals()
        self.signals.profile_checked.connect(self.profile_checked)
        
        for p in self.profiles:
            worker = SingleProfileCheck(p, self, self.signals)
            # Custom signal wrapper to track completion
            worker.setAutoDelete(True)
            pool.start(worker)
            
        # Start a watcher thread to emit finished_all when pool is clear
        threading.Thread(target=self._wait_for_completion, daemon=True).start()
        
    def _wait_for_completion(self):
        pool = QThreadPool.globalInstance()
        # Wait until there are no active threads in the global pool (or just sleep and check)
        while self._running and pool.activeThreadCount() > 0:
            time.sleep(0.5)
        if self._running:
            self.finished_all.emit()

    def stop(self):
        self._running = False
        QThreadPool.globalInstance().clear() # Clear pending tasks in the queue
        
    def check_single_profile(self, profile):
        if not self._running:
            return None
            
        cookie_str = profile.get("fb_cookie", "")
        uid = profile.get("fb_uid", "")
        if not cookie_str:
            return {"status": "Wall Out", "fb_live": "Dead"}

        session = requests.Session()
        # Use a mobile User-Agent since we are hitting mbasic.facebook.com
        mobile_ua = "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36"
        session.headers.update({
            "User-Agent": profile.get("fb_useragent_android", mobile_ua) if profile.get("fb_useragent_android") else mobile_ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
            "Sec-Ch-Ua": '"Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"',
            "Sec-Ch-Ua-Mobile": "?1",
            "Sec-Ch-Ua-Platform": '"Android"',
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1"
        })
        
        for chunk in cookie_str.split(';'):
            if '=' in chunk:
                k, v = chunk.split('=', 1)
                session.cookies.set(k.strip(), v.strip(), domain='.facebook.com')

        scraped_data = {}
        try:
            # Check basic /me
            resp = session.get("https://mbasic.facebook.com/me", timeout=15)
            
            # Detect checkpoint or dead cookie
            if "checkpoint" in resp.url or "approvals_code" in resp.text:
                return {"status": "Wall Out", "fb_live": "Dead"}
            
            # Check for login redirect - be more specific to avoid false positives
            if resp.url and ('login.php' in resp.url or '/login/' in resp.url):
                return {"status": "Wall Out", "fb_live": "Dead"}
            if 'name="login"' in resp.text and 'name="pass"' in resp.text:
                return {"status": "Wall Out", "fb_live": "Dead"}
                
            # If we reached here, it's alive
            scraped_data["status"] = "Wall Live"
            scraped_data["fb_live"] = "Live"
            
            # Parse Name — extract from www.facebook.com home page JSON data
            try:
                desktop_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                home_resp = session.get(
                    "https://www.facebook.com/",
                    headers={"User-Agent": desktop_ua},
                    timeout=15
                )
                if home_resp.status_code == 200 and home_resp.text:
                    # Pattern 1: "NAME":"UserName"
                    name_m = re.search(r'"NAME":"([^"]+)"', home_resp.text)
                    if name_m:
                        scraped_data["fb_name"] = name_m.group(1)
                    else:
                        # Pattern 2: "name":"..." near "id":"UID"
                        if uid:
                            name_m2 = re.search(
                                r'"name":"([^"]{2,40})".*?"id":"' + re.escape(uid) + '"',
                                home_resp.text[:50000]
                            )
                            if name_m2:
                                scraped_data["fb_name"] = name_m2.group(1)
                            else:
                                name_m3 = re.search(
                                    r'"id":"' + re.escape(uid) + r'".*?"name":"([^"]{2,40})"',
                                    home_resp.text[:50000]
                                )
                                if name_m3:
                                    scraped_data["fb_name"] = name_m3.group(1)
                        # Pattern 3: short_name
                        if "fb_name" not in scraped_data:
                            short_m = re.search(r'"short_name":"([^"]+)"', home_resp.text)
                            if short_m:
                                scraped_data["fb_name"] = short_m.group(1)
            except:
                pass
                    
            content_lower = resp.text.lower()
            
            # Simple Female/Male scrape
            if any(x in content_lower for x in ["female", "nữ", "woman"]): 
                scraped_data["fb_gender"] = "Nữ"
            elif any(x in content_lower for x in ["male", "nam", "man"]): 
                scraped_data["fb_gender"] = "Nam"
                
            # Friends count from mbasic index
            # Actual format: >Bạn bè<span aria-label="...">(13)</span>
            friends_match = re.search(
                r'(?:Friends|Bạn bè)[^(]*\((\d[\d,.]*)\)',
                resp.text, re.IGNORECASE
            )
            if friends_match:
                scraped_data["fb_friends"] = friends_match.group(1)
                
            # For deeper info like DOB and Created Date, go to /about
            try:
                about_resp = session.get("https://mbasic.facebook.com/me/about", timeout=15)
                about_text = about_resp.text
                
                # Birthday scrape (Basic pattern)
                dob_match = re.search(r'(?:Birthday|Ngày sinh)[<\/a-zA-Z\s=">]*?class="[a-zA-Z0-9_\s]+">([^<]+)</div>', about_text, re.IGNORECASE)
                if not dob_match:
                    # Alternative
                    dob_match = re.search(r'(?:Birthday|Ngày sinh)[\s\S]*?<tr><td[^>]*><div[^>]*>([^<]+)</div></td></tr>', about_text, re.IGNORECASE)
                    
                if dob_match:
                    dob = dob_match.group(1).strip()
                    if dob: scraped_data["fb_birthday"] = dob
                    
                # Creation year (mbasic usually shows joined Facebook on X)
                join_match = re.search(r'(?:Joined Facebook|Tham gia Facebook).*?>([a-zA-Z0-9\s,]+)<', about_text, re.IGNORECASE)
                if join_match:
                    scraped_data["fb_created"] = join_match.group(1).strip()
            except:
                pass # Accept whatever we got from /me
                
        except Exception as e:
             # Network error, we don't necessarily mark it dead if it's just a timeout, but this is a pure background checker
             return {"status": "Error"}

        return scraped_data
