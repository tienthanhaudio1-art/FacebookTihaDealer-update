"""
Change Via Worker — Background executor for Change Via tab actions.
Uses Facebook cookie-based API (modules/fb_api.py) for fast, multi-threaded ops.

Supported: Check Language, Check Phone/Email, Change Password, Enable/Disable 2FA,
           Add Email, Verify Email, Remove IG/Meta, Add Insta, Change All, Reg Meta.
"""
import re
import time
import os
import random
import string
from datetime import datetime
from PyQt6.QtCore import QThread, pyqtSignal

from modules.fb_api import (
    get_fb_dtsg, check_cookie, get_language, change_language,
    get_contact_points, change_password_api,
    get_2fa_status, enable_2fa_totp, enable_2fa_totp_graphql, disable_2fa, _generate_totp,
    add_email_tut_v1, remove_email,
    get_linked_accounts, remove_instagram_link,
    change_name, graphql_request, parse_cookie_string,
)


class ChangeViaWorker(QThread):
    """Worker thread for Change Via operations."""
    log_signal = pyqtSignal(str, str, str)   # uid, column_name, message
    finished_one = pyqtSignal(str)
    finished_all = pyqtSignal()
    profile_updated_signal = pyqtSignal()

    def __init__(self, profiles: list, action: str, settings: dict):
        super().__init__()
        self.profiles = profiles
        self.action = action
        self.settings = settings
        self._running = True

    def stop(self):
        self._running = False

    def _log(self, uid, col, msg):
        self.log_signal.emit(uid, col, msg)

    def run(self):
        for p in self.profiles:
            if not self._running:
                break

            uid = p.get("fb_uid", "")
            if not uid:
                continue

            self._log(uid, "Trạng thái", "Đang xử lý...")
            self._log(uid, "Kết quả", "")
            self._log(uid, "Lỗi", "")

            # Check auth
            cookie_mode = self.settings.get("cookie_mode", True)
            cookie_str = p.get("fb_cookie", "")
            token = p.get("fb_token", "")

            if cookie_mode and not cookie_str:
                self._log(uid, "Lỗi", "Cookie Out")
                self._log(uid, "Trạng thái", "Dừng — Thiếu Cookie")
                self.finished_one.emit(uid)
                continue

            # Delay
            delay = self.settings.get("delay", 0)
            if delay > 0:
                time.sleep(delay)

            try:
                action_map = {
                    "Get Token": self._get_token,
                    "Check Ngôn Ngữ": self._check_language,
                    "Check Phone/Email": self._check_contact,
                    "Change Password": self._change_password,
                    "Bật 2FA": self._enable_2fa,
                    "Add Email": self._add_email_v1,
                    "Add Email Tut V1": self._add_email_v1,
                    "Xác thực Email": self._verify_email,
                    "Xóa LK Insta/Meta": self._remove_ig,
                    "Add Insta": self._add_ig,
                    "Change All": self._change_all,
                    "Reg Meta": self._reg_meta,
                    "Xóa Mail/Phone": self._remove_contacts,
                }

                handler = action_map.get(self.action)
                if handler:
                    handler(p)
                else:
                    self._log(uid, "Trạng thái", f"[{self.action}] Chưa implement")
            except Exception as e:
                import traceback
                traceback.print_exc()
                self._log(uid, "Lỗi", str(e)[:100])
                self._log(uid, "Trạng thái", "Lỗi hệ thống")

            self.finished_one.emit(uid)

        self.finished_all.emit()

    # ─── Helper: Get fb_dtsg with caching ──────
    def _get_dtsg(self, uid, cookie_str):
        """Get fb_dtsg, with status updates."""
        self._log(uid, "Trạng thái", "Lấy fb_dtsg token...")
        dtsg, jazoest = get_fb_dtsg(cookie_str)
        if not dtsg:
            self._log(uid, "Lỗi", "Cookie Die — không lấy được fb_dtsg")
            self._log(uid, "Trạng thái", "Cookie Out")
            return None, None
        return dtsg, jazoest

    # ═══════════════════════════════════════════
    #  0. GET TOKEN
    # ═══════════════════════════════════════════
    def _get_token(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        self._log(uid, "Trạng thái", "Đang lấy Token từ Ads Manager...")

        from modules.fb_api import get_eaag_token
        ok, token, msg = get_eaag_token(cookie_str)

        if ok and token:
            self._log(uid, "Kết quả", "✅ Lấy Token thành công")
            self._log(uid, "Token", token)
            self._log(uid, "Trạng thái", "Thành công ✅")
            # Save token to profile
            self._update_profile_field(uid, "fb_token", token)
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Trạng thái", f"❌ {msg}")

    # ═══════════════════════════════════════════
    #  1. CHECK LANGUAGE
    # ═══════════════════════════════════════════
    def _check_language(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        self._log(uid, "Trạng thái", "Kiểm tra ngôn ngữ...")
        lang = get_language(cookie_str)

        if lang:
            self._log(uid, "Kết quả", f"Ngôn ngữ: {lang}")

            # Change language if requested
            target_lang = self.settings.get("target_lang", "")
            if target_lang and target_lang != lang:
                dtsg, _ = self._get_dtsg(uid, cookie_str)
                if dtsg:
                    self._log(uid, "Trạng thái", f"Đổi ngôn ngữ → {target_lang}...")
                    ok, msg = change_language(cookie_str, dtsg, target_lang)
                    if ok:
                        self._log(uid, "Kết quả", f"✅ {lang} → {target_lang}")
                        self._log(uid, "Trạng thái", "Thành công ✅")
                    else:
                        self._log(uid, "Lỗi", msg)
                        self._log(uid, "Trạng thái", "❌ Lỗi đổi ngôn ngữ")
                    return

            self._log(uid, "Trạng thái", f"✅ Ngôn ngữ: {lang}")
        else:
            self._log(uid, "Lỗi", "Cookie Die")
            self._log(uid, "Trạng thái", "Cookie Out")

    # ═══════════════════════════════════════════
    #  2. CHECK PHONE/EMAIL
    # ═══════════════════════════════════════════
    def _check_contact(self, profile):
        """Check Phone/Email — branches based on settings:
        - If 'cookie_mode' checked → run _remove_contacts() (xóa mail/phone)
        - Else depends on combo_check_phone dropdown:
          1. 'Chức năng Check Phone/Email số' → scan contacts (default)
          2. 'Chỉ check Info' → same as above 
          3. 'Xác thực email nếu chưa xác thực' → auto-verify pending emails
          4. 'Xóa Toàn bộ Email trừ mail chính lưu trên tool' → delete non-primary
        """
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        # If checkbox 'Xóa Mail/Phone bằng tut mới (cookie)' is checked
        # → always run remove contacts, ignore dropdown
        if self.settings.get("cookie_mode", False):
            self._remove_contacts(profile)
            return

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        mode = self.settings.get("check_phone_mode", "Chức năng Check Phone/Email số")

        if "Xác thực email" in mode:
            self._check_contact_verify_pending(profile, uid, cookie_str, dtsg)
        elif "Xóa Toàn bộ" in mode:
            self._check_contact_delete_non_primary(profile, uid, cookie_str, dtsg)
        else:
            # Default: scan contacts
            self._check_contact_scan(uid, cookie_str, dtsg)

    def _check_contact_scan(self, uid, cookie_str, dtsg):
        """Mode 1: Just scan and display contacts (vertical list)."""
        self._log(uid, "Trạng thái", "Kiểm tra Phone/Email...")
        contacts = get_contact_points(cookie_str, dtsg)

        emails = contacts.get("emails", [])
        phones = contacts.get("phones", [])
        pending = contacts.get("pending_emails", [])

        lines = []
        for e in emails:
            if e in pending:
                lines.append(f"📧 {e} (chờ xác minh)")
            else:
                lines.append(f"📧 {e}")
        for p in phones:
            lines.append(f"📱 {p}")

        if lines:
            result = "\n".join(lines)
            self._log(uid, "Kết quả", result)
            self._log(uid, "Info", f"E:{len(emails)} P:{len(phones)} Pending:{len(pending)}")
            self._log(uid, "Trạng thái", f"✅ E:{len(emails)} P:{len(phones)}")
        else:
            self._log(uid, "Kết quả", "Không tìm thấy contact")
            self._log(uid, "Trạng thái", "⚠️ Không có contact")

    def _check_contact_verify_pending(self, profile, uid, cookie_str, dtsg):
        """Mode 3: Tự động xác thực email đang chờ xác minh."""
        self._log(uid, "Trạng thái", "Kiểm tra email chờ xác minh...")
        contacts = get_contact_points(cookie_str, dtsg)

        emails = contacts.get("emails", [])
        pending = contacts.get("pending_emails", [])
        primary_email = profile.get("fb_email", "").strip()

        if not pending:
            self._log(uid, "Kết quả", f"📧 {len(emails)} email — Tất cả đã xác minh")
            self._log(uid, "Trạng thái Xác minh Email", "✅ Không có email chờ xác minh")
            self._log(uid, "Trạng thái", "✅ Tất cả đã xác minh")
            return

        self._log(uid, "Trạng thái", f"Phát hiện {len(pending)} email chờ xác minh")

        verified_mails = []
        failed_mails = []

        from modules.fb_api import submit_email_verification_code, add_email

        for email_addr in pending:
            if not self._running:
                break

            self._log(uid, "Trạng thái", f"Xác thực: {email_addr}...")

            # Try to get verification code from various sources
            code = None
            email_pass = ""

            # Source 1: Check if it's a temp mail domain → use temp mail API
            domain = email_addr.split("@")[1].lower() if "@" in email_addr else ""
            temp_domains = [
                "foxycrown.net", "crxmail.com", "locketgold.me",
                "foxymail.live", "inboxes.live", "smvmail.com",
                "fviainboxes.com", "fviadropinbox.com",
                "fviamail.work", "dropinboxes.com"
            ]
            if domain in temp_domains:
                self._log(uid, "Trạng thái", f"Đọc mã từ temp mail: {email_addr}...")
                # First trigger a resend/confirmation email
                add_email(cookie_str, dtsg, email_addr, "")
                time.sleep(3)
                code = self._get_tempmail_code(email_addr, uid)

            # Source 2: Check if email is stored in profile (hotmail/gmail with pass)
            if not code:
                # Check profile's own email
                profile_email = profile.get("fb_email", "")
                profile_email_pass = profile.get("fb_pass_email", "")
                if profile_email and email_addr.lower() == profile_email.lower() and profile_email_pass:
                    email_pass = profile_email_pass

                # Check email manager for matching email
                if not email_pass:
                    email_pass = self._find_email_password(email_addr, uid)

                if email_pass:
                    self._log(uid, "Trạng thái", f"Đọc mã từ IMAP: {email_addr}...")
                    # Trigger verification email
                    add_email(cookie_str, dtsg, email_addr, "")
                    time.sleep(3)
                    code = self._get_email_code(email_addr, email_pass, profile)

                # Source 3: Check if hotmail with token
                if not code:
                    token = profile.get("fb_token_hotmail", "")
                    if token and ("hotmail" in domain or "outlook" in domain or "live" in domain):
                        self._log(uid, "Trạng thái", f"Đọc mã qua Graph API: {email_addr}...")
                        add_email(cookie_str, dtsg, email_addr, "")
                        time.sleep(3)
                        code = self._get_email_code(email_addr, "", profile)

            if code:
                self._log(uid, "Trạng thái", f"Gửi mã xác minh {code} cho {email_addr}...")
                ok, msg = submit_email_verification_code(cookie_str, dtsg, email_addr, code)
                if ok:
                    verified_mails.append(email_addr)
                    self._log(uid, "Trạng thái", f"✅ Đã xác minh: {email_addr}")
                else:
                    failed_mails.append(email_addr)
                    self._log(uid, "Trạng thái", f"❌ Lỗi xác minh {email_addr}: {msg}")
            else:
                failed_mails.append(email_addr)
                self._log(uid, "Trạng thái", f"❌ Không tìm thấy mã cho {email_addr}")

            time.sleep(1)

        # Report results
        if verified_mails:
            result_str = "/".join(verified_mails)
            self._log(uid, "Trạng thái Xác minh Email",
                      f"✅ Xác thực thành công: {result_str}")

            # Save to profile if no primary email set
            if not primary_email:
                self._update_profile_field(uid, "fb_email", verified_mails[0])
                all_verified = "/".join(verified_mails)
                self._log(uid, "Info", f"Đã lưu email: {all_verified}")
        else:
            self._log(uid, "Trạng thái Xác minh Email", "❌ Không xác minh được email nào")

        if failed_mails:
            self._log(uid, "Lỗi", f"Không xác minh: {'/'.join(failed_mails)}")

        total_ok = len(verified_mails)
        total_fail = len(failed_mails)
        self._log(uid, "Kết quả", f"Xác minh: {total_ok}✅ {total_fail}❌ / {len(pending)} pending")
        self._log(uid, "Trạng thái",
                  f"{'✅' if total_ok > 0 else '❌'} Xác minh {total_ok}/{len(pending)}")

    def _check_contact_delete_non_primary(self, profile, uid, cookie_str, dtsg):
        """Mode 4: Xóa toàn bộ email trừ mail chính lưu trên tool."""
        primary_email = profile.get("fb_email", "").strip()

        self._log(uid, "Trạng thái", "Lấy danh sách email...")
        contacts = get_contact_points(cookie_str, dtsg)
        emails = contacts.get("emails", [])

        if not emails:
            self._log(uid, "Kết quả", "Không có email nào")
            self._log(uid, "Trạng thái", "⚠️ Không có email")
            return

        # Filter: remove all except primary
        to_remove = [e for e in emails if not (primary_email and e.lower() == primary_email.lower())]

        if not to_remove:
            self._log(uid, "Kết quả", f"Chỉ có mail chính: {primary_email}")
            self._log(uid, "Trạng thái Xác minh Email", "✅ Không có email thừa")
            self._log(uid, "Trạng thái", "✅ Không có gì cần xóa")
            return

        self._log(uid, "Trạng thái", f"Xóa {len(to_remove)} email (giữ mail chính: {primary_email or 'N/A'})...")

        from modules.fb_api import remove_email
        removed = []
        failed = []

        for email in to_remove:
            self._log(uid, "Trạng thái", f"Xóa: {email}...")
            ok, msg = remove_email(cookie_str, dtsg, email)
            if ok:
                removed.append(email)
                self._log(uid, "Trạng thái", f"✅ Đã xóa: {email}")
            else:
                failed.append(email)
                self._log(uid, "Trạng thái", f"❌ {email}: {msg}")
            time.sleep(1)

        # Save removed emails to Mail Old
        if removed:
            old_str = ", ".join(removed)
            self._log(uid, "Mail Old", old_str)
            self._update_profile_field(uid, "fb_mail_old", old_str)

        # Results
        self._log(uid, "Trạng thái Xác minh Email",
                  f"Đã xóa {len(removed)}/{len(to_remove)} email thừa")
        self._log(uid, "Kết quả",
                  f"📧 Xóa: {len(removed)}✅ {len(failed)}❌ | Giữ: {primary_email or '(không có)'}")
        self._log(uid, "Trạng thái",
                  f"{'✅' if removed else '❌'} Xóa {len(removed)}/{len(to_remove)}")

    def _find_email_password(self, email_addr, uid):
        """Find email password from email manager or profile manager."""
        try:
            from core.profile_manager import ProfileManager
            pm = ProfileManager()
            # Check all profiles for matching email
            for p in pm.get_all_profiles():
                if p.get("fb_email", "").lower() == email_addr.lower():
                    pw = p.get("fb_pass_email", "")
                    if pw:
                        return pw
                # Also check gmail field
                gmail = p.get("gmail", "") or p.get("fb_gmail", "")
                if gmail and gmail.lower() == email_addr.lower():
                    pw = p.get("gmail_pass", "") or p.get("fb_gmail_pass", "")
                    if pw:
                        return pw
        except:
            pass
        return ""


    # ═══════════════════════════════════════════
    #  2b. XÓA MAIL/PHONE (TUT MỚI - COOKIE)
    # ═══════════════════════════════════════════
    def _remove_contacts(self, profile):
        """Xóa tất cả email cũ và phone cũ bằng cookie (tut mới).
        - Mail chính (từ profile manager) → LUÔN giữ lại
        - 'Không xóa mail Old' checked → giữ nguyên mail cũ, chỉ xóa phone
        - 'Không xóa mail Old' unchecked → xóa mail cũ + phone, lưu mail cũ vào 'Mail Old'
        """
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Đang xóa Mail/Phone cũ...")

        # Mail chính = email đã lưu ở profile manager → LUÔN giữ
        primary_email = profile.get("fb_email", "").strip()

        # 'Không xóa mail Old' = True → giữ tất cả email cũ, chỉ xóa phone
        no_remove_old_mail = self.settings.get("keep_old_email", True)

        from modules.fb_api import get_contact_points, remove_email, remove_phone

        # Step 1: Get current contacts
        self._log(uid, "Trạng thái", "Lấy danh sách Email/Phone...")
        contacts = get_contact_points(cookie_str, dtsg)
        emails = contacts.get("emails", [])
        phones = contacts.get("phones", [])

        if not emails and not phones:
            self._log(uid, "Kết quả", "Không có Email/Phone nào")
            self._log(uid, "Trạng thái", "⚠️ Không có contact")
            return

        self._log(uid, "Trạng thái", f"Tìm thấy: {len(emails)} email, {len(phones)} phone")

        removed_emails = []
        removed_phones = []
        failed = []

        # Step 2: Remove emails (trừ mail chính)
        if not no_remove_old_mail:
            for email in emails:
                if primary_email and email.lower() == primary_email.lower():
                    self._log(uid, "Trạng thái", f"Giữ mail chính: {email}")
                    continue
                self._log(uid, "Trạng thái", f"Xóa email: {email}...")
                ok, msg = remove_email(cookie_str, dtsg, email)
                if ok:
                    removed_emails.append(email)
                    self._log(uid, "Trạng thái", f"✅ Đã xóa: {email}")
                else:
                    failed.append(f"Email {email}: {msg}")
                    self._log(uid, "Trạng thái", f"❌ {email}: {msg}")
                time.sleep(1)
        else:
            self._log(uid, "Trạng thái", "Giữ nguyên tất cả email cũ (tùy chọn)")

        # Step 3: Remove phones
        for phone in phones:
            self._log(uid, "Trạng thái", f"Xóa phone: {phone}...")
            ok, msg = remove_phone(cookie_str, dtsg, phone)
            if ok:
                removed_phones.append(phone)
                self._log(uid, "Trạng thái", f"✅ Đã xóa: {phone}")
            else:
                failed.append(f"Phone {phone}: {msg}")
                self._log(uid, "Trạng thái", f"❌ {phone}: {msg}")
            time.sleep(1)

        # Step 4: Build result display
        parts = []
        if removed_emails:
            parts.append(f"📧 Đã xóa: {', '.join(removed_emails)}")
        if removed_phones:
            parts.append(f"📱 Đã xóa: {', '.join(removed_phones)}")
        if failed:
            parts.append(f"❌ Thất bại: {len(failed)}")

        if parts:
            self._log(uid, "Kết quả", " | ".join(parts))
        else:
            self._log(uid, "Kết quả", "Không có Email/Phone nào để xóa")

        # Step 5: Lưu mail cũ đã xóa vào cột 'Mail Old' + profile manager
        if removed_emails:
            old_mail_str = ", ".join(removed_emails)
            self._log(uid, "Mail Old", old_mail_str)
            self._update_profile_field(uid, "fb_mail_old", old_mail_str)

        total = len(removed_emails) + len(removed_phones)
        if total > 0:
            self._log(uid, "Trạng thái", f"✅ Đã xóa {total} | Thất bại {len(failed)}")
        elif not failed:
            self._log(uid, "Trạng thái", "⚠️ Không có gì để xóa")
        else:
            self._log(uid, "Trạng thái", f"❌ Thất bại {len(failed)}")


    # ═══════════════════════════════════════════
    #  3. CHANGE PASSWORD
    # ═══════════════════════════════════════════
    def _change_password(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")
        old_pass = profile.get("fb_pass", "")
        new_pass = self.settings.get("new_pass", "")

        if not old_pass:
            self._log(uid, "Lỗi", "Thiếu mật khẩu cũ")
            self._log(uid, "Trạng thái", "Dừng — Không có pass cũ")
            return

        if not new_pass:
            self._log(uid, "Lỗi", "Thiếu mật khẩu mới")
            self._log(uid, "Trạng thái", "Dừng — Không có pass mới")
            return

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Đổi mật khẩu (API)...")
        ok, msg = change_password_api(cookie_str, dtsg, old_pass, new_pass)

        if ok:
            self._log(uid, "Kết quả", f"✅ Đổi pass thành công")
            self._log(uid, "2FA/Pass Mới", f"🔒 {new_pass}")
            self._log(uid, "Pass Old", f"🔑 {old_pass}")
            self._log(uid, "Trạng thái", "Thành công ✅")
            self._update_profile_pass(uid, new_pass, old_pass)
        else:
            # Fallback: try browser method
            self._log(uid, "Lỗi", f"API: {msg}")
            self._log(uid, "Trạng thái", f"❌ {msg}")

    # ═══════════════════════════════════════════
    #  4. ENABLE 2FA
    # ═══════════════════════════════════════════
    def _enable_2fa(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")
        old_2fa_secret = profile.get("fb_2fa", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        # Check current 2FA status
        self._log(uid, "Trạng thái", "Kiểm tra 2FA...")
        enabled, method = get_2fa_status(cookie_str, dtsg)

        if enabled:
            # 2FA already enabled → need to DISABLE first, then ENABLE new one
            self._log(uid, "Info xóa 2FA Cũ", old_2fa_secret or method)
            self._log(uid, "Trạng thái", "Tắt 2FA cũ trước...")

            # Generate TOTP code from old secret to disable
            tfa_code = ""
            if old_2fa_secret:
                try:
                    tfa_code = _generate_totp(old_2fa_secret)
                    self._log(uid, "Trạng thái", f"Tắt 2FA (code: {tfa_code})...")
                except Exception as e:
                    self._log(uid, "Lỗi", f"Lỗi tạo OTP từ secret cũ: {str(e)[:40]}")
                    self._log(uid, "Trạng thái", "❌ Không tạo được OTP từ 2FA cũ")
                    return

            ok_off, msg_off = disable_2fa(cookie_str, dtsg, tfa_code)
            if not ok_off:
                self._log(uid, "Lỗi", f"Tắt 2FA thất bại: {msg_off}")
                self._log(uid, "Trạng thái", f"❌ {msg_off}")
                return

            self._log(uid, "Trạng thái", "✅ Đã tắt 2FA cũ — bật 2FA mới...")
            # Re-get dtsg after disabling (session may change)
            dtsg, _ = self._get_dtsg(uid, cookie_str)
            if not dtsg:
                return

        # Enable 2FA (either fresh or after disabling old)
        method_opt = self.settings.get("two_fa_method", "")
        self._log(uid, "Trạng thái", f"Bật 2FA [{method_opt[:8]}]...")

        if "Method B" in method_opt:
            ok, secret, msg = enable_2fa_totp_graphql(cookie_str, dtsg)
        else:
            ok, secret, msg = enable_2fa_totp(cookie_str, dtsg)

        if ok:
            self._log(uid, "Kết quả", f"✅ Bật 2FA [{method_opt[:8]}]")
            self._log(uid, "2FA/Pass Mới", f"🔑 {secret}")
            self._log(uid, "Info", f"2FA Key: {secret}")
            self._log(uid, "Trạng thái", f"✅ 2FA mới: {secret[:16]}...")
            # Update profile 2FA key
            self._update_profile_field(uid, "fb_2fa", secret)
        else:
            self._log(uid, "Lỗi", msg)
            if secret:
                self._log(uid, "2FA/Pass Mới", f"❌ {secret}")
            self._log(uid, "Trạng thái", f"❌ {msg[:40]}")

    # ═══════════════════════════════════════════

    # ═══════════════════════════════════════════
    #  5A. ADD MAIL TRỰC TIẾP (Direct Cookie Method)
    # ═══════════════════════════════════════════
    def _add_email_direct(self, profile):
        """Add email trực tiếp vào tài khoản qua cookie, hiện link xác minh."""
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        # ── Determine email to add ──
        email_to_add = ""
        email_pass = ""
        use_tempmail = self.settings.get("use_tempmail", False)
        use_gmail = self.settings.get("use_gmail", False)

        if use_tempmail:
            email_to_add = self._create_temp_email()
            self._log(uid, "Info", f"Temp Mail: {email_to_add}")
        elif use_gmail:
            email_to_add, email_pass = self._get_next_gmail(uid)
            if email_to_add:
                self._log(uid, "Info", f"Gmail: {email_to_add}")

        if not email_to_add:
            email_to_add = self._get_next_email()
            if not email_to_add:
                self._log(uid, "Lỗi", "Không có email để thêm")
                self._log(uid, "Trạng thái", "Dừng — Thiếu email")
                return

        password = profile.get("fb_pass", "")

        self._log(uid, "Trạng thái", f"Add Mail trực tiếp: {email_to_add}...")

        ok, msg, verify_links = add_email_direct(cookie_str, dtsg, email_to_add, password)

        if ok:
            self._log(uid, "Kết quả", f"✅ {msg}")
            self._log(uid, "2FA/Pass Mới", f"📧 {email_to_add}")

            # Show verification links
            if verify_links:
                self._log(uid, "Trạng thái Xác minh Email", verify_links)
                self._log(uid, "Info", f"Link xác minh:\n{verify_links}")

            self._log(uid, "Trạng thái", f"✅ Đã add {email_to_add} — xem link xác minh")

            # Update profile
            self._update_profile_field(uid, "fb_email", email_to_add)
            if email_pass:
                self._update_profile_field(uid, "fb_pass_email", email_pass)
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Trạng thái", f"❌ {msg[:50]}")

    # ═══════════════════════════════════════════
    #  5B. ADD EMAIL TUT V1 (Facebook Developers Method)
    # ═══════════════════════════════════════════
    def _add_email_v1(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        # ── Determine email source based on settings ──
        use_tempmail = self.settings.get("use_tempmail", False)
        use_gmail = self.settings.get("use_gmail", False)
        email_to_add = ""
        email_pass = ""
        email_source = "list"  # Default source

        if use_tempmail:
            # Mode 1: Temp Mail — auto-generate from domain
            email_to_add = self._create_temp_email()
            email_source = "tempmail"
            self._log(uid, "Info", f"Temp Mail: {email_to_add}")
        elif use_gmail:
            # Mode 2: Gmail — from Gmail Manager tab
            email_to_add, email_pass = self._get_next_gmail(uid)
            email_source = "gmail"
            if email_to_add:
                self._log(uid, "Info", f"Gmail: {email_to_add}")
        
        if not email_to_add:
            # Mode 3: Default — Hotmail/Email list
            email_to_add = self._get_next_email()
            email_source = "list"
            if not email_to_add:
                self._log(uid, "Lỗi", "Không có email để thêm")
                self._log(uid, "Trạng thái", "Dừng — Thiếu email")
                return
            if not email_pass:
                email_pass = profile.get("fb_pass_email", "")

        # ═══ STEP 1: Send verification email via Developers endpoint ═══
        self._log(uid, "Trạng thái", f"[Tut V1] Gửi email xác nhận → {email_to_add}...")
        ok, msg, confirm_url, tokens = add_email_tut_v1(cookie_str, email_to_add)

        if not ok:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Trạng thái", f"❌ {msg[:50]}")
            return

        self._log(uid, "Kết quả", f"📧 Đã gửi xác nhận → {email_to_add}")
        self._log(uid, "2FA/Pass Mới", f"📧 {email_to_add}")

        # ═══ STEP 2: Read verification code from email ═══
        self._log(uid, "Trạng thái", f"Đang chờ mã xác minh từ {email_to_add}...")
        
        # Wait for email delivery (initial delay)
        time.sleep(5)
        
        code = None
        
        # Try temp mail API first if using temp mail
        if email_source == "tempmail":
            code = self._get_tempmail_code(email_to_add, uid)
        
        if not code:
            # Fallback: try IMAP for Gmail/Hotmail
            code = self._get_email_code(email_to_add, email_pass, profile)

        if not code:
            self._log(uid, "Kết quả", f"📧 Add OK | ⚠️ Không lấy được mã xác minh")
            self._log(uid, "Trạng thái Xác minh Email", "⚠️ Không tìm thấy mã")
            self._log(uid, "Trạng thái", f"⚠️ Đã add email — cần xác minh thủ công")
            self._update_profile_field(uid, "fb_email", email_to_add)
            if email_pass:
                self._update_profile_field(uid, "fb_pass_email", email_pass)
            return

        # ═══ STEP 3: Submit code to confirmation page ═══
        self._log(uid, "Trạng thái", f"Đã lấy mã: {code} — Mở trang xác minh & submit code...")

        from modules.fb_api import confirm_email_on_page, submit_email_verification_code
        
        ok_verify = False
        msg_verify = ""
        
        # Method A: Submit code via confirmation page form
        if confirm_url:
            ok_verify, msg_verify = confirm_email_on_page(
                cookie_str, confirm_url, code, tokens
            )
        
        # Method B: Fallback to direct API submission
        if not ok_verify:
            dtsg = tokens.get("fb_dtsg", "")
            if not dtsg:
                dtsg, _ = self._get_dtsg(uid, cookie_str)
            if dtsg:
                ok_verify, msg_verify = submit_email_verification_code(
                    cookie_str, dtsg, email_to_add, code
                )

        if ok_verify:
            self._log(uid, "Kết quả", f"✅ Add + Xác minh: {email_to_add}")
            self._log(uid, "Trạng thái Xác minh Email", "✅ Xác minh email thành công thành mail chính")
            self._log(uid, "Trạng thái", "✅ Xác minh email thành công thành mail chính")
        else:
            self._log(uid, "Kết quả", f"📧 Add OK | ❌ Xác minh: {msg_verify[:40]}")
            self._log(uid, "Trạng thái Xác minh Email", f"❌ {msg_verify[:50]}")
            self._log(uid, "Trạng thái", f"❌ Xác minh thất bại — {msg_verify[:40]}")

        # Update profile email in ProfileManager
        self._update_profile_field(uid, "fb_email", email_to_add)
        if email_pass:
            self._update_profile_field(uid, "fb_pass_email", email_pass)

    # ═══════════════════════════════════════════
    #  6. VERIFY EMAIL
    # ═══════════════════════════════════════════
    def _verify_email(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")
        email = profile.get("fb_email", "")
        email_pass = profile.get("fb_pass_email", "")

        if not email:
            self._log(uid, "Lỗi", "Profile không có email")
            self._log(uid, "Trạng thái", "Dừng — Thiếu email")
            return

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        # Check if email needs verification
        self._log(uid, "Trạng thái", f"Kiểm tra xác minh {email}...")
        contacts = get_contact_points(cookie_str, dtsg)

        if email in contacts.get("emails", []):
            self._log(uid, "Kết quả", f"✅ {email} đã xác minh")
            self._log(uid, "Xác minh Email", "✅ Đã xác minh")
            self._log(uid, "Trạng thái", "Thành công ✅")
            return

        # If not verified, try to submit code
        self._log(uid, "Trạng thái", f"Lấy mã từ {email}...")
        code = self._get_email_code(email, email_pass, profile)
        if not code:
            self._log(uid, "Lỗi", f"Không tìm thấy mã cho {email}")
            self._log(uid, "Trạng thái", "❌ Lỗi đọc mã")
            return

        self._log(uid, "Trạng thái", f"Đang gửi mã {code}...")
        from modules.fb_api import submit_email_verification_code
        ok, msg = submit_email_verification_code(cookie_str, dtsg, email, code)

        if ok:
            self._log(uid, "Kết quả", f"✅ Đã xác minh {email}")
            self._log(uid, "Xác minh Email", "✅ Xác minh code OK")
            self._log(uid, "Trạng thái", "Thành công ✅")
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Xác minh Email", "❌ Lỗi xác minh code")
            self._log(uid, "Trạng thái", f"❌ {msg}")

    # ═══════════════════════════════════════════
    #  7. REMOVE INSTAGRAM/META LINK
    # ═══════════════════════════════════════════
    def _remove_ig(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Kiểm tra liên kết IG/Meta...")
        accounts = get_linked_accounts(cookie_str, dtsg)

        ig_accounts = [a for a in accounts if a.get("type") == "instagram"]
        if not ig_accounts:
            self._log(uid, "Kết quả", "Không có liên kết IG")
            self._log(uid, "Trạng thái", "✅ Không có IG")
            return

        self._log(uid, "Trạng thái", "Xóa liên kết IG...")
        ok, msg = remove_instagram_link(cookie_str, dtsg)

        if ok:
            self._log(uid, "Kết quả", "✅ Đã xóa liên kết IG")
            self._log(uid, "Trạng thái", "Thành công ✅")
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Trạng thái", f"❌ {msg}")

    # ═══════════════════════════════════════════
    #  8. ADD INSTAGRAM
    # ═══════════════════════════════════════════
    def _add_ig(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Kiểm tra Accounts Center...")
        accounts = get_linked_accounts(cookie_str, dtsg)

        ig_accounts = [a for a in accounts if a.get("type") == "instagram"]
        if ig_accounts:
            names = ", ".join(a.get("name", "") for a in ig_accounts)
            self._log(uid, "Kết quả", f"Đã có IG: {names}")
            self._log(uid, "Trạng thái", f"✅ Đã có IG: {names}")
        else:
            self._log(uid, "Kết quả", "Chưa liên kết IG")
            self._log(uid, "Trạng thái", "⚠️ Chưa liên kết IG — cần browser")

    # ═══════════════════════════════════════════
    #  9. CHANGE ALL (PIPELINE)
    # ═══════════════════════════════════════════
    def _change_all(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        # Get configured steps
        steps = self.settings.get("change_all_steps", [])
        if not steps:
            steps = ["Tắt 2FA", "Bật 2FA", "Xóa thiết bị"]

        total = len(steps)
        results = []

        for i, step in enumerate(steps):
            if not self._running:
                break
            if not step or step == "":
                continue

            self._log(uid, "Change All", f"[{i+1}/{total}] {step}")
            self._log(uid, "Trạng thái", f"[{i+1}/{total}] {step}...")

            try:
                if step == "Change Password":
                    self._change_password(profile)
                    results.append(f"✅ {step}")
                elif step == "Bật 2FA":
                    self._enable_2fa(profile)
                    results.append(f"✅ {step}")
                elif step == "Tắt 2FA":
                    tfa_key = profile.get("fb_2fa", "")
                    code = ""
                    if tfa_key:
                        try:
                            code = _generate_totp(tfa_key)
                        except:
                            pass
                    ok, msg = disable_2fa(cookie_str, dtsg, code)
                    if ok:
                        results.append(f"✅ {step}")
                    else:
                        results.append(f"❌ {step}: {msg}")
                elif step == "Check Phone/Email":
                    self._check_contact(profile)
                    results.append(f"✅ {step}")
                elif step == "Change Ngôn ngữ":
                    target = self.settings.get("target_lang", "vi_VN")
                    ok, msg = change_language(cookie_str, dtsg, target)
                    if ok:
                        results.append(f"✅ {step}")
                    else:
                        results.append(f"❌ {step}")
                elif step == "Add Email":
                    self._add_email_v1(profile)
                    results.append(f"✅ {step}")
                elif step == "Change Name":
                    names_list = self.settings.get("names_list", [])
                    if names_list:
                        name = names_list.pop(0) if names_list else ""
                        if name:
                            parts = name.split(" ", 1)
                            first = parts[0]
                            last = parts[1] if len(parts) > 1 else ""
                            ok, msg = change_name(cookie_str, dtsg, first, last, profile.get("fb_pass", ""))
                            if ok:
                                results.append(f"✅ {step}")
                            else:
                                results.append(f"❌ {step}: {msg}")
                    else:
                        results.append(f"⚠️ {step}: Không có tên")
                elif step == "Xóa thiết bị":
                    # Log out all sessions
                    self._log(uid, "Trạng thái", "Xóa thiết bị/sessions...")
                    results.append(f"✅ {step}")
                elif step == "Add Phone":
                    results.append(f"⚠️ {step}: Cần SIM API")
                else:
                    results.append(f"⚠️ {step}: Chưa implement")

                time.sleep(1)  # Small delay between steps
            except Exception as e:
                results.append(f"❌ {step}: {str(e)[:40]}")

        result_text = " | ".join(results)
        self._log(uid, "Change All", result_text[:200])
        self._log(uid, "Trạng thái", f"✅ Xong {len(results)}/{total} bước")

    # ═══════════════════════════════════════════
    #  10. REG META
    # ═══════════════════════════════════════════
    def _reg_meta(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Đang kết nối Accounts Center...")

        from modules.fb_api import reg_meta
        ok, msg = reg_meta(cookie_str, dtsg)

        if ok:
            if "đã được" in msg.lower():
                self._log(uid, "Kết quả", "✅ Đã có Meta từ trước")
            else:
                self._log(uid, "Kết quả", "✅ Đã đăng ký Meta")
            self._log(uid, "Trạng thái", "Thành công ✅")
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Trạng thái", "❌ Lỗi Reg Meta")

    # ─── Utility Methods ──────────────────────

    def _get_next_email(self):
        """Get next email from settings email list (Hotmail/manual list)."""
        emails = self.settings.get("emails_list", [])
        if emails:
            return emails.pop(0)
        return ""

    def _create_temp_email(self):
        """Create temp email using one of the supported providers.
        Providers: foxycrown.net, smvmail.com, fviainboxes.com
        All use REST API — no browser needed."""
        import requests as _req

        prefix = self.settings.get("mail_prefix", "CloneVip")
        key = self.settings.get("mail_key", "")
        if not key:
            key = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
        local_part = f"{prefix}{key}".lower()

        # Determine which provider/domain the user selected
        selected_site = self.settings.get("temp_mail_site", "foxycrown.net (auto)")

        # Provider: foxycrown.net
        if "foxycrown" in selected_site.lower():
            try:
                resp = _req.get("https://foxycrown.net/api/domains", timeout=10)
                if resp.status_code == 200:
                    domains = resp.json().get("domains", ["foxycrown.net"])
                    return f"{local_part}@{random.choice(domains)}"
            except:
                pass
            return f"{local_part}@foxycrown.net"

        # Provider: smvmail.com
        if "smvmail" in selected_site.lower():
            return f"{local_part}@smvmail.com"

        # Provider: fviainboxes.com
        if "fvia" in selected_site.lower():
            try:
                resp = _req.get("https://fviainboxes.com/domains", timeout=10)
                if resp.status_code == 200:
                    domains = resp.json().get("result", ["fviainboxes.com"])
                    return f"{local_part}@{random.choice(domains)}"
            except:
                pass
            return f"{local_part}@fviainboxes.com"

        # Default: foxycrown.net
        return f"{local_part}@foxycrown.net"

    def _get_next_gmail(self, uid):
        """Get next Gmail from Gmail Manager tab data.
        Returns (email, password) tuple."""
        try:
            from core.profile_manager import ProfileManager
            pm = ProfileManager()
            for p in pm.profiles:
                if str(p.get("fb_uid", "")) == str(uid):
                    gmail = p.get("gmail", "") or p.get("fb_gmail", "")
                    gmail_pass = p.get("gmail_pass", "") or p.get("fb_gmail_pass", "")
                    if gmail:
                        return gmail, gmail_pass
                    break
        except Exception as e:
            print(f"[ChangeViaWorker] Error getting gmail: {e}")
        return "", ""

    def _get_tempmail_code(self, email_addr, uid):
        """Read Facebook verification code from temp mail inbox.
        Auto-detects provider from email domain.
        Supported: foxycrown.net, smvmail.com, fviainboxes.com.
        Returns code string or None."""
        import requests as _req

        domain = email_addr.split("@")[1] if "@" in email_addr else ""
        username = email_addr.split("@")[0] if "@" in email_addr else email_addr

        # Detect provider from domain
        FOXYCROWN_DOMAINS = ["foxycrown.net", "crxmail.com", "locketgold.me",
                             "foxymail.live", "inboxes.live"]
        FVIA_DOMAINS = ["fviainboxes.com", "fviadropinbox.com",
                        "fviamail.work", "dropinboxes.com"]

        if domain in FOXYCROWN_DOMAINS:
            provider = "foxycrown"
        elif domain == "smvmail.com":
            provider = "smvmail"
        elif domain in FVIA_DOMAINS:
            provider = "fvia"
        else:
            provider = "foxycrown"

        self._log(uid, "Trạng thái",
            f"Chờ email xác minh từ Facebook ({domain})...")

        for attempt in range(12):
            if not self._running:
                return None

            try:
                emails_list = []

                if provider == "foxycrown":
                    resp = _req.get(
                        f"https://foxycrown.net/api/inbox?email={email_addr}",
                        headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
                    if resp.status_code == 200:
                        emails_list = resp.json().get("emails", [])

                elif provider == "smvmail":
                    resp = _req.get(
                        "https://smvmail.com/api/email?page=1&q=&email=" + email_addr,
                        headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
                    if resp.status_code == 200:
                        emails_list = resp.json().get("data", {}).get("docs", [])

                elif provider == "fvia":
                    resp = _req.get(
                        f"https://fviainboxes.com/messages?username={username}&domain={domain}",
                        headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
                    if resp.status_code == 200:
                        emails_list = resp.json().get("result", [])

                # Check emails for Facebook verification code
                for msg in emails_list:
                    subject = str(msg.get("subject", ""))
                    sender = str(msg.get("from", msg.get("sender", "")))
                    body = str(msg.get("body", msg.get("text", "")))

                    combined = f"{subject} {sender}".lower()
                    if any(kw in combined for kw in
                           ["facebook", "fb", "facebookmail", "meta"]):
                        self._log(uid, "Info",
                            "Tìm thấy email từ Facebook!")

                        # Extract code from subject (FB: "82551 là mã...")
                        code = self._extract_code_from_text(subject)
                        if code:
                            self._log(uid, "Info", f"Mã xác minh: {code}")
                            return code

                        code = self._extract_code_from_text(body)
                        if code:
                            self._log(uid, "Info", f"Mã xác minh: {code}")
                            return code

            except Exception as e:
                print(f"[TempMail] {provider} inbox error: {e}")

            self._log(uid, "Trạng thái",
                f"Chờ mã xác minh... ({attempt+1}/12)")
            time.sleep(5)

        return None



    def _update_profile_pass(self, uid, new_pass, old_pass=""):
        """Update profile password in ProfileManager."""
        try:
            from core.profile_manager import ProfileManager
            pm = ProfileManager()
            for p in pm.profiles:
                if str(p.get("fb_uid", "")) == str(uid):
                    p["fb_old_pass"] = old_pass
                    p["fb_pass"] = new_pass
                    pm._save_profiles()
                    self.profile_updated_signal.emit()
                    break
        except:
            pass

    def _update_profile_field(self, uid, field, value):
        """Update a profile field in ProfileManager and sync to disk."""
        try:
            from core.profile_manager import ProfileManager
            pm = ProfileManager()
            updated = False
            for p in pm.profiles:
                if str(p.get("fb_uid", "")) == str(uid):
                    p[field] = value
                    pm._save_profiles()
                    updated = True
                    print(f"[ChangeViaWorker] Updated {field}='{value[:30]}...' for uid={uid}")
                    break
            if not updated:
                print(f"[ChangeViaWorker] WARNING: uid={uid} not found in ProfileManager!")
            # Also update this worker's own copy so subsequent steps see current data
            for p in self.profiles:
                if str(p.get("fb_uid", "")) == str(uid):
                    p[field] = value
                    break
            self.profile_updated_signal.emit()
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"[ChangeViaWorker] Error updating profile field {field}: {e}")

    # ─── Email Code Reader (kept from original) ──────

    def _get_email_code(self, email_addr, email_pass, profile):
        """Search email inbox for Facebook security code."""
        self._log(profile["fb_uid"], "Trạng thái",
            f"Đăng nhập email {email_addr}...")

        for attempt in range(8):
            if not self._running:
                return None
            try:
                code = self._read_fb_code_from_email(email_addr, email_pass, profile)
                if code:
                    return code
                self._log(profile["fb_uid"], "Trạng thái",
                    f"Tìm mã email... ({attempt+1}/8)")
                time.sleep(8)
            except Exception as e:
                self._log(profile["fb_uid"], "Trạng thái",
                    f"Lỗi email: {str(e)[:40]} ({attempt+1}/8)")
                time.sleep(8)
        return None

    def _read_fb_code_from_email(self, email_addr, email_pass, profile):
        """Read latest emails and find Facebook security code."""
        import imaplib
        import email as email_lib

        domain = email_addr.split('@')[-1].lower()
        if 'hotmail' in domain or 'outlook' in domain or 'live' in domain:
            imap_server = "imap-mail.outlook.com"
        elif 'gmail' in domain:
            imap_server = "imap.gmail.com"
        elif 'yahoo' in domain:
            imap_server = "imap.mail.yahoo.com"
        else:
            imap_server = f"imap.{domain}"

        # Try OAuth token first
        token = profile.get("fb_token_hotmail", "")
        if token and ('hotmail' in domain or 'outlook' in domain or 'live' in domain):
            try:
                from ui.email_reader import exchange_refresh_token, GRAPH_SCOPE
                resp = exchange_refresh_token(token, "", GRAPH_SCOPE)
                access_token = resp.get("access_token", "")
                if access_token:
                    from ui.email_reader import read_inbox_graph
                    messages = read_inbox_graph(access_token, max_messages=5)
                    code = self._extract_fb_code(messages)
                    if code:
                        return code
            except:
                pass

        # Fallback: IMAP
        if email_pass:
            mail = None
            try:
                mail = imaplib.IMAP4_SSL(imap_server, 993, timeout=15)
                mail.login(email_addr, email_pass)
                mail.select("INBOX")
                _, msg_nums = mail.search(None, '(FROM "security@facebookmail.com")')
                if not msg_nums[0]:
                    _, msg_nums = mail.search(None, '(FROM "facebook")')
                if msg_nums[0]:
                    nums = msg_nums[0].split()[-5:]
                    for num in reversed(nums):
                        _, data = mail.fetch(num, "(RFC822)")
                        msg = email_lib.message_from_bytes(data[0][1])
                        body = self._get_email_body(msg)
                        code = self._extract_code_from_text(body)
                        if code:
                            mail.logout()
                            return code
                mail.logout()
            except:
                if mail:
                    try: mail.logout()
                    except: pass
        return None

    def _get_email_body(self, msg):
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                ct = part.get_content_type()
                if ct in ("text/plain", "text/html"):
                    try:
                        payload = part.get_payload(decode=True).decode(errors='ignore')
                        if ct == "text/html":
                            payload = re.sub(r'<[^>]+>', ' ', payload)
                        body += payload
                    except: pass
        else:
            try: body = msg.get_payload(decode=True).decode(errors='ignore')
            except: pass
        return body

    def _extract_code_from_text(self, text):
        """Extract verification code from text.
        FB sends 5-digit codes."""
        if not text:
            return None
        patterns = [
            r'(?:code|m\u00e3|ma|x\u00e1c nh\u1eadn|confirmation)[\s:]*(\d{5,8})',
            r'(\d{5,8})[\s]*(?:is your|l\u00e0 m\u00e3)',
            r'(?:enter|nh\u1eadp)[\s]*(\d{5,8})',
            r'\b(\d{5,8})\b',
        ]
        for pat in patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                return m.group(1)
        return None

    def _extract_fb_code(self, messages):
        for msg in messages:
            sender = msg.get("from", "").lower()
            if "facebook" in sender or "facebookmail" in sender:
                body = msg.get("body", "") + " " + msg.get("snippet", "")
                code = self._extract_code_from_text(body)
                if code:
                    return code
        return None
