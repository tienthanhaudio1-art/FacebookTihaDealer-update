"""
Change Via Widget — Professional dark-themed UI for Facebook account operations.
Redesigned to match MM_Full reference tool layout with all settings and options.
"""
import os
from ui.copyable_table import CopyableTable
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget, QTableWidgetItem,
    QHeaderView, QLabel, QComboBox, QSpinBox, QCheckBox, QTextEdit, QTabWidget,
    QFrame, QGridLayout, QLineEdit, QSplitter, QGroupBox, QScrollArea
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QColor, QFont


# ── Temp Mail domain lists (from MM_Full reference) ──
TEMP_MAIL_DOMAINS = {
    "simmail.com": ["simmail.com"],
    "moakt.co": ["tmpmail.com", "tmpbox.net", "moakt.cc", "dishox.net",
                  "tmpmail.org", "tmpmail.net", "tmail.net", "dishox.org",
                  "moakt.co", "moakt.ws", "tmail.ws", "bareed.ws"],
    "inboxes.com": ["blomail.com", "chapsmail.com", "clownmail.com",
                     "dropjar.com", "fivemail.com", "getairmail.com",
                     "getmule.com", "getnada.com", "gimpmail.com",
                     "givmail.com", "guysmail.com", "inboxbear.com"],
    "tempm.com": ["tempm.com"],
    "emailfake.com": ["emailfake.com"],
    "dangdoanmail.com": ["dangdoanmail.com"],
    "custom site": [],
    "ciprmail.com": ["ciprmail.com"],
    "cloicmail.com": ["cloicmail.com"],
    "to-mail.net": ["to-mail.net", "to-mail.cc", "to-mail.org",
                     "tp-mail.xyz", "pt-mail.org", "ro-games.com"],
    "5mail.email": ["5mail.email"],
    "tempmail.ai": ["tempmail.ai"],
    "tempmail.plus": ["mailto.plus", "fexpost.com", "fexbox.org",
                       "mailbox.in.ua", "rover.info", "chitthi.in",
                       "foxtemp.com", "any.pink", "merepost.com"],
    "mailcx": ["qabq.com", "nqmo.com", "end.tw", "vuf.me", "vzm.de"],
    "malingon.top": ["malingon.top", "malingon.net", "malingon.com"],
    "unlimitmail": [],
}


class ChangeViaWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.workers = []
        self.profile_manager = None
        self._init_ui()

    def set_profile_manager(self, pm):
        """Set ProfileManager reference for UID lookup."""
        self.profile_manager = pm

    def _init_ui(self):
        self.setObjectName("ChangeViaMain")
        self.setStyleSheet(self._build_stylesheet())

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(8, 6, 8, 6)
        main_layout.setSpacing(6)

        # ═══════════════════════════════════════════
        #  1. ACTION BUTTONS ROW
        # ═══════════════════════════════════════════
        btn_row = QHBoxLayout()
        btn_row.setSpacing(4)

        actions = [
            ("Change Password", "change_pass",   "#1e6fa0", "#155d8a"),
            ("Bật 2FA",         "enable_2fa",     "#c25100", "#a84700"),
            ("Check Ngôn Ngữ",  "check_lang",     "#0a8050", "#077040"),
            ("Check Phone/Email","check_contact",  "#0a8050", "#077040"),
            ("Add Email",       "add_email",      "#1e6fa0", "#155d8a"),
            ("Xác thực Email",  "verify_email",   "#7b3fa0", "#6a3590"),
            ("Xóa LK Insta/Meta","remove_ig",     "#1e6fa0", "#155d8a"),
            ("Add Insta",       "add_ig",         "#0a8050", "#077040"),
            ("Change All",      "change_all",     "#1e6fa0", "#155d8a"),
            ("Reg Meta",        "reg_meta",       "#1e6fa0", "#155d8a"),
        ]

        self.buttons = {}
        for label, key, c1, c2 in actions:
            btn = QPushButton(label)
            btn.setFixedHeight(28)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                        stop:0 {c1}, stop:1 {c2});
                    color: white; font-weight: 700; border-radius: 3px;
                    padding: 0 10px; border: none; font-size: 11px;
                }}
                QPushButton:hover {{
                    background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                        stop:0 {c1}dd, stop:1 {c1});
                }}
                QPushButton:pressed {{ background: {c2}; }}
            """)
            btn.clicked.connect(
                lambda checked, k=key, l=label: self.start_action(k, l)
            )
            btn_row.addWidget(btn)
            self.buttons[key] = btn

        # Stop button
        self.btn_stop = QPushButton("Stop")
        self.btn_stop.setFixedHeight(28)
        self.btn_stop.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_stop.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #c92020, stop:1 #a01010);
                color: white; font-weight: 700; border-radius: 3px;
                padding: 0 14px; border: none; font-size: 11px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #e03030, stop:1 #c92020);
            }
            QPushButton:pressed { background: #801010; }
        """)
        self.btn_stop.clicked.connect(self.stop_all)
        btn_row.addWidget(self.btn_stop)

        main_layout.addLayout(btn_row)

        # ═══════════════════════════════════════════
        #  2. SETTINGS AREA (4 rows of options)
        # ═══════════════════════════════════════════
        settings_frame = QFrame()
        settings_frame.setObjectName("SettingsCard")
        sf_layout = QVBoxLayout(settings_frame)
        sf_layout.setContentsMargins(8, 6, 8, 6)
        sf_layout.setSpacing(4)

        # ── Row 1: Delay, Threads, Language, Accountscenter, TempMail, Remove old ──
        r1 = QHBoxLayout()
        r1.setSpacing(6)

        r1.addWidget(QLabel("Delay"))
        self.spin_delay = QSpinBox()
        self.spin_delay.setFixedWidth(45)
        self.spin_delay.setValue(0)
        r1.addWidget(self.spin_delay)

        r1.addWidget(QLabel("Số luồng"))
        self.spin_threads = QSpinBox()
        self.spin_threads.setFixedWidth(45)
        self.spin_threads.setValue(8)
        self.spin_threads.setMinimum(1)
        self.spin_threads.setMaximum(50)
        r1.addWidget(self.spin_threads)

        r1.addWidget(QLabel("Change Ngôn Ngữ sang"))
        self.combo_lang = QComboBox()
        self.combo_lang.addItems(["vi_VN", "en_US", "ja_JP", "ko_KR", "zh_CN",
                                  "th_TH", "pt_BR", "es_ES", "fr_FR", "de_DE"])
        self.combo_lang.setFixedWidth(80)
        r1.addWidget(self.combo_lang)

        self.chk_use_accountscenter = QCheckBox("Sử dụng link accountscenter")
        self.chk_use_accountscenter.setChecked(True)
        r1.addWidget(self.chk_use_accountscenter)

        self.chk_use_tempmail = QCheckBox("Sử dụng Temp Mail")
        r1.addWidget(self.chk_use_tempmail)
        self.combo_tempmail = QComboBox()
        self.combo_tempmail.addItems(list(TEMP_MAIL_DOMAINS.keys()))
        self.combo_tempmail.setFixedWidth(120)
        r1.addWidget(self.combo_tempmail)

        self.chk_no_remove_oldmail = QCheckBox("Không xóa mail Old")
        self.chk_no_remove_oldmail.setChecked(True)
        r1.addWidget(self.chk_no_remove_oldmail)

        r1.addWidget(QLabel("Mở Insta Chạy khi Add Email (lần)"))
        self.spin_insta_runs = QSpinBox()
        self.spin_insta_runs.setFixedWidth(45)
        self.spin_insta_runs.setValue(0)
        r1.addWidget(self.spin_insta_runs)

        r1.addStretch()
        sf_layout.addLayout(r1)

        # ── Row 2: Check Phone/Email settings, Email config ──
        r2 = QHBoxLayout()
        r2.setSpacing(6)

        self.combo_check_phone = QComboBox()
        self.combo_check_phone.addItems([
            "Chức năng Check Phone/Email số",
            "Chỉ check Info",
            "Xác thực email nếu chưa xác thực",
            "Xóa Toàn bộ Email trả mail trên tool"
        ])
        self.combo_check_phone.setFixedWidth(230)
        r2.addWidget(self.combo_check_phone)

        self.combo_remove_phone = QComboBox()
        self.combo_remove_phone.addItems(["Xóa Phone bằng tút", "Xóa Phone", "Xóa Phone bằng hít"])
        self.combo_remove_phone.setFixedWidth(140)
        r2.addWidget(self.combo_remove_phone)

        self.chk_keep_old_email = QCheckBox("Để email cũ sau khi Add Email")
        r2.addWidget(self.chk_keep_old_email)

        self.combo_add_email_tut = QComboBox()
        self.combo_add_email_tut.addItems(["Add Email Tut 1", "Add Email Tut 2", "Add Email Tut 3"])
        self.combo_add_email_tut.setFixedWidth(120)
        r2.addWidget(self.combo_add_email_tut)

        self.chk_2fa_checkpoint = QCheckBox("Bật 2fa cho nick bị Checkpoint Block")
        self.chk_2fa_checkpoint.setChecked(True)
        r2.addWidget(self.chk_2fa_checkpoint)

        r2.addWidget(QLabel("Xóa liên kết"))
        self.combo_remove_link = QComboBox()
        self.combo_remove_link.addItems(["Insta + Meta", "Chỉ Insta", "Chỉ Meta"])
        self.combo_remove_link.setFixedWidth(100)
        r2.addWidget(self.combo_remove_link)

        self.chk_reg_meta_other = QCheckBox("Reg Meta từ Email khác")
        r2.addWidget(self.chk_reg_meta_other)

        r2.addStretch()
        sf_layout.addLayout(r2)

        # ── Row 3: Add Mail retry, naming pattern, API Android, login new ──
        r3 = QHBoxLayout()
        r3.setSpacing(6)

        self.chk_addmail_retry = QCheckBox("Chức năng Add Mail có mỗi chạy")
        r3.addWidget(self.chk_addmail_retry)

        r3.addWidget(QLabel("nick thì nghỉ (phút)"))
        self.txt_rest_minutes = QLineEdit()
        self.txt_rest_minutes.setFixedWidth(50)
        r3.addWidget(self.txt_rest_minutes)

        r3.addWidget(QLabel("Cấu trúc đặt tên mail temp(vd du CloneVip*****)"))
        self.txt_mail_pattern = QLineEdit()
        self.txt_mail_pattern.setFixedWidth(180)
        r3.addWidget(self.txt_mail_pattern)

        self.chk_api_android = QCheckBox("Chạy qua API Android")
        r3.addWidget(self.chk_api_android)

        self.chk_login_new = QCheckBox("Login New trước khi chạy")
        r3.addWidget(self.chk_login_new)

        self.chk_addmail_submit_code = QCheckBox("Chức năng Add Email submit code qua api acc Noverify")
        r3.addWidget(self.chk_addmail_submit_code)

        r3.addStretch()
        sf_layout.addLayout(r3)

        # ── Row 4: Cookie operations, Spam Reg Meta ──
        r4 = QHBoxLayout()
        r4.setSpacing(6)

        self.chk_cookie_remove = QCheckBox("Xóa Mail/Phone bằng tut mới (cookie)")
        self.chk_cookie_remove.setChecked(True)
        r4.addWidget(self.chk_cookie_remove)

        r4.addWidget(QLabel("Spam Reg Meta (lần)"))
        self.spin_spam_reg = QSpinBox()
        self.spin_spam_reg.setFixedWidth(45)
        self.spin_spam_reg.setValue(10)
        r4.addWidget(self.spin_spam_reg)

        r4.addStretch()
        sf_layout.addLayout(r4)

        main_layout.addWidget(settings_frame)

        # ═══════════════════════════════════════════
        #  3. DATA TABS
        # ═══════════════════════════════════════════
        self.tabs = QTabWidget()
        self.tabs.setObjectName("DataTabs")

        # Tab 1: Thông tin tài khoản
        tab_info = QWidget()
        tab_info.setObjectName("TabContent")
        tl = QHBoxLayout(tab_info)
        tl.setContentsMargins(6, 6, 6, 6)
        tl.setSpacing(6)

        self.txt_profiles = self._make_textarea("Danh sách Profile", "0", True)
        self.txt_passwords = self._make_textarea(
            "Mật khẩu mới(Cấu trúc Matkhau****)", "", False
        )
        self.txt_instagram = self._make_textarea(
            "Danh sách Instagram (nick Insta lấy từ InstaZM)", "", True
        )
        self.txt_emails = self._make_textarea("List Add Email", "0", True)
        self.txt_2fa_col = self._make_textarea("2FA", "0", True)
        self.txt_names = self._make_textarea("Danh sách Tên", "0", True)

        tl.addWidget(self.txt_profiles, stretch=2)
        tl.addWidget(self.txt_passwords, stretch=3)
        tl.addWidget(self.txt_instagram, stretch=3)
        tl.addWidget(self.txt_emails, stretch=3)
        tl.addWidget(self.txt_2fa_col, stretch=1)
        tl.addWidget(self.txt_names, stretch=2)

        # Tab 2: Setting Change All
        self._init_tab_change_all()

        # Tab 3: Cấu hình cho Custom Site
        self._init_tab_custom_site()

        self.tabs.addTab(tab_info, "Thông tin tài khoản")
        self.tabs.addTab(self.tab_change_all, "Setting cho nút Change All")
        self.tabs.addTab(self.tab_custom_site, "Cấu hình cho Custom Site")

        main_layout.addWidget(self.tabs)

        # ═══════════════════════════════════════════
        #  4. RESULTS TABLE
        # ═══════════════════════════════════════════
        self.table = CopyableTable()
        self.table.setObjectName("ResultsTable")
        self.cols = [
            ("stt", "STT"),
            ("uid", "Profile"),
            ("info", "Info"),
            ("err", "Lỗi"),
            ("result", "Kết quả"),
            ("info_2fa", "Info xóa 2FA Cũ"),
            ("status", "Trạng thái"),
            ("change_all", "Kết quả Change All"),
            ("verify", "Trạng thái Xác minh Email"),
        ]
        self.table.setColumnCount(len(self.cols))
        self.table.setHorizontalHeaderLabels([c[1] for c in self.cols])
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(False)

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        widths = [35, 130, 80, 100, 160, 110, 140, 160]
        for i, w in enumerate(widths):
            self.table.setColumnWidth(i, w)

        main_layout.addWidget(self.table)

        self.profiles_data = []

    # ═══════════════════════════════════════════
    #  Stylesheet
    # ═══════════════════════════════════════════
    def _build_stylesheet(self):
        return """
            #ChangeViaMain {
                background: #0f1219;
            }

            #SettingsCard {
                background: #1a1f2e;
                border: 1px solid #2a3348;
                border-radius: 6px;
                padding: 2px;
            }
            #SettingsCard QLabel {
                color: #e2e8f0; font-size: 11px; font-weight: 600;
                background: transparent;
            }
            #SettingsCard QCheckBox {
                color: #e2e8f0; font-weight: 600; font-size: 11px;
            }
            #SettingsCard QCheckBox::indicator {
                width: 14px; height: 14px;
                border: 2px solid #64748b; border-radius: 3px;
                background: #0f172a;
            }
            #SettingsCard QCheckBox::indicator:checked {
                background: #3b82f6; border-color: #93c5fd;
            }
            #SettingsCard QComboBox, #SettingsCard QSpinBox, #SettingsCard QLineEdit {
                background: #0f172a; border: 1px solid #475569;
                border-radius: 3px; padding: 3px 6px;
                color: #f8fafc; min-height: 20px; font-size: 11px;
            }
            #SettingsCard QComboBox::drop-down {
                border: none; width: 16px;
            }

            #DataTabs::pane {
                background: #131824; border: 1px solid #2a3348;
                border-radius: 6px; border-top-left-radius: 0;
            }
            #DataTabs > QTabBar::tab {
                background: #151a27; border: 1px solid #2a3348;
                border-bottom: none; padding: 6px 14px;
                margin-right: 2px; font-weight: 600;
                color: #94a3b8; border-top-left-radius: 4px;
                border-top-right-radius: 4px; font-size: 11px;
            }
            #DataTabs > QTabBar::tab:selected {
                background: #131824; color: #93c5fd;
                border-top: 2px solid #3b82f6;
            }
            #DataTabs > QTabBar::tab:hover:!selected {
                background: #1a2035; color: #e2e8f0;
            }

            #ResultsTable {
                background: #0f1219; gridline-color: #1e293b;
                border: 1px solid #2a3348; border-radius: 4px;
                font-size: 11px; color: #f1f5f9;
            }
            #ResultsTable QHeaderView::section {
                background: #1a1f2e; padding: 5px 4px;
                border: none; border-bottom: 2px solid #2a3348;
                border-right: 1px solid #1e293b;
                font-weight: 700; color: #cbd5e1;
                font-size: 11px;
            }
            #ResultsTable::item { padding: 3px; }
            #ResultsTable::item:selected {
                background: #1e3a5f; color: #93c5fd;
            }
        """

    def _make_textarea(self, title, initial="", show_count=True):
        w = QWidget()
        w.setStyleSheet("background: transparent;")
        l = QVBoxLayout(w)
        l.setContentsMargins(0, 0, 0, 0)
        l.setSpacing(0)

        # Header
        hdr = QWidget()
        hdr.setFixedHeight(24)
        hdr.setStyleSheet("""
            background: #1a2035;
            border: 1px solid #2a3348;
            border-bottom: none;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
        """)
        hl = QHBoxLayout(hdr)
        hl.setContentsMargins(8, 0, 8, 0)

        lbl = QLabel(title)
        lbl.setStyleSheet(
            "color: #cbd5e1; font-size: 10px; font-weight: 700; "
            "border: none; background: transparent;"
        )
        hl.addWidget(lbl)
        hl.addStretch()

        count_lbl = QLabel("0")
        count_lbl.setStyleSheet(
            "color: #f87171; font-size: 10px; font-weight: 700; "
            "border: none; background: transparent;"
        )
        if show_count:
            hl.addWidget(count_lbl)

        l.addWidget(hdr)

        txt = QTextEdit()
        txt.setStyleSheet("""
            QTextEdit {
                background: #0f1219; border: 1px solid #2a3348;
                border-top: 1px solid #1e2538;
                font-family: 'Cascadia Code', Consolas, monospace;
                font-size: 11px; color: #e2e8f0;
                border-bottom-left-radius: 4px;
                border-bottom-right-radius: 4px;
            }
            QTextEdit:focus { border: 1px solid #3b82f6; }
        """)
        if initial and initial != "0":
            txt.setPlainText(initial)

        if show_count:
            def update_count():
                cnt = len([x for x in txt.toPlainText().split('\n') if x.strip()])
                count_lbl.setText(str(cnt))
            txt.textChanged.connect(update_count)
            update_count()

        l.addWidget(txt)
        w.text_edit = txt
        return w

    # ─── Tab: Setting Change All ──────────────
    def _init_tab_change_all(self):
        self.tab_change_all = QWidget()
        self.tab_change_all.setObjectName("TabContent")
        layout = QVBoxLayout(self.tab_change_all)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        lbl = QLabel("Các bước chạy Change All")
        lbl.setStyleSheet("font-weight: 700; color: #a78bfa; font-size: 12px;")
        layout.addWidget(lbl)

        step_options = [
            "", "Get Token", "Add Email", "Tắt 2FA", "Bật 2FA", "Change Name",
            "Change Password", "Xóa thiết bị", "Check Phone/Email",
            "Change Ngôn ngữ", "Add Phone", "Xóa LK Insta/Meta",
            "Reg Meta", "Xác thực Email"
        ]
        row = QHBoxLayout()
        row.setSpacing(4)
        self.combo_steps = []
        for i in range(7):
            cb = QComboBox()
            cb.addItems(step_options)
            cb.setMinimumWidth(95)
            self.combo_steps.append(cb)
            row.addWidget(cb)
        self.combo_steps[0].setCurrentText("Tắt 2FA")
        self.combo_steps[1].setCurrentText("Bật 2FA")
        self.combo_steps[2].setCurrentText("Xóa thiết bị")
        row.addStretch()
        layout.addLayout(row)

        # Options
        row2 = QHBoxLayout()
        row2.setSpacing(10)
        self.chk_relogin_all = QCheckBox("Relogin FB trước khi chạy")
        self.chk_log_out = QCheckBox("Log out tất cả thiết bị")
        self.chk_log_out.setChecked(True)
        self.chk_retry_api = QCheckBox("Retry lỗi API")
        self.chk_retry_api.setChecked(True)
        self.spin_retry = QSpinBox()
        self.spin_retry.setValue(5)
        self.spin_retry.setFixedWidth(45)
        row2.addWidget(self.chk_relogin_all)
        row2.addWidget(self.chk_log_out)
        row2.addWidget(self.chk_retry_api)
        row2.addWidget(self.spin_retry)
        row2.addWidget(QLabel("lần"))
        row2.addStretch()
        layout.addLayout(row2)

        layout.addStretch()

    # ─── Tab: Cấu hình Custom Site ──────────────
    def _init_tab_custom_site(self):
        self.tab_custom_site = QWidget()
        self.tab_custom_site.setObjectName("TabContent")
        layout = QVBoxLayout(self.tab_custom_site)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        lbl = QLabel("Cấu hình Custom Site cho Temp Mail")
        lbl.setStyleSheet("font-weight: 700; color: #a78bfa; font-size: 12px;")
        layout.addWidget(lbl)

        r = QHBoxLayout()
        r.setSpacing(8)
        r.addWidget(QLabel("Domain:"))
        self.txt_custom_domain = QLineEdit()
        self.txt_custom_domain.setPlaceholderText("example.com")
        self.txt_custom_domain.setFixedWidth(200)
        r.addWidget(self.txt_custom_domain)

        r.addWidget(QLabel("API Key:"))
        self.txt_custom_api_key = QLineEdit()
        self.txt_custom_api_key.setPlaceholderText("API Key nếu cần")
        self.txt_custom_api_key.setMinimumWidth(250)
        r.addWidget(self.txt_custom_api_key)
        r.addStretch()
        layout.addLayout(r)

        layout.addStretch()

    # ─── Profile Parsing ──────────────────────
    def _parse_profiles_input(self):
        """Parse UID list and lookup full profile data from ProfileManager."""
        text = self.txt_profiles.text_edit.toPlainText().strip()
        lines = [x.strip() for x in text.split('\n') if x.strip()]
        self.profiles_data = []

        # Build UID lookup from ProfileManager
        pm_lookup = {}
        if self.profile_manager:
            for p in self.profile_manager.get_all_profiles():
                uid = str(p.get("fb_uid", ""))
                if uid:
                    pm_lookup[uid] = p

        for line in lines:
            parts = line.split('|')
            uid = parts[0].strip()
            if not uid:
                continue

            # Lookup from Profile Manager
            pm_profile = pm_lookup.get(uid, {})

            profile = {
                "fb_uid": uid,
                "fb_pass": pm_profile.get("fb_pass", parts[1].strip() if len(parts) > 1 else ""),
                "fb_2fa": pm_profile.get("fb_2fa", parts[2].strip() if len(parts) > 2 else ""),
                "fb_cookie": pm_profile.get("fb_cookie", parts[3].strip() if len(parts) > 3 else ""),
                "fb_token": pm_profile.get("fb_token", parts[4].strip() if len(parts) > 4 else ""),
                "fb_email": pm_profile.get("fb_email", ""),
                "fb_pass_email": pm_profile.get("fb_pass_email", ""),
                "fb_token_hotmail": pm_profile.get("fb_token_hotmail", ""),
                "fb_name": pm_profile.get("fb_name", ""),
                "raw": line,
            }
            self.profiles_data.append(profile)

        # Populate table
        self.table.setRowCount(0)
        for i, p in enumerate(self.profiles_data):
            self.table.insertRow(i)
            stt = QTableWidgetItem(str(i + 1))
            stt.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(i, 0, stt)

            uid_item = QTableWidgetItem(p["fb_uid"])
            uid_item.setForeground(QColor("#a78bfa"))
            self.table.setItem(i, 1, uid_item)

            # Show name if available
            if p["fb_name"]:
                info = QTableWidgetItem(p["fb_name"])
                info.setForeground(QColor("#94a3b8"))
                self.table.setItem(i, 2, info)

            # Show auth status
            auth = "🔒" if p["fb_cookie"] else "❌"
            if p["fb_token"]:
                auth += " 🔑"
            status = QTableWidgetItem(f"{auth} Sẵn sàng")
            status.setForeground(QColor("#4ade80") if p["fb_cookie"] else QColor("#f87171"))
            self.table.setItem(i, 6, status)

    def load_profiles(self, profiles_list: list):
        """Called from main window to populate tab with UIDs."""
        lines = []
        for p in profiles_list:
            uid = p.get("fb_uid", "")
            if uid:
                lines.append(uid)

        current = self.txt_profiles.text_edit.toPlainText()
        if current.strip():
            self.txt_profiles.text_edit.setPlainText(
                current + "\n" + "\n".join(lines)
            )
        else:
            self.txt_profiles.text_edit.setPlainText("\n".join(lines))
        self._parse_profiles_input()

    def start_action(self, action_key, action_label):
        """Start a Change Via action on all parsed profiles."""
        self._parse_profiles_input()
        if not self.profiles_data:
            return

        settings = {
            "delay": self.spin_delay.value(),
            "threads": self.spin_threads.value(),
            "new_pass": self.txt_passwords.text_edit.toPlainText().strip() or "2026Key1@#@#",
            "cookie_mode": self.chk_cookie_remove.isChecked(),
            "api_android_mode": self.chk_api_android.isChecked(),
            "target_lang": self.combo_lang.currentText(),
            "use_accountscenter": self.chk_use_accountscenter.isChecked(),
            "use_tempmail": self.chk_use_tempmail.isChecked(),
            "tempmail_domain": self.combo_tempmail.currentText(),
            "keep_old_email": self.chk_no_remove_oldmail.isChecked(),
            "login_new": self.chk_login_new.isChecked(),
            "add_email_tut": self.combo_add_email_tut.currentText(),
            "remove_link_type": self.combo_remove_link.currentText(),
            "spam_reg_meta": self.spin_spam_reg.value(),
            "emails_list": [
                x.strip() for x in
                self.txt_emails.text_edit.toPlainText().split('\n')
                if x.strip()
            ],
            "names_list": [
                x.strip() for x in
                self.txt_names.text_edit.toPlainText().split('\n')
                if x.strip()
            ],
            "change_all_steps": [
                cb.currentText() for cb in self.combo_steps
                if cb.currentText()
            ],
        }

        from modules.change_via_worker import ChangeViaWorker
        worker = ChangeViaWorker(self.profiles_data, action_label, settings)
        worker.log_signal.connect(self.update_log)
        worker.finished_all.connect(lambda: self._on_finished(worker))
        worker.start()
        self.workers.append(worker)

    def update_log(self, uid, col_name, msg):
        """Update a cell in the results table."""
        col_idx = -1
        for i, (k, l) in enumerate(self.cols):
            if l == col_name:
                col_idx = i
                break
        if col_idx == -1:
            return

        for r in range(self.table.rowCount()):
            item = self.table.item(r, 1)
            if item and item.text() == uid:
                target = self.table.item(r, col_idx)
                if not target:
                    target = QTableWidgetItem()
                    target.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    self.table.setItem(r, col_idx, target)
                target.setText(msg)

                # Colorize
                if "Thành công" in msg or "✅" in msg:
                    target.setForeground(QColor("#4ade80"))
                elif "Thất bại" in msg or "❌" in msg or "Lỗi" in msg:
                    target.setForeground(QColor("#f87171"))
                elif "Dừng" in msg or "Out" in msg:
                    target.setForeground(QColor("#fbbf24"))
                elif "Đang" in msg:
                    target.setForeground(QColor("#a78bfa"))
                break

    def _on_finished(self, worker):
        if worker in self.workers:
            self.workers.remove(worker)

    def stop_all(self):
        for w in self.workers:
            w.stop()
        self.workers.clear()
