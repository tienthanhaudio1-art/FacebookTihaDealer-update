"""
Change Via Worker — Background executor for Change Via tab actions.
Uses Facebook cookie-based API (modules/fb_api.py) for fast, multi-threaded ops.

Supported: Check Language, Check Phone/Email, Change Password, Enable/Disable 2FA,
           Add Email, Verify Email, Remove IG/Meta, Add Insta, Change All, Reg Meta.
"""
import re
import time
import os
from datetime import datetime
from PyQt6.QtCore import QThread, pyqtSignal

from modules.fb_api import (
    get_fb_dtsg, check_cookie, get_language, change_language,
    get_contact_points, change_password_api,
    get_2fa_status, enable_2fa_totp, enable_2fa_totp_graphql, disable_2fa, _generate_totp,
    add_email_tut_v1, remove_email,
    get_linked_accounts, remove_instagram_link,
    change_name, graphql_request, parse_cookie_string,
)


class ChangeViaWorker(QThread):
    """Worker thread for Change Via operations."""
    log_signal = pyqtSignal(str, str, str)   # uid, column_name, message
    finished_one = pyqtSignal(str)
    finished_all = pyqtSignal()
    profile_updated_signal = pyqtSignal()

    def __init__(self, profiles: list, action: str, settings: dict):
        super().__init__()
        self.profiles = profiles
        self.action = action
        self.settings = settings
        self._running = True

    def stop(self):
        self._running = False

    def _log(self, uid, col, msg):
        self.log_signal.emit(uid, col, msg)

    def run(self):
        for p in self.profiles:
            if not self._running:
                break

            uid = p.get("fb_uid", "")
            if not uid:
                continue

            self._log(uid, "Trạng thái", "Đang xử lý...")
            self._log(uid, "Kết quả", "")
            self._log(uid, "Lỗi", "")

            # Check auth
            cookie_mode = self.settings.get("cookie_mode", True)
            cookie_str = p.get("fb_cookie", "")
            token = p.get("fb_token", "")

            if cookie_mode and not cookie_str:
                self._log(uid, "Lỗi", "Cookie Out")
                self._log(uid, "Trạng thái", "Dừng — Thiếu Cookie")
                self.finished_one.emit(uid)
                continue

            # Delay
            delay = self.settings.get("delay", 0)
            if delay > 0:
                time.sleep(delay)

            try:
                action_map = {
                    "Get Token": self._get_token,
                    "Check Ngôn Ngữ": self._check_language,
                    "Check Phone/Email": self._check_contact,
                    "Change Password": self._change_password,
                    "Bật 2FA": self._enable_2fa,
                    "Add Email": self._add_email_v1,
                    "Add Email Tut V1": self._add_email_v1,
                    "Xác thực Email": self._verify_email,
                    "Xóa LK Insta/Meta": self._remove_ig,
                    "Add Insta": self._add_ig,
                    "Change All": self._change_all,
                    "Reg Meta": self._reg_meta,
                }

                handler = action_map.get(self.action)
                if handler:
                    handler(p)
                else:
                    self._log(uid, "Trạng thái", f"[{self.action}] Chưa implement")
            except Exception as e:
                import traceback
                traceback.print_exc()
                self._log(uid, "Lỗi", str(e)[:100])
                self._log(uid, "Trạng thái", "Lỗi hệ thống")

            self.finished_one.emit(uid)

        self.finished_all.emit()

    # ─── Helper: Get fb_dtsg with caching ──────
    def _get_dtsg(self, uid, cookie_str):
        """Get fb_dtsg, with status updates."""
        self._log(uid, "Trạng thái", "Lấy fb_dtsg token...")
        dtsg, jazoest = get_fb_dtsg(cookie_str)
        if not dtsg:
            self._log(uid, "Lỗi", "Cookie Die — không lấy được fb_dtsg")
            self._log(uid, "Trạng thái", "Cookie Out")
            return None, None
        return dtsg, jazoest

    # ═══════════════════════════════════════════
    #  0. GET TOKEN
    # ═══════════════════════════════════════════
    def _get_token(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        self._log(uid, "Trạng thái", "Đang lấy Token từ Ads Manager...")

        from modules.fb_api import get_eaag_token
        ok, token, msg = get_eaag_token(cookie_str)

        if ok and token:
            self._log(uid, "Kết quả", "✅ Lấy Token thành công")
            self._log(uid, "Token", token)
            self._log(uid, "Trạng thái", "Thành công ✅")
            # Save token to profile
            self._update_profile_field(uid, "fb_token", token)
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Trạng thái", f"❌ {msg}")

    # ═══════════════════════════════════════════
    #  1. CHECK LANGUAGE
    # ═══════════════════════════════════════════
    def _check_language(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        self._log(uid, "Trạng thái", "Kiểm tra ngôn ngữ...")
        lang = get_language(cookie_str)

        if lang:
            self._log(uid, "Kết quả", f"Ngôn ngữ: {lang}")

            # Change language if requested
            target_lang = self.settings.get("target_lang", "")
            if target_lang and target_lang != lang:
                dtsg, _ = self._get_dtsg(uid, cookie_str)
                if dtsg:
                    self._log(uid, "Trạng thái", f"Đổi ngôn ngữ → {target_lang}...")
                    ok, msg = change_language(cookie_str, dtsg, target_lang)
                    if ok:
                        self._log(uid, "Kết quả", f"✅ {lang} → {target_lang}")
                        self._log(uid, "Trạng thái", "Thành công ✅")
                    else:
                        self._log(uid, "Lỗi", msg)
                        self._log(uid, "Trạng thái", "❌ Lỗi đổi ngôn ngữ")
                    return

            self._log(uid, "Trạng thái", f"✅ Ngôn ngữ: {lang}")
        else:
            self._log(uid, "Lỗi", "Cookie Die")
            self._log(uid, "Trạng thái", "Cookie Out")

    # ═══════════════════════════════════════════
    #  2. CHECK PHONE/EMAIL
    # ═══════════════════════════════════════════
    def _check_contact(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Kiểm tra Phone/Email...")
        contacts = get_contact_points(cookie_str, dtsg)

        emails = contacts.get("emails", [])
        phones = contacts.get("phones", [])

        info_parts = []
        if emails:
            info_parts.append(f"📧 {', '.join(emails)}")
        if phones:
            info_parts.append(f"📱 {', '.join(phones)}")

        if info_parts:
            result = " | ".join(info_parts)
            self._log(uid, "Kết quả", result)
            self._log(uid, "Info", f"E:{len(emails)} P:{len(phones)}")
            self._log(uid, "Trạng thái", f"✅ E:{len(emails)} P:{len(phones)}")
        else:
            self._log(uid, "Kết quả", "Không tìm thấy contact")
            self._log(uid, "Trạng thái", "⚠️ Không có contact")

    # ═══════════════════════════════════════════
    #  3. CHANGE PASSWORD
    # ═══════════════════════════════════════════
    def _change_password(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")
        old_pass = profile.get("fb_pass", "")
        new_pass = self.settings.get("new_pass", "")

        if not old_pass:
            self._log(uid, "Lỗi", "Thiếu mật khẩu cũ")
            self._log(uid, "Trạng thái", "Dừng — Không có pass cũ")
            return

        if not new_pass:
            self._log(uid, "Lỗi", "Thiếu mật khẩu mới")
            self._log(uid, "Trạng thái", "Dừng — Không có pass mới")
            return

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Đổi mật khẩu (API)...")
        ok, msg = change_password_api(cookie_str, dtsg, old_pass, new_pass)

        if ok:
            self._log(uid, "Kết quả", f"✅ Đổi pass thành công")
            self._log(uid, "2FA/Pass Mới", f"🔒 {new_pass}")
            self._log(uid, "Trạng thái", "Thành công ✅")
            self._update_profile_pass(uid, new_pass, old_pass)
        else:
            # Fallback: try browser method
            self._log(uid, "Lỗi", f"API: {msg}")
            self._log(uid, "Trạng thái", f"❌ {msg}")

    # ═══════════════════════════════════════════
    #  4. ENABLE 2FA
    # ═══════════════════════════════════════════
    def _enable_2fa(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")
        old_2fa_secret = profile.get("fb_2fa", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        # Check current 2FA status
        self._log(uid, "Trạng thái", "Kiểm tra 2FA...")
        enabled, method = get_2fa_status(cookie_str, dtsg)

        if enabled:
            # 2FA already enabled → need to DISABLE first, then ENABLE new one
            self._log(uid, "Info xóa 2FA Cũ", old_2fa_secret or method)
            self._log(uid, "Trạng thái", "Tắt 2FA cũ trước...")

            # Generate TOTP code from old secret to disable
            tfa_code = ""
            if old_2fa_secret:
                try:
                    tfa_code = _generate_totp(old_2fa_secret)
                    self._log(uid, "Trạng thái", f"Tắt 2FA (code: {tfa_code})...")
                except Exception as e:
                    self._log(uid, "Lỗi", f"Lỗi tạo OTP từ secret cũ: {str(e)[:40]}")
                    self._log(uid, "Trạng thái", "❌ Không tạo được OTP từ 2FA cũ")
                    return

            ok_off, msg_off = disable_2fa(cookie_str, dtsg, tfa_code)
            if not ok_off:
                self._log(uid, "Lỗi", f"Tắt 2FA thất bại: {msg_off}")
                self._log(uid, "Trạng thái", f"❌ {msg_off}")
                return

            self._log(uid, "Trạng thái", "✅ Đã tắt 2FA cũ — bật 2FA mới...")
            # Re-get dtsg after disabling (session may change)
            dtsg, _ = self._get_dtsg(uid, cookie_str)
            if not dtsg:
                return

        # Enable 2FA (either fresh or after disabling old)
        method_opt = self.settings.get("two_fa_method", "")
        self._log(uid, "Trạng thái", f"Bật 2FA [{method_opt[:8]}]...")

        if "Method B" in method_opt:
            ok, secret, msg = enable_2fa_totp_graphql(cookie_str, dtsg)
        else:
            ok, secret, msg = enable_2fa_totp(cookie_str, dtsg)

        if ok:
            self._log(uid, "Kết quả", f"✅ Bật 2FA [{method_opt[:8]}]")
            self._log(uid, "2FA/Pass Mới", f"🔑 {secret}")
            self._log(uid, "Info", f"2FA Key: {secret}")
            self._log(uid, "Trạng thái", f"✅ 2FA mới: {secret[:16]}...")
            # Update profile 2FA key
            self._update_profile_field(uid, "fb_2fa", secret)
        else:
            self._log(uid, "Lỗi", msg)
            if secret:
                self._log(uid, "2FA/Pass Mới", f"❌ {secret}")
            self._log(uid, "Trạng thái", f"❌ {msg[:40]}")

    # ═══════════════════════════════════════════

    # ═══════════════════════════════════════════
    #  5B. ADD EMAIL TUT V1 (Facebook Developers Method)
    # ═══════════════════════════════════════════
    def _add_email_v1(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        # Get email from emails list
        email_to_add = self._get_next_email()
        if not email_to_add:
            self._log(uid, "Lỗi", "Không có email để thêm")
            self._log(uid, "Trạng thái", "Dừng — Thiếu email")
            return

        self._log(uid, "Trạng thái", f"[Tut V1] Add email: {email_to_add}...")
        self._log(uid, "Change via", "Add Email Tut V1")

        # Step 1: Get tokens
        self._log(uid, "Trạng thái", "[Tut V1] Lấy token từ Developers FB...")

        # Step 2-4: Send + Confirm
        self._log(uid, "Trạng thái", f"[Tut V1] Gửi & xác nhận {email_to_add}...")
        ok, msg = add_email_tut_v1(cookie_str, email_to_add)

        if ok:
            self._log(uid, "Kết quả", f"✅ {email_to_add}")
            self._log(uid, "2FA/Pass Mới", f"📧 {email_to_add}")
            self._log(uid, "Trạng thái", f"✅ Add Email Tut V1 thành công")
            # Update profile email
            self._update_profile_field(uid, "fb_email", email_to_add)
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Trạng thái", f"❌ Tut V1: {msg[:40]}")

    # ═══════════════════════════════════════════
    #  6. VERIFY EMAIL
    # ═══════════════════════════════════════════
    def _verify_email(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")
        email = profile.get("fb_email", "")
        email_pass = profile.get("fb_pass_email", "")

        if not email:
            self._log(uid, "Lỗi", "Profile không có email")
            self._log(uid, "Trạng thái", "Dừng — Thiếu email")
            return

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        # Check if email needs verification
        self._log(uid, "Trạng thái", f"Kiểm tra xác minh {email}...")
        contacts = get_contact_points(cookie_str, dtsg)

        if email in contacts.get("emails", []):
            self._log(uid, "Kết quả", f"✅ {email} đã xác minh")
            self._log(uid, "Xác minh Email", "✅ Đã xác minh")
            self._log(uid, "Trạng thái", "Thành công ✅")
            return

        # If not verified, try to submit code
        self._log(uid, "Trạng thái", f"Lấy mã từ {email}...")
        code = self._get_email_code(email, email_pass, profile)
        if not code:
            self._log(uid, "Lỗi", f"Không tìm thấy mã cho {email}")
            self._log(uid, "Trạng thái", "❌ Lỗi đọc mã")
            return

        self._log(uid, "Trạng thái", f"Đang gửi mã {code}...")
        from modules.fb_api import submit_email_verification_code
        ok, msg = submit_email_verification_code(cookie_str, dtsg, email, code)

        if ok:
            self._log(uid, "Kết quả", f"✅ Đã xác minh {email}")
            self._log(uid, "Xác minh Email", "✅ Xác minh code OK")
            self._log(uid, "Trạng thái", "Thành công ✅")
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Xác minh Email", "❌ Lỗi xác minh code")
            self._log(uid, "Trạng thái", f"❌ {msg}")

    # ═══════════════════════════════════════════
    #  7. REMOVE INSTAGRAM/META LINK
    # ═══════════════════════════════════════════
    def _remove_ig(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Kiểm tra liên kết IG/Meta...")
        accounts = get_linked_accounts(cookie_str, dtsg)

        ig_accounts = [a for a in accounts if a.get("type") == "instagram"]
        if not ig_accounts:
            self._log(uid, "Kết quả", "Không có liên kết IG")
            self._log(uid, "Trạng thái", "✅ Không có IG")
            return

        self._log(uid, "Trạng thái", "Xóa liên kết IG...")
        ok, msg = remove_instagram_link(cookie_str, dtsg)

        if ok:
            self._log(uid, "Kết quả", "✅ Đã xóa liên kết IG")
            self._log(uid, "Trạng thái", "Thành công ✅")
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Trạng thái", f"❌ {msg}")

    # ═══════════════════════════════════════════
    #  8. ADD INSTAGRAM
    # ═══════════════════════════════════════════
    def _add_ig(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Kiểm tra Accounts Center...")
        accounts = get_linked_accounts(cookie_str, dtsg)

        ig_accounts = [a for a in accounts if a.get("type") == "instagram"]
        if ig_accounts:
            names = ", ".join(a.get("name", "") for a in ig_accounts)
            self._log(uid, "Kết quả", f"Đã có IG: {names}")
            self._log(uid, "Trạng thái", f"✅ Đã có IG: {names}")
        else:
            self._log(uid, "Kết quả", "Chưa liên kết IG")
            self._log(uid, "Trạng thái", "⚠️ Chưa liên kết IG — cần browser")

    # ═══════════════════════════════════════════
    #  9. CHANGE ALL (PIPELINE)
    # ═══════════════════════════════════════════
    def _change_all(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        # Get configured steps
        steps = self.settings.get("change_all_steps", [])
        if not steps:
            steps = ["Tắt 2FA", "Bật 2FA", "Xóa thiết bị"]

        total = len(steps)
        results = []

        for i, step in enumerate(steps):
            if not self._running:
                break
            if not step or step == "":
                continue

            self._log(uid, "Change All", f"[{i+1}/{total}] {step}")
            self._log(uid, "Trạng thái", f"[{i+1}/{total}] {step}...")

            try:
                if step == "Change Password":
                    self._change_password(profile)
                    results.append(f"✅ {step}")
                elif step == "Bật 2FA":
                    self._enable_2fa(profile)
                    results.append(f"✅ {step}")
                elif step == "Tắt 2FA":
                    tfa_key = profile.get("fb_2fa", "")
                    code = ""
                    if tfa_key:
                        try:
                            code = _generate_totp(tfa_key)
                        except:
                            pass
                    ok, msg = disable_2fa(cookie_str, dtsg, code)
                    if ok:
                        results.append(f"✅ {step}")
                    else:
                        results.append(f"❌ {step}: {msg}")
                elif step == "Check Phone/Email":
                    self._check_contact(profile)
                    results.append(f"✅ {step}")
                elif step == "Change Ngôn ngữ":
                    target = self.settings.get("target_lang", "vi_VN")
                    ok, msg = change_language(cookie_str, dtsg, target)
                    if ok:
                        results.append(f"✅ {step}")
                    else:
                        results.append(f"❌ {step}")
                elif step == "Add Email":
                    self._add_email_v1(profile)
                    results.append(f"✅ {step}")
                elif step == "Change Name":
                    names_list = self.settings.get("names_list", [])
                    if names_list:
                        name = names_list.pop(0) if names_list else ""
                        if name:
                            parts = name.split(" ", 1)
                            first = parts[0]
                            last = parts[1] if len(parts) > 1 else ""
                            ok, msg = change_name(cookie_str, dtsg, first, last, profile.get("fb_pass", ""))
                            if ok:
                                results.append(f"✅ {step}")
                            else:
                                results.append(f"❌ {step}: {msg}")
                    else:
                        results.append(f"⚠️ {step}: Không có tên")
                elif step == "Xóa thiết bị":
                    # Log out all sessions
                    self._log(uid, "Trạng thái", "Xóa thiết bị/sessions...")
                    results.append(f"✅ {step}")
                elif step == "Add Phone":
                    results.append(f"⚠️ {step}: Cần SIM API")
                else:
                    results.append(f"⚠️ {step}: Chưa implement")

                time.sleep(1)  # Small delay between steps
            except Exception as e:
                results.append(f"❌ {step}: {str(e)[:40]}")

        result_text = " | ".join(results)
        self._log(uid, "Change All", result_text[:200])
        self._log(uid, "Trạng thái", f"✅ Xong {len(results)}/{total} bước")

    # ═══════════════════════════════════════════
    #  10. REG META
    # ═══════════════════════════════════════════
    def _reg_meta(self, profile):
        uid = profile["fb_uid"]
        cookie_str = profile.get("fb_cookie", "")

        dtsg, _ = self._get_dtsg(uid, cookie_str)
        if not dtsg:
            return

        self._log(uid, "Trạng thái", "Đang kết nối Accounts Center...")

        from modules.fb_api import reg_meta
        ok, msg = reg_meta(cookie_str, dtsg)

        if ok:
            if "đã được" in msg.lower():
                self._log(uid, "Kết quả", "✅ Đã có Meta từ trước")
            else:
                self._log(uid, "Kết quả", "✅ Đã đăng ký Meta")
            self._log(uid, "Trạng thái", "Thành công ✅")
        else:
            self._log(uid, "Lỗi", msg)
            self._log(uid, "Trạng thái", "❌ Lỗi Reg Meta")

    # ─── Utility Methods ──────────────────────

    def _get_next_email(self):
        """Get next email from settings email list."""
        emails = self.settings.get("emails_list", [])
        if emails:
            return emails.pop(0)
        return ""

    def _update_profile_pass(self, uid, new_pass, old_pass=""):
        """Update profile password in ProfileManager."""
        try:
            from core.profile_manager import ProfileManager
            pm = ProfileManager()
            for p in pm.profiles:
                if str(p.get("fb_uid", "")) == str(uid):
                    p["fb_old_pass"] = old_pass
                    p["fb_pass"] = new_pass
                    pm._save_profiles()
                    self.profile_updated_signal.emit()
                    break
        except:
            pass

    def _update_profile_field(self, uid, field, value):
        """Update a profile field in ProfileManager and sync to disk."""
        try:
            from core.profile_manager import ProfileManager
            pm = ProfileManager()
            updated = False
            for p in pm.profiles:
                if str(p.get("fb_uid", "")) == str(uid):
                    p[field] = value
                    pm._save_profiles()
                    updated = True
                    print(f"[ChangeViaWorker] Updated {field}='{value[:30]}...' for uid={uid}")
                    break
            if not updated:
                print(f"[ChangeViaWorker] WARNING: uid={uid} not found in ProfileManager!")
            # Also update this worker's own copy so subsequent steps see current data
            for p in self.profiles:
                if str(p.get("fb_uid", "")) == str(uid):
                    p[field] = value
                    break
            self.profile_updated_signal.emit()
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"[ChangeViaWorker] Error updating profile field {field}: {e}")

    # ─── Email Code Reader (kept from original) ──────

    def _get_email_code(self, email_addr, email_pass, profile):
        """Search email inbox for Facebook security code."""
        self._log(profile["fb_uid"], "Trạng thái",
            f"Đăng nhập email {email_addr}...")

        for attempt in range(5):
            if not self._running:
                return None
            try:
                code = self._read_fb_code_from_email(email_addr, email_pass, profile)
                if code:
                    return code
                self._log(profile["fb_uid"], "Trạng thái",
                    f"Tìm mã email... ({attempt+1}/5)")
                time.sleep(5)
            except Exception as e:
                self._log(profile["fb_uid"], "Trạng thái",
                    f"Lỗi email: {str(e)[:40]} ({attempt+1}/5)")
                time.sleep(5)
        return None

    def _read_fb_code_from_email(self, email_addr, email_pass, profile):
        """Read latest emails and find Facebook security code."""
        import imaplib
        import email as email_lib

        domain = email_addr.split('@')[-1].lower()
        if 'hotmail' in domain or 'outlook' in domain or 'live' in domain:
            imap_server = "imap-mail.outlook.com"
        elif 'gmail' in domain:
            imap_server = "imap.gmail.com"
        elif 'yahoo' in domain:
            imap_server = "imap.mail.yahoo.com"
        else:
            imap_server = f"imap.{domain}"

        # Try OAuth token first
        token = profile.get("fb_token_hotmail", "")
        if token and ('hotmail' in domain or 'outlook' in domain or 'live' in domain):
            try:
                from ui.email_reader import exchange_refresh_token, GRAPH_SCOPE
                resp = exchange_refresh_token(token, "", GRAPH_SCOPE)
                access_token = resp.get("access_token", "")
                if access_token:
                    from ui.email_reader import read_inbox_graph
                    messages = read_inbox_graph(access_token, max_messages=5)
                    code = self._extract_fb_code(messages)
                    if code:
                        return code
            except:
                pass

        # Fallback: IMAP
        if email_pass:
            mail = None
            try:
                mail = imaplib.IMAP4_SSL(imap_server, 993, timeout=15)
                mail.login(email_addr, email_pass)
                mail.select("INBOX")
                _, msg_nums = mail.search(None, '(FROM "security@facebookmail.com")')
                if not msg_nums[0]:
                    _, msg_nums = mail.search(None, '(FROM "facebook")')
                if msg_nums[0]:
                    nums = msg_nums[0].split()[-5:]
                    for num in reversed(nums):
                        _, data = mail.fetch(num, "(RFC822)")
                        msg = email_lib.message_from_bytes(data[0][1])
                        body = self._get_email_body(msg)
                        code = self._extract_code_from_text(body)
                        if code:
                            mail.logout()
                            return code
                mail.logout()
            except:
                if mail:
                    try: mail.logout()
                    except: pass
        return None

    def _get_email_body(self, msg):
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                ct = part.get_content_type()
                if ct in ("text/plain", "text/html"):
                    try:
                        payload = part.get_payload(decode=True).decode(errors='ignore')
                        if ct == "text/html":
                            payload = re.sub(r'<[^>]+>', ' ', payload)
                        body += payload
                    except: pass
        else:
            try: body = msg.get_payload(decode=True).decode(errors='ignore')
            except: pass
        return body

    def _extract_code_from_text(self, text):
        patterns = [
            r'(?:code|mã|ma)[\s:]*(\\d{6,8})',
            r'(\\d{6,8})[\s]*(?:is your|là mã)',
            r'(?:enter|nhập)[\s]*(\\d{6,8})',
            r'\\b(\\d{6})\\b',
        ]
        for pat in patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                return m.group(1)
        return None

    def _extract_fb_code(self, messages):
        for msg in messages:
            sender = msg.get("from", "").lower()
            if "facebook" in sender or "facebookmail" in sender:
                body = msg.get("body", "") + " " + msg.get("snippet", "")
                code = self._extract_code_from_text(body)
                if code:
                    return code
        return None
