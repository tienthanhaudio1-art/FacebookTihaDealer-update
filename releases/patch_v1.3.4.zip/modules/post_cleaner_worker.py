"""
Post Cleaner Worker v8 — Facebook Activity Log scanner.

Uses Facebook's built-in date filter AND direct checkbox counting.
Handles: Vietnamese, English, and other locale date headers.

SCAN:  Navigate to activity log with date filter → scroll → count visible checkboxes.
DELETE: Select checkboxes → click Trash action → confirm.
"""
import re
import time
import os
from datetime import datetime, date, timedelta
from PyQt6.QtCore import QThread, pyqtSignal


class PostCleanerWorker(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    post_found = pyqtSignal(dict)
    scan_complete = pyqtSignal(int)
    delete_complete = pyqtSignal(int, int)
    error_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()

    # Activity log URL with date filter placeholders
    ACTIVITY_URL = (
        "https://www.facebook.com/{uid}/allactivity"
        "?activity_history=false"
        "&category_key=MANAGEPOSTSPHOTOSANDVIDEOS"
        "&manage_mode=true"
        "&should_load_landing_page=false"
    )

    def __init__(self, cookie_str, uid, start_date, end_date, mode="scan",
                 posts_to_delete=None):
        super().__init__()
        self.cookie_str = cookie_str
        self.uid = uid
        self.start_date = start_date
        self.end_date = end_date
        self.mode = mode
        self.posts_to_delete = posts_to_delete or []
        self._running = True
        self.found_posts = []

    def stop(self):
        self._running = False

    def run(self):
        try:
            from playwright.sync_api import sync_playwright
            from core.browser_manager import setup_playwright
            setup_playwright()

            with sync_playwright() as p:
                temp = os.path.join(
                    os.environ.get("TEMP", "C:\\temp"),
                    "PostCleaner", str(self.uid)
                )
                os.makedirs(temp, exist_ok=True)

                from core.browser_manager import get_browser_window_params
                wp = get_browser_window_params(0)

                ctx = p.chromium.launch_persistent_context(
                    user_data_dir=temp, headless=True,
                    args=["--disable-blink-features=AutomationControlled",
                          "--no-sandbox"],
                    viewport={"width": wp["win_w"], "height": wp["win_h"]},
                    locale="vi-VN"
                )
                page = ctx.pages[0] if ctx.pages else ctx.new_page()

                self.log_signal.emit("🔑 Đăng nhập...")
                cks = []
                for part in self.cookie_str.split(';'):
                    if '=' in part:
                        k, v = part.strip().split('=', 1)
                        cks.append({"name": k, "value": v,
                                    "domain": ".facebook.com", "path": "/"})
                if cks:
                    ctx.add_cookies(cks)

                url = self.ACTIVITY_URL.format(uid=self.uid)
                self.log_signal.emit("🌐 Mở Nhật ký hoạt động...")
                page.goto(url, wait_until="domcontentloaded", timeout=30000)
                time.sleep(4)

                if "login" in page.url.lower() or "checkpoint" in page.url.lower():
                    self.error_signal.emit("Cookie hết hạn hoặc checkpoint!")
                    ctx.close()
                    return

                self.log_signal.emit("✅ Đã mở Nhật ký hoạt động!")

                if self.mode == "scan":
                    self._scan(page)
                elif self.mode == "delete":
                    self._delete(page)

                ctx.close()

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.error_signal.emit(f"Lỗi: {str(e)[:200]}")
        finally:
            self.finished_signal.emit()

    # ═══════════════════════════════════════════
    #  SCAN — Scroll-based, uses real date headers only
    # ═══════════════════════════════════════════
    def _scan(self, page):
        self.log_signal.emit(f"🔍 Quét UID {self.uid}")
        self.log_signal.emit(
            f"📅 Từ {self.start_date.strftime('%d/%m/%Y')} → "
            f"{self.end_date.strftime('%d/%m/%Y')}"
        )

        total_found = 0
        scroll_count = 0
        prev_cb_count = 0
        all_date_sections = {}
        # How many full "no-new" cycles (each cycle = scroll + try Xem thêm)
        empty_cycles = 0
        reached_target_date = False

        while self._running:
            scroll_count += 1

            # ── 1. Count checkboxes ──
            cb_count = self._count_post_checkboxes(page)
            new_cbs = cb_count - prev_cb_count

            if new_cbs > 0:
                prev_cb_count = cb_count
                empty_cycles = 0  # reset

                current_date = self._get_latest_date_in_range(
                    all_date_sections, self.start_date, self.end_date
                )
                if current_date is None:
                    current_date = self.end_date

                for i in range(new_cbs):
                    idx = total_found + i
                    post_data = {
                        "id": f"post_{self.uid}_{idx}",
                        "date": current_date,
                        "text": f"Bài #{idx + 1}",
                    }
                    self.found_posts.append(post_data)
                    self.post_found.emit(post_data)

                total_found += new_cbs
                if total_found % 100 < 25 or total_found <= 50:
                    self.log_signal.emit(
                        f"  ✅ +{new_cbs} bài (tổng: {total_found})"
                    )
            else:
                empty_cycles += 1

            # ── 2. Check date headers every 3 scrolls ──
            if scroll_count % 3 == 1:
                date_headers = self._get_real_date_headers(page)
                for ht, hd in date_headers:
                    if ht not in all_date_sections:
                        all_date_sections[ht] = hd
                        self.log_signal.emit(
                            f"  📅 {ht} ({hd.strftime('%d/%m/%Y')})"
                        )

                # Check if we've scrolled PAST the target start_date
                for _, hd in date_headers:
                    if hd < self.start_date:
                        reached_target_date = True
                        break

            # ── 3. Stopping logic ──
            if reached_target_date:
                self.log_signal.emit(
                    "📌 Đã qua mốc ngày bắt đầu → dừng quét."
                )
                break

            # Only stop if truly no more content after 7 full cycles
            if empty_cycles >= 7:
                # Last resort: try clicking "Xem thêm"
                if self._click_show_more(page):
                    empty_cycles = 0
                    time.sleep(2)
                    continue
                else:
                    self.log_signal.emit(
                        "📌 Không còn bài viết mới (7 lần liên tiếp)."
                    )
                    break

            # Try "Xem thêm" earlier too
            if empty_cycles >= 2:
                if self._click_show_more(page):
                    empty_cycles = 0
                    time.sleep(1.5)
                    continue

            # ── 4. Scroll ──
            page.evaluate(
                "window.scrollTo(0, document.body.scrollHeight)"
            )
            time.sleep(0.6)

            if scroll_count % 20 == 0:
                self.log_signal.emit(
                    f"📄 Cuộn {scroll_count}x → {total_found} bài"
                )

        # Done
        self.log_signal.emit(f"\n{'=' * 40}")
        self.log_signal.emit(f"📊 KẾT QUẢ: {total_found} bài viết")
        self.log_signal.emit(f"{'=' * 40}")
        self.scan_complete.emit(total_found)

    def _get_real_date_headers(self, page):
        """Find ONLY real date section headers (not post descriptions).

        Real date headers are standalone short text elements like:
          "14 Tháng 3, 2026"  (Vietnamese)
          "March 14, 2026"     (English)
          "14 mars 2026"       (French)
          "2026年3月14日"       (Japanese/Chinese)

        Uses JavaScript to find short standalone text nodes that look like dates.
        """
        entries = []
        try:
            raw = page.evaluate(r"""() => {
                const results = [];
                // Find all text elements that could be date headers
                const candidates = document.querySelectorAll('span, div, h3, h4');
                for (const el of candidates) {
                    const text = (el.innerText || '').trim();
                    // Date headers are SHORT (< 35 chars) standalone text
                    if (text.length < 5 || text.length > 35) continue;
                    // Must contain a 4-digit year
                    if (!/\d{4}/.test(text)) continue;
                    // Must NOT contain typical post description words
                    if (/đã thêm|đã đăng|đã chia sẻ|added|posted|shared|lúc|at /i.test(text)) continue;
                    // Check if element has reasonable bounding box
                    const rect = el.getBoundingClientRect();
                    if (rect.height <= 0 || rect.width < 50) continue;
                    // Check it's a leaf-ish element (not a huge container)
                    if (el.children.length > 3) continue;
                    // Check approximate text === innerText (not a big container)
                    const directText = el.textContent.trim();
                    if (directText.length > 40) continue;

                    results.push({
                        text: text,
                        y: rect.y,
                        height: rect.height
                    });
                }
                // Dedupe by text
                const seen = new Set();
                return results.filter(r => {
                    if (seen.has(r.text)) return false;
                    seen.add(r.text);
                    return true;
                });
            }""")

            for item in raw:
                d = self._parse_date_header(item["text"])
                if d:
                    entries.append((item["text"], d))
        except Exception:
            pass
        return entries

    def _count_post_checkboxes(self, page):
        """Count visible post checkboxes using aria-checked attribute.

        Counts all input[type=checkbox] with aria-checked attribute,
        minus 1 for the 'Tất cả' (Select All) checkbox.
        """
        try:
            count = page.evaluate(r"""() => {
                const cbs = document.querySelectorAll(
                    'input[type="checkbox"][aria-checked]');
                let total = 0;
                for (const cb of cbs) {
                    const rect = cb.getBoundingClientRect();
                    if (rect.height <= 0) continue;
                    total++;
                }
                // First checkbox is always "Select All" — subtract it
                return Math.max(0, total - 1);
            }""")
            return count
        except Exception:
            return 0

    def _get_latest_date_in_range(self, date_sections, start_d, end_d):
        """Get the most recent date header that falls within the date range."""
        best = None
        for _, d in date_sections.items():
            if start_d <= d <= end_d:
                if best is None or d > best:
                    best = d
        return best

    def _click_show_more(self, page):
        """Click 'Xem thêm' / 'See more' / 'Show more' button."""
        try:
            clicked = page.evaluate(r"""() => {
                const keywords = ['xem thêm', 'see more', 'show more',
                                  'もっと見る', 'voir plus'];
                // Try role=button and regular buttons
                const btns = document.querySelectorAll(
                    'div[role="button"], a[role="link"], button, a, span');
                for (const btn of btns) {
                    const t = (btn.innerText || '').trim().toLowerCase();
                    const rect = btn.getBoundingClientRect();
                    if (rect.height <= 0 || rect.width <= 0) continue;
                    if (keywords.some(kw => t === kw || t.includes(kw))) {
                        btn.click();
                        return true;
                    }
                }
                return false;
            }""")
            if clicked:
                self.log_signal.emit("  🔘 Click 'Xem thêm'")
                time.sleep(2)
                return True
        except Exception:
            pass
        return False

    def _parse_date_header(self, text):
        """Parse date from header text — supports multiple formats.

        Supports:
          - Vietnamese: "14 Tháng 3, 2026" / "14 tháng 3, 2026"
          - English: "March 14, 2026" / "14 March, 2026"
          - Short VN: "14 Thg 3, 2026"
          - Numeric: "14/03/2026"
        """
        text = text.strip()

        # Vietnamese: "14 Tháng 3, 2026" or "14 tháng 3, 2026"
        m = re.match(
            r'(\d{1,2})\s+[Tt](?:háng|hg)\s+(\d{1,2}),?\s+(\d{4})', text
        )
        if m:
            try:
                return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            except ValueError:
                pass

        # English: "March 14, 2026"
        EN_MONTHS = {
            'january': 1, 'february': 2, 'march': 3, 'april': 4,
            'may': 5, 'june': 6, 'july': 7, 'august': 8,
            'september': 9, 'october': 10, 'november': 11, 'december': 12
        }
        m = re.match(
            r'([A-Za-z]+)\s+(\d{1,2}),?\s+(\d{4})', text
        )
        if m:
            month_name = m.group(1).lower()
            if month_name in EN_MONTHS:
                try:
                    return date(int(m.group(3)), EN_MONTHS[month_name], int(m.group(2)))
                except ValueError:
                    pass

        # English reverse: "14 March, 2026"
        m = re.match(
            r'(\d{1,2})\s+([A-Za-z]+),?\s+(\d{4})', text
        )
        if m:
            month_name = m.group(2).lower()
            if month_name in EN_MONTHS:
                try:
                    return date(int(m.group(3)), EN_MONTHS[month_name], int(m.group(1)))
                except ValueError:
                    pass

        return None

    # ═══════════════════════════════════════════
    #  DELETE — Batch 250, retry until done
    # ═══════════════════════════════════════════
    def _delete(self, page):
        total = len(self.posts_to_delete)
        if total == 0:
            self.delete_complete.emit(0, 0)
            return

        self.log_signal.emit(f"🗑️ Xóa {total} bài (max 250/lượt)...")

        deleted_total = 0
        batch_num = 0
        max_retries = 5  # retry per batch
        errors = 0

        while self._running and deleted_total < total:
            batch_num += 1
            remaining = total - deleted_total
            batch_size = min(remaining, 250)

            self.log_signal.emit(
                f"\n── Lượt {batch_num}: xóa {batch_size} bài "
                f"(đã xóa: {deleted_total}/{total}) ──"
            )

            # Reload activity log page for fresh state
            if batch_num > 1:
                url = self.ACTIVITY_URL.format(uid=self.uid)
                self.log_signal.emit("  🔄 Tải lại trang...")
                page.goto(url, wait_until="domcontentloaded", timeout=30000)
                time.sleep(4)

            # Try to delete this batch (with retries)
            batch_deleted = 0
            for retry in range(max_retries):
                if not self._running:
                    break

                if retry > 0:
                    self.log_signal.emit(
                        f"  🔁 Thử lại lần {retry + 1}/{max_retries}..."
                    )
                    # Reload page
                    url = self.ACTIVITY_URL.format(uid=self.uid)
                    page.goto(url, wait_until="domcontentloaded", timeout=30000)
                    time.sleep(4)

                # Step A: Select checkboxes
                selected = self._select_checkboxes(page, batch_size)
                if selected == 0:
                    self.log_signal.emit("  ⚠️ Không chọn được bài nào")
                    if retry < max_retries - 1:
                        time.sleep(2)
                        continue
                    else:
                        errors += batch_size
                        break

                self.log_signal.emit(f"  ☑ Đã chọn {selected} bài")

                # Step B: Click delete action
                ok = self._click_trash_action(page, selected)
                if ok:
                    batch_deleted = selected
                    self.log_signal.emit(
                        f"  ✅ Đã xóa {batch_deleted} bài!"
                    )
                    time.sleep(2)
                    break
                else:
                    self.log_signal.emit("  ❌ Xóa thất bại")
                    if retry < max_retries - 1:
                        time.sleep(2)

            if batch_deleted > 0:
                deleted_total += batch_deleted
            elif not self._running:
                break
            else:
                # All retries failed for this batch
                errors += batch_size
                self.log_signal.emit(
                    f"  ❌ Bỏ qua lượt {batch_num} sau {max_retries} lần thử"
                )

            self.progress_signal.emit(
                min(95, deleted_total * 100 // max(total, 1))
            )

        self.log_signal.emit(f"\n{'=' * 40}")
        self.log_signal.emit(
            f"📊 XÓA: {deleted_total}/{total}"
            + (f", lỗi: {errors}" if errors else "")
        )
        self.log_signal.emit(f"{'=' * 40}")
        self.delete_complete.emit(deleted_total, errors)

    def _select_checkboxes(self, page, count):
        """Select up to `count` post checkboxes. Returns actual selected."""
        # Scroll to top first
        page.evaluate("window.scrollTo(0, 0)")
        time.sleep(1)

        # If count covers all visible, try Select All first
        if count >= 200:
            try:
                sa_clicked = page.evaluate(r"""() => {
                    const cbs = document.querySelectorAll(
                        'input[type="checkbox"][aria-checked]');
                    for (const cb of cbs) {
                        const rect = cb.getBoundingClientRect();
                        if (rect.height <= 0) continue;
                        // First visible checkbox = Select All
                        const p = cb.closest('[role="row"]') ||
                                  cb.parentElement?.parentElement;
                        const txt = (p?.innerText || '').toLowerCase();
                        if (txt.includes('tất cả') || txt.includes('select all')
                            || txt.includes('すべて')) {
                            cb.click();
                            return true;
                        }
                        // Fallback: click first checkbox anyway
                        cb.click();
                        return true;
                    }
                    return false;
                }""")
                if sa_clicked:
                    time.sleep(1)
                    # Verify how many got selected
                    checked = page.evaluate(r"""() => {
                        const cbs = document.querySelectorAll(
                            'input[type="checkbox"][aria-checked="true"]');
                        let t = 0;
                        for (const cb of cbs) {
                            if (cb.getBoundingClientRect().height > 0) t++;
                        }
                        return Math.max(0, t - 1);
                    }""")
                    if checked > 0:
                        self.log_signal.emit(
                            f"  ☑ Select All → {checked} bài"
                        )
                        return min(checked, count)
            except Exception:
                pass

        # Manual selection: scroll and click individual checkboxes
        selected = 0
        scroll_count = 0
        seen_y = set()

        while self._running and selected < count and scroll_count < 200:
            scroll_count += 1

            checked_now = page.evaluate(r"""(maxSelect) => {
                const cbs = document.querySelectorAll(
                    'input[type="checkbox"][aria-checked="false"]');
                let clicked = 0;
                let firstSkipped = false;
                for (const cb of cbs) {
                    if (clicked >= maxSelect) break;
                    const rect = cb.getBoundingClientRect();
                    if (rect.height <= 0) continue;
                    // Skip first unchecked (might be Select All)
                    if (!firstSkipped && rect.y < 200) {
                        firstSkipped = true;
                        continue;
                    }
                    cb.click();
                    clicked++;
                }
                return clicked;
            }""", min(count - selected, 25))

            if checked_now > 0:
                selected += checked_now

            if selected >= count:
                break

            page.evaluate("window.scrollBy(0, 800)")
            time.sleep(0.5)

            if scroll_count % 10 == 0:
                self.log_signal.emit(f"    ☑ Chọn {selected}/{count}...")

        return selected

    def _click_trash_action(self, page, expected):
        """Click trash/archive action button. Returns True if succeeded."""
        page.evaluate("window.scrollTo(0, 0)")
        time.sleep(0.5)

        # Try multiple button labels
        trash_labels = [
            "Bỏ đi", "Thùng rác", "Trash", "Delete", "Xóa",
            "ゴミ箱", "削除",
        ]
        archive_labels = [
            "Lưu trữ", "Archive", "アーカイブ",
        ]

        for labels, icon in [(trash_labels, "🗑️"), (archive_labels, "📦")]:
            for label in labels:
                try:
                    btn = page.get_by_text(label, exact=True)
                    if btn.count() > 0 and btn.first.is_visible():
                        btn.first.click()
                        time.sleep(1.5)
                        self.log_signal.emit(f"  {icon} Nhấn '{label}'")
                        self._confirm_dialog(page)
                        time.sleep(1)
                        return True
                except Exception:
                    continue

        # Fallback: use JS to find buttons
        clicked = page.evaluate(r"""() => {
            const keywords = [
                'bỏ đi', 'thùng rác', 'trash', 'delete', 'xóa',
                'lưu trữ', 'archive', 'ゴミ箱', '削除'
            ];
            const btns = document.querySelectorAll(
                'div[role="button"], button, a[role="button"]');
            for (const btn of btns) {
                const text = (btn.innerText || '').trim().toLowerCase();
                const rect = btn.getBoundingClientRect();
                if (rect.height > 0 && rect.y < 200 &&
                    keywords.some(k => text.includes(k))) {
                    btn.click();
                    return text.substring(0, 30);
                }
            }
            return null;
        }""")

        if clicked:
            self.log_signal.emit(f"  🗑️ Nhấn '{clicked}'")
            time.sleep(1.5)
            self._confirm_dialog(page)
            time.sleep(1)
            return True

        self.log_signal.emit("  ❌ Không tìm thấy nút xóa!")
        return False

    def _confirm_dialog(self, page):
        """Confirm any popup dialog after clicking delete."""
        time.sleep(1)
        for attempt in range(3):
            try:
                confirmed = page.evaluate(r"""() => {
                    const keywords = [
                        'bỏ đi', 'trash', 'delete', 'xóa',
                        'lưu trữ', 'archive', 'ok', 'xác nhận',
                        'confirm', 'chuyển', 'move', 'yes',
                        '削除', 'ゴミ箱', '確認',
                    ];
                    const dialog = document.querySelector('div[role="dialog"]');
                    if (!dialog) return null;
                    const btns = dialog.querySelectorAll('button, div[role="button"]');
                    for (const btn of btns) {
                        const text = (btn.innerText || '').trim().toLowerCase();
                        const rect = btn.getBoundingClientRect();
                        if (rect.height > 0 &&
                            keywords.some(k => text.includes(k))) {
                            btn.click();
                            return text.substring(0, 30);
                        }
                    }
                    return null;
                }""")
                if confirmed:
                    self.log_signal.emit(f"  ✅ Xác nhận: '{confirmed}'")
                    return
            except Exception:
                pass
            time.sleep(1)

