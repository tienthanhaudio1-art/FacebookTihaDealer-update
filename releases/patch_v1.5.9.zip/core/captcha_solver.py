"""
Global CAPTCHA Solver Module — reCAPTCHA v2/Enterprise + FunCaptcha (Facebook).

Providers: 2Captcha (v2 JSON API), OmoCaptcha, Anti-Captcha, CapSolver, CapMonster
Settings:  data/settings.json -> two_captcha_key, omocaptcha_key,
           captcha_provider, captcha_timeout, captcha_retries

Speed optimizations:
  - Parallel racing: sends to ALL configured providers, returns first result
  - FunCaptcha (FB): OmoCaptcha FuncaptchaImageTask ($0.00027/solve, ~1s)
  - Skip checkbox click on Google pages (always fails)
  - Cached settings to avoid re-reading JSON every call
  - 2s polling interval for maximum speed

Usage from ANY login thread:
    from core.captcha_solver import handle_captcha_on_page, handle_fb_funcaptcha_on_page
    solved = handle_captcha_on_page(page, status_callback=lambda msg: ...)
    solved = handle_fb_funcaptcha_on_page(page, status_callback=lambda msg: ...)
"""
import time
import urllib.request
import urllib.parse
import json
import re
import os
import base64
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed


# ════════════════════════════════════════
#  Universal JSON API helper
# ════════════════════════════════════════

def _post_json(url, data, timeout=30):
    """POST JSON request and return parsed response dict."""
    payload = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type": "application/json", "Accept": "application/json"}
    )
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode("utf-8"))


# ════════════════════════════════════════
#  CaptchaSolver — Multi-Provider with Racing
# ════════════════════════════════════════

class CaptchaSolver:
    """Solve reCAPTCHA v2/Enterprise + FunCaptcha (Facebook) via paid API services."""

    def __init__(self, api_key="", provider="2captcha",
                 timeout=60, retries=2, omocaptcha_key=""):
        self.api_key = api_key.strip()
        self.provider = provider.lower().strip()
        self.timeout = min(timeout, 90)  # Cap at 90s max
        self.retries = retries
        self.omocaptcha_key = omocaptcha_key.strip()

    def is_configured(self):
        if self.provider == "omocaptcha":
            return bool(self.omocaptcha_key)
        return bool(self.api_key)

    def has_any_key(self):
        """Check if ANY provider key is available."""
        return bool(self.api_key) or bool(self.omocaptcha_key)

    def solve_recaptcha_v2(self, sitekey, page_url, is_enterprise=False, log=None):
        """Solve reCAPTCHA v2/Enterprise. Returns token string or ''.
        Uses parallel racing if multiple providers are configured."""
        if not self.has_any_key():
            return ""

        for attempt in range(self.retries):
            if attempt > 0 and log:
                log(f"[CAPTCHA] Retry {attempt + 1}/{self.retries}...")
                time.sleep(1)
            try:
                token = self._solve_racing(sitekey, page_url, is_enterprise, log)
                if token:
                    return token
            except Exception as e:
                if log:
                    log(f"[CAPTCHA] Error: {str(e)[:80]}")
        return ""

    def _solve_racing(self, sitekey, page_url, is_enterprise, log):
        """Send to ALL configured providers simultaneously, return first result."""
        providers = []

        # Build list of available providers
        if self.api_key:
            if self.provider in ("2captcha", ""):
                providers.append(("2Captcha", lambda: self._solve_2captcha_v2(sitekey, page_url, is_enterprise, log)))
            elif self.provider == "anti-captcha":
                providers.append(("Anti-Captcha", lambda: self._solve_generic_json(
                    "https://api.anti-captcha.com/createTask",
                    "https://api.anti-captcha.com/getTaskResult",
                    self.api_key, sitekey, page_url, is_enterprise, log,
                    enterprise_type="RecaptchaV2EnterpriseTaskProxyless",
                    standard_type="RecaptchaV2TaskProxyless"
                )))
            elif self.provider == "capsolver":
                providers.append(("CapSolver", lambda: self._solve_generic_json(
                    "https://api.capsolver.com/createTask",
                    "https://api.capsolver.com/getTaskResult",
                    self.api_key, sitekey, page_url, is_enterprise, log,
                    enterprise_type="ReCaptchaV2EnterpriseTaskProxyLess",
                    standard_type="ReCaptchaV2TaskProxyLess"
                )))
            elif self.provider == "capmonster":
                providers.append(("CapMonster", lambda: self._solve_generic_json(
                    "https://api.capmonster.cloud/createTask",
                    "https://api.capmonster.cloud/getTaskResult",
                    self.api_key, sitekey, page_url, is_enterprise, log,
                    enterprise_type="RecaptchaV2EnterpriseTaskProxyless",
                    standard_type="RecaptchaV2TaskProxyless"
                )))
            else:
                # Default to 2captcha format
                providers.append(("2Captcha", lambda: self._solve_2captcha_v2(sitekey, page_url, is_enterprise, log)))

        # Always add OmoCaptcha if key exists AND it's not the only provider
        if self.omocaptcha_key:
            providers.append(("OmoCaptcha", lambda: self._solve_omocaptcha(sitekey, page_url, log)))

        if not providers:
            return ""

        # Single provider — no threading overhead
        if len(providers) == 1:
            name, solver_fn = providers[0]
            if log:
                log(f"[CAPTCHA] Sending to {name}...")
            return solver_fn() or ""

        # Multiple providers — RACE them!
        if log:
            names = " + ".join(p[0] for p in providers)
            log(f"[CAPTCHA] 🏎️ Racing: {names}")

        result_token = ""
        stop_event = threading.Event()

        def _run_provider(name, fn):
            nonlocal result_token
            try:
                token = fn()
                if token and not stop_event.is_set():
                    result_token = token
                    stop_event.set()
                    if log:
                        log(f"[CAPTCHA] ✅ {name} won the race!")
            except Exception:
                pass

        threads = []
        for name, fn in providers:
            t = threading.Thread(target=_run_provider, args=(name, fn), daemon=True)
            threads.append(t)
            t.start()

        # Wait for first result or all threads to finish
        for t in threads:
            t.join(timeout=self.timeout + 5)
            if stop_event.is_set():
                break

        return result_token

    # ─────────────────────────────────────
    #  2Captcha — New v2 JSON API
    #  Docs: https://2captcha.com/api-docs
    # ─────────────────────────────────────
    def _solve_2captcha_v2(self, sitekey, page_url, is_enterprise, log):
        """Use 2Captcha v2 JSON API (api.2captcha.com)."""
        task_type = "RecaptchaV2EnterpriseTaskProxyless" if is_enterprise else "RecaptchaV2TaskProxyless"

        if log:
            log(f"[2Captcha] createTask ({task_type})...")

        # Step 1: createTask
        resp = _post_json("https://api.2captcha.com/createTask", {
            "clientKey": self.api_key,
            "task": {
                "type": task_type,
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        })

        if resp.get("errorId", 1) != 0:
            if log:
                log(f"[2Captcha] Error: {resp.get('errorCode', 'unknown')}")
            return ""

        task_id = resp.get("taskId")
        if not task_id:
            return ""

        if log:
            log(f"[2Captcha] taskId={task_id}, polling...")

        # Step 2: getTaskResult (poll every 2s)
        return self._poll_task_result(
            "https://api.2captcha.com/getTaskResult",
            self.api_key, task_id, log, label="2Captcha"
        )

    # ──────────────────────────────────────
    #  OmoCaptcha API
    #  Docs: https://docs.omocaptcha.com
    # ──────────────────────────────────────
    def _solve_omocaptcha(self, sitekey, page_url, log):
        """Use OmoCaptcha API (api.omocaptcha.com)."""
        if log:
            log("[OmoCaptcha] createTask...")

        # Step 1: createTask
        resp = _post_json("https://api.omocaptcha.com/v2/createTask", {
            "clientKey": self.omocaptcha_key,
            "task": {
                "type": "RecaptchaV2TokenTask",
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        })

        if resp.get("errorId", 1) != 0:
            if log:
                log(f"[OmoCaptcha] Error: {resp.get('errorCode', 'unknown')}")
            return ""

        task_id = resp.get("taskId")
        if not task_id:
            return ""

        if log:
            log(f"[OmoCaptcha] taskId={task_id}, polling...")

        # Step 2: getTaskResult (poll every 2s)
        return self._poll_task_result(
            "https://api.omocaptcha.com/v2/getTaskResult",
            self.omocaptcha_key, task_id, log, label="OmoCaptcha"
        )

    # ──────────────────────────────────────
    #  OmoCaptcha FunCaptcha Image (Facebook)
    #  Docs: https://docs.omocaptcha.com/tai-lieu-api/funcaptcha
    # ──────────────────────────────────────
    def solve_funcaptcha_image(self, image_base64, question_text, log=None):
        """Solve Facebook FunCaptcha via OmoCaptcha FuncaptchaImageTask.
        Returns the index (int) of the correct image, or -1 on failure.
        The index is 1-based: to navigate to it, click right arrow (index-1) times."""
        if not self.omocaptcha_key:
            if log:
                log("[FunCaptcha] No OmoCaptcha key configured")
            return -1

        if log:
            log("[FunCaptcha] Sending image to OmoCaptcha...")

        try:
            # Step 1: createTask
            resp = _post_json("https://api.omocaptcha.com/v2/createTask", {
                "clientKey": self.omocaptcha_key,
                "task": {
                    "type": "FuncaptchaImageTask",
                    "imageBase64": image_base64,
                    "other": question_text,
                }
            })

            if resp.get("errorId", 1) != 0:
                if log:
                    log(f"[FunCaptcha] Error: {resp.get('errorCode', resp.get('errorDescription', 'unknown'))}")
                return -1

            task_id = resp.get("taskId")
            if not task_id:
                if log:
                    log("[FunCaptcha] No taskId returned")
                return -1

            if log:
                log(f"[FunCaptcha] taskId={task_id}, polling...")

            # Step 2: getTaskResult (poll every 2s, max 30s for image tasks)
            start = time.time()
            max_wait = min(self.timeout, 30)  # Image tasks are fast, cap at 30s
            while time.time() - start < max_wait:
                time.sleep(2)
                try:
                    result = _post_json("https://api.omocaptcha.com/v2/getTaskResult", {
                        "clientKey": self.omocaptcha_key,
                        "taskId": task_id
                    })
                except Exception:
                    continue

                status = result.get("status", "")
                if status == "ready":
                    solution = result.get("solution", {})
                    index = solution.get("index", -1)
                    elapsed = int(time.time() - start)
                    if log:
                        log(f"[FunCaptcha] ✅ Solved in {elapsed}s! Answer index={index}")
                    return int(index)
                elif status == "fail" or result.get("errorId", 0) != 0:
                    if log:
                        log(f"[FunCaptcha] Error: {result.get('errorCode', 'fail')}")
                    return -1
                # status == "processing" → continue

            if log:
                log(f"[FunCaptcha] Timeout ({max_wait}s)")
            return -1

        except Exception as e:
            if log:
                log(f"[FunCaptcha] Exception: {str(e)[:80]}")
            return -1

    # ──────────────────────────────────────
    #  OmoCaptcha RecaptchaV2ImageTask (Image Grid)
    #  For "Select all images with X" challenges
    #  Docs: https://docs.omocaptcha.com/tai-lieu-api/recaptcha/recaptchav2imagetask
    # ──────────────────────────────────────
    def solve_recaptcha_v2_image(self, image_base64, question_text, log=None):
        """Solve reCAPTCHA v2 image grid challenge.
        Sends the captcha image + question to OmoCaptcha RecaptchaV2ImageTask.
        Returns list of cell indices (1-based) to click, or [] on failure.
        Image MUST be resized to standard size (100x100, 300x300, or 450x450)."""
        if not self.omocaptcha_key:
            if log:
                log("[OmoCaptcha-Grid] No key")
            return []

        if log:
            log(f"[OmoCaptcha-Grid] question='{question_text}'")

        try:
            resp = _post_json("https://api.omocaptcha.com/v2/createTask", {
                "clientKey": self.omocaptcha_key,
                "task": {
                    "type": "RecaptchaV2ImageTask",
                    "imageBase64": image_base64,
                    "question": question_text,
                }
            })

            if resp.get("errorId", 1) != 0:
                if log:
                    log(f"[OmoCaptcha-Grid] Error: {resp.get('errorCode', resp.get('errorDescription', 'unknown'))}")
                return []

            task_id = resp.get("taskId")
            if not task_id:
                return []

            start = time.time()
            while time.time() - start < 30:
                time.sleep(2)
                try:
                    result = _post_json("https://api.omocaptcha.com/v2/getTaskResult", {
                        "clientKey": self.omocaptcha_key, "taskId": task_id
                    })
                except:
                    continue
                if result.get("status") == "ready":
                    objects = result.get("solution", {}).get("objects", [])
                    if log:
                        log(f"[OmoCaptcha-Grid] ✅ {int(time.time()-start)}s → {objects}")
                    return objects
                elif result.get("status") == "fail" or result.get("errorId", 0) != 0:
                    if log:
                        log(f"[OmoCaptcha-Grid] Error: {result.get('errorCode', 'fail')}")
                    return []
            return []
        except Exception as e:
            if log:
                log(f"[OmoCaptcha-Grid] {str(e)[:80]}")
            return []

    # ──────────────────────────────────────
    #  2Captcha GridTask (Image Grid)
    #  For "Select all images with X" challenges
    #  Docs: https://2captcha.com/api-docs/grid
    # ──────────────────────────────────────
    def solve_grid_2captcha(self, image_base64, comment, rows=3, columns=3, log=None):
        """Solve image grid via 2Captcha GridTask.
        Returns list of cell indices (1-based) to click, or [] on failure."""
        if not self.api_key:
            if log:
                log("[2Captcha-Grid] No key")
            return []

        if log:
            log(f"[2Captcha-Grid] comment='{comment}' {rows}x{columns}")

        try:
            resp = _post_json("https://api.2captcha.com/createTask", {
                "clientKey": self.api_key,
                "task": {
                    "type": "GridTask",
                    "body": image_base64,
                    "comment": comment,
                    "rows": rows,
                    "columns": columns,
                }
            })

            if resp.get("errorId", 1) != 0:
                if log:
                    log(f"[2Captcha-Grid] Error: {resp.get('errorCode', 'unknown')}")
                return []

            task_id = resp.get("taskId")
            if not task_id:
                return []

            start = time.time()
            while time.time() - start < 60:
                time.sleep(3)
                try:
                    result = _post_json("https://api.2captcha.com/getTaskResult", {
                        "clientKey": self.api_key, "taskId": task_id
                    })
                except:
                    continue
                if result.get("status") == "ready":
                    cells = result.get("solution", {}).get("click", [])
                    if log:
                        log(f"[2Captcha-Grid] ✅ {int(time.time()-start)}s → {cells}")
                    return cells
                elif result.get("errorId", 0) != 0:
                    if log:
                        log(f"[2Captcha-Grid] Error: {result.get('errorCode', 'fail')}")
                    return []
            return []
        except Exception as e:
            if log:
                log(f"[2Captcha-Grid] {str(e)[:80]}")
            return []

    # ──────────────────────────────────────
    #  Generic JSON API (Anti-Captcha, CapSolver, CapMonster)
    # ──────────────────────────────────────
    def _solve_generic_json(self, create_url, result_url, api_key,
                            sitekey, page_url, is_enterprise, log,
                            enterprise_type, standard_type):
        task_type = enterprise_type if is_enterprise else standard_type
        label = create_url.split("//")[1].split(".")[1] if "//" in create_url else "API"
        if log:
            log(f"[{label}] createTask ({task_type})...")

        resp = _post_json(create_url, {
            "clientKey": api_key,
            "task": {
                "type": task_type,
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
        })

        if resp.get("errorId", 1) != 0:
            if log:
                log(f"[{label}] Error: {resp.get('errorCode', 'unknown')}")
            return ""

        task_id = resp.get("taskId")
        if not task_id:
            return ""

        if log:
            log(f"[{label}] taskId={task_id}, polling...")

        return self._poll_task_result(result_url, api_key, task_id, log, label=label)

    # ──────────────────────────────────────
    #  Unified poll (works for all providers)
    # ──────────────────────────────────────
    def _poll_task_result(self, url, api_key, task_id, log, label="API"):
        """Poll getTaskResult endpoint. Returns token or ''."""
        start = time.time()
        while time.time() - start < self.timeout:
            time.sleep(2)  # 2s poll for maximum speed
            try:
                resp = _post_json(url, {
                    "clientKey": api_key,
                    "taskId": task_id
                })
            except Exception:
                continue

            status = resp.get("status", "")
            if status == "ready":
                token = resp.get("solution", {}).get("gRecaptchaResponse", "")
                if token and log:
                    elapsed = int(time.time() - start)
                    log(f"[{label}] ✅ Solved in {elapsed}s!")
                return token
            elif status == "fail" or resp.get("errorId", 0) != 0:
                if log:
                    log(f"[{label}] Error: {resp.get('errorCode', 'fail')}")
                return ""
            # else status == "processing" → continue polling

        if log:
            log(f"[{label}] Timeout ({self.timeout}s)")
        return ""


# ════════════════════════════════════════
#  Page Helpers — Extract / Detect / Inject
# ════════════════════════════════════════

def extract_recaptcha_sitekey(page):
    """Extract reCAPTCHA v2 sitekey from page."""
    try:
        for frame in page.frames:
            url = frame.url or ""
            m = re.search(r'[?&]k=([A-Za-z0-9_-]+)', url)
            if m:
                return m.group(1)
        try:
            el = page.locator('[data-sitekey]')
            if el.count() > 0:
                return el.first.get_attribute('data-sitekey') or ""
        except:
            pass
        html = page.content()
        m = re.search(r'data-sitekey=["\']([A-Za-z0-9_-]+)["\']', html)
        if m:
            return m.group(1)
        m = re.search(r'render=([A-Za-z0-9_-]{20,})', html)
        if m:
            return m.group(1)
    except:
        pass
    return ""


def is_enterprise_recaptcha(page):
    """Detect if page uses reCAPTCHA Enterprise."""
    try:
        for frame in page.frames:
            if "/recaptcha/enterprise/" in (frame.url or ""):
                return True
        if "/recaptcha/enterprise/" in page.content():
            return True
    except:
        pass
    return False


def inject_recaptcha_token(page, token):
    """Inject reCAPTCHA token — TrustedHTML-safe, multi-frame, callback search."""
    injected = False

    # TrustedHTML-safe JS — NO innerHTML, only .value and .textContent
    inject_js = """(token) => {
        var found = false;
        // 1. Set textarea values (NO innerHTML — blocked by TrustedHTML policy)
        var textareas = document.querySelectorAll('textarea[name="g-recaptcha-response"]');
        for (var i = 0; i < textareas.length; i++) {
            textareas[i].value = token;
            try { textareas[i].textContent = token; } catch(e) {}
            textareas[i].style.display = 'block';
            found = true;
        }
        var el = document.getElementById('g-recaptcha-response');
        if (el) { el.value = token; found = true; }
        // 2. Find and call the reCAPTCHA callback
        if (typeof ___grecaptcha_cfg !== 'undefined') {
            try {
                var clients = ___grecaptcha_cfg.clients;
                for (var ck in clients) {
                    var client = clients[ck];
                    function searchCb(obj, depth) {
                        if (depth > 4 || !obj || typeof obj !== 'object') return false;
                        if (obj instanceof HTMLElement || obj instanceof Node || obj instanceof Window) return false;
                        if (typeof obj.callback === 'function') {
                            try { obj.callback(token); return true; } catch(e) {}
                        }
                        for (var key in obj) {
                            if (key === 'window' || key === 'document') continue;
                            var val = obj[key];
                            if (!val || typeof val !== 'object') continue;
                            if (val instanceof HTMLElement || val instanceof Node || val instanceof Window) continue;
                            if (searchCb(val, depth + 1)) return true;
                        }
                        return false;
                    }
                    if (searchCb(client, 0)) { found = true; break; }
                }
            } catch(e) {}
        }
        // 3. Try grecaptcha.enterprise.execute()
        if (typeof grecaptcha !== 'undefined') {
            try {
                if (grecaptcha.enterprise && grecaptcha.enterprise.execute) {
                    grecaptcha.enterprise.execute();
                    found = true;
                }
            } catch(e) {}
        }
        return found;
    }"""

    # Run injection on main page
    try:
        if page.evaluate(inject_js, token):
            injected = True
    except:
        pass

    # Also try in reCAPTCHA frames
    try:
        for frame in page.frames:
            furl = frame.url or ""
            if "recaptcha" in furl and "bframe" not in furl:
                try:
                    frame.evaluate(inject_js, token)
                    injected = True
                except:
                    pass
    except:
        pass

    # Set anchor checkbox as checked
    try:
        for frame in page.frames:
            furl = frame.url or ""
            if "recaptcha" in furl and "anchor" in furl:
                try:
                    frame.evaluate("""() => {
                        var anchor = document.getElementById('recaptcha-anchor');
                        if (anchor) {
                            anchor.setAttribute('aria-checked', 'true');
                            anchor.classList.add('recaptcha-checkbox-checked');
                        }
                    }""")
                except:
                    pass
    except:
        pass

    return injected


def detect_recaptcha_page(page):
    """Check if current page has a reCAPTCHA challenge."""
    try:
        url = page.url or ""
        if "challenge/recaptcha" in url:
            return True
        try:
            body_text = page.inner_text("body", timeout=3000)[:2000].lower()
        except:
            body_text = ""
        keywords = [
            "i'm not a robot", "confirm you're not a robot",
            "verify it's you", "not a robot", "recaptcha",
            "xac minh", "robot",
        ]
        if any(kw in body_text for kw in keywords):
            return True
        for frame in page.frames:
            if "recaptcha" in (frame.url or ""):
                return True
    except:
        pass
    return False


# ════════════════════════════════════════
#  Settings Loader (with cache)
# ════════════════════════════════════════

_cached_solver = None
_cached_solver_mtime = 0

def get_captcha_solver_from_settings():
    """Create CaptchaSolver from data/settings.json.
    Caches the solver and only reloads when file changes."""
    global _cached_solver, _cached_solver_mtime
    try:
        settings_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "data", "settings.json"
        )
        mtime = os.path.getmtime(settings_path)
        if _cached_solver and mtime == _cached_solver_mtime:
            return _cached_solver

        with open(settings_path, "r", encoding="utf-8") as f:
            s = json.load(f)
        solver = CaptchaSolver(
            api_key=s.get("two_captcha_key", ""),
            provider=s.get("captcha_provider", "2captcha"),
            timeout=min(int(s.get("captcha_timeout", 60)), 90),
            retries=int(s.get("captcha_retries", 2)),
            omocaptcha_key=s.get("omocaptcha_key", ""),
        )
        _cached_solver = solver
        _cached_solver_mtime = mtime
        return solver
    except Exception:
        return CaptchaSolver("")


# ════════════════════════════════════════
#  Global Handler — Call from ANY Login Thread
# ════════════════════════════════════════

def handle_captcha_on_page(page, status_callback=None, max_attempts=2, skip_submit=False):
    """
    Universal CAPTCHA handler -- call from any login thread.
    Returns True if CAPTCHA was detected, False if none found.

    Speed optimizations:
    - Skips checkbox click on Google pages (always fails, wastes 3s)
    - Uses parallel provider racing
    - Minimal sleep delays
    """
    def emit(msg):
        if status_callback:
            try:
                status_callback(msg)
            except:
                pass

    if not detect_recaptcha_page(page):
        return False

    emit("[CAPTCHA] Phát hiện reCAPTCHA — đang xử lý...")

    # Check if this is a Google page (checkbox click never works on Google)
    is_google = False
    try:
        url_lower = (page.url or "").lower()
        is_google = "google.com" in url_lower or "gstatic.com" in url_lower
    except:
        pass

    for attempt in range(max_attempts):
        if attempt > 0:
            emit(f"[CAPTCHA] Thử lại lần {attempt + 1}...")
            time.sleep(1)

        # Step 1: Try clicking checkbox (SKIP on Google — always fails)
        if not is_google:
            try:
                for frame in page.frames:
                    furl = frame.url or ""
                    if "recaptcha" in furl and "anchor" in furl:
                        cb = frame.locator('#recaptcha-anchor')
                        if cb.count() > 0:
                            cb.first.click()
                            time.sleep(2)
                            try:
                                if cb.first.get_attribute("aria-checked") == "true":
                                    emit("[OK] reCAPTCHA vượt qua (click)")
                                    if not skip_submit:
                                        _click_form_submit(page)
                                        time.sleep(2)
                                    return True
                            except:
                                pass
            except:
                pass

        # Step 2: Try IMAGE-BASED solving first (faster, $0.00027/solve, ~1s)
        # This handles "Select all images with X" challenges
        image_solved = _try_image_based_captcha(page, emit)
        if image_solved:
            emit("[OK] reCAPTCHA image grid bypassed ✅")
            if not skip_submit:
                _click_form_submit(page)
                time.sleep(2)
            return True

        # Step 3: Fallback to TOKEN-BASED solving (sitekey → token injection)
        solver = get_captcha_solver_from_settings()
        if not solver.has_any_key():
            emit("[!] Cần CAPTCHA API Key (Cài đặt -> Trình duyệt -> API Key)")
            return True

        sitekey = extract_recaptcha_sitekey(page)
        if not sitekey:
            emit("[X] Không tìm thấy sitekey reCAPTCHA")
            continue

        enterprise = is_enterprise_recaptcha(page)

        token = solver.solve_recaptcha_v2(sitekey, page.url, is_enterprise=enterprise, log=emit)
        if token:
            emit("[OK] CAPTCHA solved! Injecting token...")
            inject_recaptcha_token(page, token)
            time.sleep(1)
            if not skip_submit:
                _click_form_submit(page)
                time.sleep(3)
            else:
                emit("[OK] Skip submit (2FA mode — caller will handle)")

            if not detect_recaptcha_page(page):
                emit("[OK] reCAPTCHA bypassed ✅")
                return True
            else:
                emit("[!] CAPTCHA still present after inject, retrying...")
        else:
            emit(f"[X] CAPTCHA solving failed (attempt {attempt + 1})")

    return True


def _try_image_based_captcha(page, emit, _depth=0):
    """Solve reCAPTCHA image grid via DUAL RACING: 2Captcha GridTask + OmoCaptcha RecaptchaV2ImageTask.
    Handles 'Select all images with X' type challenges.
    Returns True if solved, False otherwise."""
    if _depth > 5:
        emit("[ImageGrid] Max rounds reached")
        return False

    solver = get_captcha_solver_from_settings()
    if not solver.omocaptcha_key and not solver.api_key:
        return False

    # Find the reCAPTCHA bframe (challenge frame)
    bframe = None
    for frame in page.frames:
        furl = (frame.url or "").lower()
        if "recaptcha" in furl and "bframe" in furl:
            bframe = frame
            break

    if not bframe:
        return False

    emit("[ImageGrid] Phát hiện reCAPTCHA image grid...")

    # Detect grid type: 3x3 or 4x4
    rows, cols = 3, 3
    try:
        if bframe.locator('table.rc-imageselect-table-44').count() > 0:
            rows, cols = 4, 4
        elif bframe.locator('table.rc-imageselect-table-42').count() > 0:
            rows, cols = 4, 2
        elif bframe.locator('table.rc-imageselect-table-33').count() > 0:
            rows, cols = 3, 3
        else:
            # Check if ANY table is visible
            table = bframe.locator('table[class*="rc-imageselect-table"]')
            if table.count() == 0 or not table.first.is_visible(timeout=2000):
                return False
    except:
        return False

    emit(f"[ImageGrid] Grid: {rows}x{cols}")

    # ─── Extract question text ───
    question = ""
    # Strategy 1: Get the bold keyword from within the description
    try:
        for sel in ['.rc-imageselect-desc strong', '.rc-imageselect-desc-no-canonical strong',
                    '.rc-imageselect-desc-wrapper strong', '.rc-imageselect-instructions strong']:
            try:
                el = bframe.locator(sel)
                if el.count() > 0:
                    question = el.first.inner_text(timeout=2000).strip()
                    if question:
                        break
            except:
                continue
    except:
        pass

    # Strategy 2: Full description text, extract keyword
    if not question:
        try:
            for sel in ['.rc-imageselect-desc', '.rc-imageselect-desc-no-canonical',
                        '.rc-imageselect-desc-wrapper']:
                try:
                    el = bframe.locator(sel)
                    if el.count() > 0:
                        full_text = el.first.inner_text(timeout=2000).strip()
                        if full_text:
                            # Try to extract just the keyword
                            import re as _re
                            m = _re.search(r'(?:with|of|containing|showing|a\s+)\s*(.+?)(?:\s*\.|$)',
                                          full_text, _re.IGNORECASE)
                            if m:
                                question = m.group(1).strip()
                            else:
                                question = full_text
                            break
                except:
                    continue
        except:
            pass

    # Strategy 3: Full body text scan
    if not question:
        try:
            body_text = bframe.inner_text("body", timeout=3000)[:500]
            for line in body_text.split('\n'):
                line = line.strip()
                if any(kw in line.lower() for kw in ['select', 'click', 'choose', 'pick', 'verify']):
                    question = line
                    break
        except:
            pass

    if not question:
        emit("[ImageGrid] Không trích được câu hỏi từ captcha")
        return False

    emit(f"[ImageGrid] Question: '{question}'")

    # ─── Screenshot the image TABLE ONLY (not container with text) ───
    screenshot_bytes = None
    try:
        # Priority: screenshot only the table element for clean image
        table_sel = f'table.rc-imageselect-table-{rows}{cols}'
        table_el = bframe.locator(table_sel)
        if table_el.count() > 0 and table_el.first.is_visible(timeout=2000):
            screenshot_bytes = table_el.first.screenshot(timeout=5000)
            emit(f"[ImageGrid] Captured table: {table_sel}")
    except:
        pass

    if not screenshot_bytes:
        try:
            # Fallback: any visible table
            table_el = bframe.locator('table[class*="rc-imageselect-table"]')
            if table_el.count() > 0:
                screenshot_bytes = table_el.first.screenshot(timeout=5000)
                emit("[ImageGrid] Captured table (fallback)")
        except:
            pass

    if not screenshot_bytes:
        try:
            # Last resort: challenge container
            container = bframe.locator('.rc-imageselect-target, .rc-imageselect-challenge')
            if container.count() > 0:
                screenshot_bytes = container.first.screenshot(timeout=5000)
        except:
            pass

    if not screenshot_bytes:
        emit("[ImageGrid] Không thể chụp ảnh grid")
        return False

    # ─── Resize to standard size for API ───
    target_size = (450, 450) if rows == 4 else (300, 300)
    try:
        from io import BytesIO
        from PIL import Image as PILImage
        img = PILImage.open(BytesIO(screenshot_bytes))
        img = img.resize(target_size, PILImage.LANCZOS)
        buf = BytesIO()
        img.save(buf, format='JPEG', quality=90)
        image_b64 = base64.b64encode(buf.getvalue()).decode('utf-8')
        emit(f"[ImageGrid] Image resized to {target_size[0]}x{target_size[1]}")
    except ImportError:
        emit("[ImageGrid] PIL unavailable, sending raw image")
        image_b64 = base64.b64encode(screenshot_bytes).decode('utf-8')
    except Exception as e:
        emit(f"[ImageGrid] Resize fallback: {str(e)[:40]}")
        image_b64 = base64.b64encode(screenshot_bytes).decode('utf-8')

    # ─── RACE both providers ───
    cells = []
    stop_event = threading.Event()

    # Build the full comment for 2Captcha (needs full instruction)
    full_comment = f"Select all images with {question}" if len(question.split()) < 5 else question

    def _solve_omo():
        nonlocal cells
        try:
            result = solver.solve_recaptcha_v2_image(image_b64, question, log=emit)
            if result and not stop_event.is_set():
                cells = result
                stop_event.set()
        except:
            pass

    def _solve_2cap():
        nonlocal cells
        try:
            result = solver.solve_grid_2captcha(image_b64, full_comment, rows=rows, columns=cols, log=emit)
            if result and not stop_event.is_set():
                cells = result
                stop_event.set()
        except:
            pass

    providers = []
    if solver.omocaptcha_key:
        providers.append(("OmoCaptcha", _solve_omo))
    if solver.api_key:
        providers.append(("2Captcha", _solve_2cap))

    if not providers:
        return False

    if len(providers) == 1:
        emit(f"[ImageGrid] Sending to {providers[0][0]}...")
        providers[0][1]()
    else:
        emit(f"[ImageGrid] 🏎️ Racing: {' + '.join(p[0] for p in providers)}")
        threads = []
        for name, fn in providers:
            t = threading.Thread(target=fn, daemon=True)
            threads.append(t)
            t.start()
        # Wait for first result or timeout
        for t in threads:
            t.join(timeout=65)
            if stop_event.is_set():
                break

    if not cells:
        emit("[ImageGrid] Không có kết quả từ API")
        return False

    # ─── Click the cells ───
    emit(f"[ImageGrid] Clicking cells: {cells}")
    try:
        tiles = bframe.locator('td.rc-imageselect-tile')
        total = tiles.count()
        for idx in cells:
            tile_pos = idx - 1  # 1-based → 0-based
            if 0 <= tile_pos < total:
                try:
                    tiles.nth(tile_pos).click()
                    time.sleep(0.3)
                except:
                    pass
    except Exception as e:
        emit(f"[ImageGrid] Click error: {str(e)[:50]}")
        return False

    # ─── Click VERIFY ───
    time.sleep(0.5)
    try:
        verify = bframe.locator('#recaptcha-verify-button')
        if verify.count() > 0 and verify.first.is_visible(timeout=2000):
            verify.first.click()
            emit("[ImageGrid] Đã click VERIFY ✅")
            time.sleep(3)
        else:
            for sel in ['button:has-text("Verify")', 'button:has-text("Xác minh")',
                        '#recaptcha-verify', 'button[id*="verify"]']:
                try:
                    btn = bframe.locator(sel)
                    if btn.count() > 0:
                        btn.first.click()
                        emit("[ImageGrid] Đã click VERIFY ✅")
                        time.sleep(3)
                        break
                except:
                    continue
    except:
        pass

    # ─── Check result ───
    try:
        if not detect_recaptcha_page(page):
            return True
        # Multi-round: new challenge appeared
        try:
            new_table = bframe.locator('table[class*="rc-imageselect-table"]')
            if new_table.count() > 0 and new_table.first.is_visible(timeout=1500):
                emit(f"[ImageGrid] Round {_depth+2}: new challenge...")
                time.sleep(1)
                return _try_image_based_captcha(page, emit, _depth=_depth+1)
        except:
            pass
    except:
        pass

    return False


def _click_form_submit(page):
    """Click Next/Verify/Submit button on current page."""
    for sel in [
        'button:has-text("Tiep theo")', 'button:has-text("Next")',
        'button:has-text("Verify")', 'button:has-text("Xac minh")',
        'button:has-text("Continue")', 'button:has-text("Sign in")',
        '#submit', 'button[type="submit"]', '#passwordNext',
        '#identifierNext', '#identifierNext button',
    ]:
        try:
            btn = page.locator(sel)
            if btn.count() > 0 and btn.first.is_visible(timeout=2000):
                btn.first.click()
                return True
        except:
            continue
    return False


# ════════════════════════════════════════
#  Facebook FunCaptcha (Image Selection)
# ════════════════════════════════════════

def detect_fb_funcaptcha(page):
    """Detect Facebook's FunCaptcha (image selection captcha with arrows).
    Returns True if FunCaptcha is visible on the page."""
    try:
        # Method 1: Check for FunCaptcha iframe
        for frame in page.frames:
            furl = (frame.url or "").lower()
            if "funcaptcha" in furl or "arkoselabs" in furl or "arkose" in furl:
                return True

        # Method 2: Check page content for FunCaptcha markers
        try:
            body = page.inner_text("body", timeout=3000)[:3000].lower()
        except:
            body = ""

        funcaptcha_keywords = [
            "pick the image", "select the image",
            "chọn ảnh", "chọn hình",
            "rotate the image", "xoay hình",
            "which image", "correct way up",
            "match the requested", "same as",
        ]
        if any(kw in body for kw in funcaptcha_keywords):
            return True

        # Method 3: Check for FB security check with image challenge
        html = ""
        try:
            html = page.content()[:5000].lower()
        except:
            pass
        if ("captcha" in html or "security_check" in html or "checkpoint" in html):
            # Look for image elements that indicate FunCaptcha
            try:
                imgs = page.locator('img[src*="captcha"], img[src*="image_raw"], #captcha_image, .captcha_img')
                if imgs.count() > 0:
                    return True
            except:
                pass

        # Method 4: FunCaptcha specific selectors
        try:
            fc_selectors = [
                '#fc-iframe-wrap',
                'iframe[src*="funcaptcha"]',
                'iframe[src*="arkoselabs"]',
                '.arkose-challenge',
                '#captcha_response_field',
            ]
            for sel in fc_selectors:
                try:
                    el = page.locator(sel)
                    if el.count() > 0 and el.first.is_visible(timeout=500):
                        return True
                except:
                    continue
        except:
            pass

    except:
        pass
    return False


def _extract_fb_captcha_image_and_question(page):
    """Extract the FunCaptcha image and question text from Facebook's captcha page.
    Returns (image_base64, question_text) or (None, None) on failure."""
    image_b64 = None
    question = ""

    # ── Strategy 1: FunCaptcha iframe (arkoselabs) ──
    for frame in page.frames:
        furl = (frame.url or "").lower()
        if "funcaptcha" in furl or "arkoselabs" in furl or "arkose" in furl:
            try:
                # Extract question text from the challenge
                question_el = frame.locator('h2, .challenge-text, [class*="instruction"], [class*="prompt"]')
                if question_el.count() > 0:
                    question = question_el.first.inner_text(timeout=2000)

                # Screenshot the captcha image area
                img_el = frame.locator('img.challenge-image, img[class*="captcha"], .challenge-container img, canvas')
                if img_el.count() > 0:
                    screenshot_bytes = img_el.first.screenshot(timeout=5000)
                    image_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")
                    return image_b64, question
            except:
                pass

    # ── Strategy 2: Direct FB captcha (image + buttons) ──
    try:
        # Try to find captcha image directly on page
        captcha_selectors = [
            'img[src*="captcha"]',
            'img[src*="image_raw"]',
            '#captcha_image',
            '.captcha_img',
            'img[alt*="captcha"]',
            'img[alt*="security"]',
        ]
        for sel in captcha_selectors:
            try:
                el = page.locator(sel)
                if el.count() > 0 and el.first.is_visible(timeout=1000):
                    screenshot_bytes = el.first.screenshot(timeout=5000)
                    image_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")
                    break
            except:
                continue
    except:
        pass

    # ── Strategy 3: Screenshot the entire captcha container ──
    if not image_b64:
        try:
            container_selectors = [
                '#captcha_challenge',
                '.captcha-container',
                '[class*="captcha"]',
                '#checkpoint_response',
            ]
            for sel in container_selectors:
                try:
                    el = page.locator(sel)
                    if el.count() > 0 and el.first.is_visible(timeout=1000):
                        screenshot_bytes = el.first.screenshot(timeout=5000)
                        image_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")
                        break
                except:
                    continue
        except:
            pass

    # ── Extract question text if not found yet ──
    if not question:
        try:
            body_text = page.inner_text("body", timeout=3000)[:2000]
            # Look for instruction/question patterns
            for line in body_text.split('\n'):
                line = line.strip()
                ll = line.lower()
                if any(kw in ll for kw in [
                    "pick", "select", "which", "choose", "rotate", "match",
                    "chọn", "xoay", "hãy",
                    "correct way", "same as", "arrows",
                ]):
                    question = line
                    break
        except:
            pass

    if not question:
        question = "Pick the correct image"

    return image_b64, question


def handle_fb_funcaptcha_on_page(page, status_callback=None, max_attempts=3):
    """Handle Facebook FunCaptcha (image selection captcha).
    Detects FunCaptcha, captures image, sends to OmoCaptcha, clicks answer.
    Returns True if FunCaptcha was detected (even if not solved)."""
    def emit(msg):
        if status_callback:
            try:
                status_callback(msg)
            except:
                pass

    if not detect_fb_funcaptcha(page):
        return False

    emit("[FunCaptcha] Phát hiện Facebook CAPTCHA — đang xử lý...")

    solver = get_captcha_solver_from_settings()
    if not solver.omocaptcha_key:
        emit("[FunCaptcha] Cần OmoCaptcha API Key để giải FunCaptcha")
        return True

    for attempt in range(max_attempts):
        if attempt > 0:
            emit(f"[FunCaptcha] Thử lại lần {attempt + 1}...")
            time.sleep(1)

        # Step 1: Extract captcha image and question
        emit("[FunCaptcha] Đang chụp captcha...")
        image_b64, question = _extract_fb_captcha_image_and_question(page)

        if not image_b64:
            emit("[FunCaptcha] Không thể chụp ảnh captcha")
            # Maybe it's in a frame — try full page screenshot
            try:
                screenshot_bytes = page.screenshot(timeout=5000)
                image_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")
                emit("[FunCaptcha] Dùng screenshot toàn trang")
            except:
                continue

        emit(f"[FunCaptcha] Question: {question[:60]}...")

        # Step 2: Send to OmoCaptcha
        answer_index = solver.solve_funcaptcha_image(image_b64, question, log=emit)

        if answer_index < 0:
            emit(f"[FunCaptcha] Không giải được (attempt {attempt + 1})")
            continue

        # Step 3: Navigate to the correct image
        # The API returns the position (1-based). Image starts at position 1.
        # Click right arrow (answer_index - 1) times to reach it.
        clicks_needed = answer_index - 1
        if clicks_needed < 0:
            clicks_needed = 0

        emit(f"[FunCaptcha] Index={answer_index}, clicking {clicks_needed} times...")

        # Find and click the right arrow button
        for _ in range(clicks_needed):
            try:
                # Try FunCaptcha arrow buttons
                arrow_selectors = [
                    'a.right-arrow', 'button.right-arrow',
                    '[aria-label="Next"]', '[aria-label="Tiep theo"]',
                    'a[class*="right"]', 'button[class*="right"]',
                    'a[class*="next"]', 'button[class*="next"]',
                    '.arrow-right', '#captcha_next',
                ]
                clicked = False
                for sel in arrow_selectors:
                    try:
                        btn = page.locator(sel)
                        if btn.count() > 0 and btn.first.is_visible(timeout=500):
                            btn.first.click()
                            clicked = True
                            time.sleep(0.3)
                            break
                    except:
                        continue

                # Also try in FunCaptcha iframe
                if not clicked:
                    for frame in page.frames:
                        furl = (frame.url or "").lower()
                        if "funcaptcha" in furl or "arkoselabs" in furl:
                            for sel in arrow_selectors:
                                try:
                                    btn = frame.locator(sel)
                                    if btn.count() > 0:
                                        btn.first.click()
                                        clicked = True
                                        time.sleep(0.3)
                                        break
                                except:
                                    continue
                            break
            except:
                pass

        # Step 4: Click VERIFY / Submit
        time.sleep(0.5)
        verify_clicked = False
        verify_texts = ["VERIFY", "Verify", "Submit", "Xác minh", "Gửi", "OK"]
        for txt in verify_texts:
            try:
                # Try on main page
                for sel in [f'button:has-text("{txt}")', f'a:has-text("{txt}")', f'[type="submit"]:has-text("{txt}")']:
                    btn = page.locator(sel)
                    if btn.count() > 0 and btn.first.is_visible(timeout=500):
                        btn.first.click()
                        verify_clicked = True
                        break
                if verify_clicked:
                    break
                # Try in FunCaptcha iframe
                for frame in page.frames:
                    furl = (frame.url or "").lower()
                    if "funcaptcha" in furl or "arkoselabs" in furl:
                        for sel in [f'button:has-text("{txt}")', f'a:has-text("{txt}")']:
                            try:
                                btn = frame.locator(sel)
                                if btn.count() > 0:
                                    btn.first.click()
                                    verify_clicked = True
                                    break
                            except:
                                continue
                        break
                if verify_clicked:
                    break
            except:
                continue

        if verify_clicked:
            emit("[FunCaptcha] Đã click VERIFY, đợi kết quả...")
        else:
            emit("[FunCaptcha] Không tìm nút Verify, thử Enter...")
            try:
                page.keyboard.press("Enter")
            except:
                pass

        time.sleep(3)

        # Check if captcha is still present
        if not detect_fb_funcaptcha(page):
            emit("[FunCaptcha] ✅ FunCaptcha bypassed!")
            return True
        else:
            emit(f"[FunCaptcha] CAPTCHA vẫn còn sau attempt {attempt + 1}")

    emit("[FunCaptcha] Hết lần thử")
    return True

